codeunit 60005 "FTT-CST Event Functions"
{
    Permissions = tabledata "Cust. Ledger Entry" = rm; //NRD

    procedure FillInContactExtraFieldsOnInsert(var Contact: Record Contact)
    var
        MarketingSetup: Record "Marketing Setup";
    begin
        MarketingSetup.Get();
        if MarketingSetup."FTT-CST Def. Mailing Group" <> '' then
            Contact."FTT-CST Notif. Mail Gr. Code" := MarketingSetup."FTT-CST Def. Mailing Group";
    end;

    procedure FillInCustomerExtraFieldsOnInsert(var Customer: Record Customer)
    var
        MarketingSetup: Record "Marketing Setup";
    begin
        MarketingSetup.Get();
        if MarketingSetup."FTT-CST Def. Mailing Group" <> '' then
            Customer."FTT-CST Notif. Mail Gr. Code" := MarketingSetup."FTT-CST Def. Mailing Group";
    end;

    procedure FillInDocAttmtExtraFieldsOnInsert(var DocumentAttachment: Record "Document Attachment")
    var
        MarketingSetup: Record "Marketing Setup";
    begin
        MarketingSetup.Get();
        if Format(MarketingSetup."FTT-CST Def. Attach. Not. Per.") <> '' then
            DocumentAttachment."FTT-CST Notification Period" := MarketingSetup."FTT-CST Def. Attach. Not. Per.";
    end;

    procedure CheckMSA(SalesHeader: Record "Sales Header")
    var
        DocumentAttachment: Record "Document Attachment";
        SalesReceivablesSetup: Record "Sales & Receivables Setup";
        ErrorContextElement: Codeunit "Error Context Element";
        ErrorMessageMgt: Codeunit "Error Message Management";
    begin
        SalesReceivablesSetup.Get();
        if not SalesReceivablesSetup."MSA Control in SO Posting" then
            exit;

        if SalesHeader."Invoice without MSA" then
            exit;

        if not SalesHeader.Invoice then
            exit;

        DocumentAttachment.SetRange("Table ID", SalesHeader.RecordId.TableNo);
        DocumentAttachment.SetRange("No.", SalesHeader."No.");
        DocumentAttachment.SetRange("Document Type", "Attachment Document Type"::Order);
        DocumentAttachment.SetRange("MSA Document", true);
        if not DocumentAttachment.IsEmpty() then
            exit;

        ErrorMessageMgt.PushContext(ErrorContextElement, SalesHeader.RecordId, 0, CheckMSAAdditionalErr);
        ErrorMessageMgt.LogContextFieldError(SalesHeader.FieldNo("Invoice without MSA"), CheckMSAErr, '', 0, '');
    end;

    procedure ModifyInvoiceWithoutMSA(var SalesHeader: Record "Sales Header")
    var
        SalesLine: Record "Sales Line";
        ShouldBeUpdated: Boolean;
    begin
        SalesLine.SetRange("Document Type", SalesHeader."Document Type");
        SalesLine.SetRange("Document No.", SalesHeader."No.");
        if not SalesLine.FindSet() then
            exit;

        repeat
            if SalesLine."Qty. to Invoice" + SalesLine."Quantity Invoiced" < SalesLine.Quantity then
                ShouldBeUpdated := true;
        until SalesLine.Next() = 0;

        if ShouldBeUpdated then
            SalesHeader."Invoice without MSA" := false;
    end;

    procedure CalcCommissionBaseAmount(var CustLedgerEntry: Record "Cust. Ledger Entry")
    begin
        if CustLedgerEntry."Salesperson Code" = '' then
            exit;

        if CustLedgerEntry."Document Type" = "Gen. Journal Document Type"::Invoice then
            CustLedgerEntry."FTT-CST Comm. Base Am. (LCY)" := CalcCommissionBaseAmountForInvoice(CustLedgerEntry);

        if CustLedgerEntry."Document Type" = "Gen. Journal Document Type"::"Credit Memo" then
            CustLedgerEntry."FTT-CST Comm. Base Am. (LCY)" := CalcCommissionBaseAmountForCrMemo2(CustLedgerEntry); //NRD
    end;


    local procedure CalcCommissionBaseAmountForInvoice(CustLedgerEntry: Record "Cust. Ledger Entry"): Decimal
    var
        FTTCSTSalespCommRate: Record "FTT-CST Salesp. Comm. Rate";
        Item: Record Item;
        SalesInvoiceHeader: Record "Sales Invoice Header";
        SalesInvoiceLine: Record "Sales Invoice Line";
        LineCommBaseLCY: Decimal;
        TotalLineCommBaseLCY: Decimal;
        ItemCommisionValue: Integer;
    begin
        if not SalesInvoiceHeader.Get(CustLedgerEntry."Document No.") then
            exit;

        SalesInvoiceLine.SetRange("Document No.", SalesInvoiceHeader."No.");
        SalesInvoiceLine.SetRange(Type, "Sales Line Type"::Item);
        if not SalesInvoiceLine.FindSet() then
            exit;

        repeat
            LineCommBaseLCY := 0;
            Item.Get(SalesInvoiceLine."No.");
            FTTCSTSalespCommRate.Reset();
            FTTCSTSalespCommRate.SetRange("Salesperson Code", CustLedgerEntry."Salesperson Code");
            FTTCSTSalespCommRate.SetRange("Item Category Code", SalesInvoiceLine."Item Category Code");
            FTTCSTSalespCommRate.SetRange("Agreement Period", SalesInvoiceHeader."FTT-CST Agr. Period Number");
            if FTTCSTSalespCommRate.FindSet() then begin
                ItemCommisionValue := GetPercentFromEnum(Item);
                if SalesInvoiceHeader."Currency Code" = '' then
                    LineCommBaseLCY := SalesInvoiceLine.Amount * (FTTCSTSalespCommRate."Commission Rate %" / 100) * (ItemCommisionValue / 100)
                else
                    LineCommBaseLCY := (SalesInvoiceLine.Amount * (FTTCSTSalespCommRate."Commission Rate %" / 100) * (ItemCommisionValue / 100)) / SalesInvoiceHeader."Currency Factor";

                TotalLineCommBaseLCY += LineCommBaseLCY;
            end;
        until SalesInvoiceLine.Next() = 0;

        exit(TotalLineCommBaseLCY);
    end;

    local procedure CalcCommissionBaseAmountForCrMemo2(CustLedgerEntry: Record "Cust. Ledger Entry"): Decimal
    var
        SalesCrMemoHeader: Record "Sales Cr.Memo Header";
        SalesCrMemoLine: Record "Sales Cr.Memo Line";
        LineCommBaseLCY: Decimal;
        TotalLineCommBaseLCY: Decimal;
    begin
        if not SalesCrMemoHeader.Get(CustLedgerEntry."Document No.") then
            exit;

        SalesCrMemoLine.SetRange("Document No.", SalesCrMemoHeader."No.");
        SalesCrMemoLine.SetRange(Type, "Sales Line Type"::Item);
        SalesCrMemoLine.SetRange("FTT-CST Eligible", true);
        if not SalesCrMemoLine.FindSet() then
            exit;
        repeat
            LineCommBaseLCY := LineCommBaseLCY + SalesCrMemoLine."Commission Base Amount (LCY)";
        until SalesCrMemoLine.next = 0;
        Commit();

        TotalLineCommBaseLCY := LineCommBaseLCY;

        exit(TotalLineCommBaseLCY);
    end;

    local procedure CalcCommissionBaseAmountForCrMemo(CustLedgerEntry: Record "Cust. Ledger Entry"): Decimal
    var
        FTTCSTSalespCommRate: Record "FTT-CST Salesp. Comm. Rate";
        Item: Record Item;
        SalesCrMemoHeader: Record "Sales Cr.Memo Header";
        SalesCrMemoLine: Record "Sales Cr.Memo Line";
        LineCommBaseLCY: Decimal;
        TotalLineCommBaseLCY: Decimal;
        ItemCommisionValue: Integer;
    begin
        if not SalesCrMemoHeader.Get(CustLedgerEntry."Document No.") then
            exit;

        SalesCrMemoLine.SetRange("Document No.", SalesCrMemoHeader."No.");
        SalesCrMemoLine.SetRange(Type, "Sales Line Type"::Item);
        if not SalesCrMemoLine.FindSet() then
            exit;

        repeat
            LineCommBaseLCY := 0;
            Item.Get(SalesCrMemoLine."No.");
            FTTCSTSalespCommRate.Reset();
            FTTCSTSalespCommRate.SetRange("Salesperson Code", CustLedgerEntry."Salesperson Code");
            FTTCSTSalespCommRate.SetRange("Item Category Code", SalesCrMemoLine."Item Category Code");
            FTTCSTSalespCommRate.SetRange("Agreement Period", SalesCrMemoHeader."FTT-CST Agr. Period Number");
            if FTTCSTSalespCommRate.FindSet() then begin
                ItemCommisionValue := GetPercentFromEnum(Item);
                if SalesCrMemoHeader."Currency Code" = '' then
                    LineCommBaseLCY := SalesCrMemoLine.Amount * (FTTCSTSalespCommRate."Commission Rate %" / 100) * (ItemCommisionValue / 100) * (-1)
                else
                    LineCommBaseLCY := (SalesCrMemoLine.Amount * (FTTCSTSalespCommRate."Commission Rate %" / 100) * (ItemCommisionValue / 100)) / SalesCrMemoHeader."Currency Factor" * (-1);

                TotalLineCommBaseLCY += LineCommBaseLCY;
            end;
        until SalesCrMemoLine.Next() = 0;

        exit(TotalLineCommBaseLCY);
    end;


    procedure InsertCommisionEntryForAppliedEntry(CustLedgerEntry: Record "Cust. Ledger Entry");
    var
        Team: Record Team;
        TeamSalesperson: Record "Team Salesperson";
    begin
        if not CheckCustomerLedgerEntryNo(CustLedgerEntry) then
            exit;

        if CustLedgerEntry.Open then
            exit;

        InsertCommisionEntryForSalesperson(CustLedgerEntry, true);

        TeamSalesperson.SetRange("Salesperson Code", CustLedgerEntry."Salesperson Code");
        if not TeamSalesperson.FindSet() then
            exit;

        repeat
            Team.Get(TeamSalesperson."Team Code");
            if Team."FTT-CST Supervisor Code" <> '' then
                InsertCommisionEntryForSupervisor(CustLedgerEntry, Team, true);
        until TeamSalesperson.Next() = 0;
    end;

    procedure InsertCommisionEntryForUnAppliedEntry(CustLedgerEntry: Record "Cust. Ledger Entry");
    var
        Team: Record Team;
        TeamSalesperson: Record "Team Salesperson";
    begin
        if not CheckCustomerLedgerEntryNo(CustLedgerEntry) then
            exit;

        if not CustLedgerEntry.Open then
            exit;

        if CustLedgerEntry."FTT-CST Temp Remaining Amount" <> 0 then
            exit;

        InsertCommisionEntryForSalesperson(CustLedgerEntry, false);

        TeamSalesperson.SetRange("Salesperson Code", CustLedgerEntry."Salesperson Code");
        if not TeamSalesperson.FindSet() then
            exit;

        repeat
            Team.Get(TeamSalesperson."Team Code");
            if Team."FTT-CST Supervisor Code" <> '' then
                InsertCommisionEntryForSupervisor(CustLedgerEntry, Team, false);
        until TeamSalesperson.Next() = 0;
    end;

    local procedure CheckCustomerLedgerEntryNo(CustLedgerEntry: Record "Cust. Ledger Entry"): Boolean
    begin
        if (CustLedgerEntry."Document Type" <> "Gen. Journal Document Type"::Invoice) and (CustLedgerEntry."Document Type" <> "Gen. Journal Document Type"::"Credit Memo") then
            exit(false);
        if CustLedgerEntry."Salesperson Code" = '' then
            exit(false);
        if CustLedgerEntry."FTT-CST Comm. Base Am. (LCY)" = 0 then begin
            CalcCommissionBaseAmount(CustLedgerEntry);
            if CustLedgerEntry."FTT-CST Comm. Base Am. (LCY)" = 0 then
                exit(false);
        end;

        exit(true);
    end;

    local procedure GetPostingDateFromDetailedCustLedgerEntry(EntryNo: Integer) PostingDate: Date
    var
        DetailedCustLedgEntry: Record "Detailed Cust. Ledg. Entry";
    begin
        PostingDate := 0D;
        DetailedCustLedgEntry.SetAscending("Entry No.", false);
        DetailedCustLedgEntry.SetRange("Entry Type", "Detailed CV Ledger Entry Type"::Application);
        DetailedCustLedgEntry.SetRange("Cust. Ledger Entry No.", EntryNo);
        if DetailedCustLedgEntry.FindSet() then
            PostingDate := DetailedCustLedgEntry."Posting Date";
    end;

    local procedure GetPercentFromEnum(Item: Record Item) Percent: Integer
    var
        Index: Integer;
        OrdinalValue: Integer;
        LevelName: Text;
    begin
        OrdinalValue := Item."FTT-CST Salesp. Comm. Type".AsInteger();
        Index := "FTT-CST SalespCommType".Ordinals().IndexOf(OrdinalValue);
        LevelName := "FTT-CST SalespCommType".Names().Get(Index);
        Evaluate(Percent, LevelName);
    end;

    procedure ModifyTempRemainingAmount(EntryNo: Integer)
    var
        CustLedgerEntry: Record "Cust. Ledger Entry";
    begin
        CustLedgerEntry.Get(EntryNo);
        CustLedgerEntry.CalcFields("Remaining Amt. (LCY)");
        CustLedgerEntry."FTT-CST Temp Remaining Amount" := CustLedgerEntry."Remaining Amt. (LCY)";
        CustLedgerEntry.Modify();
    end;

    local procedure InsertCommisionEntryForSupervisor(CustLedgerEntry: Record "Cust. Ledger Entry"; Team: Record Team; PositoveEntry: Boolean)
    var
        FTTCSTCommisionEntry: Record "FTT-CST Commision Entry";
    begin

        FTTCSTCommisionEntry.Init();
        FTTCSTCommisionEntry."Entry No." := 0;
        FTTCSTCommisionEntry."Salesperson Code" := CustLedgerEntry."Salesperson Code";
        FTTCSTCommisionEntry."Commission Beneficiary Code" := Team."FTT-CST Supervisor Code";

        if CustLedgerEntry."FTT-CST Comm. Base Am. (LCY)" = 0 then
            CalcCommissionBaseAmount(CustLedgerEntry); //NRD

        FTTCSTCommisionEntry."Commission Amount (LCY)" := CustLedgerEntry."FTT-CST Comm. Base Am. (LCY)" * Team."FTT-CST Supervisor Reward, %" / 100;
        if not PositoveEntry then
            FTTCSTCommisionEntry."Commission Amount (LCY)" := FTTCSTCommisionEntry."Commission Amount (LCY)" * -1;
        FTTCSTCommisionEntry."Cust. Ledger Entry No." := CustLedgerEntry."Entry No.";
        FTTCSTCommisionEntry.Insert();
    end;

    local procedure InsertCommisionEntryForSalesperson(CustLedgerEntry: Record "Cust. Ledger Entry"; PositoveEntry: Boolean)
    var
        FTTCSTCommisionEntry: Record "FTT-CST Commision Entry";
    begin

        FTTCSTCommisionEntry.Init();
        FTTCSTCommisionEntry."Entry No." := 0;
        FTTCSTCommisionEntry."Salesperson Code" := CustLedgerEntry."Salesperson Code";
        FTTCSTCommisionEntry."Commission Beneficiary Code" := CustLedgerEntry."Salesperson Code";

        if CustLedgerEntry."FTT-CST Comm. Base Am. (LCY)" = 0 then
            CalcCommissionBaseAmount(CustLedgerEntry); //NRD

        FTTCSTCommisionEntry."Commission Amount (LCY)" := CustLedgerEntry."FTT-CST Comm. Base Am. (LCY)";
        if not PositoveEntry then
            FTTCSTCommisionEntry."Commission Amount (LCY)" := FTTCSTCommisionEntry."Commission Amount (LCY)" * -1;
        FTTCSTCommisionEntry."Cust. Ledger Entry No." := CustLedgerEntry."Entry No.";
        FTTCSTCommisionEntry.Insert();
    end;

    procedure ModifyCreatedDateInCommisionEntry()
    var
        FTTCSTCommisionEntry: Record "FTT-CST Commision Entry";
    begin
        FTTCSTCommisionEntry.SetRange("Created Date", 0D);
        FTTCSTCommisionEntry.SetFilter("Cust. Ledger Entry No.", '<>%1', 0);
        if not FTTCSTCommisionEntry.FindSet(true) then
            exit;

        repeat
            FTTCSTCommisionEntry."Created Date" := GetPostingDateFromDetailedCustLedgerEntry(FTTCSTCommisionEntry."Cust. Ledger Entry No.");
            FTTCSTCommisionEntry.Modify();
        until FTTCSTCommisionEntry.Next() = 0;
    end;

    procedure ModifyCostType(SalesHeader: Record "Sales Header")
    var
        Item: Record Item;
        SalesLine: Record "Sales Line";
    begin
        SalesLine.SetRange("Document Type", SalesHeader."Document Type");
        SalesLine.SetRange("Document No.", SalesHeader."No.");
        if not SalesLine.FindSet() then
            exit;

        repeat
            if SalesLine.Type = "Sales Line Type"::Item then begin
                Item.Get(SalesLine."No.");
                SalesLine."FTT-CST Cost Type" := Item."FTT-CST Cost Type";
                SalesLine.Modify();
            end;
        until SalesLine.Next() = 0;
    end;

    var
        CheckMSAAdditionalErr: Label 'Enable the "MSA Document" checkbox for the attached document or the "MSA Attachment Control in Sales Order Posting" checkbox for the sales order or the "MSA Control in SO Posting" checkbox in the Sales & Receivables Setup';
        CheckMSAErr: Label 'Sales order cannot be posted without MSA. Attach the document and enable the "MSA Document" checkbox for it or enable the "Invoice without MSA" checkbox for the sales order.';

}

