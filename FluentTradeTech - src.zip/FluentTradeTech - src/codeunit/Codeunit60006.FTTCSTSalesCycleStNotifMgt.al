codeunit 60006 "FTT-CST Sal Cycle St Notif Mgt"
{
    procedure EmailSalesCycleStageNotification(var OpportunityEntry: Record "Opportunity Entry"): Boolean
    begin
        if SendEmailSalesCycleStageNotification(OpportunityEntry) then
            exit(true);
    end;

    local procedure SendEmailSalesCycleStageNotification(var OpportunityEntry: Record "Opportunity Entry"): Boolean
    var
        SendingEmailAccount: Record "Email Account";
        Email: Codeunit Email;
        EmailMessage: Codeunit "Email Message";
    begin
        SendingEmailAccount := GetEmailSenderAccount(); //damo

        if CreateEmailSalesCycleStageNotification(OpportunityEntry, EmailMessage) then
            if Email.Send(EmailMessage, SendingEmailAccount) then
                exit(true);
    end;

    local procedure CreateEmailSalesCycleStageNotification(var OpportunityEntry: Record "Opportunity Entry"; EmailMessage: Codeunit "Email Message"): Boolean
    var

        EmailBody: Text;
        EmailRecipients: Text;
        EmailSubject: Text;
    begin
        EmailRecipients := GetEmailRecipientsForSalesCycleStageNotification(OpportunityEntry);

        if EmailRecipients = '' then
            exit(false);

        EmailSubject := GenerateSalesCycleStageNotificationEmailSubject(OpportunityEntry);
        EmailBody := GenerateSalesCycleStageNotificationEmailBody(OpportunityEntry);

        EmailMessage.Create(EmailRecipients, EmailSubject, EmailBody, true);
        exit(true);
    end;

    local procedure GetEmailSenderAccount() SendingEmailAccount: Record "Email Account";
    var
        MarketingSetup: Record "Marketing Setup";
        EmailAccount: Codeunit "Email Account";
    begin
        MarketingSetup.Get();
        MarketingSetup.TestField("FTT-CST Sending E-mail Acc. Id");

        EmailAccount.GetAllAccounts(true, SendingEmailAccount);
        SendingEmailAccount.SetRange("Account Id", MarketingSetup."FTT-CST Sending E-mail Acc. Id");
        SendingEmailAccount.FindFirst();
    end;

    local procedure GetEmailRecipientsForSalesCycleStageNotification(var OpportunityEntry: Record "Opportunity Entry"): Text
    var
        Opportunity: Record Opportunity;
        EmailRecipients: Text;
    begin
        Opportunity.Get(OpportunityEntry."Opportunity No.");
        EmailRecipients += GetContactMailingGroupEmails(Opportunity."FTT-CST Notif. Mail. Gr. Code"); //Damo

        exit(EmailRecipients);
    end;

    local procedure GetContactMailingGroupEmails(MailingGroupCode: Code[10]): Text
    var
        Contact: Record Contact;
        ContactMailingGroup: Record "Contact Mailing Group";
        FoundEmails: Text;
    begin
        ContactMailingGroup.Reset();
        ContactMailingGroup.SetRange("Mailing Group Code", MailingGroupCode);
        ContactMailingGroup.SetLoadFields("Contact No.");
        if ContactMailingGroup.FindSet() then
            repeat
                if Contact.Get(ContactMailingGroup."Contact No.") then
                    if Contact."E-Mail" <> '' then
                        if FoundEmails = '' then
                            FoundEmails := Contact."E-Mail"
                        else
                            FoundEmails += ';' + Contact."E-Mail";
            until ContactMailingGroup.Next() = 0;
        exit(FoundEmails);
    end;

    local procedure GenerateSalesCycleStageNotificationEmailSubject(var OpportunityEntry: Record "Opportunity Entry"): Text
    var
        Opportunity: Record Opportunity;
        FixedSubjectTextLbl: Label 'New Sales Stage for Opportunity';
        SubjectMaskLbl: Label '%1 %2, %3, %4', Locked = true;
    begin
        IF Opportunity.Get(OpportunityEntry."Opportunity No.") then
            Opportunity.CalcFields("Contact Name");

        exit(StrSubstNo(SubjectMaskLbl, FixedSubjectTextLbl, Opportunity."No.", Opportunity."Contact Name", Opportunity.Description));
    end;

    local procedure GenerateSalesCycleStageNotificationEmailBody(var OpportunityEntry: Record "Opportunity Entry") BodyText: Text
    var
        Opportunity: Record Opportunity;
        EndLbl: Label 'Have a nice day.';
        //EntityMaskLbl: Label 'For Opportunity %1, %2 %3 was updated:';
        EntityMaskLbl: Label 'For Opportunity %1, %2 %3 %4';
        GreetingLbl: Label 'Dear colleagues,';
        NewStageLbl: Label '<b>New Stage:</b>';
        NewValueLabel: Label '%1: %2,';
        NoReplyLbl: Label 'It is an automatic e-mail and doesn’t require an answer.';
        OpportunityLinkLbl: Label '<a href="%1">Opportunity link</a>';
        EstimatedLCY, EstimatedLCY2 : Text[250];
        lCont: Record Contact;
        lGenLed: Record "General Ledger Setup";
    begin
        IF Opportunity.Get(OpportunityEntry."Opportunity No.") THEN
            Opportunity.CalcFields("Contact Name");
        lGenLed.GET();
        IF lCont.GET(Opportunity."Contact No.") then begin
            EstimatedLCY := lCont."Currency Code";
            IF EstimatedLCY = '' THEN
                EstimatedLCY2 := StrSubstNo('Estimated Value (%1)', lGenLed."LCY Code")
            ELSE
                EstimatedLCY2 := StrSubstNo('Estimated Value (%1)', EstimatedLCY);
        end;
        BodyText := GreetingLbl + NewLine() + NewLine();
        BodyText += StrSubstNo(EntityMaskLbl, OpportunityEntry."Opportunity No.", Opportunity."Contact Name", Opportunity.Description, OpportunityEntry.FieldCaption("Sales Cycle Stage")) + NewLine() + NewLine();
        //BodyText += StrSubstNo(EntityMaskLbl, OpportunityEntry."Opportunity No.", Opportunity."Contact Name", Opportunity.Description, OpportunityEntry.FieldCaption("Sales Cycle Stage")) + NewLine() + NewLine();
        BodyText += NewStageLbl + NewLine();
        BodyText += StrSubstNo(NewValueLabel, OpportunityEntry.FieldCaption("Action Taken"), OpportunityEntry."Action Taken") + NewLine();
        //BodyText += StrSubstNo(NewValueLabel, OpportunityEntry.FieldCaption("Sales Cycle Stage"), OpportunityEntry."Sales Cycle Stage") + NewLine();
        BodyText += StrSubstNo(NewValueLabel, OpportunityEntry.FieldCaption("Sales Cycle Stage Description"), OpportunityEntry."Sales Cycle Stage Description") + NewLine();
        BodyText += StrSubstNo(NewValueLabel, OpportunityEntry.FieldCaption("Date of Change"), OpportunityEntry."Date of Change") + NewLine();
        BodyText += StrSubstNo(NewValueLabel, OpportunityEntry.FieldCaption("Estimated Close Date"), OpportunityEntry."Estimated Close Date") + NewLine();
        BodyText += StrSubstNo(NewValueLabel, 'Currency', OpportunityEntry."Estimated Value - Currency") + NewLine();
        BodyText += StrSubstNo(NewValueLabel, 'Estimated Value', OpportunityEntry."Estimated Value (LCY)") + NewLine();
        //BodyText += StrSubstNo(NewValueLabel, OpportunityEntry.FieldCaption("Estimated Value (LCY)"), OpportunityEntry."Estimated Value (LCY)") + NewLine();
        //BodyText += StrSubstNo(NewValueLabel, OpportunityEntry.FieldCaption("Calcd. Current Value (LCY)"), OpportunityEntry."Calcd. Current Value (LCY)") + NewLine();
        //BodyText += StrSubstNo(NewValueLabel, OpportunityEntry.FieldCaption("Completed %"), OpportunityEntry."Completed %") + NewLine();
        //BodyText += StrSubstNo(NewValueLabel, OpportunityEntry.FieldCaption("Chances of Success %"), OpportunityEntry."Chances of Success %") + NewLine();
        BodyText += StrSubstNo(NewValueLabel, OpportunityEntry.FieldCaption("Probability %"), OpportunityEntry."Probability %") + NewLine();
        BodyText += StrSubstNo(OpportunityLinkLbl, GetUrl(ClientType::Current, CompanyName, ObjectType::Page, Page::"Opportunity Card", Opportunity, false)) + NewLine() + NewLine();
        BodyText += NoReplyLbl + NewLine() + EndLbl;
    end;

    local procedure NewLine(): Text
    var
    begin
        exit('<br>');
    end;
}