codeunit 50002 "GMAIL Auto API Trigger"
{
    TableNo = "Job Queue Entry";
    Permissions = tabledata "Job Queue Entry" = r,
                  tabledata "GMAIL Maintenance Setup" = rimd;
    trigger OnRun()
    var
        codGMAILInteg: Codeunit "Gmail Integration";
        UserSetupG: Record "GMAIL Maintenance Setup";
    begin
        rec."Parameter String" := UpperCase(rec."Parameter String");
        case rec."Parameter String" OF
            'SYNC-EMAILINBOUND':
                begin
                    IF NOT UserSetupG.Get() then
                        EXIT;

                    IF UserSetupG."Refresh Token" <> '' then begin
                        if (CurrentDateTime < UserSetupG."Token Expiration DateTime") then begin
                            codGMAILInteg.ShowGMAILList(UserSetupG."CRM Email", UserSetupG."API Token Key", 1, true);
                            Commit();
                        end;
                    end;


                end;
            'SYNC-EMAILOUTBOUND':
                begin
                    IF NOT UserSetupG.Get() then
                        EXIT;

                    IF UserSetupG."Refresh Token" <> '' then begin
                        if (CurrentDateTime < UserSetupG."Token Expiration DateTime") then begin
                            codGMAILInteg.ShowGMAILList(UserSetupG."CRM Email", UserSetupG."API Token Key", 2, true);
                            Commit();
                        end;
                    end;
                end;
            'SYNC-TOKEN':
                UserAllRefreshToken;
        end;

        //UserAllRefreshToken();
    end;

    procedure UserAllRefreshToken()
    var

        URL3: Text;
        GMAILMgtSetup: Record "GMAIL Maintenance Setup";
        myHttpContent: HttpContent;
        myHttpHeaders: HttpHeaders;
        request: HttpRequestMessage;
        MyHttpClient: HttpClient;
        MyHttpResponseMessage: HttpResponseMessage;
        myToken: Text;
        myContentHeaders: HttpHeaders;
        Jtoken: JsonToken;
        isSuccess: Boolean;
        Response: HttpResponseMessage;
        URL2: Text;
        Token: Text;
        JO: JsonObject;
        JT: JsonToken;
        ExpireInTxt2: Text[1024];
        TxtToInteExp2: Integer;
        ConverToDateTime2: DateTime;

    begin
        if not GMAILMgtSetup.Get() then
            exit;

        IF GMAILMgtSetup."Refresh Token" <> '' then begin
            if (CurrentDateTime > GMAILMgtSetup."Token Expiration DateTime") then begin
                URL3 := GMAILMgtSetup."Token URL" + '?' +
                '&client_id=' + GMAILMgtSetup."Client ID" +
                '&client_secret=' + GMAILMgtSetup."Client Secret ID" +
                '&refresh_token=' + GMAILMgtSetup."Refresh Token" +
                '&grant_type=refresh_token';

                request.SetRequestUri(URL3);
                request.Method := 'POST';
                isSuccess := MyHttpClient.Send(request, Response);

                if isSuccess then begin
                    if Response.HttpStatusCode = 200 then begin
                        Response.Content().ReadAs(Token);

                        JO.ReadFrom(Token);

                        if JO.Get('access_token', JT) then
                            JT.WriteTo(Token);
                        GMAILMgtSetup."API Token Key" := copystr(Token, 2, strlen(Token) - 2);

                        if JO.Get('expires_in', JT) then
                            ExpireInTxt2 := StrSubstNo('%1', JT.AsValue().AsInteger());

                        Evaluate(TxtToInteExp2, ExpireInTxt2 + '000');
                        ConverToDateTime2 := (CurrentDateTime + (TxtToInteExp2));
                        GMAILMgtSetup."Token Expiration DateTime" := ConverToDateTime2;
                        GMAILMgtSetup.Modify();
                        Commit();

                    end;
                end;
            end;
        end;
    end;

}