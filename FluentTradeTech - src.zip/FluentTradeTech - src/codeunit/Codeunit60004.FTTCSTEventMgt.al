codeunit 60004 "FTT-CST Event Mgt."
{
    Permissions = tabledata "Cust. Ledger Entry" = M;

    [EventSubscriber(ObjectType::Table, Database::Contact, 'OnAfterInsertEvent', '', false, false)]
    local procedure OnAfterInsertContact(var Rec: Record Contact; RunTrigger: Boolean)
    var
        EventFunctions: Codeunit "FTT-CST Event Functions";
    begin
        if Rec.IsTemporary then
            exit;

        EventFunctions.FillInContactExtraFieldsOnInsert(Rec);
    end;

    [EventSubscriber(ObjectType::Table, Database::Customer, 'OnAfterInsertEvent', '', false, false)]
    local procedure OnAfterInsertCustomer(var Rec: Record Customer; RunTrigger: Boolean)
    var
        EventFunctions: Codeunit "FTT-CST Event Functions";
    begin
        if Rec.IsTemporary then
            exit;

        EventFunctions.FillInCustomerExtraFieldsOnInsert(Rec);
    end;

    [EventSubscriber(ObjectType::Table, Database::"Document Attachment", 'OnBeforeInsertAttachment', '', false, false)]
    local procedure OnBeforeInsertDocAttachment(var DocumentAttachment: Record "Document Attachment"; var RecRef: RecordRef)
    var
        EventFunctions: Codeunit "FTT-CST Event Functions";
    begin
        if DocumentAttachment.IsTemporary then
            exit;

        if not (DocumentAttachment."Table ID" in [Database::Contact, Database::Customer]) then
            exit;

        EventFunctions.FillInDocAttmtExtraFieldsOnInsert(DocumentAttachment);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Sales-Post", 'OnCheckAndUpdateOnAfterSetPostingFlags', '', false, false)]
    local procedure OnCheckAndUpdateOnAfterSetPostingFlags(var SalesHeader: Record "Sales Header")
    var
        EventFunctions: Codeunit "FTT-CST Event Functions";
    begin
        if SalesHeader.IsTemporary then
            exit;

        if SalesHeader."Document Type" <> "Sales Document Type"::Order then
            exit;

        EventFunctions.CheckMSA(SalesHeader);
        EventFunctions.ModifyInvoiceWithoutMSA(SalesHeader);
    end;

    // [EventSubscriber(ObjectType::Table, Database::"Cust. Ledger Entry", OnAfterInsertEvent, '', false, false)]
    // local procedure CustLedgerEntryOnAfterInsertEvent(var Rec: Record "Cust. Ledger Entry")
    // var
    //     EventFunctions: Codeunit "FTT-CST Event Functions";
    // begin
    //     if Rec.IsTemporary then
    //         exit;

    //     EventFunctions.CalcCommissionBaseAmount(Rec);
    //     Rec.Modify();
    // end;

    [EventSubscriber(ObjectType::Table, Database::"Detailed Cust. Ledg. Entry", OnAfterInsertEvent, '', false, false)]
    local procedure DetailedCustLedgEntry(var Rec: Record "Detailed Cust. Ledg. Entry")
    var
        EventFunctions: Codeunit "FTT-CST Event Functions";
    begin
        if Rec.IsTemporary then
            exit;

        EventFunctions.ModifyCreatedDateInCommisionEntry();
    end;

    [EventSubscriber(ObjectType::Table, Database::"Cust. Ledger Entry", 'OnAfterCopyCustLedgerEntryFromCVLedgEntryBuffer', '', false, false)]
    local procedure OnAfterCopyCustLedgerEntryFromCVLedgEntryBuffer(var CustLedgerEntry: Record "Cust. Ledger Entry")
    var
        EventFunctions: Codeunit "FTT-CST Event Functions";
    begin
        //EventFunctions.InsertCommisionEntryForAppliedEntry(CustLedgerEntry);\

    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Gen. Jnl.-Post Line", 'OnBeforeCustLedgEntryModify', '', false, false)]
    local procedure OnBeforeCustLedgEntryModify(var CustLedgerEntry: Record "Cust. Ledger Entry")
    var
        EventFunctions: Codeunit "FTT-CST Event Functions";
    begin
        //EventFunctions.InsertCommisionEntryForUnAppliedEntry(CustLedgerEntry);
    end;

    [EventSubscriber(ObjectType::Page, Page::"Unapply Customer Entries", 'OnBeforeRecInsert', '', false, false)]
    local procedure OnBeforeRecInsertUnapplyCustomeEntries(var RecDtldCustLedgEntry: Record "Detailed Cust. Ledg. Entry")
    var
        EventFunctions: Codeunit "FTT-CST Event Functions";
    begin
        EventFunctions.ModifyTempRemainingAmount(RecDtldCustLedgEntry."Cust. Ledger Entry No.");
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"CustEntry-Apply Posted Entries", 'OnAfterUnApplyCustomer', '', false, false)]
    local procedure OnAfterUnApplyCustomer()
    var
        EventFunctions: Codeunit "FTT-CST Event Functions";
    begin
        EventFunctions.ModifyCreatedDateInCommisionEntry();
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"CustEntry-Apply Posted Entries", 'OnCustPostApplyCustLedgEntryOnBeforeCommit', '', false, false)]
    local procedure OnCustPostApplyCustLedgEntryOnBeforeCommit()
    var
        EventFunctions: Codeunit "FTT-CST Event Functions";
    begin
        EventFunctions.ModifyCreatedDateInCommisionEntry();
    end;

    [EventSubscriber(ObjectType::Table, Database::"Sales Header", 'OnAfterGetPstdDocLinesToReverse', '', false, false)]
    local procedure OnAfterGetPstdDocLinesToReverse(var SalesHeader: Record "Sales Header")
    var
        EventFunctions: Codeunit "FTT-CST Event Functions";
    begin
        EventFunctions.ModifyCostType(SalesHeader);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Correct Posted Sales Invoice", 'OnAfterCreateCopyDocument', '', false, false)]
    local procedure OnAfterCreateCopyDocument(var SalesHeader: Record "Sales Header")
    var
        EventFunctions: Codeunit "FTT-CST Event Functions";
    begin
        EventFunctions.ModifyCostType(SalesHeader);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Copy Document Mgt.", 'OnAfterInsertToSalesLine', '', false, false)]
    local procedure OnAfterInsertToSalesLine(var ToSalesLine: Record "Sales Line"; FromSalesLine: Record "Sales Line")
    begin
        if FromSalesLine."Document No." = '' then
            exit;

        if FromSalesLine."Document Type" in [FromSalesLine."Document Type"::Quote, FromSalesLine."Document Type"::Order, FromSalesLine."Document Type"::Invoice] then begin
            if FromSalesLine."Document Type" = FromSalesLine."Document Type"::Quote then
                ToSalesLine."FTT-CST Copied Document Type" := "Sales Document Type From"::Quote;
            if FromSalesLine."Document Type" = FromSalesLine."Document Type"::Order then
                ToSalesLine."FTT-CST Copied Document Type" := "Sales Document Type From"::Order;
            if FromSalesLine."Document Type" = FromSalesLine."Document Type"::Invoice then
                ToSalesLine."FTT-CST Copied Document Type" := "Sales Document Type From"::Invoice;
            ToSalesLine."FTT-CST Copied Document No." := FromSalesLine."Document No.";
            ToSalesLine."FTT-CST Copied Line No." := FromSalesLine."Line No.";
            ToSalesLine."FTT-CST Location Code" := FromSalesLine."FTT-CST Location Code"; //NRD
            ToSalesLine."FTT-CST Unit Price" := FromSalesLine."FTT-CST Unit Price"; //NRD
            ToSalesLine."FTT-CST Sublocation" := FromSalesLine."FTT-CST Sublocation"; //NRD
            ToSalesLine."FTT-CST Component Option" := FromSalesLine."FTT-CST Component Option"; //NRD
            ToSalesLine."Commission Agreement No." := FromSalesLine."Commission Agreement No."; //NRD
            ToSalesLine."Agreement Period" := FromSalesLine."Agreement Period"; //nrd
            ToSalesLine.Modify();
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Copy Document Mgt.", 'OnCopySalesInvLinesToDocOnAfterCopySalesDocLine', '', false, false)]
    local procedure OnCopySalesInvLinesToDocOnAfterCopySalesDocLine(FromSalesInvLine: Record "Sales Invoice Line"; ToSalesLine: Record "Sales Line")
    var
        recSalesHeader: Record "Sales Header";
    begin

        ToSalesLine."FTT-CST Copied Document Type" := "Sales Document Type From"::"Posted Invoice";
        ToSalesLine."FTT-CST Copied Document No." := FromSalesInvLine."Document No.";
        ToSalesLine."FTT-CST Copied Line No." := FromSalesInvLine."Line No.";
        ToSalesLine.Modify();

        //NRD
        recSalesHeader.Reset();
        recSalesHeader.SetRange("Document Type", recSalesHeader."Document Type"::"Return Order");
        recSalesHeader.SetRange("No.", ToSalesLine."Document No.");
        recSalesHeader.SetFilter("FTT-CST Agr. Starting Date", '%1', 0D);
        if recSalesHeader.FindFirst() then begin
            recSalesHeader.Validate("FTT-CST Agr. Starting Date", FromSalesInvLine."FTT-CST Agreement Date From");
            recSalesHeader.Validate("FTT-CST Agr. Ending Date", FromSalesInvLine."FTT-CST Agreement Date To");
            recSalesHeader.Modify()
        end;
        //+
    end;

    [EventSubscriber(ObjectType::Table, Database::"Sales Line", 'OnValidateNoOnCopyFromTempSalesLine', '', false, false)]
    local procedure OnValidateNoOnCopyFromTempSalesLine(var SalesLine: Record "Sales Line"; var TempSalesLine: Record "Sales Line" temporary)
    begin
        SalesLine."FTT-CST Agreement Date From" := TempSalesLine."FTT-CST Agreement Date From";
        SalesLine."FTT-CST Agreement Date To" := TempSalesLine."FTT-CST Agreement Date To";
    end;
}
