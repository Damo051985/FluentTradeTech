codeunit 50003 "GMAIL Integ.Spreadsheet"
{
    trigger OnRun()
    begin

    end;

    procedure UpdateCRMTemplatefromSalesQuote(pSalesQuote: Record "Sales Header"; SendEmail: Boolean)
    var
        GenLedgSetup: Record "General Ledger Setup";
        Text001: Text[450];
        Text002: Label 'Fluent Trade Technologies software pricing methodology is based on the individual components and feeds that its clients utilise. This initial pricing proposal is presented in %1 and relates to the proposed initial project scope as Fluent understands it. Final written requirements are to be mutually agreed upon before a firm price proposal from Fluent. If relevant, additional hardware and infrastructure fees may also apply. ';
        FileName: Text;
        SQSalesLine: Record "Sales Line";
        Instreamtest: InStream;
        CrySymbol: Text;
        Currency: Record Currency;
        ListofStartIndex: array[100] of integer;
        ListOfEndIndex: array[100] of integer;
        TotalIndex: Integer;
        lTotalDeleted: Integer;
        lLocation: Record Location;
        FirstRun: Integer;
    begin
        if not GenLedgSetup.Get() then
            exit;

        TestSpreedID := CreateaCopyCRMTemplate();
        commit;
        SheetID := GetSheetIDFromCRMTemplate();

        //>>Dan
        IF (GetAllLocationCode(pSalesQuote)) AND (TempLoc.FINDSET) THEN BEGIN
            repeat
                FirstRun += 1;
                IF FirstRun = 1 THEN BEGIN
                    UpdateSheets(SheetID, TempLoc.Code);
                    SLEEP(5000);
                    TempLoc.Name := FORMAT(SheetID);
                    TempLoc.Modify;
                END ELSE BEGIN
                    AddSheets();
                    Sleep(5000);
                    Evaluate(SheetID, SheetID2);
                    UpdateSheets(SheetID, TempLoc.Code);
                    Sleep(5000);
                    TempLoc.Name := FORMAT(SheetID);
                    TempLoc.Modify;
                END;
            until TempLoc.Next = 0;
        END;
        //<<Dan
        //>>Dan
        TempLoc.Reset;
        IF TempLoc.FINDSET then
            repeat
                Sleep(2000);
                Evaluate(SheetID, TempLoc.name);
                TotalIndex := 0;
                Clear(ListofStartIndex);
                Clear(ListOfEndIndex);
                lTotalDeleted := 0;
                CrySymbol := '';

                //<<Dan
                //UpdateCustName - 
                if not UpdateCRMTemplate(TempLoc.Code + '!A1:A1', pSalesQuote."Ship-to Name") then
                    Error('Error on the Customer Name %1', pSalesQuote."Ship-to Name");
                Sleep(2000);
                //UpdateCurrency
                if pSalesQuote."Currency Code" <> '' then begin
                    CrySymbol := GetCurrencySymbol(pSalesQuote."Currency Code");
                    if not UpdateCRMTemplate(TempLoc.Code + '!A2:A2', pSalesQuote."Currency Code") then
                        Error('Error on the Currency Code %1', pSalesQuote."Currency Code");
                end else begin
                    CrySymbol := GenLedgSetup."Local Currency Symbol";

                    if not UpdateCRMTemplate(TempLoc.Code + '!A2:A2', GenLedgSetup."LCY Code") then
                        Error('Error on the Currency Code %1', GenLedgSetup."LCY Code");
                end;
                Sleep(2000);
                //UpdateDisclaimer - 
                if pSalesQuote."Currency Code" <> '' then
                    Text001 := StrSubstNo(Text002, pSalesQuote."Currency Code")
                else
                    Text001 := StrSubstNo(Text002, GenLedgSetup."LCY Code");

                if not UpdateCRMTemplate(TempLoc.Code + '!B4:B4', Text001) then
                    Error('Error on the Disclaimer');

                Sleep(2000);

                UpdateNonOptional(pSalesQuote, CrySymbol, TotalIndex, ListofStartIndex, ListOfEndIndex, lTotalDeleted);
                Sleep(2000);
                UpdateOptional(pSalesQuote, CrySymbol, TotalIndex, ListofStartIndex, ListOfEndIndex, lTotalDeleted);
                Sleep(2000);
                UpdateDetailedLines(pSalesQuote, CrySymbol, TotalIndex, ListofStartIndex, ListOfEndIndex, lTotalDeleted);
                Sleep(2000);
                UpdateCrossConnectLines(pSalesQuote, CrySymbol, TotalIndex, ListofStartIndex, ListOfEndIndex, lTotalDeleted);
                Commit();
                Sleep(2000);
                AdditionalUpdate(pSalesQuote);
                Sleep(2000);
                //Message('%1', CreateJson(SheetID, ListofStartIndex, ListOfEndIndex, TotalIndex));
                DeleteZeroValueInCRMTemplate(CreateJson(SheetID, ListofStartIndex, ListOfEndIndex, TotalIndex));
                Commit();
            until TempLoc.Next = 0; //dan
        IF tempLoc.Count = 0 then
            ERROR('No Line in Document No. %1', pSalesQuote."No.");
        //<<Dan
        //UpdateCrossConnectLines(pSalesQuote, CrySymbol, TotalIndex, ListofStartIndex, ListOfEndIndex, lTotalDeleted);
        if not SendEmail then begin
            FileName := Format('SQ-' + pSalesQuote."No." + '_' + pSalesQuote."Ship-to Name");
            //FileName := 'test';
            DownloadCRMTemplate(FileName, SendEmail, Instreamtest);
        end else begin
            DownloadCRMTemplate(FileName, true, Instreamtest);
            Commit();

            pSalesQuote.SalesQuoteExtTemp.ImportStream(Instreamtest, FileName, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet(.xlsx)');
            pSalesQuote.Modify();
            Commit();
        end;
        Commit();

        DeleteCopyCRMTemplate(TestSpreedID);
    end;

    procedure GetCurrencySymbol(pCureCode: Code[20]): Text[10]
    var
        Currency_l: Record Currency;
    begin
        if not Currency_l.get(pCureCode) then
            exit('');

        Currency_l.TestField(Symbol);

        exit(Currency_l.Symbol)
    end;

    procedure UpdateNonOptional(pSalesQuote2: Record "Sales Header"; pCurrSymbol: Text[10]; var ptotalIndex: integer; var pListofStartIndex: array[100] of integer; var pListOfEndIndex: array[100] of integer; var TotalDeleted: integer)
    var
        SQSalesLine: Record "Sales Line";
        SQSalesLine2: Record "Sales Line";
        TotalInvDiscount: Decimal;
        TextDiscount, TextUpdate : Text[1024];
        SndYrDisc: Decimal;
        C9Value, D9Value, C9Value2 : decimal;
    begin
        //UpdateLCFSYRC - 
        InitializedVariables();
        C9Value := 0;
        D9Value := 0;
        SndYrDisc := 0;
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1|%2|%3|%4', 'DR', 'LICENSE', 'REDUNDANCY', 'FEED');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums("Line Amount");
            C9Value := SQSalesLine."Line Amount";
            C9Value2 := SQSalesLine."Line Amount";

            if not UpdateCRMTemplate(TempLoc.Code + '!C9:C9', pCurrSymbol + Format(C9Value2)) then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            //if not UpdateCRMTemplate(TempLoc.Code + '!C9:C9', pCurrSymbol + Format(SQSalesLine."Line Amount")) then
            //Error('Error on the LCFSYRC');

            SQSalesLine2.Reset();
            SQSalesLine2.SetRange("Document Type", pSalesQuote2."Document Type");
            SQSalesLine2.SetRange("Document No.", pSalesQuote2."No.");
            SQSalesLine2.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
            SQSalesLine2.SetRange("FTT-CST Optional", SQSalesLine2."FTT-CST Optional"::No);
            SQSalesLine2.SetRange(Type, SQSalesLine2.Type::Item);
            SQSalesLine2.SetFilter("FTT-CST Parent Item Cat. Code", '%1|%2|%3|%4', 'DR', 'LICENSE', 'REDUNDANCY', 'FEED');
            SQSalesLine2.SetRange("SDP Items", false);
            SQSalesLine2.SetFilter("FTT-CST Cost Type", '%1|%2', SQSalesLine2."FTT-CST Cost Type"::YRC, SQSalesLine2."FTT-CST Cost Type"::YRCCalculated);
            if SQSalesLine2.FindSet() then begin
                SQSalesLine2.CalcSums("Line Amount");
                D9Value := SQSalesLine2."Line Amount";
                if not UpdateCRMTemplate(TempLoc.Code + '!D9:D9', pCurrSymbol + Format(D9Value)) then
                    Error('Error on the LCFSYRC');
                Sleep(2000);
            end;
        end
        else begin
            TotalDeleted += 1;
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := 8;
            pListOfEndIndex[ptotalIndex] := 9;
        end;
        Sleep(2000);
        //UpdateFSDPYRCHOTCOLD 
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetRange("SDP Items", true);
        SQSalesLine.SetRange("FTT-CST Cost Type", SQSalesLine."FTT-CST Cost Type"::YRC);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1', 'LICENSE');
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums("Line Amount");
            XLValAmt1 := SQSalesLine."Line Amount";
            XLValAmt2 := SQSalesLine."Line Amount";
            if not UpdateCRMTemplate(TempLoc.Code + '!C10:C10', pCurrSymbol + Format(XLValAmt1))
               then
                Error('Error on the FSDPYRCHOTCOLD');

            if not UpdateCRMTemplate(TempLoc.Code + '!D10:D10', pCurrSymbol + Format(XLValAmt2))
             then
                Error('Error on the FSDPYRCHOTCOLD');
            Sleep(2000);
        end else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (9 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (10 - TotalDeleted);
            TotalDeleted += 1;
        end;
        Sleep(2000);
        //UpdateFSDPNRC
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetRange("SDP Items", true);
        SQSalesLine.SetRange("FTT-CST Cost Type", SQSalesLine."FTT-CST Cost Type"::NRC);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1', 'INSTALLATION');
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums("Line Amount");
            XLValAmt3 := SQSalesLine."Line Amount";
            if not UpdateCRMTemplate(TempLoc.Code + '!C11:C11', pCurrSymbol + Format(XLValAmt3)) then
                Error('Error on the FSDPNRC');
            Sleep(2000);
        end else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (10 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (11 - TotalDeleted);
            TotalDeleted += 1;
        end;
        Sleep(2000);
        //UpdateIASNRCSDP
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1', 'INSTALLATION');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums("Line Amount");
            XLValAmt4 := SQSalesLine."Line Amount";
            if not UpdateCRMTemplate(TempLoc.Code + '!C12:C12', pCurrSymbol + Format(XLValAmt4)) then
                Error('Error on the IASNRCSDP');
            Sleep(2000);
        end
        else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (11 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (12 - TotalDeleted);
            TotalDeleted += 1;
        end;
        Sleep(2000);
        //UpdateSERVERANDSETUPSDP
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1|%2', 'SERVERS SET UP', 'HARDWARE');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums("Line Amount");
            XLValAmt5 := SQSalesLine."Line Amount";
            if not UpdateCRMTemplate(TempLoc.Code + '!C13:C13', pCurrSymbol + Format(XLValAmt5)) then
                Error('Error on the UpdateSERVERANDSETUPSDP');
            Sleep(2000);
        end
        else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (12 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (13 - TotalDeleted);
            TotalDeleted += 1;
        end;
        Sleep(2000);
        //UpdateHOSTINGLONDINGYRC
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1', 'HOSTING & MANAGEMENT');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums("Line Amount");
            XLValAmt6 := SQSalesLine."Line Amount";
            XLValAmt7 := SQSalesLine."Line Amount";
            if not UpdateCRMTemplate(TempLoc.Code + '!C14:C14', pCurrSymbol + Format(XLValAmt6)) then
                Error('Error on the HOSTINGLONDINGYRC');
            Sleep(2000);
            if not UpdateCRMTemplate(TempLoc.Code + '!D14:D14', pCurrSymbol + Format(XLValAmt7)) then
                Error('Error on the HOSTINGLONDINGYRC');
            Sleep(2000);
        end
        else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (13 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (14 - TotalDeleted);
            TotalDeleted += 1;
        end;

        Sleep(2000);
        //UpdateCONNECTIVITY
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1', 'CROSS CONNECTS');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums("Line Amount");
            XLValAmt8 := SQSalesLine."Line Amount" + GetInternationalLineTotal(pSalesQuote2);

            if not UpdateCRMTemplate(TempLoc.Code + '!C15:C15', pCurrSymbol + Format(XLValAmt8)) then
                Error('Error on the CONNECTIVITY');
            Sleep(2000);
            SQSalesLine2.Reset();
            SQSalesLine2.SetRange("Document Type", pSalesQuote2."Document Type");
            SQSalesLine2.SetRange("Document No.", pSalesQuote2."No.");
            SQSalesLine2.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
            SQSalesLine2.SetRange("FTT-CST Optional", SQSalesLine2."FTT-CST Optional"::No);
            SQSalesLine2.SetRange(Type, SQSalesLine2.Type::Item);
            SQSalesLine2.SetFilter("FTT-CST Parent Item Cat. Code", '%1', 'CROSS CONNECTS');
            SQSalesLine2.SetRange("SDP Items", false);
            SQSalesLine2.SetFilter("FTT-CST Cost Type", '%1|%2', SQSalesLine2."FTT-CST Cost Type"::YRC, SQSalesLine2."FTT-CST Cost Type"::MRC);
            if SQSalesLine2.FindSet() then begin
                SQSalesLine2.CalcSums("Line Amount");
                XLValAmt9 := SQSalesLine2."Line Amount";
                if not UpdateCRMTemplate(TempLoc.Code + '!D15:D15', pCurrSymbol + Format(XLValAmt9)) then
                    Error('Error on the LCFSYRC');
                Sleep(2000);
            end;
        end else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (14 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (15 - TotalDeleted);
            TotalDeleted += 1;
        end;
        Sleep(2000);
        //UpdateDiscount
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetFilter("Allow Invoice Disc.", '%1', true);
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums(SQSalesLine."Inv. Discount Amount", SQSalesLine."Line Amount");
            if SQSalesLine."Inv. Discount Amount" <> 0 then begin
                TotalInvDiscount := (SQSalesLine."Inv. Discount Amount" / SQSalesLine."Line Amount");
                TotalInvDiscount := (TotalInvDiscount * 100);
                TotalInvDiscount := Round(TotalInvDiscount, 1, '=');
                if not UpdateCRMTemplate(TempLoc.Code + '!C19:C19', StrSubstNo('%1', TotalInvDiscount) + '%') then
                    Error('Error on the Discount %');
                Sleep(2000);
                TextDiscount := StrSubstNo('Applied %1 % of discount to the licensing costs for software', TotalInvDiscount);
                if not UpdateCRMTemplate(TempLoc.Code + '!B17:B17', TextDiscount) then
                    Error('Error on the Discount %');
                Sleep(2000);
                //>>101424 Update
                //Evaluate(SndYrDisc, ('.' + FORMAT(TotalInvDiscount)));
                //if not UpdateCRMTemplate(TempLoc.Code + '!D19:D19', FORMAT(SndYrDisc)) then
                //Error('Error on the Discount %');

            end ELSE begin

            end;
        end;
        /*
        ptotalIndex += 1;
        pListofStartIndex[ptotalIndex] := (15 - TotalDeleted);
        pListOfEndIndex[ptotalIndex] := (16 - TotalDeleted);
        TotalDeleted += 1;
        */
        IF (TotalInvDiscount = 0) THEN begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (16 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (17 - TotalDeleted);
            TotalDeleted += 1;
        end ELSE begin

        end;

        UpdateCRMTemplate(TempLoc.Code + '!B18:B18', 'TOTAL cost by year'); //101424 Update
        //<<101424 Update
        Sleep(2000);
    end;

    procedure UpdateOptional(pSalesQuote2: Record "Sales Header"; pCurrSymbol: Text[10]; var ptotalIndex: integer; var pListofStartIndex: array[100] of integer; var pListOfEndIndex: array[100] of integer; var TotalDeleted: Integer)
    var
        SQSalesLine: Record "Sales Line";
        SQSalesLine2: record "Sales Line";
        NotAllZeroValue: Boolean;
        ListofStartIndexTemp: array[100] of integer;
        ListofEndIndexTemp: array[100] of integer;
        totalIndexTemp: integer;
        TextUpdate: Text[1024];
        I: integer;
    begin
        //UpdateLCFSYRC - 
        NotAllZeroValue := false; //dan update 102524
        InitializedVariables();
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::Yes);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1|%2|%3|%4', 'DR', 'LICENSE', 'REDUNDANCY', 'FEED');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums("FTT-CST Unit Price"); //changed to unit price from line amount
            IF SQSalesLine."FTT-CST Unit Price" <> 0 THEN BEGIN //dan 102524
                if not UpdateCRMTemplate(TempLoc.Code + '!C23:C23', pCurrSymbol + Format(SQSalesLine."FTT-CST Unit Price")) then
                    Error('Error on the LCFSYRC');
                Sleep(2000);
                NotAllZeroValue := true;
            End;
            SQSalesLine2.Reset();
            SQSalesLine2.SetRange("Document Type", pSalesQuote2."Document Type");
            SQSalesLine2.SetRange("Document No.", pSalesQuote2."No.");
            SQSalesLine2.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
            SQSalesLine2.SetRange("FTT-CST Optional", SQSalesLine2."FTT-CST Optional"::Yes);
            SQSalesLine2.SetRange(Type, SQSalesLine2.Type::Item);
            SQSalesLine2.SetFilter("FTT-CST Parent Item Cat. Code", '%1|%2|%3|%4', 'DR', 'LICENSE', 'REDUNDANCY', 'FEED');
            SQSalesLine2.SetRange("SDP Items", false);
            SQSalesLine2.SetFilter("FTT-CST Cost Type", '%1|%2', SQSalesLine2."FTT-CST Cost Type"::YRC, SQSalesLine2."FTT-CST Cost Type"::YRCCalculated);
            if SQSalesLine2.FindSet() then begin
                SQSalesLine2.CalcSums("FTT-CST Unit Price");
                IF SQSalesLine2."FTT-CST Unit Price" <> 0 THEN BEGIN //dan 102524
                    if not UpdateCRMTemplate(TempLoc.Code + '!D23:D23', pCurrSymbol + Format(SQSalesLine2."FTT-CST Unit Price")) then
                        Error('Error on the LCFSYRC');
                    Sleep(2000);
                    NotAllZeroValue := true;
                End;
            end;
            //>>dan 102524 Update
            IF NotAllZeroValue = False THEN begin
                totalIndexTemp += 1;
                ListofStartIndexTemp[totalIndexTemp] := (22 - TotalDeleted);
                ListofEndIndexTemp[totalIndexTemp] := (23 - TotalDeleted);
            end;
            //<<Dan 102524 update
        end else begin
            totalIndexTemp += 1;
            ListofStartIndexTemp[totalIndexTemp] := (22 - TotalDeleted);
            ListofEndIndexTemp[totalIndexTemp] := (23 - TotalDeleted);
        end;

        Sleep(2000);
        //UpdateFSDPYRCHOTCOLD 
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::Yes);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetRange("SDP Items", true);
        SQSalesLine.SetRange("FTT-CST Cost Type", SQSalesLine."FTT-CST Cost Type"::YRC);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1', 'LICENSE');
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums("FTT-CST Unit Price"); //changed to unit price from line amount
            IF SQSalesLine."FTT-CST Unit Price" <> 0 THEN BEGIN //dan 102524
                if not UpdateCRMTemplate(TempLoc.Code + '!C24:C24', pCurrSymbol + Format(SQSalesLine."FTT-CST Unit Price")) then
                    Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);
                if not UpdateCRMTemplate(TempLoc.Code + '!D24:D24', pCurrSymbol + Format(SQSalesLine."FTT-CST Unit Price"))
               then
                    Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);
                NotAllZeroValue := true;
            End;
            //>>dan 102524 Update
            IF NotAllZeroValue = False THEN begin
                totalIndexTemp += 1;
                ListofStartIndexTemp[totalIndexTemp] := 23;
                ListofEndIndexTemp[totalIndexTemp] := 24;
            end;
            //<<Dan 102524 update
        end else begin
            totalIndexTemp += 1;
            ListofStartIndexTemp[totalIndexTemp] := 23;
            ListofEndIndexTemp[totalIndexTemp] := 24;
        end;
        Sleep(2000);
        //UpdateFSDPNRC
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::Yes);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetRange("SDP Items", true);
        SQSalesLine.SetRange("FTT-CST Cost Type", SQSalesLine."FTT-CST Cost Type"::NRC);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1', 'INSTALLATION');
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums("FTT-CST Unit Price"); //changed to unit price from line amount
            IF SQSalesLine."FTT-CST Unit Price" <> 0 THEN BEGIN //dan 102524
                if not UpdateCRMTemplate(TempLoc.Code + '!C25:C25', pCurrSymbol + Format(SQSalesLine."FTT-CST Unit Price")) then
                    Error('Error on the FSDPNRC');
                Sleep(2000);
                NotAllZeroValue := true;
            End;
            //>>dan 102524 Update
            IF NotAllZeroValue = False THEN begin
                totalIndexTemp += 1;
                ListofStartIndexTemp[totalIndexTemp] := 24;
                ListofEndIndexTemp[totalIndexTemp] := 25;
            end;
            //<<Dan 102524 update
        end else begin
            totalIndexTemp += 1;
            ListofStartIndexTemp[totalIndexTemp] := 24;
            ListofEndIndexTemp[totalIndexTemp] := 25;
        end;
        Sleep(2000);
        //UpdateIASNRCSDP
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::Yes);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1', 'INSTALLATION');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums("FTT-CST Unit Price"); //changed to unit price from line amount
            IF SQSalesLine."FTT-CST Unit Price" <> 0 THEN BEGIN //dan 102524
                if not UpdateCRMTemplate(TempLoc.Code + '!C26:C26', pCurrSymbol + Format(SQSalesLine."FTT-CST Unit Price")) then
                    Error('Error on the IASNRCSDP');
                Sleep(2000);
                NotAllZeroValue := true;
            end;
            //>>dan 102524 Update
            IF NotAllZeroValue = False THEN begin
                totalIndexTemp += 1;
                ListofStartIndexTemp[totalIndexTemp] := 25;
                ListofEndIndexTemp[totalIndexTemp] := 26;
            end;
            //<<Dan 102524 update
        end else begin
            totalIndexTemp += 1;
            ListofStartIndexTemp[totalIndexTemp] := 25;
            ListofEndIndexTemp[totalIndexTemp] := 26;
        end;
        Sleep(2000);
        //UpdateSERVERANDSETUPSDP
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::Yes);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1|%2', 'SERVERS SET UP', 'HARDWARE');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums("FTT-CST Unit Price"); //changed to unit price from line amount
            IF (SQSalesLine."FTT-CST Unit Price" <> 0) THEN BEGIN//dan 102524
                if not UpdateCRMTemplate(TempLoc.Code + '!C27:C27', pCurrSymbol + Format(SQSalesLine."FTT-CST Unit Price")) then
                    Error('Error on the UpdateSERVERANDSETUPSDP');
                Sleep(2000);
                NotAllZeroValue := true;
            End;
            //>>dan 102524 Update
            IF NotAllZeroValue = False THEN begin
                totalIndexTemp += 1;
                ListofStartIndexTemp[totalIndexTemp] := 26;
                ListofEndIndexTemp[totalIndexTemp] := 27;
            end;
            //<<Dan 102524 update
        end else begin
            totalIndexTemp += 1;
            ListofStartIndexTemp[totalIndexTemp] := 26;
            ListofEndIndexTemp[totalIndexTemp] := 27;
        end;
        Sleep(2000);
        //UpdateHOSTINGLONDINGYRC
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::Yes);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1', 'HOSTING & MANAGEMENT');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums("FTT-CST Unit Price"); //changed to unit price from line amount
            IF (SQSalesLine."FTT-CST Unit Price" <> 0) THEN BEGIN//dan 102524
                if not UpdateCRMTemplate(TempLoc.Code + '!C28:C28', pCurrSymbol + Format(SQSalesLine."FTT-CST Unit Price")) then
                    Error('Error on the HOSTINGLONDINGYRC');
                Sleep(2000);
                if not UpdateCRMTemplate(TempLoc.Code + '!D28:D28', pCurrSymbol + Format(SQSalesLine."FTT-CST Unit Price")) then
                    Error('Error on the HOSTINGLONDINGYRC');
                Sleep(2000);
                NotAllZeroValue := true;
            END;
            //>>dan 102524 Update
            IF NotAllZeroValue = False THEN begin
                totalIndexTemp += 1;
                ListofStartIndexTemp[totalIndexTemp] := 27;
                ListofEndIndexTemp[totalIndexTemp] := 28;
            end;
            //<<Dan 102524 update
        end else begin
            totalIndexTemp += 1;
            ListofStartIndexTemp[totalIndexTemp] := 27;
            ListofEndIndexTemp[totalIndexTemp] := 28;
        end;
        Sleep(2000);
        //UpdateCONNECTIVITY
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::Yes);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1', 'CROSS CONNECTS');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums("FTT-CST Unit Price");
            IF (SQSalesLine."FTT-CST Unit Price" <> 0) THEN BEGIN//dan 102524
                if not UpdateCRMTemplate(TempLoc.Code + '!C29:C29', pCurrSymbol + Format(SQSalesLine."Unit Price")) then
                    Error('Error on the CONNECTIVITY');
                Sleep(2000);
                NotAllZeroValue := true;
            End;
            SQSalesLine2.Reset();
            SQSalesLine2.SetRange("Document Type", pSalesQuote2."Document Type");
            SQSalesLine2.SetRange("Document No.", pSalesQuote2."No.");
            SQSalesLine2.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
            SQSalesLine2.SetRange("FTT-CST Optional", SQSalesLine2."FTT-CST Optional"::Yes);
            SQSalesLine2.SetRange(Type, SQSalesLine2.Type::Item);
            SQSalesLine2.SetFilter("FTT-CST Parent Item Cat. Code", '%1', 'CROSS CONNECTS');
            SQSalesLine2.SetRange("SDP Items", false);
            SQSalesLine2.SetFilter("FTT-CST Cost Type", '%1|%2', SQSalesLine2."FTT-CST Cost Type"::YRC, SQSalesLine2."FTT-CST Cost Type"::MRC);
            if SQSalesLine2.FindSet() then begin
                SQSalesLine2.CalcSums("FTT-CST Unit Price");
                IF (SQSalesLine2."FTT-CST Unit Price" <> 0) THEN BEGIN//dan 102524
                    if not UpdateCRMTemplate(TempLoc.Code + '!D29:D29', pCurrSymbol + Format(SQSalesLine2."FTT-CST Unit Price")) then
                        Error('Error on the LCFSYRC');
                    Sleep(2000);
                    NotAllZeroValue := true;
                End;
            end;
            //>>dan 102524 Update
            IF NotAllZeroValue = False THEN begin
                totalIndexTemp += 1;
                ListofStartIndexTemp[totalIndexTemp] := 28;
                ListofEndIndexTemp[totalIndexTemp] := 29;
            end;
            //<<Dan 102524 update
        end else begin
            totalIndexTemp += 1;
            ListofStartIndexTemp[totalIndexTemp] := 28;
            ListofEndIndexTemp[totalIndexTemp] := 29;
        end;
        Sleep(2000);
        if not NotAllZeroValue then begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (20 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (31 - TotalDeleted);
            TotalDeleted := TotalDeleted + 11;
        end else begin
            for I := 1 to totalIndexTemp do begin
                ptotalIndex += 1;
                pListofStartIndex[ptotalIndex] := (ListofStartIndexTemp[i] - TotalDeleted);
                pListOfEndIndex[ptotalIndex] := (ListofEndIndexTemp[i] - TotalDeleted);
                TotalDeleted += 1;
            end;
        end;
    end;
    //Nimrod Dan
    procedure UpdateDetailedLines(pSalesQuote2: Record "Sales Header"; pCurrSymbol: Text[10]; var ptotalIndex: integer; var pListofStartIndex: array[100] of integer; var pListOfEndIndex: array[100] of integer; var TotalDeleted: Integer)
    var
        SQSalesLine: Record "Sales Line";
        NotAllZeroValue: Boolean;
        ListofStartIndexTemp: array[100] of integer;
        ListofEndIndexTemp: array[100] of integer;
        totalIndexTemp: integer;
        I: integer;
        TotalCountOfLicense: integer;
        StartLicenseDetIndex: Integer;
        EndLicenseDetIndex: integer;
        TotalRemIndex: Integer;
        TextOption: Text[250];
        LabelInteg: label 'Intergration and full setup of %1 site, one time fee (%2% of total primary %3 site licenses + Redundancy)';
        LabelRedundancy: Label '%1 (%2% of total primary %3 site licenses)';
        LabelDR: Label '%1 (%2% of total primary %3 site licenses)';
        TextOption2: Text[250];
        TextOption3: Text[250];
        TextOption4: Text[250];
        TextOption5: Text[250];
        LabelHardware: label 'Server Hardware (%1 INT, %2 UAT, %3 PROD)';
        LabelSERVER: label 'Server setup (%1 INT, %2 UAT, %3 PROD)';
        TotalOfProdHdware: Integer;
        TotalofUAThardware: integer;
        TotalOfIntegHrdware: Integer;
        TotalofSharedConnectNRC, TotalofSharedConnectNRC2, InterLine : Decimal;
        TotalofSharedConnectMRC, TotalofSharedConnectMRC2 : Decimal;
        TotalofDEDICATEDConnectNRC, TotalofDEDICATEDConnectNRC2 : Decimal;
        TotalofDEDICATEDConnectMRC, TotalofDEDICATEDConnectMRC2 : Decimal;
    begin
        //UpdateLCFSYRC - 
        InitializedVariables();
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1', 'LICENSE');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindSet() then begin
            TotalCountOfLicense := SQSalesLine.Count;
            StartLicenseDetIndex := 36;
            EndLicenseDetIndex := 35;
            repeat
                XLValAmt10 := SQSalesLine."Unit Price";
                XLValQty10 := SQSalesLine."Quantity";
                XLValAmt9 := SQSalesLine."Line Amount";
                if not UpdateCRMTemplate(TempLoc.Code + '!B' + StrSubstNo('%1', StartLicenseDetIndex) + ':B' + StrSubstNo('%1', StartLicenseDetIndex), SQSalesLine.Description) then
                    Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);
                if not UpdateCRMTemplate(TempLoc.Code + '!C' + StrSubstNo('%1', StartLicenseDetIndex) + ':C' + StrSubstNo('%1', StartLicenseDetIndex), (StrSubstNo('%1', XLValQty10))) then
                    Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);
                if not UpdateCRMTemplate(TempLoc.Code + '!D' + StrSubstNo('%1', StartLicenseDetIndex) + ':D' + StrSubstNo('%1', StartLicenseDetIndex), pCurrSymbol + (StrSubstNo('%1', XLValAmt10))) then
                    Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);
                //>>Dan
                if not UpdateCRMTemplate(TempLoc.Code + '!H' + StrSubstNo('%1', StartLicenseDetIndex) + ':H' + StrSubstNo('%1', StartLicenseDetIndex), SQSalesLine."FTT-CST Comments Fluent") then
                    Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);
                //<<Dan
                if SQSalesLine."FTT-CST Cost Type" = SQSalesLine."FTT-CST Cost Type"::NRC then
                    if not UpdateCRMTemplate(TempLoc.Code + '!F' + StrSubstNo('%1', StartLicenseDetIndex) + ':F' + StrSubstNo('%1', StartLicenseDetIndex), pCurrSymbol + (StrSubstNo('%1', XLValAmt9))) then
                        Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);
                StartLicenseDetIndex += 1;
                EndLicenseDetIndex += 1;

            until SQSalesLine.Next() = 0;

            for I := StartLicenseDetIndex to 50 do begin
                ptotalIndex += 1;
                pListofStartIndex[ptotalIndex] := (EndLicenseDetIndex - TotalDeleted);
                pListOfEndIndex[ptotalIndex] := (I - TotalDeleted);
                StartLicenseDetIndex += 1;
                EndLicenseDetIndex += 1;
                TotalDeleted += 1;
            end;

        end;
        Sleep(2000);
        //UpdateFSDPYRCHOTCOLD 
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("Item Category Code", '%1', 'STANDARD TAKER FEED');
        if SQSalesLine.FindSet() then begin
            /*
            SQSalesLine.CalcSums("Line Amount", Quantity);
            if not UpdateCRMTemplate(TempLoc.Code + '!C51:C51', StrSubstNo('%1', SQSalesLine.Quantity)) then
                Error('Error on the FSDPYRCHOTCOLD');
            //dan commented 101424
            if not UpdateCRMTemplate(TempLoc.Code + '!D51:D51', pCurrSymbol + Format(SQSalesLine."Line Amount")) then
                Error('Error on the FSDPYRCHOTCOLD');

            if SQSalesLine."FTT-CST Cost Type" = SQSalesLine."FTT-CST Cost Type"::NRC then
                if not UpdateCRMTemplate(TempLoc.Code + '!F51:F51', pCurrSymbol + Format(SQSalesLine."Line Amount")) then
                    Error('Error on the FSDPYRCHOTCOLD');
            */
            IF NOT UpdateCrossConnectLines2(pSalesQuote2) THEN begin //Update 101624
                ptotalIndex += 1;
                pListofStartIndex[ptotalIndex] := (50 - TotalDeleted);
                pListOfEndIndex[ptotalIndex] := (51 - TotalDeleted);
                TotalDeleted += 1;
            END;
        end else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (50 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (51 - TotalDeleted);
            TotalDeleted += 1;
        end;
        Sleep(2000);
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("Item Category Code", '%1', 'STANDARD MAKER FEED');
        if SQSalesLine.FindSet() then begin
            /*
            SQSalesLine.CalcSums("Line Amount", Quantity);
            if not UpdateCRMTemplate(TempLoc.Code + '!C52:C52', StrSubstNo('%1', SQSalesLine.Quantity)) then
                Error('Error on the FSDPYRCHOTCOLD');
            //Dan Commented 101424
            if not UpdateCRMTemplate(TempLoc.Code + '!D52:D52', pCurrSymbol + Format(SQSalesLine."Line Amount")) then
                Error('Error on the FSDPYRCHOTCOLD');

            if SQSalesLine."FTT-CST Cost Type" = SQSalesLine."FTT-CST Cost Type"::NRC then
                if not UpdateCRMTemplate(TempLoc.Code + '!F52:F52', pCurrSymbol + Format(SQSalesLine."Line Amount")) then
                    Error('Error on the FSDPYRCHOTCOLD');
                    */
            IF NOT UpdateCrossConnectLines2(pSalesQuote2) THEN begin //Update 101624
                ptotalIndex += 1;
                pListofStartIndex[ptotalIndex] := (51 - TotalDeleted);
                pListOfEndIndex[ptotalIndex] := (52 - TotalDeleted);
                TotalDeleted += 1;
            END;
        end else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (51 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (52 - TotalDeleted);
            TotalDeleted += 1;
        end;
        Sleep(2000);
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("Item Category Code", '%1|%2', 'NS MAKER FEED', 'NS TAKER FEED');
        if SQSalesLine.FindSet() then begin
            /*
            SQSalesLine.CalcSums("Line Amount", Quantity);
            if not UpdateCRMTemplate(TempLoc.Code + '!C53:C53', StrSubstNo('%1', SQSalesLine.Quantity)) then
                Error('Error on the FSDPYRCHOTCOLD');
            //Dan Commented 101424    
            if not UpdateCRMTemplate(TempLoc.Code + '!D53:D53', pCurrSymbol + Format(SQSalesLine."Line Amount")) then
                Error('Error on the FSDPYRCHOTCOLD');

            if SQSalesLine."FTT-CST Cost Type" = SQSalesLine."FTT-CST Cost Type"::NRC then
                if not UpdateCRMTemplate(TempLoc.Code + '!F53:F53', pCurrSymbol + Format(SQSalesLine."Line Amount")) then
                    Error('Error on the FSDPYRCHOTCOLD');
                    */
            IF NOT UpdateCrossConnectLines2(pSalesQuote2) THEN begin //Update 101624
                ptotalIndex += 1;
                pListofStartIndex[ptotalIndex] := (52 - TotalDeleted);
                pListOfEndIndex[ptotalIndex] := (53 - TotalDeleted);
                TotalDeleted += 1;
            END;
        end else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (52 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (53 - TotalDeleted);
            TotalDeleted += 1;
        end;
        Sleep(2000);
        //UpdateLCFSYRC - 
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1', 'REDUNDANCY');
        //SQSalesLine.SetFilter("Item Category Code", '%1', 'REDUNDANCY');
        SQSalesLine.SetRange("FTT-CST Cost Type", SQSalesLine."FTT-CST Cost Type"::YRCCalculated);
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindFirst() then begin
            TextOption4 := StrSubstNo(LabelRedundancy, SQSalesLine.Description, SQSalesLine."FTT-CST Redundancy PriceCalc %", SQSalesLine."FTT-CST Sublocation");
            if not UpdateCRMTemplate(TempLoc.Code + '!B35:B35', StrSubstNo('Primary Site, %1', SQSalesLine."FTT-CST Sublocation")) then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            if not UpdateCRMTemplate(TempLoc.Code + '!B14:B14', StrSubstNo('Hosting - %1 %2 - YRC', SQSalesLine."FTT-CST Location Code", SQSalesLine."FTT-CST Sublocation")) then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            if not UpdateCRMTemplate(TempLoc.Code + '!B15:B15', StrSubstNo('Connectivity - %1 %2 - YRC + NRC', SQSalesLine."FTT-CST Location Code", SQSalesLine."FTT-CST Sublocation")) then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            if not UpdateCRMTemplate(TempLoc.Code + '!B28:B28', StrSubstNo('Hosting - %1 %2 - YRC', SQSalesLine."FTT-CST Location Code", SQSalesLine."FTT-CST Sublocation")) then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            if not UpdateCRMTemplate(TempLoc.Code + '!B29:B29', StrSubstNo('Connectivity - %1 %2 - YRC + NRC', SQSalesLine."FTT-CST Location Code", SQSalesLine."FTT-CST Sublocation")) then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            if not UpdateCRMTemplate(TempLoc.Code + '!B55:B55', TextOption4) then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            if not UpdateCRMTemplate(TempLoc.Code + '!E55:E55', '=' + StrSubstNo('E54 * %1', SQSalesLine."FTT-CST Redundancy PriceCalc %") + '%') then
                Error('Error on the LCFSYRC');
            Sleep(2000);
        end else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (54 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (55 - TotalDeleted);
            TotalDeleted += 1;
        end;
        Sleep(2000);
        //UpdateLCFSYRC - 
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No); //remove comment
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1', 'DR');
        SQSalesLine.SetRange("FTT-CST Cost Type", SQSalesLine."FTT-CST Cost Type"::YRCCalculated);
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindFirst() then begin
            TextOption5 := StrSubstNo(LabelDR, SQSalesLine.Description, SQSalesLine."FTT-CST Redundancy PriceCalc %", SQSalesLine."FTT-CST Sublocation");
            if not UpdateCRMTemplate(TempLoc.Code + '!B56:B56', TextOption5) then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            if not UpdateCRMTemplate(TempLoc.Code + '!E56:E56', '=' + StrSubstNo('E54 * %1', SQSalesLine."FTT-CST Redundancy PriceCalc %") + '%') then
                Error('Error on the LCFSYRC');
            Sleep(2000);
        end else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (55 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (56 - TotalDeleted);
            TotalDeleted += 1;
        end;
        Sleep(2000);
        InitializedVariables();
        //UpdateINSTALLATION - 
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1', 'INSTALLATION');
        SQSalesLine.SetFilter("FTT-CST Unit Price", '%1', 0);
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindFirst() then begin
            SQSalesLine.CalcSums(Quantity, "Line Amount");
            XLValAmt1 := SQSalesLine."Line Amount";
            XLValQty1 := SQSalesLine.Quantity;
            TextOption := StrSubstNo(LabelInteg, SQSalesLine."FTT-CST Sublocation", SQSalesLine."FTT-CST Redundancy PriceCalc %", SQSalesLine."FTT-CST Sublocation");
            if not UpdateCRMTemplate(TempLoc.Code + '!B62:B62', TextOption) then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            if not UpdateCRMTemplate(TempLoc.Code + '!C62:C62', '1') then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            //>>Dan
            if not UpdateCRMTemplate(TempLoc.Code + '!H62:H62', SQSalesLine."FTT-CST Comments Fluent") then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            //<<Dan
            IF SQSalesLine."FTT-CST Cost Type" = SQSalesLine."FTT-CST Cost Type"::NRC then begin
                if not UpdateCRMTemplate(TempLoc.Code + '!D62:D62', pCurrSymbol + Format(XLValAmt1)) then
                    Error('Error on the LCFSYRC');
                Sleep(2000);
                if not UpdateCRMTemplate(TempLoc.Code + '!E62:E62', pCurrSymbol + Format(0)) then
                    Error('Error on the LCFSYRC');
                Sleep(2000);
            end else if SQSalesLine."FTT-CST Cost Type" = SQSalesLine."FTT-CST Cost Type"::MRC then begin
                if not UpdateCRMTemplate(TempLoc.Code + '!D62:D62', pCurrSymbol + Format(0)) then
                    Error('Error on the LCFSYRC');
                Sleep(2000);
                if not UpdateCRMTemplate(TempLoc.Code + '!E62:E62', pCurrSymbol + Format(XLValAmt1)) then
                    Error('Error on the LCFSYRC');
                Sleep(2000);
            end;
        end else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (61 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (62 - TotalDeleted);
            TotalDeleted += 1;
        end;

        //UpdateINSTALLATION - 
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1', 'INSTALLATION');
        SQSalesLine.SetFilter("FTT-CST Unit Price", '<>%1', 0);
        SQSalesLine.SetRange("SDP Items", True); //102424 nimrod Change
        SQSalesLine.SetRange("FTT-CST Cost Type", SQSalesLine."FTT-CST Cost Type"::NRC);
        if SQSalesLine.FindFirst() then begin
            XLValAmt2 := SQSalesLine."Line Amount";
            SQSalesLine.CalcSums(Quantity, "Line Amount");
            XLValQty2 := SQSalesLine."FTT-CST Unit Price";
            //extOption := StrSubstNo(LabelInteg, SQSalesLine."FTT-CST Sublocation", SQSalesLine."FTT-CST Redundancy PriceCalc %", SQSalesLine."FTT-CST Sublocation");

            if not UpdateCRMTemplate(TempLoc.Code + '!B63:B63', SQSalesLine.Description) then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            //if not UpdateCRMTemplate(TempLoc.Code + '!C63:C63', '1') then
            //Error('Error on the LCFSYRC');
            //>>Dan
            if not UpdateCRMTemplate(TempLoc.Code + '!C63:C63', FORMAT(SQSalesLine.Quantity)) then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            if not UpdateCRMTemplate(TempLoc.Code + '!H63:H63', SQSalesLine."FTT-CST Comments Fluent") then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            IF SQSalesLine."FTT-CST Cost Type" = SQSalesLine."FTT-CST Cost Type"::NRC then begin
                if not UpdateCRMTemplate(TempLoc.Code + '!D63:D63', pCurrSymbol + Format(XLValQty2)) then
                    Error('Error on the LCFSYRC');
                Sleep(2000);
                if not UpdateCRMTemplate(TempLoc.Code + '!E63:E63', pCurrSymbol + Format(0)) then
                    Error('Error on the LCFSYRC');
                Sleep(2000);
                //<<Dan
                //IF SQSalesLine."FTT-CST Cost Type" = SQSalesLine."FTT-CST Cost Type"::NRC then begin
                //if not UpdateCRMTemplate(TempLoc.Code + '!D63:D63', pCurrSymbol + Format(SQSalesLine."Line Amount")) then
                //Error('Error on the LCFSYRC');
            end else if SQSalesLine."FTT-CST Cost Type" = SQSalesLine."FTT-CST Cost Type"::MRC then begin
                if not UpdateCRMTemplate(TempLoc.Code + '!E63:E63', pCurrSymbol + Format(XLValAmt2)) then
                    Error('Error on the LCFSYRC');
                Sleep(2000);
                if not UpdateCRMTemplate(TempLoc.Code + '!D63:D63', pCurrSymbol + Format(0)) then
                    Error('Error on the LCFSYRC');
                Sleep(2000);
            end;
        end else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (62 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (63 - TotalDeleted);
            TotalDeleted += 1;
        end;

        Sleep(2000);
        //UpdateHARDWARE
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("Item Category Code", '%1', 'HARDWARE');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums("Line Amount");
            XLValAmt3 := SQSalesLine."FTT-CST Unit Price";
            repeat
                if SQSalesLine."No." = '1096' then
                    TotalOfProdHdware += SQSalesLine.Quantity;

                if SQSalesLine."No." = '1097' then
                    TotalofUAThardware += SQSalesLine.Quantity;

                if SQSalesLine."No." = '1117' then
                    TotalOfIntegHrdware += SQSalesLine.Quantity;

            until SQSalesLine.Next() = 0;

            TextOption2 := StrSubstNo(LabelHardware, TotalOfIntegHrdware, TotalofUAThardware, TotalOfProdHdware);
            if not UpdateCRMTemplate(TempLoc.Code + '!B64:B64', TextOption2) then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            if not UpdateCRMTemplate(TempLoc.Code + '!C64:C64', StrSubstNo('%1', (TotalOfProdHdware + TotalofUAThardware + TotalOfIntegHrdware))) then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            //>>Dan
            if not UpdateCRMTemplate(TempLoc.Code + '!H64:H64', SQSalesLine."FTT-CST Comments Fluent") then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            //<<Dan
            IF SQSalesLine."FTT-CST Cost Type" = SQSalesLine."FTT-CST Cost Type"::NRC then begin
                if not UpdateCRMTemplate(TempLoc.Code + '!D64:D64', pCurrSymbol + Format(XLValAmt3)) then
                    Error('Error on the LCFSYRC');
                Sleep(2000);
                if not UpdateCRMTemplate(TempLoc.Code + '!E64:E64', pCurrSymbol + Format(0)) then
                    Error('Error on the LCFSYRC');
                Sleep(2000);
            end else if SQSalesLine."FTT-CST Cost Type" = SQSalesLine."FTT-CST Cost Type"::MRC then begin
                if not UpdateCRMTemplate(TempLoc.Code + '!D64:D64', pCurrSymbol + Format(0)) then
                    Error('Error on the LCFSYRC');
                Sleep(2000);
                if not UpdateCRMTemplate(TempLoc.Code + '!E64:E64', pCurrSymbol + Format(XLValAmt3)) then
                    Error('Error on the LCFSYRC');
                Sleep(2000);
            end;
        end else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (64 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (65 - TotalDeleted);
            TotalDeleted += 1;
        end;

        //UpdateSERVERSETUPS
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("Item Category Code", '%1', 'SERVERS SET UP');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums("Line Amount");
            XLValAmt4 := SQSalesLine."FTT-CST Unit Price";
            TextOption3 := StrSubstNo(LabelSERVER, TotalOfIntegHrdware, TotalofUAThardware, TotalOfProdHdware);
            if not UpdateCRMTemplate(TempLoc.Code + '!B65:B65', TextOption3) then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            if not UpdateCRMTemplate(TempLoc.Code + '!C65:C65', StrSubstNo('%1', (TotalOfProdHdware + TotalofUAThardware + TotalOfIntegHrdware))) then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            //>>Dan
            if not UpdateCRMTemplate(TempLoc.Code + '!H65:H65', SQSalesLine."FTT-CST Comments Fluent") then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            //<<Dan
            IF SQSalesLine."FTT-CST Cost Type" = SQSalesLine."FTT-CST Cost Type"::NRC then begin
                if not UpdateCRMTemplate(TempLoc.Code + '!D65:D65', pCurrSymbol + Format(XLValAmt4)) then
                    Error('Error on the LCFSYRC');
                Sleep(2000);
                if not UpdateCRMTemplate(TempLoc.Code + '!E65:E65', pCurrSymbol + Format(0)) then
                    Error('Error on the LCFSYRC');
                Sleep(2000);
            end else if SQSalesLine."FTT-CST Cost Type" = SQSalesLine."FTT-CST Cost Type"::MRC then begin
                if not UpdateCRMTemplate(TempLoc.Code + '!D65:D65', pCurrSymbol + Format(0)) then
                    Error('Error on the LCFSYRC');
                Sleep(2000);
                if not UpdateCRMTemplate(TempLoc.Code + '!E65:E65', pCurrSymbol + Format(XLValAmt4)) then
                    Error('Error on the LCFSYRC');
                Sleep(2000);
            end;
        end else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (65 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (66 - TotalDeleted);
            TotalDeleted += 1;
        end;
        Sleep(2000);
        //UpdateHOSTING
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("Item Category Code", '%1', 'HOSTING & MANAGEMENT');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums("Line Amount");
            XLValAmt5 := SQSalesLine."FTT-CST Unit Price";
            if not UpdateCRMTemplate(TempLoc.Code + '!C67:C67', StrSubstNo('%1', SQSalesLine.Quantity)) then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            //>>Dan
            if not UpdateCRMTemplate(TempLoc.Code + '!H67:H67', SQSalesLine."FTT-CST Comments Fluent") then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            //<<Dan
            IF SQSalesLine."FTT-CST Cost Type" = SQSalesLine."FTT-CST Cost Type"::MRC then begin
                //if not UpdateCRMTemplate(TempLoc.Code + '!E67:E67', pCurrSymbol + Format((SQSalesLine."Line Amount" / 12))) then
                if not UpdateCRMTemplate(TempLoc.Code + '!E67:E67', pCurrSymbol + Format((XLValAmt5))) then
                    Error('Error on the LCFSYRC');
                Sleep(2000);
            end;
            //>> Update 101824
            IF SQSalesLine.Quantity = 0 THEN begin
                ptotalIndex += 1;
                pListofStartIndex[ptotalIndex] := (66 - TotalDeleted);
                pListOfEndIndex[ptotalIndex] := (67 - TotalDeleted);
                TotalDeleted += 1;
            end;
            //<< Update 101824
        end else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (66 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (67 - TotalDeleted);
            TotalDeleted += 1;
        end;
        //>>Dan
        Sleep(2000);
        //UpdateInternationalLine
        InterLine := 0;

        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("Item Category Code", '%1', 'INTERNATIONAL LINE');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindSet() then begin

            StartLicenseDetIndex := 68;
            EndLicenseDetIndex := 67;
            repeat
                //SQSalesLine.CalcSums("Line Amount", Quantity, "FTT-CST Unit Price"); //Dan update 102324
                XLValAmt6 := SQSalesLine."FTT-CST Unit Price";
                InterLine := SQSalesLine.Quantity;

                if not UpdateCRMTemplate(TempLoc.Code + '!B' + StrSubstNo('%1', StartLicenseDetIndex) + ':B' + StrSubstNo('%1', StartLicenseDetIndex), StrSubstNo('%1', SQSalesLine.Description)) then
                    Error('Error on the LCFSYRC');
                Sleep(2000);
                if not UpdateCRMTemplate(TempLoc.Code + '!C' + StrSubstNo('%1', StartLicenseDetIndex) + ':C' + StrSubstNo('%1', StartLicenseDetIndex), StrSubstNo('%1', SQSalesLine.Quantity)) then
                    Error('Error on the LCFSYRC');
                Sleep(2000);
                //>>Dan
                if not UpdateCRMTemplate(TempLoc.Code + '!H' + StrSubstNo('%1', StartLicenseDetIndex) + ':H' + StrSubstNo('%1', StartLicenseDetIndex), SQSalesLine."FTT-CST Comments Fluent") then
                    Error('Error on the LCFSYRC');
                Sleep(2000);
                //<<Dan
                IF SQSalesLine."FTT-CST Cost Type" = SQSalesLine."FTT-CST Cost Type"::MRC then begin
                    if not UpdateCRMTemplate(TempLoc.Code + '!E' + StrSubstNo('%1', StartLicenseDetIndex) + ':E' + StrSubstNo('%1', StartLicenseDetIndex), pCurrSymbol + Format(XLValAmt6)) then
                        Error('Error on the LCFSYRC');
                    Sleep(2000);
                end else if SQSalesLine."FTT-CST Cost Type" = SQSalesLine."FTT-CST Cost Type"::NRC then begin
                    if not UpdateCRMTemplate(TempLoc.Code + '!D' + StrSubstNo('%1', StartLicenseDetIndex) + ':D' + StrSubstNo('%1', StartLicenseDetIndex), pCurrSymbol + Format(XLValAmt6)) then
                        Error('Error on the LCFSYRC');
                    Sleep(2000);
                end;
                StartLicenseDetIndex += 1;
                EndLicenseDetIndex += 1;
                Sleep(2000);
            // IF InterLine = 0 THEN begin
            //     ptotalIndex += 1;
            //     pListofStartIndex[ptotalIndex] := (67 - TotalDeleted);
            //     pListOfEndIndex[ptotalIndex] := (68 - TotalDeleted);
            //     TotalDeleted += 1;
            // end;
            until SQSalesLine.Next() = 0;

            for I := StartLicenseDetIndex to 72 do begin
                ptotalIndex += 1;
                pListofStartIndex[ptotalIndex] := (EndLicenseDetIndex - TotalDeleted);
                pListOfEndIndex[ptotalIndex] := (I - TotalDeleted);
                StartLicenseDetIndex += 1;
                EndLicenseDetIndex += 1;
                TotalDeleted += 1;
            end;

        end else begin
            //ptotalIndex += 1;
            //pListofStartIndex[ptotalIndex] := (67 - TotalDeleted);
            //pListOfEndIndex[ptotalIndex] := (68 - TotalDeleted);
            //TotalDeleted += 1;
            StartLicenseDetIndex := 68;
            EndLicenseDetIndex := 67;
            for I := StartLicenseDetIndex to 72 do begin
                ptotalIndex += 1;
                pListofStartIndex[ptotalIndex] := (EndLicenseDetIndex - TotalDeleted);
                pListOfEndIndex[ptotalIndex] := (I - TotalDeleted);
                StartLicenseDetIndex += 1;
                EndLicenseDetIndex += 1;
                TotalDeleted += 1;
            end;
        end;
        //<<Dan
        Sleep(2000);
        //UpdateSHAREDCONNECT
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("Item Category Code", '%1|%2', 'SHARED MRC C-C', 'SHARED NRC C-C');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums(Quantity);

            repeat

                if SQSalesLine."Item Category Code" = 'SHARED NRC C-C' then begin
                    TotalofSharedConnectNRC += SQSalesLine."FTT-CST Unit Price";
                    TotalofSharedConnectNRC2 := SQSalesLine."FTT-CST Unit Price"; //Update 101524
                end;
                if SQSalesLine."Item Category Code" = 'SHARED MRC C-C' then begin
                    TotalofSharedConnectMRC += SQSalesLine."Line Amount";
                    TotalofSharedConnectMRC2 := SQSalesLine."FTT-CST Unit Price"; //Update 101524
                end;
            until SQSalesLine.Next() = 0;
            //>>Dan Commented
            //if not UpdateCRMTemplate(TempLoc.Code + '!C70:C70', StrSubstNo('%1', SQSalesLine.Quantity)) then
            //Error('Error on the LCFSYRC');
            //Added
            if not UpdateCRMTemplate(TempLoc.Code + '!H74:H74', SQSalesLine."FTT-CST Comments Fluent") then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            //<<Dan
            //>>Update 101524
            /*
            if TotalofSharedConnectNRC <> 0 then begin
                if not UpdateCRMTemplate(TempLoc.Code + '!D70:D70', pCurrSymbol + Format(TotalofSharedConnectNRC)) then
                    Error('Error on the LCFSYRC');
            end;
            if TotalofSharedConnectMRC <> 0 then begin
                if not UpdateCRMTemplate(TempLoc.Code + '!E70:E70', pCurrSymbol + Format((TotalofSharedConnectMRC / 12))) then
                    Error('Error on the LCFSYRC');
            end;
            */
            if TotalofSharedConnectNRC2 <> 0 then begin //NRD - 04112024 - Uncomment
                if not UpdateCRMTemplate(TempLoc.Code + '!D74:D74', pCurrSymbol + Format(TotalofSharedConnectNRC2)) then
                    Error('Error on the LCFSYRC');
                Sleep(2000);
            end;
            if TotalofSharedConnectMRC2 <> 0 then begin //NRD - 04112024 - Uncomment
                if not UpdateCRMTemplate(TempLoc.Code + '!E74:E74', pCurrSymbol + Format(TotalofSharedConnectMRC2)) then
                    Error('Error on the LCFSYRC');
                Sleep(2000);
            end;
            //<<Update 101524

        end else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (72 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (73 - TotalDeleted);
            TotalDeleted += 1;
        end;
        Sleep(2000);
        //UpdateDEDICATEDCONNECT
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("Item Category Code", '%1|%2', 'DEDICATED MRC C-C', 'DEDICATED NRC C-C');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums(Quantity);

            repeat

                if SQSalesLine."Item Category Code" = 'DEDICATED NRC C-C' then begin
                    TotalofDEDICATEDConnectNRC += SQSalesLine."Unit Price";
                    TotalofDEDICATEDConnectNRC2 := SQSalesLine."FTT-CST Unit Price"; //Update 101524
                End;
                if SQSalesLine."Item Category Code" = 'DEDICATED MRC C-C' then begin
                    TotalofDEDICATEDConnectMRC += SQSalesLine."Line Amount";
                    TotalofDEDICATEDConnectMRC2 := SQSalesLine."FTT-CST Unit Price"; //Update 101524
                end;
            until SQSalesLine.Next() = 0;
            //>>Dan
            //if not UpdateCRMTemplate(TempLoc.Code + '!C71:C71', StrSubstNo('%1', SQSalesLine.Quantity)) then
            //    Error('Error on the LCFSYRC');
            //Added
            if not UpdateCRMTemplate(TempLoc.Code + '!H75:H75', SQSalesLine."FTT-CST Comments Fluent") then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            //<<Dan
            //>>Update 101524
            /*
            IF TotalofDEDICATEDConnectNRC <> 0 then begin
                if not UpdateCRMTemplate(TempLoc.Code + '!D71:D71', pCurrSymbol + Format(TotalofDEDICATEDConnectNRC)) then
                    Error('Error on the LCFSYRC');
            end;
            if TotalofDEDICATEDConnectMRC <> 0 then begin
                if not UpdateCRMTemplate(TempLoc.Code + '!E71:E71', pCurrSymbol + Format((TotalofDEDICATEDConnectMRC / 12))) then
                    Error('Error on the LCFSYRC');
            end;
            */
            IF TotalofDEDICATEDConnectNRC2 <> 0 then begin //NRD - 04112024 - Uncomment
                if not UpdateCRMTemplate(TempLoc.Code + '!D75:D75', pCurrSymbol + Format(TotalofDEDICATEDConnectNRC2)) then
                    Error('Error on the LCFSYRC');
                Sleep(2000);
            end;
            if TotalofDEDICATEDConnectMRC2 <> 0 then begin //NRD - 04112024 - Uncomment
                if not UpdateCRMTemplate(TempLoc.Code + '!E75:E75', pCurrSymbol + Format(TotalofDEDICATEDConnectMRC2)) then
                    Error('Error on the LCFSYRC');
                Sleep(2000);
            end;
            //<<Update 101524
        end else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (73 - TotalDeleted); //Mark this change minus 1 up to UpdateHosting for deleting
            pListOfEndIndex[ptotalIndex] := (74 - TotalDeleted);
            TotalDeleted += 1;
        end;
        Sleep(2000);
    end;

    local procedure GetInternationalLineTotal(pSalesQuote2: Record "Sales Header"): decimal
    var
        SQSalesLine: Record "Sales Line";
    begin
        InterLineAddConn := 0;
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("Item Category Code", '%1', 'INTERNATIONAL LINE');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums("Line Amount");
            InterLineAddConn := SQSalesLine."Line Amount";
        End;
        Exit(InterLineAddConn);
    end;

    local procedure GetYRCPriceFeeds(ItemCode: code[50]; pSalesQuote3: Record "Sales Header"; pLocationCode: code[20]): Decimal
    var
        salesline_l: Record "Sales Line";
    begin
        salesline_l.Reset();
        salesline_l.SetRange("Document Type", pSalesQuote3."Document Type");
        salesline_l.SetRange("Document No.", pSalesQuote3."No.");
        salesline_l.SetRange(Type, salesline_l.Type::Item);
        salesline_l.SetRange("FTT-CST Cost Type", salesline_l."FTT-CST Cost Type"::YRC);
        salesline_l.SetRange("No.", ItemCode);
        salesline_l.SetRange("FTT-CST Location Code", pLocationCode);
        if salesline_l.FindFirst() then
            exit(salesline_l."Line Amount"); //Dan Price only not the amount 
                                             //exit(salesline_l."Unit Price"); //Dan

    end;
    //Nimrod Dan
    procedure UpdateCrossConnectLines(pSalesQuote2: Record "Sales Header"; pCurrSymbol: Text[10]; var ptotalIndex: integer; var pListofStartIndex: array[100] of integer; var pListOfEndIndex: array[100] of integer; var TotalDeleted: Integer)
    var
        CrossConnectLines: Record "FTT-CST Cross Connect Lines";
        CrossConnectLines2: Record "FTT-CST Cross Connect Lines";
        CrossConnectLines3: Record "FTT-CST Cross Connect Lines";
        lSQ: Record "Sales Line";
        ListofStartIndexTemp: array[100] of integer;
        ListofEndIndexTemp: array[100] of integer;
        totalIndexTemp: integer;
        I: integer;
        TotalCountOfLicense: integer;
        StartLicenseDetIndex: Integer;
        StartLicenseDetIndex2: Integer;
        EndLicenseDetIndex: integer;
        SalesLineItemprice, SalesLineItemprice2, SalesLineItemprice3, SalesLineItemprice4, SalesLineItemprice5 : Decimal;
        SalesLineQty2, SalesLineQty3, SalesLineQty4, SalesLineQty5 : Decimal;
        SalesLineQuantity, SharedConnect, DedicatedConnect : decimal;
    begin
        //UpdateTakerFeeds  //NRD - fix
        InitializedVariables();
        FluentCommet := '';
        SalesLineItemprice4 := 0;
        SalesLineItemprice2 := 0;
        SalesLineItemprice3 := 0;
        SalesLineItemprice5 := 0;
        SalesLineQty4 := 0;
        SalesLineQty2 := 0;
        SalesLineQty3 := 0;
        SalesLineQty5 := 0;
        SharedConnect := 0;
        DedicatedConnect := 0;
        //NRD - 04112024
        CrossConnectLines3.Reset();
        CrossConnectLines3.SetRange("Document Type", pSalesQuote2."Document Type");
        CrossConnectLines3.SetRange("Document No.", pSalesQuote2."No.");
        CrossConnectLines3.SetRange("FTT-CST Location Code", TempLoc.Code); //dan
        if CrossConnectLines3.IsEmpty then begin
            StartLicenseDetIndex := 79;
            EndLicenseDetIndex := 78;
            for I := StartLicenseDetIndex to 104 do begin
                ptotalIndex += 1;
                pListofStartIndex[ptotalIndex] := (EndLicenseDetIndex - TotalDeleted);
                pListOfEndIndex[ptotalIndex] := (I - TotalDeleted);
                StartLicenseDetIndex += 1;
                EndLicenseDetIndex += 1;
                TotalDeleted += 1;
            end;
            exit;
        end;
        //+
        CrossConnectLines.Reset();
        CrossConnectLines.SetRange("Document Type", pSalesQuote2."Document Type");
        CrossConnectLines.SetRange("Document No.", pSalesQuote2."No.");
        CrossConnectLines.SetRange("FTT-CST Location Code", TempLoc.Code); //dan
        CrossConnectLines.SetFilter("Item Category Code", '%1|%2', 'NS TAKER FEED', 'STANDARD TAKER FEED');
        if CrossConnectLines.FindSet() then begin
            StartLicenseDetIndex := 80;
            EndLicenseDetIndex := 79;
            repeat
                SalesLineQuantity := 0;
                SalesLineQuantity := GetQuantity(CrossConnectLines."Item No.", pSalesQuote2, CrossConnectLines."FTT-CST Location Code");
                SalesLineItemprice := 0; //Dan 090924
                SalesLineItemprice := GetYRCPriceFeeds(CrossConnectLines."Item No.", pSalesQuote2, CrossConnectLines."FTT-CST Location Code");
                Commit();

                if not UpdateCRMTemplate(TempLoc.Code + '!B' + StrSubstNo('%1', StartLicenseDetIndex) + ':B' + StrSubstNo('%1', StartLicenseDetIndex), Format(CrossConnectLines.Description)) then
                    Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);
                if not UpdateCRMTemplate(TempLoc.Code + '!C' + StrSubstNo('%1', StartLicenseDetIndex) + ':C' + StrSubstNo('%1', StartLicenseDetIndex), (StrSubstNo('%1', CrossConnectLines."Quantity 1"))) then BEGIN
                    Error('Error on the FSDPYRCHOTCOLD');
                    SharedConnect += CrossConnectLines."Quantity 1";
                End;
                Sleep(2000);
                if not UpdateCRMTemplate(TempLoc.Code + '!D' + StrSubstNo('%1', StartLicenseDetIndex) + ':D' + StrSubstNo('%1', StartLicenseDetIndex), (StrSubstNo('%1', CrossConnectLines."Quantity 2"))) then Begin
                    Error('Error on the FSDPYRCHOTCOLD');
                    DedicatedConnect += CrossConnectLines."Quantity 2";
                End;
                Sleep(2000);
                if not UpdateCRMTemplate(TempLoc.Code + '!E' + StrSubstNo('%1', StartLicenseDetIndex) + ':E' + StrSubstNo('%1', StartLicenseDetIndex), (StrSubstNo('%1', CrossConnectLines."Quantity 3"))) then
                    Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);
                if not UpdateCRMTemplate(TempLoc.Code + '!F' + StrSubstNo('%1', StartLicenseDetIndex) + ':F' + StrSubstNo('%1', StartLicenseDetIndex), (StrSubstNo('%1', CrossConnectLines."Quantity 4"))) then
                    Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);
                if not UpdateCRMTemplate(TempLoc.Code + '!G' + StrSubstNo('%1', StartLicenseDetIndex) + ':G' + StrSubstNo('%1', StartLicenseDetIndex), pCurrSymbol + (StrSubstNo('%1', SalesLineItemprice))) then
                    Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);
                if CrossConnectLines."Item Category Code" = 'NS TAKER FEED' then begin
                    SalesLineItemprice2 += SalesLineItemprice;
                    SalesLineQty2 += SalesLineQuantity;
                    if not UpdateCRMTemplate(TempLoc.Code + '!H' + StrSubstNo('%1', StartLicenseDetIndex) + ':H' + StrSubstNo('%1', StartLicenseDetIndex), 'TRUE') then
                        Error('Error on the FSDPYRCHOTCOLD');

                end else BEGIN
                    SalesLineItemprice3 += SalesLineItemprice;
                    SalesLineQty3 += SalesLineQuantity;
                    if not UpdateCRMTemplate(TempLoc.Code + '!H' + StrSubstNo('%1', StartLicenseDetIndex) + ':H' + StrSubstNo('%1', StartLicenseDetIndex), 'FALSE') then
                        Error('Error on the FSDPYRCHOTCOLD');
                End;
                Sleep(2000);
                if not UpdateCRMTemplate(TempLoc.Code + '!I' + StrSubstNo('%1', StartLicenseDetIndex) + ':I' + StrSubstNo('%1', StartLicenseDetIndex), (StrSubstNo('%1', SalesLineQuantity))) then
                    Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);
                //>>Dan 102324
                if not UpdateCRMTemplate(TempLoc.Code + '!J' + StrSubstNo('%1', StartLicenseDetIndex) + ':J' + StrSubstNo('%1', StartLicenseDetIndex), (StrSubstNo('%1', FluentCommet))) then
                    Error('Error on the FSDPYRCHOTCOLD');
                //<<Dan 102324
                Sleep(2000);
                StartLicenseDetIndex += 1;
                EndLicenseDetIndex += 1;

            until CrossConnectLines.Next() = 0;
            Sleep(2000);
            for I := StartLicenseDetIndex to 102 do begin //nrd
                ptotalIndex += 1;
                pListofStartIndex[ptotalIndex] := (EndLicenseDetIndex - TotalDeleted);
                pListOfEndIndex[ptotalIndex] := (I - TotalDeleted);
                StartLicenseDetIndex += 1;
                EndLicenseDetIndex += 1;
                TotalDeleted += 1;
            end;
        end ELSE BEGIN
            //>>Update 101724
            StartLicenseDetIndex := 79; //NRD - 04112024
            EndLicenseDetIndex := 78; //NRD- 04112024
            for I := StartLicenseDetIndex to 102 do begin
                ptotalIndex += 1;
                pListofStartIndex[ptotalIndex] := (EndLicenseDetIndex - TotalDeleted);
                pListOfEndIndex[ptotalIndex] := (I - TotalDeleted);
                StartLicenseDetIndex += 1;
                EndLicenseDetIndex += 1;
                TotalDeleted += 1;
            end;
        END;
        //<<Update 101724
        Sleep(2000);
        //>>Update 101624
        //if not UpdateCRMTemplate(TempLoc.Code + '!D51:D51', pCurrSymbol + Format(SalesLineItemprice3)) then
        //Error('Error on the FSDPYRCHOTCOLD');
        //<<Update 101624    
        //UpdateMakerFeeds
        FluentCommet := '';
        CrossConnectLines2.Reset();
        CrossConnectLines2.SetRange("Document Type", pSalesQuote2."Document Type");
        CrossConnectLines2.SetRange("Document No.", pSalesQuote2."No.");
        CrossConnectLines2.Setrange("FTT-CST Location Code", TempLoc.Code); //dan
        CrossConnectLines2.SetFilter("Item Category Code", '%1|%2', 'NS MAKER FEED', 'STANDARD MAKER FEED');
        if CrossConnectLines2.FindSet() then begin
            StartLicenseDetIndex2 := 104;
            repeat
                SalesLineQuantity := 0;
                SalesLineQuantity := GetQuantity(CrossConnectLines2."Item No.", pSalesQuote2, CrossConnectLines2."FTT-CST Location Code");
                SalesLineItemprice := 0; //Dan 090924
                SalesLineItemprice := GetYRCPriceFeeds(CrossConnectLines2."Item No.", pSalesQuote2, CrossConnectLines2."FTT-CST Location Code"); //dan bug found fix

                if not UpdateCRMTemplate(TempLoc.Code + '!B' + StrSubstNo('%1', StartLicenseDetIndex2) + ':B' + StrSubstNo('%1', StartLicenseDetIndex2), FORMAT(CrossConnectLines2.Description)) then
                    Error('Error on the FSDPYRCHOTCOLD');
                Commit();
                Sleep(2000);
                if not UpdateCRMTemplate(TempLoc.Code + '!C' + StrSubstNo('%1', StartLicenseDetIndex2) + ':C' + StrSubstNo('%1', StartLicenseDetIndex2), (StrSubstNo('%1', CrossConnectLines2."Quantity 1"))) then begin
                    Error('Error on the FSDPYRCHOTCOLD');
                    SharedConnect += CrossConnectLines."Quantity 1";
                End;
                Sleep(2000);
                if not UpdateCRMTemplate(TempLoc.Code + '!D' + StrSubstNo('%1', StartLicenseDetIndex2) + ':D' + StrSubstNo('%1', StartLicenseDetIndex2), (StrSubstNo('%1', CrossConnectLines2."Quantity 2"))) then begin
                    Error('Error on the FSDPYRCHOTCOLD');
                    DedicatedConnect += CrossConnectLines."Quantity 2";
                End;
                Sleep(2000);
                if not UpdateCRMTemplate(TempLoc.Code + '!E' + StrSubstNo('%1', StartLicenseDetIndex2) + ':E' + StrSubstNo('%1', StartLicenseDetIndex2), (StrSubstNo('%1', CrossConnectLines2."Quantity 3"))) then
                    Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);
                if not UpdateCRMTemplate(TempLoc.Code + '!F' + StrSubstNo('%1', StartLicenseDetIndex2) + ':F' + StrSubstNo('%1', StartLicenseDetIndex2), (StrSubstNo('%1', CrossConnectLines2."Quantity 4"))) then
                    Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);
                if not UpdateCRMTemplate(TempLoc.Code + '!G' + StrSubstNo('%1', StartLicenseDetIndex2) + ':G' + StrSubstNo('%1', StartLicenseDetIndex2), pCurrSymbol + (StrSubstNo('%1', SalesLineItemprice))) then
                    Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);
                if CrossConnectLines2."Item Category Code" = 'NS MAKER FEED' then begin
                    SalesLineItemprice4 += SalesLineItemprice;
                    SalesLineQty4 += SalesLineQuantity;
                    if not UpdateCRMTemplate(TempLoc.Code + '!H' + StrSubstNo('%1', StartLicenseDetIndex2) + ':H' + StrSubstNo('%1', StartLicenseDetIndex2), 'TRUE') then
                        Error('Error on the FSDPYRCHOTCOLD');
                end else BEGIN
                    SalesLineItemprice5 += SalesLineItemprice;
                    SalesLineQty5 += SalesLineQuantity;
                    if not UpdateCRMTemplate(TempLoc.Code + '!H' + StrSubstNo('%1', StartLicenseDetIndex2) + ':H' + StrSubstNo('%1', StartLicenseDetIndex2), 'FALSE') then
                        Error('Error on the FSDPYRCHOTCOLD');
                End;
                Sleep(2000);
                if not UpdateCRMTemplate(TempLoc.Code + '!I' + StrSubstNo('%1', StartLicenseDetIndex2) + ':I' + StrSubstNo('%1', StartLicenseDetIndex2), (StrSubstNo('%1', SalesLineQuantity))) then
                    Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);
                //>>Dan 102324
                if not UpdateCRMTemplate(TempLoc.Code + '!J' + StrSubstNo('%1', StartLicenseDetIndex2) + ':J' + StrSubstNo('%1', StartLicenseDetIndex2), (StrSubstNo('%1', FluentCommet))) then
                    Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);
                //<<Dan 102324
                StartLicenseDetIndex2 += 1;
                Sleep(2000);

            until CrossConnectLines2.Next() = 0;
            //>>dan Update 102424
        end ELSE begin
            // StartLicenseDetIndex := 104;
            // EndLicenseDetIndex := 103;
            // for I := StartLicenseDetIndex to 104 do begin
            //     ptotalIndex += 1;
            //     pListofStartIndex[ptotalIndex] := (EndLicenseDetIndex - TotalDeleted);
            //     pListOfEndIndex[ptotalIndex] := (I - TotalDeleted);
            //     StartLicenseDetIndex += 1;
            //     EndLicenseDetIndex += 1;
            //     TotalDeleted += 1;
            // end;
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (104 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (103 - TotalDeleted);
            TotalDeleted += 1;
        end;
        //<<dan Update 102424
        //>>Update 101624
        if SalesLineItemprice3 <> 0 then begin //NRD - 04112024
            if not UpdateCRMTemplate(TempLoc.Code + '!D51:D51', pCurrSymbol + Format(SalesLineItemprice3)) then
                Error('Error on the FSDPYRCHOTCOLD');
        end;

        if SalesLineItemprice5 <> 0 then begin //NRD - 04112024
            if not UpdateCRMTemplate(TempLoc.Code + '!D52:D52', pCurrSymbol + Format(SalesLineItemprice5)) then
                Error('Error on the FSDPYRCHOTCOLD');
        end;

        if (SalesLineItemprice2 + SalesLineItemprice4) <> 0 then begin //NRD - 04112024
            if not UpdateCRMTemplate(TempLoc.Code + '!D53:D53', pCurrSymbol + Format(SalesLineItemprice2 + SalesLineItemprice4)) then
                Error('Error on the FSDPYRCHOTCOLD');
        end;

        //Quantity 
        if SalesLineQty3 <> 0 then begin //NRD - 04112024
            if not UpdateCRMTemplate(TempLoc.Code + '!C51:C51', Format(SalesLineQty3)) then
                Error('Error on the FSDPYRCHOTCOLD');
        end;
        if SalesLineQty5 <> 0 then begin //NRD - 04112024
            if not UpdateCRMTemplate(TempLoc.Code + '!C52:C52', Format(SalesLineQty5)) then
                Error('Error on the FSDPYRCHOTCOLD');
        end;

        if (SalesLineQty2 + SalesLineQty4) <> 0 then begin //NRD - 04112024
            if not UpdateCRMTemplate(TempLoc.Code + '!C53:C53', Format(SalesLineQty2 + SalesLineQty4)) then
                Error('Error on the FSDPYRCHOTCOLD');
        end;
        //<<Update 101624
    end;

    local Procedure AdditionalUpdate(pSQ: Record "Sales Header");
    var
        SQSalesLine: Record "Sales Line";
        SQSalesLine2: Record "Sales Line";
        TotalInvDiscount: Decimal;
        TextDiscount, TextUpdate : Text[1024];
        SndYrDisc: Decimal;
        C9Value, D9Value, C9Value2 : decimal;
    Begin
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSQ."Document Type");
        SQSalesLine.SetRange("Document No.", pSQ."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '<>%1', 'REDUNDANCY');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.Findfirst() then begin
            TextUpdate := StrSubstNo('Primary Site, %1', SQSalesLine."FTT-CST Sublocation");
            UpdateCRMTemplate(TempLoc.Code + '!B35:B35', TextUpdate);
            Sleep(2000);
            TextUpdate := StrSubstNo('Hosting - %1 %2 - YRC', TempLoc.Code, SQSalesLine."FTT-CST Sublocation");
            UpdateCRMTemplate(TempLoc.Code + '!B14:B14', TextUpdate);
            Sleep(2000);
            TextUpdate := StrSubstNo('Connectivity - %1 %2 - YRC + NRC', TempLoc.Code, SQSalesLine."FTT-CST Sublocation");
            UpdateCRMTemplate(TempLoc.Code + '!B15:B15', TextUpdate);
            Sleep(2000);
            TextUpdate := StrSubstNo('Hosting - %1 %2 - YRC', TempLoc.Code, SQSalesLine."FTT-CST Sublocation");
            UpdateCRMTemplate(TempLoc.Code + '!B28:B28', TextUpdate);
            Sleep(2000);
            TextUpdate := StrSubstNo('Connectivity - %1 %2 - YRC + NRC', TempLoc.Code, SQSalesLine."FTT-CST Sublocation");
            UpdateCRMTemplate(TempLoc.Code + '!B29:B29', TextUpdate);
            Sleep(2000);
        End;
    End;
    //>>Update 101624
    procedure UpdateCrossConnectLines2(pSalesQuote2: Record "Sales Header"): boolean
    var
        CrossConnectLines: Record "FTT-CST Cross Connect Lines";
        CrossConnectLines2: Record "FTT-CST Cross Connect Lines";
        HasValue: Boolean;
    begin
        HasValue := False;
        CrossConnectLines.Reset();
        CrossConnectLines.SetRange("Document Type", pSalesQuote2."Document Type");
        CrossConnectLines.SetRange("Document No.", pSalesQuote2."No.");
        CrossConnectLines.SetRange("FTT-CST Location Code", TempLoc.Code); //dan
        CrossConnectLines.SetFilter("Item Category Code", '%1|%2', 'NS TAKER FEED', 'STANDARD TAKER FEED');
        if CrossConnectLines.FindSet() then BEGIN
            HasValue := TRUE;
            Exit(HasValue);
        End;
        CrossConnectLines2.Reset();
        CrossConnectLines2.SetRange("Document Type", pSalesQuote2."Document Type");
        CrossConnectLines2.SetRange("Document No.", pSalesQuote2."No.");
        CrossConnectLines2.Setrange("FTT-CST Location Code", TempLoc.Code); //dan
        CrossConnectLines2.SetFilter("Item Category Code", '%1|%2', 'NS MAKER FEED', 'STANDARD MAKER FEED');
        if CrossConnectLines2.FindSet() then begin
            HasValue := TRUE;
            Exit(HasValue);
        End;
    end;
    //<<Update 101624
    local procedure GetQuantity(ItemCode: code[50]; pSalesQuote3: Record "Sales Header"; pLocationCode: code[20]): Decimal
    var
        salesline_l: Record "Sales Line";
    begin
        salesline_l.Reset();
        salesline_l.SetRange("Document Type", pSalesQuote3."Document Type");
        salesline_l.SetRange("Document No.", pSalesQuote3."No.");
        salesline_l.SetRange(Type, salesline_l.Type::Item);
        salesline_l.SetRange("FTT-CST Cost Type", salesline_l."FTT-CST Cost Type"::YRC);
        salesline_l.SetRange("No.", ItemCode);
        salesline_l.SetRange("FTT-CST Location Code", pLocationCode);
        if salesline_l.FindFirst() then begin
            FluentCommet := salesline_l."FTT-CST Comments Fluent";
            exit(salesline_l."Quantity");
        End;
    end;

    procedure UpdateCRMTemplate(pTemplateRange: text[250]; pValue: Text[1024]): Boolean
    var
        Url: Text;

        ResponseMessage: HttpResponseMessage;
        JObject: JsonObject;
        Response: HttpResponseMessage;
        ApiResult: Text;
        PostUrl: Text;
        APPName: Text;
        GMAILMGT: Record "GMAIL Maintenance Setup";
        myHttpContent: HttpContent;
        myHttpHeaders: HttpHeaders;
        lHeaders: HttpHeaders;
        request: HttpRequestMessage;
        MyHttpClient: HttpClient;
        MyHttpResponseMessage: HttpResponseMessage;
        myToken: Text;
        myContentHeaders: HttpHeaders;
        Jtoken: JsonToken;
        JArray: JsonArray;
        isSuccess: Boolean;
    begin
        if not GMAILMGT.Get() then
            exit;

        isSuccess := false;
        ClearLastError;

        PostUrl := 'https://sheets.googleapis.com/v4/spreadsheets/' + TestSpreedID + '/values/' + pTemplateRange + '?includeValuesInResponse=true&responseValueRenderOption=FORMATTED_VALUE&valueInputOption=USER_ENTERED';
        myHttpContent.WriteFrom(CreateSHJson(pTemplateRange, pValue));
        request.SetRequestUri(PostUrl);
        myHttpHeaders.Clear();
        lHeaders.Clear();

        myHttpContent.GetHeaders(lHeaders);
        lHeaders.Remove('Content-Type');
        lHeaders.Add('Content-Type', 'application/json');
        myHttpContent.GetHeaders(lHeaders);
        request.GetHeaders(myHttpHeaders);

        myHttpHeaders.Clear();
        myHttpHeaders.Add('Authorization', 'Bearer ' + GMAILMGT."API Token Key");
        myHttpHeaders.Add('Scopes', 'https://www.googleapis.com/auth/drive' +
                                    'https://www.googleapis.com/auth/drive.file' +
                                    'https://www.googleapis.com/auth/spreadsheets');
        request.Content := myHttpContent;
        request.GetHeaders(myHttpHeaders);
        request.Method := 'PUT';

        isSuccess := MyHttpClient.Send(request, MyHttpResponseMessage);
        //Message('%1', MyHttpResponseMessage.HttpStatusCode);
        if isSuccess then begin
            //Message('%1', MyHttpResponseMessage.HttpStatusCode);
            if MyHttpResponseMessage.HttpStatusCode = 404 then
                exit(false);

            MyHttpResponseMessage.Content().ReadAs(myToken);
            JObject.ReadFrom(myToken);

            exit(true);
        end;

        exit(false);
    end;

    procedure GetSheetIDFromCRMTemplate(): Integer
    var
        Url: Text;

        ResponseMessage: HttpResponseMessage;
        JObject: JsonObject;
        Response: HttpResponseMessage;
        ApiResult: Text;
        PostUrl: Text;
        APPName: Text;
        GMAILMGT: Record "GMAIL Maintenance Setup";
        myHttpContent: HttpContent;
        myHttpHeaders: HttpHeaders;
        lHeaders: HttpHeaders;
        request: HttpRequestMessage;
        MyHttpClient: HttpClient;
        MyHttpResponseMessage: HttpResponseMessage;
        myToken: Text;
        myContentHeaders: HttpHeaders;
        Jtoken: JsonToken;
        JArray: JsonArray;
        isSuccess: Boolean;
        lJsonBuff: Record "JSON Buffer";
    begin
        if not GMAILMGT.Get() then
            exit;

        isSuccess := false;
        ClearLastError;

        PostUrl := 'https://sheets.googleapis.com/v4/spreadsheets/' + TestSpreedID;

        request.SetRequestUri(PostUrl);
        myHttpHeaders.Clear();
        lHeaders.Clear();

        myHttpContent.GetHeaders(lHeaders);
        lHeaders.Remove('Content-Type');
        lHeaders.Add('Content-Type', 'application/json');
        myHttpContent.GetHeaders(lHeaders);
        request.GetHeaders(myHttpHeaders);

        myHttpHeaders.Clear();
        myHttpHeaders.Add('Authorization', 'Bearer ' + GMAILMGT."API Token Key");
        myHttpHeaders.Add('Scopes', 'https://www.googleapis.com/auth/drive' +
                          'https://www.googleapis.com/auth/drive.file' +
                          'https://www.googleapis.com/auth/drive.readonly' +
                          'https://www.googleapis.com/auth/spreadsheets.readonly' +
                          'https://www.googleapis.com/auth/spreadsheets');
        request.Content := myHttpContent;
        request.GetHeaders(myHttpHeaders);
        request.Method := 'GET';

        isSuccess := MyHttpClient.Send(request, MyHttpResponseMessage);

        if isSuccess then begin
            MyHttpResponseMessage.Content().ReadAs(myToken);
            JObject.ReadFrom(myToken);

            if JObject.Get('sheets', Jtoken) then
                JArray := Jtoken.AsArray();
            exit(ReadJsonArray(JArray));
        end;

        EXIT(0);
    end;

    local procedure ReadJsonArray(JItemsArray: JsonArray): Integer;
    var
        JItemLineToken: JsonToken;
        JItemLine: JsonObject;
        JItemDesc: JsonToken;
        JsonObject2: JsonObject;
        JSTONtoketn3: JsonToken;
        OutPut: Text;
    begin

        foreach JitemLineToken in JItemsArray do begin

            JItemLine := JItemLineToken.AsObject();
            if JItemLine.Get('properties', JItemDesc) then
                if JItemDesc.IsObject then
                    JItemDesc.WriteTo(OutPut);
            JsonObject2.ReadFrom(OutPut);
            if JsonObject2.Get('sheetId', JSTONtoketn3) then
                EXIT(JSTONtoketn3.AsValue().AsInteger());
        end;
    end;

    procedure CreateaCopyCRMTemplate(): Text[1024]
    var
        Url: Text;

        ResponseMessage: HttpResponseMessage;
        JObject: JsonObject;
        Response: HttpResponseMessage;
        ApiResult: Text;
        PostUrl: Text;
        APPName: Text;
        GMAILMGT: Record "GMAIL Maintenance Setup";
        myHttpContent: HttpContent;
        myHttpHeaders: HttpHeaders;
        lHeaders: HttpHeaders;
        request: HttpRequestMessage;
        MyHttpClient: HttpClient;
        MyHttpResponseMessage: HttpResponseMessage;
        myToken: Text;
        myContentHeaders: HttpHeaders;
        Jtoken: JsonToken;
        JArray: JsonArray;
        isSuccess: Boolean;
    begin
        if not GMAILMGT.Get() then
            exit;

        isSuccess := false;
        ClearLastError;

        PostUrl := 'https://www.googleapis.com/drive/v3/files/' + GMAILMGT."CRM Template SHID" + '/copy?enforceSingleParent=true&ignoreDefaultVisibility=true';

        request.SetRequestUri(PostUrl);
        myHttpHeaders.Clear();
        lHeaders.Clear();

        myHttpContent.GetHeaders(lHeaders);
        lHeaders.Remove('Content-Type');
        lHeaders.Add('Content-Type', 'application/json');
        myHttpContent.GetHeaders(lHeaders);
        request.GetHeaders(myHttpHeaders);

        myHttpHeaders.Clear();
        myHttpHeaders.Add('Authorization', 'Bearer ' + GMAILMGT."API Token Key");
        myHttpHeaders.Add('Scopes', 'https://www.googleapis.com/auth/drive' +
                                    'https://www.googleapis.com/auth/drive.file' +
                                    'https://www.googleapis.com/auth/drive.photos.readonly' +
                                    'https://www.googleapis.com/auth/drive.appdata');
        request.Content := myHttpContent;
        request.GetHeaders(myHttpHeaders);
        request.Method := 'POST';

        isSuccess := MyHttpClient.Send(request, MyHttpResponseMessage);

        if isSuccess then begin
            MyHttpResponseMessage.Content().ReadAs(myToken);
            JObject.ReadFrom(myToken);

            if JObject.Get('id', Jtoken) then
                exit(Jtoken.AsValue().AsText());
        end;

        exit('');
    end;

    //>>dan 091024
    procedure AddSheets();
    var
        jObj, JObject, jObject2, jObject3, jObject4 : JsonObject;
        PostUrl: Text;
        GMAILMGT: Record "GMAIL Maintenance Setup";
        Txt: Text;
    begin
        if not GmailMgtSetup.Get() then
            exit;

        jObject.Add('destinationSpreadsheetId', TestSpreedID);
        jObject.WriteTo(txt);

        PostUrl := PostUrls(FALSE);
        PostURLFunction(txt, PostUrl);

    end;

    procedure UpdateSheets(pSheetID: integer; pLocCode: Code[20])
    var
        jObj, JObject, jObject2, jObject3, jObject4 : JsonObject;
        jArr, jArray, jArray2 : JsonArray;
        PostUrl: Text;
        GMAILMGT: Record "GMAIL Maintenance Setup";
        Txt: Text;
    begin

        if not GmailMgtSetup.Get() then
            exit;

        jObject.Add('requests', jArr);
        jObject3.Add('properties', jObject4);
        jObject3.Add('fields', 'title');
        jObject4.Add('sheetId', ForMat(pSheetID));
        jObject4.Add('title', pLocCode);
        jObject2.ADD('updateSheetProperties', jObject3);
        jArr.Add(jObject2);
        jObject.WriteTo(txt);

        PostUrl := PostUrls(True);
        PostURLFunction(txt, PostUrl);
    end;

    procedure PostURLs(pAddSheet: Boolean): Text
    var
        PostURL: Text[1024];
    Begin
        CASE pAddSheet OF
            TRUE:
                PostURL := 'https://sheets.googleapis.com/v4/spreadsheets/' + TestSpreedID + ':batchUpdate';
            Else
                PostUrl := 'https://sheets.googleapis.com/v4/spreadsheets/' + TestSpreedID + '/sheets/' + FORMAT(SheetID) + ':copyTo';
        End;
        Exit(PostUrl)
    End;

    Procedure PostURLFunction(pTxt: Text[1024]; pPostURL: Text[1024])
    var
        ResponseMessage: HttpResponseMessage;
        Response: HttpResponseMessage;
        jObject: JsonObject;
        jArray: JsonArray;
        jToken: JsonToken;
        GMAILMGT: Record "GMAIL Maintenance Setup";
        myHttpContent: HttpContent;
        myHttpHeaders: HttpHeaders;
        lHeaders: HttpHeaders;
        request: HttpRequestMessage;
        MyHttpClient, HttpCli : HttpClient;
        MyHttpResponseMessage: HttpResponseMessage;
        myToken: Text;
        myContentHeaders: HttpHeaders;
        isSuccess: Boolean;
        ResponseTxt: Text;
        j: JsonObject;
    Begin
        isSuccess := false;
        ClearLastError;

        myHttpContent.WriteFrom(ptxt);
        request.SetRequestUri(pPostUrl);
        myHttpHeaders.Clear();
        lHeaders.Clear();

        myHttpContent.GetHeaders(lHeaders);

        lHeaders.Remove('Content-Type');
        lHeaders.Add('Content-Type', 'application/json');
        myHttpContent.GetHeaders(lHeaders);
        request.GetHeaders(myHttpHeaders);
        myHttpHeaders.Clear();

        myHttpHeaders.Add('Authorization', 'Bearer ' + GmailMgtSetup."API Token Key");
        myHttpHeaders.Add('Scopes', 'https://www.googleapis.com/auth/drive' +
                          'https://www.googleapis.com/auth/drive.file' +
                          'https://www.googleapis.com/auth/spreadsheets');
        request.Content := myHttpContent;
        request.GetHeaders(myHttpHeaders);
        request.Method := 'POST';

        isSuccess := MyHttpClient.Send(request, MyHttpResponseMessage);

        SheetID2 := '';
        IF MyHttpResponseMessage.IsSuccessStatusCode() THEN begin
            MyHttpResponseMessage.Content().ReadAs(ResponseTxt);
            j.ReadFrom(ResponseTxt);
            SheetID2 := GetJsonTextField(j, 'sheetId');
        end;
    End;

    ProceDure getJsonTextField(Jobj: JsonObject; pTxt: Text): Text
    Var
        Result: JsonToken;
    Begin
        IF jObj.Get(pTxt, Result) then
            Exit(Result.AsValue().AsText());
    End;

    procedure GetAllLocationCode(pSQ: Record "sales header"): Boolean
    var
        lSQ: Record "sales line";
    Begin
        IF NOT TempLoc.IsTemporary THEN
            Exit(False);

        TempLoc.DELETEALL;
        CLEAR(lSQ);
        lSQ.SetRange("Document Type", pSQ."Document Type");
        lSQ.SetRange("Document No.", pSQ."No.");
        IF lSQ.FINDSET THEN begin
            repeat
                TempLoc.INIT;
                TempLoc.Code := lSQ."FTT-CST Location Code";
                IF TempLoc.Insert THEN;
            until lSQ.Next = 0;
        end Else
            Exit(False);
        Exit(True);
    End;
    //<<Dan 091024
    procedure DeleteCopyCRMTemplate(pText: Text[1024])
    var
        Url: Text;

        ResponseMessage: HttpResponseMessage;
        JObject: JsonObject;
        Response: HttpResponseMessage;
        ApiResult: Text;
        PostUrl: Text;
        APPName: Text;
        GMAILMGT: Record "GMAIL Maintenance Setup";
        myHttpContent: HttpContent;
        myHttpHeaders: HttpHeaders;
        lHeaders: HttpHeaders;
        request: HttpRequestMessage;
        MyHttpClient: HttpClient;
        MyHttpResponseMessage: HttpResponseMessage;
        myToken: Text;
        myContentHeaders: HttpHeaders;
        Jtoken: JsonToken;
        JArray: JsonArray;
        isSuccess: Boolean;

    begin
        if not GMAILMGT.Get() then
            exit;

        isSuccess := false;
        ClearLastError;


        PostUrl := 'https://www.googleapis.com/drive/v3/files/' + TestSpreedID + '?enforceSingleParent=true';

        request.SetRequestUri(PostUrl);
        myHttpHeaders.Clear();
        lHeaders.Clear();

        myHttpContent.GetHeaders(lHeaders);
        lHeaders.Remove('Content-Type');
        lHeaders.Add('Content-Type', 'application/json');
        myHttpContent.GetHeaders(lHeaders);
        request.GetHeaders(myHttpHeaders);

        myHttpHeaders.Clear();
        myHttpHeaders.Add('Authorization', 'Bearer ' + GMAILMGT."API Token Key");
        myHttpHeaders.Add('Scopes', 'https://www.googleapis.com/auth/drive' +
                                    'https://www.googleapis.com/auth/drive.file' +
                                    'https://www.googleapis.com/auth/drive.appdata');
        request.Content := myHttpContent;
        request.GetHeaders(myHttpHeaders);
        request.Method := 'DELETE';

        isSuccess := MyHttpClient.Send(request, MyHttpResponseMessage);
    end;


    local procedure CreateSHJson(pTemplateRange: Text; pValue: text): Text
    var
        MyJobject: JsonObject;
        ThingJObject: JsonArray;
        ThingJObject2: JsonArray;
        JsonData: Text;
    begin

        MyJobject.Add('majorDimension', 'COLUMNS');
        MyJobject.Add('range', pTemplateRange);

        Clear(ThingJObject);
        Clear(ThingJObject2);

        ThingJObject2.Add(pValue);
        ThingJObject.Add(ThingJObject2);
        MyJobject.Add('values', ThingJObject);
        MyJobject.WriteTo(JsonData);

        //Message(JsonData);
        exit(JsonData);
    end;

    procedure DownloadCRMTemplate(pFileName: Text; SendEmail2: Boolean; Var Instreadm2: InStream)
    var

        ResponseMessage: HttpResponseMessage;
        JObject: JsonObject;
        Response: HttpResponseMessage;
        PostUrl: Text;
        GMAILMGT: Record "GMAIL Maintenance Setup";
        myHttpContent: HttpContent;
        myHttpHeaders: HttpHeaders;
        lHeaders: HttpHeaders;
        request: HttpRequestMessage;
        MyHttpClient: HttpClient;
        MyHttpResponseMessage: HttpResponseMessage;
        myToken: Text;
        myContentHeaders: HttpHeaders;
        isSuccess: Boolean;

        TestFileName: Text;
    begin
        if not GMAILMGT.Get() then
            exit;

        isSuccess := false;
        ClearLastError;

        PostUrl := 'https://www.googleapis.com/drive/v3/files/' + TestSpreedID + '/export?mimeType=application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';

        request.SetRequestUri(PostUrl);
        myHttpHeaders.Clear();
        lHeaders.Clear();

        myHttpContent.GetHeaders(lHeaders);
        lHeaders.Remove('Content-Type');
        lHeaders.Add('Content-Type', 'application/json');
        myHttpContent.GetHeaders(lHeaders);
        request.GetHeaders(myHttpHeaders);
        myHttpHeaders.Clear();

        myHttpHeaders.Add('Authorization', 'Bearer ' + GMAILMGT."API Token Key");
        myHttpHeaders.Add('Scopes', 'https://www.googleapis.com/auth/drive' +
                          'https://www.googleapis.com/auth/drive.file' +
                          'https://www.googleapis.com/auth/drive.meet.readonly' +
                          'https://www.googleapis.com/auth/drive.readonly');
        request.Content := myHttpContent;
        request.GetHeaders(myHttpHeaders);
        request.Method := 'GET';
        isSuccess := MyHttpClient.Send(request, MyHttpResponseMessage);

        if isSuccess then begin
            MyHttpResponseMessage.Content().ReadAs(Instreadm2);

            TestFileName := pFileName + '.xlsx';

            If not SendEmail2 then
                DownloadFromStream(Instreadm2, '', '', '', TestFileName);
        end;
    end;

    procedure DeleteZeroValueInCRMTemplate(ptext: text)
    var

        ResponseMessage: HttpResponseMessage;
        JObject: JsonObject;
        Response: HttpResponseMessage;
        PostUrl: Text;
        GMAILMGT: Record "GMAIL Maintenance Setup";
        myHttpContent: HttpContent;
        myHttpHeaders: HttpHeaders;
        lHeaders: HttpHeaders;
        request: HttpRequestMessage;
        MyHttpClient: HttpClient;
        MyHttpResponseMessage: HttpResponseMessage;
        myToken: Text;
        myContentHeaders: HttpHeaders;
        isSuccess: Boolean;

        TestFileName: Text;
    begin
        if not GMAILMGT.Get() then
            exit;

        isSuccess := false;
        ClearLastError;

        PostUrl := 'https://sheets.googleapis.com/v4/spreadsheets/' + TestSpreedID + ':batchUpdate';

        myHttpContent.WriteFrom(ptext);

        request.SetRequestUri(PostUrl);
        myHttpHeaders.Clear();
        lHeaders.Clear();

        myHttpContent.GetHeaders(lHeaders);

        lHeaders.Remove('Content-Type');
        lHeaders.Add('Content-Type', 'application/json');
        myHttpContent.GetHeaders(lHeaders);
        request.GetHeaders(myHttpHeaders);
        myHttpHeaders.Clear();

        myHttpHeaders.Add('Authorization', 'Bearer ' + GMAILMGT."API Token Key");
        myHttpHeaders.Add('Scopes', 'https://www.googleapis.com/auth/drive' +
                          'https://www.googleapis.com/auth/drive.file' +
                          'https://www.googleapis.com/auth/spreadsheets');
        request.Content := myHttpContent;
        request.GetHeaders(myHttpHeaders);
        request.Method := 'POST';
        isSuccess := MyHttpClient.Send(request, MyHttpResponseMessage);

    end;

    local procedure CreateJson(pSheetID2: integer; arraypStartIndex2: array[100] of integer; arraypEndIndex2: array[100] of integer; TotalIndex: integer): Text
    var
        MyJobject: JsonObject;
        ThingJObject: JsonArray;
        ThingJObject3: JsonObject;
        ThingJObject2: JsonObject;
        ThingJObject4: JsonObject;
        JsonData: Text;
        I: integer;
    begin

        Clear(ThingJObject);


        For I := 1 to TotalIndex do begin
            Clear(ThingJObject2);
            clear(ThingJObject3);
            clear(ThingJObject4);


            ThingJObject4.add('sheetId', pSheetID2);
            ThingJObject4.add('dimension', 'ROWS');
            ThingJObject4.add('startIndex', arraypStartIndex2[i]);
            ThingJObject4.add('endIndex', arraypEndIndex2[i]);

            ThingJObject3.Add('range', ThingJObject4);
            ThingJObject2.Add('deleteDimension', ThingJObject3);

            ThingJObject.add(ThingJObject2);
        end;

        MyJobject.Add('requests', ThingJObject);

        MyJobject.WriteTo(JsonData);


        exit(JsonData);
    end;

    local procedure CreateJson2(pSheetID2: integer): Text
    var
        MyJobject: JsonObject;
        ThingJObject: JsonArray;
        ThingJObject3: JsonObject;
        ThingJObject2: JsonObject;
        ThingJObject4: JsonObject;
        JsonData: Text;
    begin
        Clear(ThingJObject);

        Clear(ThingJObject2);
        clear(ThingJObject3);
        clear(ThingJObject4);
        ThingJObject4.add('sheetId', pSheetID2);
        ThingJObject4.add('dimension', 'ROWS');
        ThingJObject4.add('startIndex', 16);
        ThingJObject4.add('endIndex', 17);
        ThingJObject3.Add('range', ThingJObject4);
        ThingJObject2.Add('deleteDimension', ThingJObject3);
        ThingJObject.add(ThingJObject2);

        MyJobject.Add('requests', ThingJObject);
        MyJobject.WriteTo(JsonData);
        exit(JsonData);
    end;

    Local Procedure InitializedVariables()
    var
    Begin
        XLValAmt1 := 0;
        XLValAmt2 := 0;
        XLValAmt3 := 0;
        XLValAmt4 := 0;
        XLValAmt5 := 0;
        XLValAmt6 := 0;
        XLValAmt7 := 0;
        XLValAmt8 := 0;
        XLValAmt9 := 0;
        XLValAmt10 := 0;
        XLValQty1 := 0;
        XLValQty2 := 0;
        XLValQty3 := 0;
        XLValQty4 := 0;
        XLValQty5 := 0;
        XLValQty6 := 0;
        XLValQty7 := 0;
        XLValQty8 := 0;
        XLValQty9 := 0;
        XLValQty10 := 0;
    End;

    var
        TestSpreedID, SheetID2 : text;
        SheetID: integer;
        LocCode: Code[50];
        GmailMgtSetup: Record "GMAIL Maintenance Setup";
        TempLoc: Record Location Temporary;
        XLValQty1, XLValQty2, XLValQty3, XLValQty4, XLValQty5, XLValQty6, XLValQty7, XLValQty8, XLValQty9, XLValQty10 : Decimal;
        XLValAmt1, XLValAmt2, XLValAmt3, XLValAmt4, XLValAmt5, XLValAmt6, XLValAmt7, XLValAmt8, XLValAmt9, XLValAmt10, InterLineAddConn : decimal;
        FluentCommet: Text[250];

}