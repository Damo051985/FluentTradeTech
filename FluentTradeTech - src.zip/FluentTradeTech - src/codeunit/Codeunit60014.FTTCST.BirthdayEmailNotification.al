codeunit 60014 "Birthday Email Notification"
{
    trigger OnRun()
    var
        myInt: Integer;
    begin
        BirthdayNotification();
    end;

    Procedure BirthdayNotification()
    var
        lSubjectTxt: Label '%1!';
        lDearAll: Label '<p style="font-family:Verdana,Arial;font-size:10pt">%1'; //Top Greetings
        lSentBody1: Label '</b></b></b></b></b></p><p style="font-family:Verdana,Arial;font-size:9pt">%2';
        lSentBody2: Label '<BR> %3';
        lSentBody3: Label '<BR> %4';
        lSentBody4: Label '<BR> %5';
        lSentBody6: Label '<p style="font-family:Verdana,Arial;font-size:10pt">%6';
        lSentBody7: Label '</b></p><p style="font-family:Verdana,Arial;font-size:10pt">%7';
        lEmailMSG: Codeunit "Email Message";
        lEmail: Codeunit Email;
        lRecipient: List of [Text];
        lCCRecipient: List Of [Text];
        lBCCRecipient: List Of [Text];
        lSetSubject, lSetBody1, lSetBody2, lSetBody3, lSetBody4, lSetBody5, lSetBody6, lSetBody7 : Text;
        lSentMsg: Text;
        lBody: Text;
        BdayEmail: Record "Birthday Email Notif. Setup";
        lUserSetup: Record "User Setup";
        lMailGrp: Record "Email Mailing Group";
        lMailGrpCode: Record "Email Mailing Group Code";
        lEmp: Record Employee;
    begin
        CheckBirthdayNotif();
        IF gEmpID = '' THEN EXIT;
        CLEAR(BdayEmail);
        BdayEmail.SETFILTER("User ID", gEmpID);
        IF BdayEmail.FINDSET then
            repeat
                Clear(lRecipient);
                Clear(lCCRecipient);
                Clear(lBCCRecipient);
                IF (lEmp.GET(BdayEmail."User ID")) AND (lEmp."Company E-Mail" <> '') then
                    lRecipient.Add(lEmp."Company E-Mail");

                IF lMailGrpCode.GET(BdayEmail."Mailing Group") THEN begin
                    Clear(lMailGrp);
                    lMailGrp.SetRange("Mailing Group Code", lMailGrpCode."Mailing Group Code");
                    IF lMailGrp.FINDSET THEN begin
                        repeat
                            IF (lMailGrp.Email <> '') then begin
                                IF (lMailGrp."Send By" = lMailGrp."Send By"::" ") OR (lMailGrp."Send By" = lMailGrp."Send By"::CC) THEN
                                    lCCRecipient.Add(lMailGrp.Email)
                                ELSE
                                    lBCCRecipient.ADD(lMailGrp.Email);
                            end ELSE begin
                                IF (lEmp.GET(lMailGrp."User ID")) AND (lEmp."Company E-Mail" <> '') then
                                    IF (lMailGrp."Send By" = lMailGrp."Send By"::" ") OR (lMailGrp."Send By" = lMailGrp."Send By"::CC) THEN
                                        lCCRecipient.Add(lEmp."Company E-Mail")
                                    ELSE
                                        lBCCRecipient.Add(lEmp."Company E-Mail")
                            end;
                        until lMailGrp.Next = 0;
                    end;
                end;

                BdayEmail.CalcFields("Emoji 1", "Emoji 2");
                lSetSubject := STRSUBSTNO(BdayEmail.Subject + ' ' + BdayEmail."Full Name");
                lSentMSG := lDearAll + lSentBody1 + lSentBody2 + lSentBody3 + lSentBody4 + lSentBody6 + lSentBody7;

                lBody := StrSubsTno(lSentMsg, (BdayEmail."Top Greetings" + ' ' + BdayEmail."Full Name" + ','), BdayEmail."Email Body 1", BdayEmail."Email Body 2",
                        BdayEmail."Email Body 3", BdayEmail."Email Body 4", BdayEmail."Bottom Greetings", BdayEmail."Greeting From");

                lEmailMSG.Create(lRecipient, lSetSubject, lBody, True, lCCRecipient, lBCCRecipient);
                IF lEmail.Send(lEmailMSG, Enum::"Email Scenario"::"Customer Statement") then;

            until BdayEmail.Next = 0;
    end;

    procedure DateFormula()
    var
        DayTxt, MonthTxt, YearTxt : Text[30];
        DayInt, MonthInt, YearInt : Integer;
        lEmp: Record Employee;
        inputDate: Date;
        lExp: Text[30];
        lBdayNot: Record "Birthday Email Notif. Setup";
        lDateForm: DateFormula;
        lDateFormTxt: Text[10];
    Begin
        Clear(lEmp);
        lDateFormTxt := '';
        IF lEmp.FINDSET THEN BEGIN
            Repeat
                IF (lEmp."Birth Date" <> 0D) AND (lBdayNot.GET(lEmp."No.")) THEN BEGIN
                    lDateForm := lBdayNot."Date Period";
                    lDateFormTxt := FORMAT(lDateForm);
                    IF lDateFormTxt <> '' THEN BEGIN
                        DayInt := DATE2DMY(lEmp."Birth Date", 1);
                        MonthInt := DATE2DMY(lEmp."Birth Date", 2);
                        YearInt := DATE2DMY(TODAY, 3);
                        InputDate := DMY2Date(DayInt, MonthInt, YearInt);
                        lExp := '<-' + FORMAT(lBdayNot."Date Period") + '>';
                        lBdayNot."notification Date" := CalcDate(lExp, InputDate);
                        lBdayNot.MODIFY;
                    END;
                END;
            Until lEmp.Next = 0;
        end;
    End;

    Local procedure CheckBirthdayNotif()
    Var
        BdayNotifSetup: Record "Birthday Email Notif. Setup";
        MailGroup: Record "Email Mailing Group";
        MailGroupCode: Record "Email Mailing Group Code";
        lEmp: Record Employee;
    Begin
        DateFormula;
        gEmpID := '';
        Clear(BdayNotifSetup);
        IF BdayNotifSetup.FINDSET THEN begin
            Repeat
                IF (BdayNotifSetup."notification Date" = TODAY) AND (lEmp.GET(BdayNotifSetup."User ID")) AND (lEmp."Company E-Mail" <> '') then
                    gEmpID += BdayNotifSetup."User ID" + '|';
            Until BdayNotifSetup.Next = 0;
            gEmpID := DelChr(gEmpID, '>', '|');
        end;
    End;

    var
        gEmpID: Code[250];
}
