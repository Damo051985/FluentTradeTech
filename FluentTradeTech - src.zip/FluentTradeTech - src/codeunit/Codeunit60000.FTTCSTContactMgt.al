codeunit 60000 "FTT-CST Contact Mgt."
{
    local procedure FillSubsidiaryType(var Contact: Record Contact)
    begin
        if Contact.Type = Contact.Type::Company then
            Contact."FTT-CST Subsidiary Type" := 0;

        if (Contact.Type = Contact.Type::Person) and (Contact."FTT-CST Subsidiary No." = '') then
            Contact."FTT-CST Subsidiary Type" := 0;

        if (Contact.Type = Contact.Type::Person) and (Contact."FTT-CST Subsidiary No." <> '') then
            Contact."FTT-CST Subsidiary Type" := 2;

        if Contact.Type = Contact.Type::"Subsidiary Company" then
            Contact."FTT-CST Subsidiary Type" := 1;
    end;

    local procedure DeleteSubsidiaryContact(Contact: Record Contact)
    var
        Cont: Record Contact;
    begin
        if Contact.Type <> Contact.Type::"Subsidiary Company" then
            exit;

        Cont.Reset();
        Cont.SetCurrentKey("FTT-CST Subsidiary No.");
        Cont.SetRange("FTT-CST Subsidiary No.", Contact."No.");
        Cont.SetRange(Type, Contact.Type::Person);
        if Cont.Find('-') then
            repeat
                Cont.Delete(true);
            until Cont.Next() = 0;
    end;

    local procedure DeleteRelatedSubsidiaryContacts(Contact: Record Contact)
    var
        Cont: Record Contact;
    begin
        if Contact.Type <> Contact.Type::Company then
            exit;

        Cont.Reset();
        Cont.SetCurrentKey("Company No.");
        Cont.SetRange("Company No.", Contact."No.");
        Cont.SetRange(Type, Contact.Type::"Subsidiary Company");
        if Cont.Find('-') then
            repeat
                Cont.Delete();
            until Cont.Next() = 0;
    end;

    local procedure FillCompanyNoFromSubsidiaryCompany(var Rec: Record Contact)
    var
        Contact: Record Contact;
    begin
        Contact.Reset();
        Contact.SetRange("FTT-CST Subsidiary No.", Rec."No.");
        Contact.SetRange(Type, Contact.Type::Person);
        if Contact.FindSet() then
            repeat
                Contact."Company No." := Rec."Company No.";
                Contact."Company Name" := Rec."Company Name";
                Contact.Modify();
            until Contact.Next() = 0;
    end;

    local procedure SyncSubsidiaryName(var Contact: Record Contact)
    var
        Cont: Record Contact;
    begin
        Cont.Reset();
        Cont.SetRange(Type, Cont.Type::Person);
        Cont.SetFilter("No.", '<>%1', Contact."No.");
        Cont.SetRange("FTT-CST Subsidiary No.", Contact."FTT-CST Subsidiary No.");
        if Cont.FindSet() then
            repeat begin
                Cont."FTT-CST Subsidiary Name" := Contact.Name;
                Cont.Modify();
            end until Cont.Next() = 0;

        Contact."FTT-CST Subsidiary Name" := Contact.Name;
    end;

    [EventSubscriber(ObjectType::Table, Database::Contact, 'OnAfterValidateEvent', 'Name', true, true)]
    local procedure OnAfterValidateContactName(var Rec: Record Contact; xRec: Record Contact)
    begin
        if Rec.Type = Rec.Type::"Subsidiary Company" then
            SyncSubsidiaryName(Rec);
    end;

    [EventSubscriber(ObjectType::Table, Database::Contact, 'OnAfterSetTypeForContact', '', true, true)]
    local procedure OnAfterSetTypeForContact(var Contact: Record Contact; xContact: Record Contact)
    begin
        if Contact.Type = Contact.Type::"Subsidiary Company" then begin
            Contact."FTT-CST Subsidiary No." := Contact."No.";
            Contact."FTT-CST Subsidiary Name" := Contact.Name;
            Contact."Company No." := '';
            Contact."Company Name" := '';
        end else begin
            Contact."FTT-CST Subsidiary No." := '';
            Contact."FTT-CST Subsidiary Name" := '';
        end;
    end;

    [EventSubscriber(ObjectType::Table, Database::Contact, 'OnAfterValidateEvent', 'Company No.', true, true)]
    local procedure OnAfterValidateCompanyNo(var Rec: Record Contact; xRec: Record Contact)
    begin
        if Rec.Type = Rec.Type::Person then
            if (Rec."Company No." <> xRec."Company No.") and (xRec."Company No." <> '') then begin
                Rec."FTT-CST Subsidiary No." := '';
                Rec."FTT-CST Subsidiary Name" := '';
                Rec.Modify();
            end;

        if Rec.Type = Rec.Type::"Subsidiary Company" then
            FillCompanyNoFromSubsidiaryCompany(Rec);
    end;

    [EventSubscriber(ObjectType::Table, Database::Contact, 'OnAfterValidateEvent', 'Type', true, true)]
    local procedure OnAfterValidateType(var Rec: Record Contact; xRec: Record Contact)
    begin
        FillSubsidiaryType(Rec);
    end;

    [EventSubscriber(ObjectType::Table, Database::Contact, 'OnAfterValidateEvent', 'FTT-CST Subsidiary No.', true, true)]
    local procedure OnAfterValidateSubsidiaryNo(var Rec: Record Contact; xRec: Record Contact)
    begin
        FillSubsidiaryType(Rec);
    end;

    [EventSubscriber(ObjectType::Table, Database::Contact, 'OnBeforeDeleteEvent', '', true, true)]
    local procedure OnBeforeDeleteContactEvent(var Rec: Record Contact)
    begin
        DeleteSubsidiaryContact(Rec);
        DeleteRelatedSubsidiaryContacts(Rec);
    end;

    [EventSubscriber(ObjectType::Table, Database::Contact, 'OnBeforeCheckContactType', '', true, true)]
    local procedure OnBeforeCheckContactType(var Contact: Record Contact; ContactType: Enum "Contact Type"; var IsHandled: Boolean)
    begin
        if Contact.Type = Contact.Type::"Subsidiary Company" then begin
            Contact.TestField("Company No.");
            IsHandled := true;
        end;
    end;
}
