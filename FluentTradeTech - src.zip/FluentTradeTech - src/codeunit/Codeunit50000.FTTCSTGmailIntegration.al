
codeunit 50000 "Gmail Integration"
{

    Permissions = tabledata "GMAIL Maintenance Setup" = rimd;

    var

    trigger OnRun()
    begin

    end;
    //GET https://gmail.googleapis.com/gmail/v1/users/{userId}/messages/{messageId}/attachments/{id}
    //dan

    procedure ShowGMAILList(pEmailID: Text[100]; pAPITokenKey: text[250]; EmailType: Integer; Auto: Boolean)
    var
        Url: Text;

        ResponseMessage: HttpResponseMessage;
        JObject: JsonObject;
        Response: HttpResponseMessage;

        ApiResult: Text;
        PostUrl: Text;
        APPName: Text;
        GMAILMGT: Record "GMAIL Maintenance Setup";
        myHttpContent: HttpContent;
        myHttpHeaders: HttpHeaders;
        lHeaders: HttpHeaders;
        request: HttpRequestMessage;
        MyHttpClient: HttpClient;
        MyHttpResponseMessage: HttpResponseMessage;
        myToken: Text;
        myContentHeaders: HttpHeaders;
        Jtoken: JsonToken;
        JArray: JsonArray;
        isSuccess: Boolean;
        GMAILInboxList: Record "Gmail Inbound/Outbound";

    begin
        if not GMAILMGT.Get() then
            exit;
        isSuccess := false;
        ClearLastError;

        Clear(DialogBox);

        if not Auto then begin
            if EmailType = 1 then
                DialogBox.Open('Please wait a few minutes until the GMAIL Inbound Synchronization it''s done!')
            else
                DialogBox.Open('Please wait a few minutes until the GMAIL Outbound Synchronization it''s done!');
        end;

        if EmailType = 1 then
            PostUrl := 'https://gmail.googleapis.com/gmail/v1/users/' + pEmailID + '/messages?maxResults=30&includeSpamTrash=false&labelIds=INBOX'
        else
            PostUrl := 'https://gmail.googleapis.com/gmail/v1/users/' + pEmailID + '/messages?maxResults=30&includeSpamTrash=false&labelIds=SENT';

        request.SetRequestUri(PostUrl);
        myHttpHeaders.Clear();
        lHeaders.Clear();
        myHttpContent.GetHeaders(lHeaders);
        lHeaders.Remove('Content-Type');
        lHeaders.Add('Content-Type', 'application/json');
        myHttpContent.GetHeaders(lHeaders);
        request.GetHeaders(myHttpHeaders);

        myHttpHeaders.Clear();
        myHttpHeaders.Add('Authorization', 'Bearer ' + pAPITokenKey);
        myHttpHeaders.Add('Scopes', 'https://mail.google.com/' +
                                    'https://www.googleapis.com/auth/gmail.modify' +
                                    'https://www.googleapis.com/auth/gmail.readonly');

        request.Content := myHttpContent;
        request.GetHeaders(myHttpHeaders);
        request.Method := 'GET';
        isSuccess := MyHttpClient.Send(request, MyHttpResponseMessage);

        if isSuccess then begin
            MyHttpResponseMessage.Content().ReadAs(myToken);
            JObject.ReadFrom(myToken);

            if JObject.Get('messages', Jtoken) then begin

                JArray := Jtoken.AsArray();
                ReadItemsJson(JArray, pEmailID, EmailType);
                Commit();
                GMAILInboxList.Reset();
                GMAILInboxList.SetFilter(Subject, '%1', '');
                if GMAILInboxList.FindSet() then
                    repeat
                        GetdetailMessage(GMAILInboxList."GMAIL Inbox ID");
                    until GMAILInboxList.Next() = 0;
                Commit();
                if not Auto then
                    DialogBox.Close();

            end;
        end;

    end;

    local procedure ReadItemsJson(JItemsArray: JsonArray; pEmailID2: Text[250]; EmailType: Integer)
    var

        GMALInboxList: Record "Gmail Inbound/Outbound";
        GMALInboxListLast: Record "Gmail Inbound/Outbound";
        RecGmailDeletedLogs: Record "GMAIL Deleted Logs";
        JItemLineToken: JsonToken;
        JItemLine: JsonObject;
        JItemDesc: JsonToken;
        JitemDescDet: Text[250];
        LastEntryno: Integer;
    begin
        LastEntryno := 0;

        foreach JitemLineToken in JItemsArray do begin
            JitemDescDet := '';
            JItemLine := JItemLineToken.AsObject();
            if JItemLine.Get('id', JItemDesc) then
                JitemDescDet := JItemDesc.AsValue().AsText();

            // RecGmailDeletedLogs.Reset();
            // RecGmailDeletedLogs.SetRange("GMAIL Inbox ID", JitemDescDet);
            if not RecGmailDeletedLogs.Get(JitemDescDet) then begin
                // Message(JitemDescDet);
                GMALInboxList.Reset();
                GMALInboxList.SetRange("GMAIL Inbox ID", JitemDescDet);
                if not GMALInboxList.FindFirst() then begin
                    GMALInboxList.Init();
                    GMALInboxListLast.Reset();
                    if GMALInboxListLast.FindLast() then
                        GMALInboxList.EntryNo := GMALInboxListLast.EntryNo + 1
                    else
                        GMALInboxList.EntryNo := 1;
                    GMALInboxList."GMAIL Inbox ID" := JitemDescDet;
                    GMALInboxList."Email ID" := pEmailID2;
                    if EmailType = 1 then
                        GMALInboxList."Email Type" := GMALInboxList."Email Type"::Inbox
                    else
                        GMALInboxList."Email Type" := GMALInboxList."Email Type"::Sent;

                    GMALInboxList."Created by User" := UserId;
                    GMALInboxList."Date created" := today;
                    GMALInboxList.Insert(true);
                end;
            end;
        end;
    end;

    procedure GetdetailMessage(pGmailInboxID: Text[250])
    var
        Url: Text;
        ResponseMessage: HttpResponseMessage;
        JObject: JsonObject;
        Response: HttpResponseMessage;

        ApiResult: Text;
        PostUrl: Text;
        APPName: Text;
        GMAILMGT: Record "GMAIL Maintenance Setup";
        myHttpContent: HttpContent;
        myHttpHeaders: HttpHeaders;
        lHeaders: HttpHeaders;
        request: HttpRequestMessage;
        MyHttpClient: HttpClient;
        MyHttpResponseMessage: HttpResponseMessage;
        myToken: Text;
        myContentHeaders: HttpHeaders;
        Jtoken: JsonToken;
        JArray: JsonArray;
        isSuccess: Boolean;
        GMAILInboxList: Record "Gmail Inbound/Outbound";
        JItemstoken: JsonToken;
        JMessageContent: JsonToken;
        JMessageContent2: JsonToken;
        JMessageContent3: JsonToken;
        JSTONtoketn3: JsonToken;
        JMessageContentDesc: Text[2500];
        JObject2: JsonObject;
        JMessageThreadID: JsonToken;
        JMessageThreadIDDesc: Text[250];
        OutPut: Text;
        JArray2: JsonArray;
        IntCount: Integer;
        JsonObject2: JsonObject;
        TotalAttachement_l: Integer;
        ListofFileName_l: array[100] of text;
        ListofMimeType_l: array[100] of Text;
        ListofAttachmentID_l: array[100] of Text;
        DetailedMessage_l: Text;
    begin

        if not GMAILMGT.Get() then
            exit;
        isSuccess := false;
        ClearLastError;

        PostUrl := ' https://gmail.googleapis.com/gmail/v1/users/' + GMAILMGT."CRM Email" + '/messages/' + pGmailInboxID;

        request.SetRequestUri(PostUrl);
        myHttpHeaders.Clear();
        lHeaders.Clear();
        myHttpContent.GetHeaders(lHeaders);
        lHeaders.Remove('Content-Type');
        lHeaders.Add('Content-Type', 'application/json');
        myHttpContent.GetHeaders(lHeaders);
        request.GetHeaders(myHttpHeaders);

        myHttpHeaders.Clear();
        myHttpHeaders.Add('Authorization', 'Bearer ' + GMAILMGT."API Token Key");
        myHttpHeaders.Add('Scopes', 'https://mail.google.com/' +
                                    'https://www.googleapis.com/auth/gmail.modify' +
                                    'https://www.googleapis.com/auth/gmail.readonly');

        request.Content := myHttpContent;
        request.GetHeaders(myHttpHeaders);
        request.Method := 'GET';
        isSuccess := MyHttpClient.Send(request, MyHttpResponseMessage);
        // Message('%1', isSuccess);
        if isSuccess then begin
            MyHttpResponseMessage.Content().ReadAs(myToken);
            JObject.ReadFrom(myToken);
            //Message(myToken);
            if JObject.Get('threadId', JMessageThreadID) then
                JMessageThreadIDDesc := JMessageThreadID.AsValue().AsText();

            if JObject.Get('snippet', JMessageContent2) then
                JMessageContentDesc := JMessageContent2.AsValue().AsText();


            if JObject.Get('payload', Jtoken) then begin
                //Get Detailed Message in HTML Format
                if Jtoken.AsObject().Get('parts', JMessageContent) then begin
                    JArray2 := JMessageContent.AsArray();
                    ReadItemsJson4(JArray2, DetailedMessage_l);
                    Commit();
                end else begin
                    //First Email Thread
                    if Jtoken.AsObject().Get('body', JMessageContent) then
                        if JMessageContent.IsObject then
                            JMessageContent.WriteTo(OutPut);
                    JsonObject2.ReadFrom(OutPut);
                    if JsonObject2.Get('data', JSTONtoketn3) then
                        DetailedMessage_l := JSTONtoketn3.AsValue().AsText();
                end;

                //UploadAttachment
                ReadItemsJson3(JArray2, TotalAttachement_l, ListofFileName_l, ListofMimeType_l, ListofAttachmentID_l);
                commit();

                if TotalAttachement_l <> 0 then begin
                    if isHasEmaillCreated(pGmailInboxID) = false then begin
                        For IntCount := 1 to TotalAttachement_l do begin
                            GetAttachment(pGmailInboxID, GMAILMGT."CRM Email", TotalAttachement_l, ListofFileName_l[IntCount], ListofMimeType_l[IntCount], ListofAttachmentID_l[IntCount]);
                            Commit();
                        end;
                    end;

                end;

                if Jtoken.AsObject().Get('headers', JItemstoken) then
                    JArray := JItemstoken.AsArray();
                ReadItemsJson2(JArray, JMessageContentDesc, pGmailInboxID, JMessageThreadIDDesc, DetailedMessage_l);
                Commit();
            end;
        end;
        //until GMAILInboxList.Next() = 0;
    end;

    local procedure isHasEmaillCreated(pGmailInboxID: Text[250]): Boolean
    var
        recEmailAttachement: Record "GMAIL Attachment";
    begin
        recEmailAttachement.Reset();
        recEmailAttachement.SetRange("GMAIL Inbox ID", pGmailInboxID);
        if recEmailAttachement.FindFirst() then
            exit(true);

        exit(false);
    end;
    //Import Attachment
    local procedure ReadItemsJson3(JItemsArray: JsonArray; var TotalAttachement: Integer; var ListofFileName: array[100] of text; var ListofMimeType: array[100] of Text; var ListofAttachmentID: array[100] of Text)
    var

        GMALInboxList: Record "Gmail Inbound/Outbound";
        JItemLineToken: JsonToken;
        JItemLine: JsonObject;
        JItemDesc: JsonToken;
        JItemDescValue: JsonToken;
        JItemDescValue2: JsonToken;
        JItemDescValue3: JsonToken;
        recEmailRelatoion: Record "GMAIL Email Relation";
        recEmailRelatoion2: Record "GMAIL Email Relation";
        recEmailRelatoion3: Record "GMAIL Email Relation";
        recEmailRelatoion4: Record "GMAIL Email Relation";
        Base64Convert: Codeunit "Base64 Convert";
        JsonObject2: JsonObject;
        OutPut: Text;
        JSTONtoketn3: JsonToken;
        JsonArray2: JsonArray;
        JITEMLineToken3: JsonToken;
        JITEMLine2: JsonObject;
        WithAttachment: Boolean;
    begin
        TotalAttachement := 0;
        WithAttachment := false;
        foreach JitemLineToken in JItemsArray do begin

            JItemLine := JItemLineToken.AsObject();
            if JItemLine.Get('mimeType', JItemDescValue) then
                if JItemDescValue.AsValue().AsText() IN ['multipart/alternative', 'multipart/related', 'text/html'] then
                    WithAttachment := true;

            if WithAttachment then begin
                if JItemLine.Get('partId', JItemDesc) then begin
                    if JItemDesc.AsValue().AsText() <> '0' then begin

                        if JItemLine.Get('mimeType', JItemDescValue2) then begin
                            if (JItemDescValue2.AsValue().AsText() <> 'application/ics') AND (JItemDescValue2.AsValue().AsText() <> 'image/jpeg') AND (JItemDescValue2.AsValue().AsText() <> 'image/png') then begin
                                if JItemLine.Get('filename', JItemDescValue3) then begin
                                    if JItemDescValue3.AsValue().AsText() = '' then
                                        exit;

                                    //if JItemDescValue3.AsValue().AsText() <> 'Fluent logo.jpg' then begin
                                    TotalAttachement += 1;
                                    ListofMimeType[TotalAttachement] := JItemDescValue2.AsValue().AsText();
                                    ListofFileName[TotalAttachement] := JItemDescValue3.AsValue().AsText();
                                    // if JItemLine.Get('filename', JItemDescValue3) then
                                    //     ListofFileName[TotalAttachement] := JItemDescValue3.AsValue().AsText();
                                    if JItemLine.Get('body', JItemDesc) then
                                        if JItemDesc.IsObject then
                                            JItemDesc.WriteTo(OutPut);
                                    JsonObject2.ReadFrom(OutPut);
                                    if JsonObject2.Get('attachmentId', JSTONtoketn3) then
                                        ListofAttachmentID[TotalAttachement] := JSTONtoketn3.AsValue().AsText();
                                    //end;
                                end;
                            end;
                        end;
                    end;
                end;
            end;
        end;
    end;

    local procedure ReadItemsJson4(JItemsArray: JsonArray; var Detailedmessage: Text)
    var

        GMALInboxList: Record "Gmail Inbound/Outbound";
        JItemLineToken: JsonToken;
        JItemLine: JsonObject;
        JItemDesc: JsonToken;
        JItemDescValue: JsonToken;
        JItemDescValue2: JsonToken;
        JItemDescValue4: JsonToken;
        JItemDescValue3: JsonToken;
        JItemDescValue5: JsonToken;
        JsonObject2: JsonObject;
        JsonObject3: JsonObject;
        OutPut: Text;
        JSTONtoketn3: JsonToken;
        JsonArray2: JsonArray;
        JITEMLineToken3: JsonToken;
        JITEMLineToken4: JsonToken;
        JITEMLine2: JsonObject;
        JSonArray4: JsonArray;
    begin


        foreach JitemLineToken in JItemsArray do begin

            JItemLine := JItemLineToken.AsObject();
            if JItemLine.Get('mimeType', JItemDescValue) then
                if JItemDescValue.AsValue().AsText() = 'text/html' then begin
                    if JItemLine.Get('body', JItemDesc) then
                        if JItemDesc.IsObject then
                            JItemDesc.WriteTo(OutPut);
                    JsonObject2.ReadFrom(OutPut);
                    if JsonObject2.Get('data', JSTONtoketn3) then
                        Detailedmessage := JSTONtoketn3.AsValue().AsText();
                end else if JItemDescValue.AsValue().AsText() <> 'multipart/related' then begin
                    if JItemLine.Get('parts', JItemDesc) then
                        JsonArray2 := JItemDesc.AsArray();
                    foreach JITEMLineToken3 in JsonArray2 do begin
                        JITEMLine2 := JITEMLineToken3.AsObject();
                        if JITEMLine2.Get('mimeType', JItemDescValue2) then
                            if JItemDescValue2.AsValue().AsText() = 'text/html' then begin
                                if JITEMLine2.Get('body', JItemDescValue3) then
                                    if JItemDescValue3.IsObject then
                                        JItemDescValue3.WriteTo(OutPut);
                                JsonObject2.ReadFrom(OutPut);
                                if JsonObject2.Get('data', JSTONtoketn3) then
                                    Detailedmessage := JSTONtoketn3.AsValue().AsText();
                            end;
                    end;
                end else begin
                    if JItemLine.Get('parts', JItemDesc) then
                        JsonArray2 := JItemDesc.AsArray();
                    foreach JITEMLineToken3 in JsonArray2 do begin
                        JITEMLine2 := JITEMLineToken3.AsObject();
                        if JITEMLine2.Get('parts', JItemDescValue2) then
                            JSonArray4 := JItemDescValue2.AsArray();
                        foreach JITEMLineToken4 in JSonArray4 do begin
                            JsonObject3 := JITEMLineToken4.AsObject();
                            if JsonObject3.Get('mimeType', JItemDescValue4) then
                                if JItemDescValue4.AsValue().AsText() = 'text/html' then begin
                                    if JsonObject3.Get('body', JItemDescValue5) then
                                        if JItemDescValue5.IsObject then
                                            JItemDescValue5.WriteTo(OutPut);
                                    JsonObject2.ReadFrom(OutPut);
                                    if JsonObject2.Get('data', JSTONtoketn3) then
                                        Detailedmessage := JSTONtoketn3.AsValue().AsText();
                                end;
                        end;

                    end;
                end;
        end;
    end;


    procedure Base64URLtoBase64(pText: Text): Text
    var
        s: Text;
    begin
        s := pText;
        s := ReplacteString(s, '-', '+');
        s := ReplacteString(s, '_', '/');
        //s := ReplacteString(s, '=', '');
        exit(s);
    end;

    local procedure ReplacteString(String: Text; FindWhat: Text; ReplaceWith: Text) NewString: Text
    begin
        while StrPos(String, FindWhat) > 0 do
            String := DelStr(String, StrPos(String, FindWhat)) + ReplaceWith + CopyStr(String, StrPos(String, FindWhat) + StrLen(FindWhat));
        NewString := String;
    end;

    local procedure ReadItemsJson2(JItemsArray: JsonArray; MsgContent: Text[2500]; InboxID: Text[250]; ThreadID: Text[250]; detailedMessage_p: Text)
    var

        GMALInboxList: Record "Gmail Inbound/Outbound";
        JItemLineToken: JsonToken;
        JItemLine: JsonObject;
        JItemDesc: JsonToken;
        JItemDescValue: JsonToken;
        JitemDescDet: Text;
        JitemDescDetValue: Text;
        LastEntryno: Integer;
        DeliverToDec: Text[250];
        DeliverToRec: Text[1024];
        DeliverToBCC: Text[1024];
        DateReceived: Text[250];
        SubjectText: Text[250];
        DateFromName: Text;
        OutStream2: OutStream;
        recEmailRelatoion: Record "GMAIL Email Relation";
        recEmailRelatoion2: Record "GMAIL Email Relation";
        recEmailRelatoion3: Record "GMAIL Email Relation";
        recEmailRelatoion4: Record "GMAIL Email Relation";
        Base64Convert: Codeunit "Base64 Convert";
        TempBlob: Codeunit "Temp Blob";
        Instream2: InStream;

    begin
        LastEntryno := 0;


        foreach JitemLineToken in JItemsArray do begin

            JItemLine := JItemLineToken.AsObject();
            if JItemLine.Get('name', JItemDesc) then
                JitemDescDet := JItemDesc.AsValue().AsText();
            if JItemLine.Get('value', JItemDescValue) then
                JitemDescDetValue := JItemDescValue.AsValue().AsText();
            case JitemDescDet of
                'To':
                    DeliverToDec := JitemDescDetValue;
                'Cc':
                    DeliverToRec := JitemDescDetValue;
                'Bcc':
                    DeliverToBCC := JitemDescDetValue;
                'Date':
                    DateReceived := JitemDescDetValue;
                'Subject':
                    SubjectText := JitemDescDetValue;
                'From':
                    begin
                        JitemDescDetValue := JitemDescDetValue.Replace('\u003c', ',');
                        JitemDescDetValue := JitemDescDetValue.Replace('\u003e', '');
                        DateFromName := JitemDescDetValue;
                    end;
            end;

        end;
        clear(OutStream2);
        GMALInboxList.Reset();
        GMALInboxList.SetRange("GMAIL Inbox ID", InboxID);
        if GMALInboxList.FindFirst() then begin

            GMALInboxList."Date Received" := getCorrectDate(DateReceived);
            GMALInboxList."Sent To" := DeliverToDec;
            GMALInboxList.Recipients := DeliverToRec;
            GMALInboxList."Marked as Unread" := false;
            GMALInboxList.BCC := DeliverToBCC;
            GMALInboxList."Message Content".CreateOutStream(OutStream2);
            //OutStream2.WriteText(MsgContent);
            OutStream2.WriteText(detailedMessage_p);
            GMALInboxList.Subject := SubjectText;
            GMALInboxList."Thread ID" := ThreadID;
            GMALInboxList."Sent From" := DateFromName;
            if GMALInboxList.Modify() then begin
                Commit();
                recEmailRelatoion3.Reset();
                recEmailRelatoion3.SetRange("Thread ID", ThreadID);
                if not recEmailRelatoion3.FindFirst() then
                    exit;

                recEmailRelatoion.Reset();
                recEmailRelatoion.SetFilter("Thread ID", '%1', ThreadID);
                recEmailRelatoion.SetFilter("GMAIL Inbox ID", '%1', recEmailRelatoion3."GMAIL Inbox ID");
                if recEmailRelatoion.FindSet() then
                    repeat

                        recEmailRelatoion2.Init();
                        recEmailRelatoion4.Reset();
                        if recEmailRelatoion4.FindLast() then
                            recEmailRelatoion2.EntryNo := recEmailRelatoion4.EntryNo + 1
                        else
                            recEmailRelatoion2.EntryNo := 1;

                        recEmailRelatoion2."Email Type" := GMALInboxList."Email Type";
                        recEmailRelatoion2."Inbox Entry No." := GMALInboxList.EntryNo;
                        recEmailRelatoion2."Thread ID" := ThreadID;
                        recEmailRelatoion2."Linked Document Type" := recEmailRelatoion."Linked Document Type";
                        recEmailRelatoion2."Linked Document No." := recEmailRelatoion."Linked Document No.";
                        recEmailRelatoion2."Sent From" := DateFromName;
                        recEmailRelatoion2."Sent To" := DeliverToDec;
                        if GMALInboxList."Email Type" = GMALInboxList."Email Type"::Inbox then
                            recEmailRelatoion2."Date Received" := GMALInboxList."Date Received"
                        else begin
                            recEmailRelatoion2."Date Received" := GMALInboxList."Date Received";
                            recEmailRelatoion2."Date Sent" := GMALInboxList."Date Received";
                        end;
                        recEmailRelatoion2.Subject := SubjectText;
                        recEmailRelatoion2."GMAIL Inbox ID" := GMALInboxList."GMAIL Inbox ID";
                        recEmailRelatoion2.Insert(true);
                        Commit();
                    until recEmailRelatoion.Next() = 0;
            end;


        end;
    end;


    local procedure getCorrectDate(dateTimeText: Text[2500]): Date
    var
        Month: Text[10];
        Day: Text[20];
        Year: Text[20];
        DelUnncessary: Text[2500];
        CopyDayWord: Text[10];
        DT: Date;
        Time2: Text[20];
    begin

        if dateTimeText.Contains('Mon') then
            dateTimeText := dateTimeText.Replace('Mon,', '');

        if dateTimeText.Contains('Tue') then
            dateTimeText := dateTimeText.Replace('Tue,', '');

        if dateTimeText.Contains('Wed') then
            dateTimeText := dateTimeText.Replace('Wed,', '');

        if dateTimeText.Contains('Thu') then
            dateTimeText := dateTimeText.Replace('Thu,', '');

        if dateTimeText.Contains('Fri') then
            dateTimeText := dateTimeText.Replace('Fri,', '');

        if dateTimeText.Contains('Sat') then
            dateTimeText := dateTimeText.Replace('Sat,', '');

        if dateTimeText.Contains('Sun') then
            dateTimeText := dateTimeText.Replace('Sun,', '');

        DelUnncessary := dateTimeText.Trim();

        if DelUnncessary.Contains('Jan') then
            Month := '01';

        if DelUnncessary.Contains('Feb') then
            Month := '02';
        if DelUnncessary.Contains('Mar') then
            Month := '03';
        if DelUnncessary.Contains('Apr') then
            Month := '04';
        if DelUnncessary.Contains('May') then
            Month := '05';
        if DelUnncessary.Contains('Jun') then
            Month := '06';
        if DelUnncessary.Contains('Jul') then
            Month := '07';
        if DelUnncessary.Contains('Aug') then
            Month := '08';
        if DelUnncessary.Contains('Sep') then
            Month := '09';
        if DelUnncessary.Contains('Oct') then
            Month := '10';
        if DelUnncessary.Contains('Nov') then
            Month := '11';
        if DelUnncessary.Contains('Dec') then
            Month := '12';

        Day := CopyStr(DelUnncessary, 1, 2);
        Day := Day.Trim();


        if StrLen(Day) <> 2 then
            Year := CopyStr(DelUnncessary, 7, 4)
        else
            Year := CopyStr(DelUnncessary, 8, 4);


        evaluate(DT, (Month + '/' + Day + '/' + Year));

        exit(DT);

    end;


    procedure GetAttachment(pGmailInboxID: Text[250]; pEmailID3: Text[250]; TotalAttachement: Integer; ListofFileName: text; ListofMimeType: Text; ListofAttachmentID: Text)
    var
        Url: Text;
        ResponseMessage: HttpResponseMessage;
        JObject: JsonObject;
        Response: HttpResponseMessage;

        ApiResult: Text;
        PostUrl: Text;
        APPName: Text;
        GMAILMGT: Record "GMAIL Maintenance Setup";
        myHttpContent: HttpContent;
        myHttpHeaders: HttpHeaders;
        lHeaders: HttpHeaders;
        request: HttpRequestMessage;
        MyHttpClient: HttpClient;
        MyHttpResponseMessage: HttpResponseMessage;
        myToken: Text;
        myContentHeaders: HttpHeaders;
        Jtoken: JsonToken;
        JArray: JsonArray;
        isSuccess: Boolean;
        GMAILInboxList: Record "Gmail Inbound/Outbound";
        TempBlob: Codeunit "Temp Blob";
        OutStream2: OutStream;
        InsTream2: InStream;
        recEmailAttachement: record "GMAIL Attachment";
        recEmailAttachementLast: Record "GMAIL Attachment";
        Base64Convert: Codeunit "Base64 Convert";

    begin
        if not GMAILMGT.Get() then
            exit;
        isSuccess := false;
        ClearLastError;

        PostUrl := 'https://gmail.googleapis.com/gmail/v1/users/' + pEmailID3 + '/messages/' + pGmailInboxID + '/attachments/' + ListofAttachmentID;

        request.SetRequestUri(PostUrl);
        myHttpHeaders.Clear();
        lHeaders.Clear();
        myHttpContent.GetHeaders(lHeaders);
        lHeaders.Remove('Content-Type');
        lHeaders.Add('Content-Type', 'application/json');
        myHttpContent.GetHeaders(lHeaders);
        request.GetHeaders(myHttpHeaders);



        myHttpHeaders.Clear();
        myHttpHeaders.Add('Authorization', 'Bearer ' + GMAILMGT."API Token Key");
        myHttpHeaders.Add('Scopes', 'https://mail.google.com/' +
                                    'https://www.googleapis.com/auth/gmail.modify' +
                                    'https://www.googleapis.com/auth/gmail.readonly');

        request.Content := myHttpContent;
        request.GetHeaders(myHttpHeaders);
        request.Method := 'GET';
        isSuccess := MyHttpClient.Send(request, MyHttpResponseMessage);

        if isSuccess then begin
            MyHttpResponseMessage.Content().ReadAs(myToken);
            JObject.ReadFrom(myToken);

            if JObject.Get('data', Jtoken) then begin
                Clear(TempBlob);
                Clear(OutStream2);
                Clear(InsTream2);

                TempBlob.CreateOutStream(OutStream2);
                Base64Convert.FromBase64(Base64URLtoBase64(Jtoken.AsValue().AsText()), OutStream2);
                TempBlob.CreateInStream(InsTream2);
                Commit();

                recEmailAttachement.Init();
                recEmailAttachementLast.Reset();
                if recEmailAttachementLast.FindLast() then
                    recEmailAttachement.EntryNo := recEmailAttachementLast.EntryNo + 1
                else
                    recEmailAttachement.EntryNo := 1;
                recEmailAttachement."GMAIL Inbox ID" := pGmailInboxID;
                recEmailAttachement."Date Created" := Today;
                recEmailAttachement."Created By USER" := UserId;
                recEmailAttachement."File Name" := ListofFileName;
                recEmailAttachement."Mime Type" := ListofMimeType;
                recEmailAttachement.Data.ImportStream(InsTream2, ListofFileName, ListofMimeType);
                recEmailAttachement.Insert();
                Commit();

            end;
        end;
    end;




    Var

        DialogBox: Dialog;
}