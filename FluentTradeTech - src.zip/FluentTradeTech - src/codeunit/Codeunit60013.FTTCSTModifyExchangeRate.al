codeunit 60013 ModifyExchangeRate
{

    trigger OnRun()
    var
        lConv1, lConv2, Result : decimal;
        Direction: Text[10];
        Precision: Decimal;
    Begin
        lConv1 := 0;
        lConv2 := 0;
        Result := 0;
        Clear(Curr);
        IF Curr.FINDSET THEN begin
            repeat
                Clear(CurrExcrate2);
                CurrExcrate2.SetRange("Currency Code", Curr.Code);
                IF (CurrExcrate2.FINDLAST) AND (NOT CurrExcrate2."FTTCST Updated to Rate") THEN begin
                    CurrExcrate2."Relational Adjmt Exch Rate Amt" := 1;
                    CurrExcrate2."Relational Exch. Rate Amount" := 1;
                    CurrExcrate2.Modify;
                end;

                Clear(CurrExcrate);
                CurrExcrate.SetRange("Currency Code", Curr.Code);
                IF CurrExcrate.FINDLAST THEN begin
                    IF (CurrExcrate."Exchange Rate Amount" <> 0) AND (CurrExcrate."Relational Adjmt Exch Rate Amt" <> 0) AND (CurrExcrate."Relational Exch. Rate Amount" <> 0) AND
                    (NOT CurrExcRate."FTTCST Updated to Rate") then begin
                        lConv1 := CurrExcrate."Relational Exch. Rate Amount" / CurrExcrate."Exchange Rate Amount";
                        lConv2 := CurrExcrate."Exchange Rate Amount" / lConv1;
                        Direction := '>';
                        Precision := 0.00001;
                        Result := ROUND(lConv2, Precision, Direction);
                        //CurrExcrate.VALIDATE("Relational Adjmt Exch Rate Amt", Result);
                        //CurrExcrate.VALIDATE("Relational Exch. Rate Amount", Result);
                        CurrExcrate.VALIDATE("Relational Adjmt Exch Rate Amt", lConv2);
                        CurrExcrate.VALIDATE("Relational Exch. Rate Amount", lConv2);
                        CurrExcrate."FTTCST Updated to Rate" := TRUE;
                        CurrExcrate.Modify(TRUE);
                    end;
                end;
            until Curr.Next = 0;
        end;
    End;

    var
        CurrExcrate, CurrExcrate2 : Record "Currency Exchange Rate";
        Curr: Record Currency;
        gCompName: Text[250];
}
