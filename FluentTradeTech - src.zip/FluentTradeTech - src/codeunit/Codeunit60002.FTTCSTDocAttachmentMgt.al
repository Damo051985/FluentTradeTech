codeunit 60002 "FTT-CST Doc. Attachment Mgt."
{
    [EventSubscriber(ObjectType::Page, Page::"Document Attachment Details", 'OnAfterOpenForRecRef', '', false, false)]
    local procedure SetFiltersOnAfterOpenForRecRef(var DocumentAttachment: Record "Document Attachment"; var RecRef: RecordRef; var FlowFieldsEditable: Boolean)
    begin
        SetDocumentAttachmentFiltersForRecRef(DocumentAttachment, RecRef);
    end;

    [EventSubscriber(ObjectType::Table, Database::Contact, 'OnAfterDeleteEvent', '', false, false)]
    local procedure DeleteAttachedDocumentsOnAfterDeleteContact(var Rec: Record Contact; RunTrigger: Boolean)
    var
        RecRef: RecordRef;
    begin
        RecRef.GetTable(Rec);
        DeleteAttachedDocuments(RecRef);
    end;

    [EventSubscriber(ObjectType::Page, Page::"Document Attachment Factbox", 'OnBeforeDrillDown', '', false, false)]
    local procedure RunDetailsOnBeforeDrillDown(DocumentAttachment: Record "Document Attachment"; var RecRef: RecordRef)
    var
        Contact: Record Contact;
    begin
        case DocumentAttachment."Table ID" of
            Database::Contact:
                begin
                    RecRef.Open(Database::Contact);
                    if Contact.Get(DocumentAttachment."No.") then
                        RecRef.GetTable(Contact);
                end;
        end;
    end;

    [EventSubscriber(ObjectType::Table, Database::"Document Attachment", 'OnAfterInitFieldsFromRecRef', '', false, false)]
    local procedure SetFieldsOnAfterInitFieldsFromRecRef(var DocumentAttachment: Record "Document Attachment"; var RecRef: RecordRef)
    begin
        SetDocumentAttachmentFieldsFromRecRef(DocumentAttachment, RecRef);
    end;

    [EventSubscriber(ObjectType::Table, Database::Customer, 'OnAfterRenameEvent', '', false, false)]
    local procedure MoveAttachedDocumentsOnAfterRenameCustomer(var Rec: Record Customer; var xRec: Record Customer; RunTrigger: Boolean)
    var
        MoveFromRecRef: RecordRef;
        MoveToRecRef: RecordRef;
    begin
        MoveFromRecRef.GetTable(xRec);
        MoveToRecRef.GetTable(Rec);

        MoveAttachmentsWithinSameRecordType(MoveFromRecRef, MoveToRecRef);
    end;

    local procedure SetDocumentAttachmentFieldsFromRecRef(var DocumentAttachment: Record "Document Attachment"; var RecRef: RecordRef)
    var
        Contact: Record Contact;
    begin
        case RecRef.Number of
            Database::Contact:
                DocumentAttachment.Validate("No.", RecRef.Field(Contact.FieldNo("No.")).Value);
        end;
    end;

    local procedure SetDocumentAttachmentFiltersForRecRef(var DocumentAttachment: Record "Document Attachment"; RecRef: RecordRef)
    var
        Contact: Record Contact;
    begin
        case RecRef.Number of
            Database::Contact:
                DocumentAttachment.SetRange("No.", RecRef.Field(Contact.FieldNo("No.")).Value);
        end;
    end;

    procedure DeleteAttachedDocuments(RecRef: RecordRef)
    var
        DocumentAttachment: Record "Document Attachment";
    begin
        if RecRef.IsTemporary() then
            exit;

        if DocumentAttachment.IsEmpty() then
            exit;

        SetDocumentAttachmentFiltersForRecRef(DocumentAttachment, RecRef);
        if not DocumentAttachment.IsEmpty() then
            DocumentAttachment.DeleteAll();
    end;

    procedure MoveAttachmentsWithinSameRecordType(var MoveFromRecRef: RecordRef; var MoveToRecRef: RecordRef)
    var
        DocumentAttachmentFound: Record "Document Attachment";
        DocumentAttachmentToCreate: Record "Document Attachment";
        MoveFromFieldRef: FieldRef;
        MoveToFieldRef: FieldRef;
        MoveFromRecNo: Code[20];
        MoveToRecNo: Code[20];
    begin
        if MoveFromRecRef.Number() <> MoveToRecRef.Number() then
            exit;

        if MoveFromRecRef.IsTemporary() or MoveToRecRef.IsTemporary() then
            exit;

        DocumentAttachmentFound.SetRange("Table ID", MoveFromRecRef.Number);
        case MoveFromRecRef.Number of
            Database::Contact:
                begin
                    MoveFromFieldRef := MoveFromRecRef.Field(1);
                    MoveFromRecNo := MoveFromFieldRef.Value;
                    MoveToFieldRef := MoveToRecRef.Field(1);
                    MoveToRecNo := MoveToFieldRef.Value;
                    DocumentAttachmentFound.SetRange("No.", MoveFromRecNo);
                end;
        end;

        if DocumentAttachmentFound.IsEmpty() then
            exit;

        if DocumentAttachmentFound.FindSet() then
            repeat
                Clear(DocumentAttachmentToCreate);
                DocumentAttachmentToCreate.Init();
                DocumentAttachmentToCreate.TransferFields(DocumentAttachmentFound);
                DocumentAttachmentToCreate.Validate("No.", MoveToRecNo);
                DocumentAttachmentToCreate.Insert(true);
            until DocumentAttachmentFound.Next() = 0;

        DocumentAttachmentFound.DeleteAll(true);
    end;

    procedure GenerateExpiredAttachmentEmailSubject(EntityNo: Code[20]; EntityCaption: Text; EntityName: Text): Text
    var
        FixedSubjectTextLbl: Label 'Expiration of attachments for';
        SubjectMaskLbl: Label '%1 %2 %3, %4', Comment = '%1 - Fixed Text; %2 - Entity Caption; %3 - Entity No; %4 - Entity Name', Locked = true;
    begin
        exit(StrSubstNo(SubjectMaskLbl, FixedSubjectTextLbl, EntityCaption, EntityNo, EntityName));
    end;

    procedure GenerateExpiredAttachmentEmailBody(var DocAttachment: Record "Document Attachment"; EntityCaption: Text; EntityName: Text) BodyText: Text
    var
        LineNo: Integer;
        AttachmentMaskLbl: Label '%1. %2.%3. %4: %5.', Comment = '%1 - ; %2 - ; %3 -; %4 - ; %5 - ';
        EndLbl: Label 'Have a nice day.';
        EntityMaskLbl: Label 'For %1 %2, %3 next attachments expire soon:', Comment = '%1 - ; %2 - ; %3 -';
        GreetingLbl: Label 'Dear colleagues,';
        NoReplyLbl: Label 'It is an automatic e-mail and doesn''t require an answer.';
        RequestLbl: Label 'Please, take the necessary actions.';
        AttachmentLineText: Text;
        EntityHeadingLineText: Text;
    begin
        BodyText := GreetingLbl + NewLine() + NewLine();
        EntityHeadingLineText := StrSubstNo(EntityMaskLbl, EntityCaption, DocAttachment."No.", EntityName);
        BodyText += EntityHeadingLineText + NewLine();

        LineNo := 1;
        if DocAttachment.FindSet() then
            repeat
                AttachmentLineText :=
                    StrSubstNo(
                        AttachmentMaskLbl,
                        LineNo, DocAttachment."File Name", DocAttachment."File Extension", DocAttachment.FieldCaption("FTT-CST Expiration Date"), DocAttachment."FTT-CST Expiration Date");
                BodyText += AttachmentLineText + NewLine();

                LineNo += 1;
            until DocAttachment.Next() = 0;

        BodyText += RequestLbl + NewLine() + NewLine();
        BodyText += NoReplyLbl + NewLine();
        BodyText += EndLbl;
    end;

    local procedure NewLine(): Text[2]
    var
        CrLf: Text[2];
    begin
        CrLf[1] := 13;
        CrLf[2] := 10;
        exit(CrLf);
    end;
}
