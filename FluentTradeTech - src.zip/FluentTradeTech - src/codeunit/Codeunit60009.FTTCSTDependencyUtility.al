codeunit 60009 "FTT-CST Dependency Utility"
{
    procedure CheckDependencySetup()
    var
        SalesReceivablesSetup: record "Sales & Receivables Setup";
    begin
        if SalesReceivablesSetup.GET() then begin
            SalesReceivablesSetup.TestField("FTT-CST Ded. MRC CC Category");
            SalesReceivablesSetup.TestField("FTT-CST Ded. NRC CC Category");
            SalesReceivablesSetup.TestField("FTT-CST DR Category");
            SalesReceivablesSetup.TestField("FTT-CST HARDWARE");
            SalesReceivablesSetup.TestField("FTT-CST Hosting and management");
            SalesReceivablesSetup.TestField("FTT-CST Integration Category");
            SalesReceivablesSetup.TestField("FTT-CST INTERNATIONAL Line");
            SalesReceivablesSetup.TestField("FTT-CST Item Region Dim. Code");
            SalesReceivablesSetup.TestField("FTT-CST LICENSE");
            SalesReceivablesSetup.TestField("FTT-CST NS MAKER FEED");
            SalesReceivablesSetup.TestField("FTT-CST Parent CROSS CONNECT");
            SalesReceivablesSetup.TestField("FTT-CST Parent FEED");
            SalesReceivablesSetup.TestField("FTT-CST Redundancy Category");
            SalesReceivablesSetup.TestField("FTT-CST Servers Set Up");
            SalesReceivablesSetup.TestField("FTT-CST Shared MRC CC Category");
            SalesReceivablesSetup.TestField("FTT-CST Shared NRC CC Category");
            SalesReceivablesSetup.TestField("FTT-CST STANDARD MAKER FEED");
            SalesReceivablesSetup.TestField("FTT-CST NS TAKER FEED");
            SalesReceivablesSetup.TestField("FTT-CST STANDARD TAKER FEED");
        end else
            Error('Please make setup %1', SalesReceivablesSetup.TableCaption);
    end;
}
