codeunit 60012 LostOpportunity
{
    trigger OnRun()
    begin

    end;

    Procedure LostTotalRevenue()
    var
        lOpp: Record Opportunity;
        lOppEnt: Record "Opportunity Entry";
        lSH: Record "Sales Header";
        lSL: Record "Sales Line";
        lTot: Decimal;
        lDocNo: Code[1024];
        llostOpp: Record LostOpportunityTable;
        lFound: Boolean;
        lCurrCode: Code[20];
        lCont: Record Contact;
    Begin
        Clear(llostOpp);
        IF llostOpp.FINDSET THEN begin
            repeat
                lCurrCode := '';
                IF lCont.GET(llostOpp.Prospect) then
                    lCurrCode := lCont."Currency Code";
                lDocNo := '';
                lTot := 0;
                Clear(lOpp);
                lOpp.SetRange(Status, lOpp.Status::Lost);
                lOpp.SETFILTER("Contact Name", '%1', llostOpp.Name);
                lOpp.Setfilter("Salesperson Code", '%1', llostOpp.Salesperson);
                IF lOpp.FINDSET THEN begin
                    repeat
                        lSH.SetRange("Document Type", lSH."Document Type"::Quote);
                        lSH.Setfilter("Opportunity No.", '%1', lOpp."No.");
                        IF lSH.FindSet() THEN begin
                            repeat
                                lSH.CalcFields(Amount, "Amount Including VAT");
                                lTot += (GetSOLine(lSH) - lSH."Invoice Discount Value");
                            until lSH.Next = 0;
                        end;
                        lDocNo += lOpp."No." + '|';
                    until lOpp.Next = 0;
                end;

                IF lTot <> 0 THEN BEGIN
                    llostOpp."Total Revenue" := (lTot * GetConvertion(lCurrCode));
                    lDocNo := DELCHR(lDocNo, '>', '|');
                    llostOpp."Doc. No." := lDocNo;
                    llostOpp.Modify;
                END;
            until llostOpp.Next = 0;
        end;
    End;

    Local Procedure GetConvertion(pCurCode: Code[20]): decimal
    var
        lCurEx: Record "Currency Exchange Rate";
        lCont: Record Contact;
        lCurrCode: Code[20];
        lExcRate: Decimal;
    Begin
        IF pCurCode = '' then
            exit(1);
        Clear(lCurEx);
        lCurEx.SETRANGE("Currency Code", pCurCode);
        IF lCurEx.FINDLAST then
            IF lCurEx."Exchange Rate Amount" = 0 THEN
                Exit(1);
        EXIT(lCurEx."Exchange Rate Amount");
    End;

    Local Procedure GetSOLine(pSH: Record "Sales Header"): Decimal
    var
        lSL: Record "Sales Line";
        lYRC: decimal;
        lSH: Record "Sales Header";
    Begin
        lYRC := 0;
        Clear(lSL);
        lSL.SetRange("Document Type", pSH."Document Type");
        lSL.SetRange("Document No.", pSH."No.");
        lSL.SetRange("FTT-CST Optional", lSL."FTT-CST Optional"::No);
        if lSL.FindSet() then BEGIN
            repeat
                IF lSL."FTT-CST Cost Type" <> lSL."FTT-CST Cost Type"::NRC THEN BEGIN
                    lYRC += lSL."Line Amount";
                END;
            until lSL.next = 0;
        END;
        EXIT(lYRC);
    End;


    var
        Conn: decimal;
}
