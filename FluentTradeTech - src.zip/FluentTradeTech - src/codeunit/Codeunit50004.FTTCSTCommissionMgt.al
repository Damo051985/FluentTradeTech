codeunit 50004 "FTT-CST Commission Mgt."
{
    Permissions = tabledata "Sales Invoice Line" = rm,
                   tabledata "Cust. Ledger Entry" = rm,
                   tabledata "Sales Cr.Memo Line" = rm;

    trigger OnRun()
    begin

    end;

    procedure CreatePurchasheInvoice(TotalAppLCY: Decimal; CommmWorksheetHeader: Record "Commission Worksheet Header"): Boolean
    var
        PurchHeader: Record "Purchase Header";
        PurchLine: Record "Purchase Line";
        CommSetup: Record "FTT-CST Commission Agr. Setup";
        PurchPost: Codeunit "Purch.-Post";
        PurchInvHeader: Record "Purch. Inv. Header";
        codPurchNumber: Code[50];
        PurchaseInvoice: Page "Purchase Invoice";
        recSalesPerson: Record "Salesperson/Purchaser";
    begin
        CommSetup.Get();

        if not recSalesPerson.get(CommmWorksheetHeader."Vendor No.  (SalesPerson)") then
            exit;

        recSalesPerson.TestField("Comm. Vendor No.");

        PurchHeader.Reset();
        PurchHeader.Init();
        PurchHeader."Document Type" := PurchHeader."Document Type"::Invoice;
        PurchHeader.Insert(true);

        PurchHeader.Validate(PurchHeader."Buy-from Vendor No.", recSalesPerson."Comm. Vendor No.");
        PurchHeader.Validate("Currency Code", CommSetup."Default Currency Code"); //NRD
        PurchHeader."Vendor Invoice No." := CommmWorksheetHeader."Document No.";
        PurchHeader."Comm. Document No." := CommmWorksheetHeader."Document No.";
        PurchHeader."Posting Description" := StrSubstNo('This invoice is for Commission Document No. %1', CommmWorksheetHeader."Document No.");
        PurchHeader."Posting Date" := TODAY;

        PurchHeader.Modify();

        PurchLine.Reset();
        PurchLine.Init();
        PurchLine."Document Type" := PurchLine."Document Type"::Invoice;
        PurchLine."Document No." := PurchHeader."No.";
        PurchLine.Type := PurchLine.type::"G/L Account";
        PurchLine.Validate(PurchLine."No.", CommSetup."Payable G/L Account No.");
        PurchLine.Validate(PurchLine.Quantity, 1);
        PurchLine.Validate(PurchLine."Direct Unit Cost", TotalAppLCY);
        PurchLine.Insert(true);

        CommmWorksheetHeader."Comm. PI No." := PurchHeader."No.";
        CommmWorksheetHeader.Modify();



        Commit();

        if CommSetup."PI Create/Post" then begin
            PurchPost.SetSuppressCommit(true);
            PurchPost.Run(PurchHeader);

            PurchInvHeader.Reset();
            PurchInvHeader.SetRange(PurchInvHeader."Pre-Assigned No.", CommmWorksheetHeader."Comm. PI No.");
            if PurchInvHeader.FindFirst() then begin
                CommmWorksheetHeader."Comm. Payable Doc. No." := PurchInvHeader."No.";
                CommmWorksheetHeader.Status := CommmWorksheetHeader.Status::"Payable Posted";
                CommmWorksheetHeader."Payable Due Date" := PurchInvHeader."Due Date";
                CommmWorksheetHeader.Modify();

                Message('Payable Successfully Posted with Posted Purchase Invoice No. %1', PurchInvHeader."No.");

            end;

        end else begin
            CommmWorksheetHeader."Payable Due Date" := PurchHeader."Due Date";
            CommmWorksheetHeader.Status := CommmWorksheetHeader.Status::"Payable Created";
            CommmWorksheetHeader.Modify();

            Message('Payable Successfully Created with Purchase Invoice No. %1', CommmWorksheetHeader."Comm. PI No.");
            Clear(PurchaseInvoice);
            PurchaseInvoice.SetRecord(PurchHeader);
            PurchaseInvoice.Run();
        end;

        exit(true);


    end;

    procedure CreatePurchasheInvoiceSV(TotalAppLCY: Decimal; CommmWorksheetHeader: Record "Commission SV. Worksht. Header"): Boolean
    var
        PurchHeader: Record "Purchase Header";
        PurchLine: Record "Purchase Line";
        CommSetup: Record "FTT-CST Commission Agr. Setup";
        PurchPost: Codeunit "Purch.-Post";
        PurchInvHeader: Record "Purch. Inv. Header";
        codPurchNumber: Code[50];
        PurchaseInvoice: Page "Purchase Invoice";
        recSalesPerson: Record "Salesperson/Purchaser";
    begin
        CommSetup.Get();

        if not recSalesPerson.get(CommmWorksheetHeader."Vendor No.  (SalesPerson)") then
            exit;

        recSalesPerson.TestField("Comm. Vendor No.");

        PurchHeader.Reset();
        PurchHeader.Init();
        PurchHeader."Document Type" := PurchHeader."Document Type"::Invoice;
        PurchHeader.Insert(true);

        PurchHeader.Validate(PurchHeader."Buy-from Vendor No.", recSalesPerson."Comm. Vendor No.");

        PurchHeader."Vendor Invoice No." := CommmWorksheetHeader."Document No.";
        PurchHeader."Comm. Document No." := CommmWorksheetHeader."Document No.";
        PurchHeader."Posting Description" := StrSubstNo('This invoice is for Commission Supervisor Document No. %1', CommmWorksheetHeader."Document No.");
        PurchHeader."Posting Date" := TODAY;

        PurchHeader.Modify();

        PurchLine.Reset();
        PurchLine.Init();
        PurchLine."Document Type" := PurchLine."Document Type"::Invoice;
        PurchLine."Document No." := PurchHeader."No.";
        PurchLine.Type := PurchLine.type::"G/L Account";
        PurchLine.Validate(PurchLine."No.", CommSetup."Payable G/L Account No.");
        PurchLine.Validate(PurchLine.Quantity, 1);
        PurchLine.Validate(PurchLine."Direct Unit Cost", TotalAppLCY);
        PurchLine.Insert(true);

        CommmWorksheetHeader."Comm. PI No." := PurchHeader."No.";
        CommmWorksheetHeader.Modify();



        Commit();

        if CommSetup."PI Create/Post" then begin
            PurchPost.SetSuppressCommit(true);
            PurchPost.Run(PurchHeader);

            PurchInvHeader.Reset();
            PurchInvHeader.SetRange(PurchInvHeader."Pre-Assigned No.", CommmWorksheetHeader."Comm. PI No.");
            if PurchInvHeader.FindFirst() then begin
                CommmWorksheetHeader."Comm. Payable Doc. No." := PurchInvHeader."No.";
                CommmWorksheetHeader.Status := CommmWorksheetHeader.Status::"Payable Posted";
                CommmWorksheetHeader."Payable Due Date" := PurchInvHeader."Due Date";
                CommmWorksheetHeader.Modify();

                Message('Payable Successfully Posted with Posted Purchase Invoice No. %1', PurchInvHeader."No.");

            end;

        end else begin
            CommmWorksheetHeader."Payable Due Date" := PurchHeader."Due Date";
            CommmWorksheetHeader.Status := CommmWorksheetHeader.Status::"Payable Created";
            CommmWorksheetHeader.Modify();

            Message('Payable Successfully Created with Purchase Invoice No. %1', CommmWorksheetHeader."Comm. PI No.");
            Clear(PurchaseInvoice);
            PurchaseInvoice.SetRecord(PurchHeader);
            PurchaseInvoice.Run();
        end;

        exit(true);


    end;


    procedure CreatePayment(var CommWorksheetHeader: Record "Commission Worksheet Header")
    var
        GenJnlLine: Record "Gen. Journal Line";
        GenJnlLine2: Record "Gen. Journal Line";
        GenJnlBatch: Record "Gen. Journal Batch";
        VendLedgEntry: Record "Vendor Ledger Entry";
        CommSetup: Record "FTT-CST Commission Agr. Setup";
        NoSeriesMgnt: Codeunit "No. Series";
        Vendor: Record Vendor;
        GenJnlPostLine: Codeunit "Gen. Jnl.-Post Line";
        PurchInvHeader: Record "Purch. Inv. Header";
        PaymentNo: Code[40];
        PaymentJournal: Page "Payment Journal";
        PaymentMEthod: Record "Payment Method";
    begin
        if not PaymentMEthod.Get(CommWorksheetHeader."Payment Method Code") then
            exit;

        CommSetup.Get();
        CommSetup.TestField("Default Currency Code");
        GenJnlBatch.Reset();
        GenJnlBatch.SetRange(GenJnlBatch."Journal Template Name", CommSetup."Claimed Jornal Template");
        GenJnlBatch.SetRange(GenJnlBatch.Name, CommSetup."Claimed Journal Batch");
        if GenJnlBatch.FindFirst() then begin
            GenJnlLine.Init();
            PaymentNo := NoSeriesMgnt.GetNextNo(GenJnlBatch."No. Series");
            GenJnlLine."Journal Template Name" := CommSetup."Claimed Jornal Template";
            GenJnlLine.validate("Journal Batch Name", CommSetup."Claimed Journal Batch");
            GenJnlLine."Line No." := GetLastLineNo(CommSetup."Claimed Jornal Template", CommSetup."Claimed Journal Batch") + 10000;
            GenJnlLine.Description := StrSubstNo('This payment is for Commission Document No. %1', CommWorksheetHeader."Document No.");
            GenJnlLine."Document Type" := GenJnlLine."Document Type"::Payment;
            GenJnlLine."Posting Date" := today;
            if PaymentMEthod."Bal. Account Type" = PaymentMEthod."Bal. Account Type"::"Bank Account" then begin
                GenJnlLine."Bal. Account Type" := GenJnlLine."Bal. Account Type"::"Bank Account";
                GenJnlLine."Bal. Account No." := CommWorksheetHeader."PDC Bank Account No.";
            end else begin
                GenJnlLine."Bal. Account Type" := GenJnlBatch."Bal. Account Type";
                GenJnlLine."Bal. Account No." := GenJnlBatch."Bal. Account No.";
            end;

            GenJnlLine."Comm. Document No." := CommWorksheetHeader."Document No.";
            GenJnlLine."Document No." := PaymentNo;
            GenJnlLine."Account Type" := GenJnlLine."Account Type"::Vendor;
            GenJnlLine.Validate("Account No.", CommWorksheetHeader."Vendor No.  (SalesPerson)");
            GenJnlLine.Validate("Currency Code", CommSetup."Default Currency Code");
            CommWorksheetHeader.CalcFields("Total Application Amount");
            Vendor.Reset();
            Vendor.SetRange("No.", CommWorksheetHeader."Vendor No.  (SalesPerson)");
            if Vendor.FindFirst() then begin
                GenJnlLine."Payment Method Code" := Vendor."Payment Method Code";
            end;
            GenJnlLine.validate(Amount, Abs(CommWorksheetHeader."Total Application Amount"));

            GenJnlLine.Validate("Applies-to Doc. Type", GenJnlLine."Applies-to Doc. Type"::Invoice);
            GenJnlLine.Validate("Applies-to Doc. No.", CommWorksheetHeader."Comm. Payable Doc. No.");
            GenJnlLine.UpdateAppliesToInvoiceID();
            GenJnlLine.Insert(true);

            CommWorksheetHeader.Status := CommWorksheetHeader.Status::"Payment Created";
            CommWorksheetHeader."Comm. Payment Doc. No." := PaymentNo;
            CommWorksheetHeader.Modify();

            if CommSetup."Create & Post Payment" then begin
                Commit();
                GenJnlPostLine.Run(GenJnlLine);
                GenJnlLine2.Reset();
                GenJnlLine2.SetRange("Journal Template Name", CommSetup."Claimed Jornal Template");
                GenJnlLine2.SetRange("Journal Batch Name", CommSetup."Claimed Journal Batch");
                GenJnlLine2.SetRange("Document No.", PaymentNo);
                if GenJnlLine2.FindFirst() then
                    GenJnlLine2.Delete();

            end else begin
                PaymentJournal.SetRecord(GenJnlLine);
                PaymentJournal.Run();
            end;

        end;
    end;

    procedure CreatePaymentSV(var CommWorksheetHeader: Record "Commission SV. Worksht. Header")
    var
        GenJnlLine: Record "Gen. Journal Line";
        GenJnlLine2: Record "Gen. Journal Line";
        GenJnlBatch: Record "Gen. Journal Batch";
        VendLedgEntry: Record "Vendor Ledger Entry";
        CommSetup: Record "FTT-CST Commission Agr. Setup";
        NoSeriesMgnt: Codeunit "No. Series";
        Vendor: Record Vendor;
        GenJnlPostLine: Codeunit "Gen. Jnl.-Post Line";
        PurchInvHeader: Record "Purch. Inv. Header";
        PaymentNo: Code[40];
        PaymentJournal: Page "Payment Journal";
        PaymentMEthod: Record "Payment Method";
    begin
        if not PaymentMEthod.Get(CommWorksheetHeader."Payment Method Code") then
            exit;

        CommSetup.Get();
        CommSetup.TestField("Default Currency Code");
        GenJnlBatch.Reset();
        GenJnlBatch.SetRange(GenJnlBatch."Journal Template Name", CommSetup."Claimed SV Jornal Template");
        GenJnlBatch.SetRange(GenJnlBatch.Name, CommSetup."Claimed SV Journal Batch");
        if GenJnlBatch.FindFirst() then begin
            GenJnlLine.Init();
            PaymentNo := NoSeriesMgnt.GetNextNo(GenJnlBatch."No. Series");
            GenJnlLine."Journal Template Name" := CommSetup."Claimed SV Jornal Template";
            GenJnlLine.validate("Journal Batch Name", CommSetup."Claimed SV Journal Batch");
            GenJnlLine."Line No." := GetLastLineNo(CommSetup."Claimed SV Jornal Template", CommSetup."Claimed SV Journal Batch") + 10000;
            GenJnlLine.Description := StrSubstNo('This payment is for Commission Supervisor Document No. %1', CommWorksheetHeader."Document No.");
            GenJnlLine."Document Type" := GenJnlLine."Document Type"::Payment;
            GenJnlLine."Posting Date" := today;
            if PaymentMEthod."Bal. Account Type" = PaymentMEthod."Bal. Account Type"::"Bank Account" then begin
                GenJnlLine."Bal. Account Type" := GenJnlLine."Bal. Account Type"::"Bank Account";
                GenJnlLine."Bal. Account No." := CommWorksheetHeader."PDC Bank Account No.";
            end else begin
                GenJnlLine."Bal. Account Type" := GenJnlBatch."Bal. Account Type";
                GenJnlLine."Bal. Account No." := GenJnlBatch."Bal. Account No.";
            end;
            GenJnlLine."Comm. Document No." := CommWorksheetHeader."Document No.";
            GenJnlLine."Document No." := PaymentNo;
            GenJnlLine."Account Type" := GenJnlLine."Account Type"::Vendor;
            GenJnlLine.Validate("Account No.", CommWorksheetHeader."Vendor No.  (SalesPerson)");
            GenJnlLine.Validate("Currency Code", CommSetup."Default Currency Code");
            CommWorksheetHeader.CalcFields("Total Application Amount");
            Vendor.Reset();
            Vendor.SetRange("No.", CommWorksheetHeader."Vendor No.  (SalesPerson)");
            if Vendor.FindFirst() then begin
                GenJnlLine."Payment Method Code" := Vendor."Payment Method Code";
            end;
            GenJnlLine.validate(Amount, Abs(CommWorksheetHeader."Total Application Amount"));

            GenJnlLine.Validate("Applies-to Doc. Type", GenJnlLine."Applies-to Doc. Type"::Invoice);
            GenJnlLine.Validate("Applies-to Doc. No.", CommWorksheetHeader."Comm. Payable Doc. No.");
            GenJnlLine.UpdateAppliesToInvoiceID();
            GenJnlLine.Insert(true);

            CommWorksheetHeader.Status := CommWorksheetHeader.Status::"Payment Created";
            CommWorksheetHeader."Comm. Payment Doc. No." := PaymentNo;
            CommWorksheetHeader.Modify();

            if CommSetup."Create & Post Payment" then begin
                Commit();
                GenJnlPostLine.Run(GenJnlLine);
                GenJnlLine2.Reset();
                GenJnlLine2.SetRange("Journal Template Name", CommSetup."Claimed Jornal Template");
                GenJnlLine2.SetRange("Journal Batch Name", CommSetup."Claimed Journal Batch");
                GenJnlLine2.SetRange("Document No.", PaymentNo);
                if GenJnlLine2.FindFirst() then
                    GenJnlLine2.Delete();

            end else begin
                PaymentJournal.SetRecord(GenJnlLine);
                PaymentJournal.Run();
            end;


        end;
    end;

    local procedure GetLastLineNo(JournalTemplate: Code[50]; JournalBatchName: Code[50]): Integer
    var
        GenJnlLine: Record "Gen. Journal Line";
    begin
        GenJnlLine.Reset();
        GenJnlLine.SetRange("Journal Template Name", JournalTemplate);
        GenJnlLine.SetRange("Journal Batch Name", JournalBatchName);
        if GenJnlLine.FindFirst() then
            exit(GenJnlLine."Line No.")
        else
            exit(0);
    end;

    procedure GetPercentFromEnum(Item: Record Item) Percent: Integer
    var
        Index: Integer;
        OrdinalValue: Integer;
        LevelName: Text;
    begin
        OrdinalValue := Item."FTT-CST Salesp. Comm. Type".AsInteger();
        Index := "FTT-CST SalespCommType".Ordinals().IndexOf(OrdinalValue);
        LevelName := "FTT-CST SalespCommType".Names().Get(Index);
        Evaluate(Percent, LevelName);
    end;

    procedure InsertCommissionPerSalesPersonCM(CustLedgerEntry2: Record "Cust. Ledger Entry"; CommPercent: Decimal; AppliedInvoice: code[50]; CommAmtLCY: Decimal; AgreementNo: code[50]; CommAmt: Decimal)
    var
        recCommissionEntry: Record "FTT-CST Commission Entries";
    begin
        CustLedgerEntry2.CalcFields(Amount);
        recCommissionEntry.Init();
        recCommissionEntry."Entry No." := 0;
        recCommissionEntry."Document Type" := CustLedgerEntry2."Document Type";
        recCommissionEntry."Document Date" := CustLedgerEntry2."Posting Date";
        recCommissionEntry."Document No." := CustLedgerEntry2."Document No.";
        recCommissionEntry."Sell-to Customer No." := CustLedgerEntry2."Sell-to Customer No.";
        recCommissionEntry."Sell-to Customer Name" := CustLedgerEntry2."Customer Name";
        recCommissionEntry."Currency Code" := CustLedgerEntry2."Currency Code";
        recCommissionEntry."Salesperson Code" := CustLedgerEntry2."Salesperson Code";
        recCommissionEntry."Commission %" := CommPercent;
        recCommissionEntry."Cust. Ledger Entry No." := CustLedgerEntry2."Entry No.";
        recCommissionEntry."Commission Agreement No." := AgreementNo;
        if CustLedgerEntry2."Document Type" = CustLedgerEntry2."Document Type"::"Credit Memo" then
            recCommissionEntry.Open := false
        else
            recCommissionEntry.Open := true;

        recCommissionEntry."Cust. Price Group Code" := GetCustPriceGroupCode(CustLedgerEntry2."Sell-to Customer No.");
        recCommissionEntry.Insert();
        Commit();

        InsertdltdCommissionEntryperSalesPerson(recCommissionEntry, AppliedInvoice, CommAmtLCY, CommAmt);
        Commit();

        InsertCommisionEntryForSupervisor(CustLedgerEntry2, AppliedInvoice);
        Commit();
    end;

    procedure InsertCommissionEntryperSalesPerson(CustLedgerEntry2: Record "Cust. Ledger Entry"; CommPercent: Decimal; AppliedInvoice: code[50]; CommAmtLCY: Decimal; AgreementNo: code[50]; CommAmt: Decimal)
    var
        recCommissionEntry: Record "FTT-CST Commission Entries";
    begin
        CustLedgerEntry2.CalcFields(Amount);
        recCommissionEntry.Init();
        recCommissionEntry."Entry No." := 0;
        recCommissionEntry."Document Type" := CustLedgerEntry2."Document Type";
        recCommissionEntry."Document Date" := CustLedgerEntry2."Posting Date";
        recCommissionEntry."Document No." := CustLedgerEntry2."Document No.";
        recCommissionEntry."Sell-to Customer No." := CustLedgerEntry2."Sell-to Customer No.";
        recCommissionEntry."Sell-to Customer Name" := CustLedgerEntry2."Customer Name";
        recCommissionEntry."Currency Code" := CustLedgerEntry2."Currency Code";
        recCommissionEntry."Salesperson Code" := CustLedgerEntry2."Salesperson Code";
        recCommissionEntry."Commission %" := CommPercent;
        recCommissionEntry."Cust. Ledger Entry No." := CustLedgerEntry2."Entry No.";
        recCommissionEntry."Commission Agreement No." := AgreementNo;
        if CustLedgerEntry2."Document Type" = CustLedgerEntry2."Document Type"::"Credit Memo" then
            recCommissionEntry.Open := false
        else
            recCommissionEntry.Open := true;

        recCommissionEntry."Cust. Price Group Code" := GetCustPriceGroupCode(CustLedgerEntry2."Sell-to Customer No.");
        recCommissionEntry.Insert();
        Commit();

        InsertdltdCommissionEntryperSalesPerson(recCommissionEntry, AppliedInvoice, CommAmtLCY, CommAmt);
        Commit();

        InsertCommisionEntryForSupervisor(CustLedgerEntry2, AppliedInvoice);
        Commit();

    end;

    procedure GetDiffDate(StartingDate: Date; EndingDate: Date): Decimal
    var
        GeneralLedgerSetup: Record "General Ledger Setup";
        DiffDate: Decimal;
        DiffM: Integer;
        DiffY: Integer;
    begin

        DiffM := Date2DMY(EndingDate, 2) - Date2DMY(StartingDate, 2);
        DiffY := Date2DMY(EndingDate, 3) - Date2DMY(StartingDate, 3);
        DiffDate := 12 * DiffY + DiffM;
        if Date2DMY(EndingDate, 1) > Date2DMY(StartingDate, 1) then
            DiffDate += 1;

        if DiffDate = 0 then
            DiffDate := 1;

        GeneralLedgerSetup.Get();
        DiffDate := Round(DiffDate, GeneralLedgerSetup."Unit-Amount Rounding Precision");
        exit(DiffDate);


    end;

    procedure InsertSupervisorEntry(CustLedgerEntry2: Record "Cust. Ledger Entry"; CommPercent: Decimal; AppliedInvoice: code[50]; SupvCode: code[20]; AgreementCode: code[50])
    var
        recSupervisorEntry: Record "FTT-CST SV Ledger Entry";

    begin
        recSupervisorEntry.Reset();
        recSupervisorEntry.SetRange("Document Type", CustLedgerEntry2."Document Type");
        recSupervisorEntry.SetRange("Document No.", CustLedgerEntry2."Document No.");
        if not recSupervisorEntry.FindFirst() then begin
            recSupervisorEntry.Init();
            recSupervisorEntry."Entry No." := 0;
            recSupervisorEntry."Document Type" := CustLedgerEntry2."Document Type";
            recSupervisorEntry."Document Date" := CustLedgerEntry2."Posting Date";
            recSupervisorEntry."Document No." := CustLedgerEntry2."Document No.";
            recSupervisorEntry."Sell-to Customer No." := CustLedgerEntry2."Sell-to Customer No.";
            recSupervisorEntry."Sell-to Customer Name" := CustLedgerEntry2."Customer Name";
            recSupervisorEntry."Currency Code" := CustLedgerEntry2."Currency Code";
            recSupervisorEntry."Salesperson Code" := CustLedgerEntry2."Salesperson Code";
            recSupervisorEntry."Supervisor Code" := SupvCode;
            recSupervisorEntry."Supervisor Reward %" := CommPercent;
            recSupervisorEntry."Commission Agreement No." := AgreementCode;
            recSupervisorEntry."Cust. Ledger Entry No." := CustLedgerEntry2."Entry No.";
            if CustLedgerEntry2."Document Type" = CustLedgerEntry2."Document Type"::"Credit Memo" then
                recSupervisorEntry.Open := false
            else
                recSupervisorEntry.Open := true;

            if recSupervisorEntry.Insert() then begin
                recSupervisorEntry.CalcFields("Commission Amount (LCY)", "Commission Amount");
                recSupervisorEntry."Supervisor Reward Amount" := recSupervisorEntry."Commission Amount" * (CommPercent / 100);
                recSupervisorEntry."Supervisor Reward Amount (LCY)" := recSupervisorEntry."Commission Amount (LCY)" * (CommPercent / 100);
                recSupervisorEntry.Modify();
            end;
            Commit();

            InsertdltdCommissionEntrySupervisor(recSupervisorEntry, AppliedInvoice);
            Commit();
        end;
    end;

    local procedure InsertdltdCommissionEntrySupervisor(pCommEntry: Record "FTT-CST SV Ledger Entry"; AppliedInvoice: code[50])
    var
        recdltgSuperEntry: Record "FTT-CST Super Dtld. Ledg. Ent.";
    begin

        recdltgSuperEntry.Reset();
        recdltgSuperEntry.SetRange("Supv. Ledger Entry No.", pCommEntry."Entry No.");
        if not recdltgSuperEntry.FindFirst() then begin
            pCommEntry.CalcFields("Commission Amount (LCY)", "Commission Amount");
            recdltgSuperEntry.Init();
            recdltgSuperEntry."Entry No." := 0;
            recdltgSuperEntry."Entry Type" := recdltgSuperEntry."Entry Type"::"Initial Entry";
            recdltgSuperEntry."Posting Date" := pCommEntry."Document Date";
            recdltgSuperEntry."Document Type" := pCommEntry."Document Type";
            recdltgSuperEntry."Document No." := pCommEntry."Document No.";
            recdltgSuperEntry."Customer No." := pCommEntry."Sell-to Customer No.";
            recdltgSuperEntry."Salesperson Code" := pCommEntry."Salesperson Code";
            recdltgSuperEntry."Commission Amount" := pCommEntry."Commission Amount";
            recdltgSuperEntry."Commission Amount (LCY)" := pCommEntry."Commission Amount (LCY)";
            recdltgSuperEntry."Supervisor Reward Amount" := pCommEntry."Supervisor Reward Amount";
            recdltgSuperEntry."Supervisor Reward Amount (LCY)" := pCommEntry."Supervisor Reward Amount (LCY)";
            recdltgSuperEntry."Currency Code" := pCommEntry."Currency Code";
            recdltgSuperEntry."Created By" := UserId;
            recdltgSuperEntry."Supv. Ledger Entry No." := pCommEntry."Entry No.";
            recdltgSuperEntry.Insert();
            Commit();

            if (pCommEntry."Document Type" = pCommEntry."Document Type"::"Credit Memo") AND (AppliedInvoice <> '') then
                InsertSuperApplicationEntryCM(recdltgSuperEntry, AppliedInvoice)
        end;
    end;

    local procedure InsertSuperApplicationEntryCM(dltgCommEntry: Record "FTT-CST Super Dtld. Ledg. Ent."; AppliedInvoice: code[50])
    var
        recdtlgCommissionLdgrEntry: Record "FTT-CST Super Dtld. Ledg. Ent.";
        recCommissionLedgerEntry: Record "FTT-CST SV Ledger Entry";
    begin
        recCommissionLedgerEntry.Reset();
        recCommissionLedgerEntry.SetRange("Document Type", recCommissionLedgerEntry."Document Type"::Invoice);
        recCommissionLedgerEntry.SetRange("Document No.", AppliedInvoice);
        if recCommissionLedgerEntry.FindFirst() then begin
            recCommissionLedgerEntry.CalcFields("Commission Amount (LCY)", "Commission Amount");
            recdtlgCommissionLdgrEntry.Init();
            recdtlgCommissionLdgrEntry.TransferFields(dltgCommEntry);
            recdtlgCommissionLdgrEntry."Entry No." := 0;
            recdtlgCommissionLdgrEntry."Entry Type" := recdtlgCommissionLdgrEntry."Entry Type"::Application;
            recdtlgCommissionLdgrEntry."Commission Amount (LCY)" := recCommissionLedgerEntry."Commission Amount (LCY)" * -1;
            recdtlgCommissionLdgrEntry."Commission Amount" := recCommissionLedgerEntry."Commission Amount" * -1;
            recdtlgCommissionLdgrEntry."Supervisor Reward Amount" := recCommissionLedgerEntry."Supervisor Reward Amount" * -1;
            recdtlgCommissionLdgrEntry."Supervisor Reward Amount (LCY)" := recCommissionLedgerEntry."Supervisor Reward Amount (LCY)" * -1;
            recdtlgCommissionLdgrEntry."Supv. Ledger Entry No." := recCommissionLedgerEntry."Entry No.";
            recdtlgCommissionLdgrEntry.Insert();
            Commit();

            recCommissionLedgerEntry."Rem. Super. Reward Amt (LCY)" := 0;
            recCommissionLedgerEntry."Rem. Super. Reward Amt" := 0;
            recCommissionLedgerEntry.Open := false;
            recCommissionLedgerEntry.Modify();
        end;
    end;

    procedure InsertCommisionEntryForSupervisor(CustLedgerEntry: Record "Cust. Ledger Entry"; AppliedInvoice: code[50]);
    var
        Team: Record Team;
        TeamSalesperson: Record "Team Salesperson";
        CommissionAgrmhdr: Record "FTT-CST Comm. Agrm. Header";
        CommissionAgrmLines: Record "FTT-CST Comm. Agrm. Lines";
    begin

        TeamSalesperson.SetRange("Salesperson Code", CustLedgerEntry."Salesperson Code");
        if not TeamSalesperson.FindSet() then
            exit;

        repeat
            Team.Get(TeamSalesperson."Team Code");
            if Team."FTT-CST Supervisor Code" <> '' then begin
                CommissionAgrmhdr.Reset();
                CommissionAgrmhdr.SetRange("Salesperson Type", CommissionAgrmhdr."Salesperson Type"::Team);
                CommissionAgrmhdr.SetRange("Type No.", Team.Code);
                CommissionAgrmhdr.SetRange("Supervisor Code", Team."FTT-CST Supervisor Code");
                //CommissionAgrmhdr.SetRange("Agreement Period", SalesInvoiceHeader."FTT-CST Agr. Period Number"); //Temporary
                CommissionAgrmhdr.SetFilter("Agr. Ending Date", '>%1', CustLedgerEntry."Posting Date");
                CommissionAgrmhdr.SetRange(Status, CommissionAgrmhdr.Status::Activated);
                if CommissionAgrmhdr.FindFirst() then begin
                    CommissionAgrmLines.Reset();
                    CommissionAgrmLines.SetRange("Agreement No.", CommissionAgrmhdr."Agreement No.");
                    CommissionAgrmLines.SetRange("Salesperson Code", CustLedgerEntry."Salesperson Code");
                    if CommissionAgrmLines.FindFirst() then begin
                        InsertSupervisorEntry(CustLedgerEntry, CommissionAgrmLines."Commission %", AppliedInvoice, CommissionAgrmhdr."Supervisor Code", CommissionAgrmhdr."Agreement No.");
                    end;

                end;
            end;
        until TeamSalesperson.Next() = 0;
    end;


    local procedure InsertdltdCommissionEntryperSalesPerson(pCommEntry: Record "FTT-CST Commission Entries"; AppliedInvoice: code[50]; CommAmtLCY: Decimal; CommAmt: Decimal)
    var
        recdltgCommEntry: Record "FTT-CST Dtldg. Comm. Entries";
    begin

        recdltgCommEntry.Reset();
        recdltgCommEntry.SetRange("Comm. Ledger Entry No.", pCommEntry."Entry No.");
        if not recdltgCommEntry.FindFirst() then begin
            pCommEntry.CalcFields("Commission Amount (LCY)");
            recdltgCommEntry.Init();
            recdltgCommEntry."Entry No." := 0;
            recdltgCommEntry."Entry Type" := recdltgCommEntry."Entry Type"::"Initial Entry";
            recdltgCommEntry."Posting Date" := pCommEntry."Document Date";
            recdltgCommEntry."Document Type" := pCommEntry."Document Type";
            recdltgCommEntry."Document No." := pCommEntry."Document No.";
            recdltgCommEntry."Customer No." := pCommEntry."Sell-to Customer No.";
            recdltgCommEntry."Commission Amount (LCY)" := CommAmtLCY;
            recdltgCommEntry."Commission Amount" := CommAmt;

            recdltgCommEntry."Currency Code" := pCommEntry."Currency Code";
            recdltgCommEntry."Comm. Ledger Entry No." := pCommEntry."Entry No.";
            recdltgCommEntry.Insert();
            Commit();

            if (pCommEntry."Document Type" = pCommEntry."Document Type"::"Credit Memo") AND (AppliedInvoice <> '') then
                InsertApplicationEntryCM(recdltgCommEntry, AppliedInvoice, CommAmtLCY, CommAmt)
        end;
    end;

    local procedure InsertApplicationEntryCM(dltgCommEntry: Record "FTT-CST Dtldg. Comm. Entries"; AppliedInvoice: code[50]; CommAmtLCY: Decimal; CommAmt: Decimal)
    var
        recdtlgCommissionLdgrEntry: Record "FTT-CST Dtldg. Comm. Entries";
        recCommissionLedgerEntry: Record "FTT-CST Commission Entries";
        RemAmtCommLcy: Decimal;
        RemAmtComm: Decimal;
    begin
        recCommissionLedgerEntry.Reset();
        recCommissionLedgerEntry.SetRange("Document Type", recCommissionLedgerEntry."Document Type"::Invoice);
        recCommissionLedgerEntry.SetRange("Document No.", AppliedInvoice);
        if recCommissionLedgerEntry.FindFirst() then begin
            RemAmtCommLcy := 0;
            recCommissionLedgerEntry.CalcFields("Commission Amount (LCY)");
            recdtlgCommissionLdgrEntry.Init();
            recdtlgCommissionLdgrEntry.TransferFields(dltgCommEntry);
            recdtlgCommissionLdgrEntry."Entry No." := 0;
            recdtlgCommissionLdgrEntry."Entry Type" := recdtlgCommissionLdgrEntry."Entry Type"::Application;
            recdtlgCommissionLdgrEntry."Commission Amount (LCY)" := CommAmtLCY;
            recdtlgCommissionLdgrEntry."Commission Amount" := CommAmt;
            recdtlgCommissionLdgrEntry."Comm. Ledger Entry No." := recCommissionLedgerEntry."Entry No.";
            recdtlgCommissionLdgrEntry.Insert();
            Commit();

            RemAmtCommLcy := recCommissionLedgerEntry."Commission Amount (LCY)" - abs(CommAmtLCY);
            RemAmtComm := recCommissionLedgerEntry."Commission Amount" - abs(CommAmt);
            if RemAmtCommLcy = 0 then begin

                recCommissionLedgerEntry."Rem. Commission Amount (LCY)" := 0;
                recCommissionLedgerEntry."Rem. Commission Amount" := 0;
                recCommissionLedgerEntry.Open := false;
                recCommissionLedgerEntry.Modify();
            end else begin

                recCommissionLedgerEntry."Rem. Commission Amount (LCY)" := RemAmtCommLcy;
                recCommissionLedgerEntry."Rem. Commission Amount" := RemAmtComm;
                recCommissionLedgerEntry.Open := true;
                recCommissionLedgerEntry.Modify();
            end
        end;
    end;

    procedure InsertApplicationEntryPayment(CommWsLines: Record "Commission Worksheet Lines"; docno: code[20]; pPostingDate: Date; CurrCode: code[20])
    var
        recdtlgCommissionLdgrEntry: Record "FTT-CST Dtldg. Comm. Entries";
        recCommissionLedgerEntry: Record "FTT-CST Commission Entries";
        RemAmtCommLcy: Decimal;
        RemAmtComm: Decimal;
        SalesInvHeader: Record "Sales Invoice Header";
    begin
        if not SalesInvHeader.get(CommWsLines."Inv, Document No.") then
            exit;

        recCommissionLedgerEntry.Reset();
        recCommissionLedgerEntry.SetRange("Document Type", recCommissionLedgerEntry."Document Type"::Invoice);
        recCommissionLedgerEntry.SetRange("Document No.", CommWsLines."Inv, Document No.");
        recCommissionLedgerEntry.SetRange("Entry No.", CommWsLines."Comm. Entry No.");
        if recCommissionLedgerEntry.FindFirst() then begin
            RemAmtCommLcy := 0;
            recCommissionLedgerEntry.CalcFields("Commission Amount (LCY)", "Rem. Commission Amount (LCY)", "Commission Amount", "Rem. Commission Amount");
            recdtlgCommissionLdgrEntry.Init();
            recdtlgCommissionLdgrEntry."Entry No." := 0;
            recdtlgCommissionLdgrEntry."Currency Code" := CurrCode;
            recdtlgCommissionLdgrEntry."Document No." := docno;
            recdtlgCommissionLdgrEntry."Posting Date" := pPostingDate;
            recdtlgCommissionLdgrEntry."Customer No." := recCommissionLedgerEntry."Sell-to Customer No.";
            recdtlgCommissionLdgrEntry."Created By" := UserId;
            recdtlgCommissionLdgrEntry."Entry Type" := recdtlgCommissionLdgrEntry."Entry Type"::Application;
            recdtlgCommissionLdgrEntry."Document Type" := recdtlgCommissionLdgrEntry."Document Type"::Payment;
            recdtlgCommissionLdgrEntry."Commission Amount" := recCommissionLedgerEntry."Commission Amount" * -1;

            if CurrCode <> '' then
                recdtlgCommissionLdgrEntry."Commission Amount (LCY)" := (CommWsLines."Application Amount" * -1) / SalesInvHeader."Currency Factor"
            else
                recdtlgCommissionLdgrEntry."Commission Amount (LCY)" := CommWsLines."Application Amount" * -1;

            recdtlgCommissionLdgrEntry."Comm. Ledger Entry No." := recCommissionLedgerEntry."Entry No.";
            recdtlgCommissionLdgrEntry.Insert();
            Commit();

            if CurrCode <> '' then begin
                RemAmtCommLcy := recCommissionLedgerEntry."Rem. Commission Amount (LCY)" - ((CommWsLines."Application Amount" * -1) / SalesInvHeader."Currency Factor");
                RemAmtComm := recCommissionLedgerEntry."Rem. Commission Amount" - abs(CommWsLines."Application Amount");
            end else begin
                RemAmtCommLcy := recCommissionLedgerEntry."Rem. Commission Amount (LCY)" - abs(CommWsLines."Application Amount");
                RemAmtComm := recCommissionLedgerEntry."Rem. Commission Amount" - abs(CommWsLines."Application Amount");
            end;

            if RemAmtComm = 0 then begin //Change to RemAmtComm from RemAmtCommLcy
                recCommissionLedgerEntry."Rem. Commission Amount (LCY)" := 0;
                recCommissionLedgerEntry."Rem. Commission Amount" := 0;
                recCommissionLedgerEntry.Open := false;
                recCommissionLedgerEntry.Modify();
            end else begin
                RemAmtComm := recCommissionLedgerEntry."Rem. Commission Amount" - abs(CommWsLines."Application Amount");
                Commit();
                recCommissionLedgerEntry."Rem. Commission Amount" := RemAmtComm;
                recCommissionLedgerEntry."Rem. Commission Amount (LCY)" := RemAmtCommLcy;
                recCommissionLedgerEntry.Open := true;
                recCommissionLedgerEntry.Modify();
            end
        end;
    end;

    procedure InsertApplicationEntryPaymentSV(CommWsLines: Record "Commission SV. Worksheet Lines"; docno: code[20]; pPostingDate: Date; CurrCode: code[20])
    var
        recdtlgCommissionLdgrEntry: Record "FTT-CST Super Dtld. Ledg. Ent.";
        recCommissionLedgerEntry: Record "FTT-CST SV Ledger Entry";
        RemAmtCommLcy: Decimal;
        RemAmtComm: Decimal;
        SalesInvHeader: Record "Sales Invoice Header";
    begin
        if not SalesInvHeader.get(CommWsLines."Inv, Document No.") then
            exit;

        recCommissionLedgerEntry.Reset();
        recCommissionLedgerEntry.SetRange("Document Type", recCommissionLedgerEntry."Document Type"::Invoice);
        recCommissionLedgerEntry.SetRange("Document No.", CommWsLines."Inv, Document No.");
        if recCommissionLedgerEntry.FindFirst() then begin
            RemAmtCommLcy := 0;
            recCommissionLedgerEntry.CalcFields("Commission Amount (LCY)", "Rem. Super. Reward Amt (LCY)", "Rem. Super. Reward Amt", "Commission Amount");
            recdtlgCommissionLdgrEntry.Init();
            recdtlgCommissionLdgrEntry."Entry No." := 0;
            recdtlgCommissionLdgrEntry."Currency Code" := CurrCode;
            recdtlgCommissionLdgrEntry."Document No." := docno;
            recdtlgCommissionLdgrEntry."Posting Date" := pPostingDate;
            recdtlgCommissionLdgrEntry."Customer No." := recCommissionLedgerEntry."Sell-to Customer No.";
            recdtlgCommissionLdgrEntry."Salesperson Code" := recCommissionLedgerEntry."Salesperson Code";
            recdtlgCommissionLdgrEntry."Commission Amount (LCY)" := recCommissionLedgerEntry."Commission Amount (LCY)";
            recdtlgCommissionLdgrEntry."Commission Amount" := recCommissionLedgerEntry."Commission Amount";
            recdtlgCommissionLdgrEntry."Created By" := UserId;
            recdtlgCommissionLdgrEntry."Entry Type" := recdtlgCommissionLdgrEntry."Entry Type"::Application;
            recdtlgCommissionLdgrEntry."Document Type" := recdtlgCommissionLdgrEntry."Document Type"::Payment;
            recdtlgCommissionLdgrEntry."Supervisor Reward Amount" := CommWsLines."Application Amount" * -1;
            if CurrCode <> '' then
                recdtlgCommissionLdgrEntry."Supervisor Reward Amount (LCY)" := (CommWsLines."Application Amount" / SalesInvHeader."Currency Factor") * -1
            else
                recdtlgCommissionLdgrEntry."Supervisor Reward Amount" := CommWsLines."Application Amount" * -1;

            //recdtlgCommissionLdgrEntry."Supervisor Reward Amount (LCY)" := CommWsLines."Application Amount" * -1;
            recdtlgCommissionLdgrEntry."Supv. Ledger Entry No." := recCommissionLedgerEntry."Entry No.";
            recdtlgCommissionLdgrEntry.Insert();
            Commit();

            if CurrCode <> '' then
                RemAmtCommLcy := recCommissionLedgerEntry."Rem. Super. Reward Amt (LCY)" - (abs(CommWsLines."Application Amount") / SalesInvHeader."Currency Factor")
            else
                RemAmtCommLcy := recCommissionLedgerEntry."Rem. Super. Reward Amt (LCY)" - abs(CommWsLines."Application Amount");


            //RemAmtCommLcy := recCommissionLedgerEntry."Rem. Super. Reward Amt (LCY)" - abs(CommWsLines."Application Amount");

            if RemAmtCommLcy = 0 then begin
                recCommissionLedgerEntry."Rem. Super. Reward Amt (LCY)" := 0;
                recCommissionLedgerEntry."Rem. Super. Reward Amt" := 0;
                recCommissionLedgerEntry.Open := false;
                recCommissionLedgerEntry.Modify();
            end else begin
                RemAmtComm := recCommissionLedgerEntry."Rem. Super. Reward Amt" - abs(CommWsLines."Application Amount");
                Commit();
                recCommissionLedgerEntry."Rem. Super. Reward Amt" := RemAmtComm;
                recCommissionLedgerEntry."Rem. Super. Reward Amt (LCY)" := RemAmtCommLcy;
                recCommissionLedgerEntry.Open := true;
                recCommissionLedgerEntry.Modify();
            end
        end;
    end;


    local procedure GetCustPriceGroupCode(custNo: code[20]): code[20]
    var
        recCustomer: Record Customer;
    begin
        if not recCustomer.Get(custNo) then
            exit('');

        exit(recCustomer."Customer Price Group")
    end;

    [EventSubscriber(ObjectType::Page, Page::Navigate, OnAfterNavigateFindRecords, '', false, false)]
    local procedure Navigate_OnAfterNavigateFindRecords(var Sender: Page Navigate; var DocumentEntry: Record "Document Entry" temporary; DocNoFilter: Text; PostingDateFilter: Text; var NewSourceRecVar: Variant; ExtDocNo: Code[250]; HideDialog: Boolean)
    var
        CommissionLedgerEntry: Record "FTT-CST Commission Entries";
    begin

        if CommissionLedgerEntry.ReadPermission() then begin
            CommissionLedgerEntry.SetCurrentKey("Document No.", "Document Date");
            CommissionLedgerEntry.SetFilter("Document No.", DocNoFilter);
            CommissionLedgerEntry.SetFilter("Document Date", PostingDateFilter);

            InsertIntoDocEntry(DocumentEntry, DATABASE::"FTT-CST Commission Entries", 0, CopyStr(CommissionLedgerEntry.TableCaption(), 1, 1024), CommissionLedgerEntry.Count());
        end;
    end;

    procedure InsertIntoDocEntry(var TempDocumentEntry: Record "Document Entry" temporary; DocTableID: Integer; DocType: Option; DocTableName: Text[1024]; DocNoOfRecords: Integer)
    begin
        if DocNoOfRecords = 0 then
            exit;

        TempDocumentEntry.Init();
        TempDocumentEntry."Entry No." := TempDocumentEntry."Entry No." + 1;
        TempDocumentEntry."Table ID" := DocTableID;
        TempDocumentEntry."Document Type" := Enum::"Document Entry Document Type".FromInteger(DocType); //DocType
        TempDocumentEntry."Table Name" := CopyStr(DocTableName, 1, MaxStrLen(TempDocumentEntry."Table Name"));
        TempDocumentEntry."No. of Records" := DocNoOfRecords;
        TempDocumentEntry.Insert();
    end;


    [EventSubscriber(ObjectType::Page, Page::Navigate, OnAfterNavigateShowRecords, '', false, false)]
    local procedure Navigate_OnAfterNavigateShowRecords(var Sender: Page Navigate; TableID: Integer; DocNoFilter: Text; PostingDateFilter: Text; ItemTrackingSearch: Boolean; var TempDocumentEntry: Record "Document Entry" temporary; SalesInvoiceHeader: Record "Sales Invoice Header"; SalesCrMemoHeader: Record "Sales Cr.Memo Header"; PurchInvHeader: Record "Purch. Inv. Header"; PurchCrMemoHdr: Record "Purch. Cr. Memo Hdr."; ServiceInvoiceHeader: Record "Service Invoice Header"; ServiceCrMemoHeader: Record "Service Cr.Memo Header"; ContactType: Enum "Navigate Contact Type"; ContactNo: Code[250]; ExtDocNo: Code[250])
    var
        CommissionLedgerEntry: Record "FTT-CST Commission Entries";
    begin
        if CommissionLedgerEntry.ReadPermission() then
            if TableID = DATABASE::"FTT-CST Commission Entries" then begin
                CommissionLedgerEntry.SetCurrentKey("Document No.", "Document Date");
                CommissionLedgerEntry.SetFilter("Document No.", DocNoFilter);
                CommissionLedgerEntry.SetFilter("Document Date", PostingDateFilter);
                PAGE.Run(50030, CommissionLedgerEntry);
            end;
    end;

    //Unapply Entries
    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Gen. Jnl.-Post Line", 'OnBeforeCustLedgEntryModify', '', false, false)]
    local procedure OnBeforeCustLedgEntryModify(var CustLedgerEntry: Record "Cust. Ledger Entry")
    begin
        UpdateCommLedgerEntriesUnAppliedEntries;
    end;
    //Apply Entries
    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Gen. Jnl.-Post Line", OnAfterCustPostApplyCustLedgEntry, '', false, false)]
    local procedure "Gen. Jnl.-Post Line_OnAfterCustPostApplyCustLedgEntry"(var GenJnlLine: Record "Gen. Journal Line"; var GLReg: Record "G/L Register"; CustLedgerEntry: Record "Cust. Ledger Entry")
    begin
        UpdateCommLedgerEntriesAppliedEntries;
    end;


    procedure UpdateCommLedgerEntriesAppliedEntries()
    var
        CommLedgerEntires: Record "FTT-CST Commission Entries";
        CommSVLedgerEntires: Record "FTT-CST SV Ledger Entry";
    begin
        CommLedgerEntires.Reset();
        CommLedgerEntires.SetRange("Document Type", CommLedgerEntires."Document Type"::Invoice);
        CommLedgerEntires.SetRange("Invoice Settled", false);
        if CommLedgerEntires.FindSet() then
            repeat
                CommLedgerEntires.CalcFields("Amount Paid", "Amount (Excl. Vat)");
                if abs(CommLedgerEntires."Amount (Excl. Vat)") = abs(CommLedgerEntires."Amount Paid") then begin
                    CommLedgerEntires."Invoice Settled" := true;
                    CommLedgerEntires.Modify();
                    Commit();

                    CommSVLedgerEntires.Reset();
                    CommSVLedgerEntires.SetRange("Document Type", CommSVLedgerEntires."Document Type"::Invoice);
                    CommSVLedgerEntires.SetRange("Document No.", CommLedgerEntires."Document No.");
                    if CommSVLedgerEntires.FindFirst() then begin
                        CommSVLedgerEntires."Invoice Settled" := true;
                        CommSVLedgerEntires.Modify();
                    end;
                end;

            until CommLedgerEntires.Next() = 0;

    end;

    local procedure UpdateCommLedgerEntriesUnAppliedEntries()
    var
        CommLedgerEntires: Record "FTT-CST Commission Entries";
    begin
        CommLedgerEntires.Reset();
        CommLedgerEntires.SetRange("Document Type", CommLedgerEntires."Document Type"::Invoice);
        CommLedgerEntires.SetRange("Invoice Settled", true);
        if CommLedgerEntires.FindSet() then
            repeat
                CommLedgerEntires.CalcFields("Amount Paid", "Amount (Excl. Vat)");
                if abs(CommLedgerEntires."Amount (Excl. Vat)") <> abs(CommLedgerEntires."Amount Paid") then
                    CommLedgerEntires."Invoice Settled" := false;
                CommLedgerEntires.Modify();
            until CommLedgerEntires.Next() = 0;

    end;


    procedure CalculateCommissionBase(pSalesHeader: Record "Sales Header")
    var
        SalesLine: Record "Sales Line";
        LineCommBase: Decimal;
        LineAmount: Decimal;
        CommPercent: Decimal;
        Item: Record Item;
        ItemCommisionValue: Integer;
        CommissionAgrmhdr: Record "FTT-CST Comm. Agrm. Header";
        CommissionAgrmLines: Record "FTT-CST Comm. Agrm. Lines";

    begin


        CommissionAgrmhdr.Reset();
        CommissionAgrmhdr.SetRange("Salesperson Type", CommissionAgrmhdr."Salesperson Type"::Salesperson);
        CommissionAgrmhdr.SetRange("Type No.", pSalesHeader."Salesperson Code");
        CommissionAgrmhdr.SetFilter("Agr. Ending Date", '>%1', pSalesHeader."Posting Date");
        CommissionAgrmhdr.SetRange(Status, CommissionAgrmhdr.Status::Activated);
        if CommissionAgrmhdr.FindFirst() then begin
            SalesLine.SetRange("Document No.", pSalesHeader."No.");
            SalesLine.SetRange(Type, "Sales Line Type"::Item);

            if not SalesLine.FindSet() then
                exit;
            repeat

                LineCommBase := 0;
                LineAmount := 0;
                Item.Get(SalesLine."No.");
                if Item."FTT-CST Eligible" then begin

                    CommissionAgrmLines.Reset();
                    CommissionAgrmLines.SetRange("Agreement No.", CommissionAgrmhdr."Agreement No.");
                    CommissionAgrmLines.SetRange("Item Category Type", CommissionAgrmLines."Item Category Type"::"Parent Item Category");
                    CommissionAgrmLines.SetRange("Category No.", SalesLine."FTT-CST Parent Item Cat. Code");
                    CommissionAgrmLines.SetRange("Agreement Period", SalesLine."Agreement Period");
                    if CommissionAgrmLines.FindSet() then begin
                        CommPercent := CommissionAgrmLines."Commission %";
                        ItemCommisionValue := GetPercentFromEnum(Item);

                        LineAmount := SalesLine.Amount;
                        LineCommBase := LineAmount * (CommissionAgrmLines."Commission %" / 100) * (ItemCommisionValue / 100);
                        Commit();
                        SalesLine."Commission Base Amount" := Round(LineCommBase, 0.01, '=');
                        SalesLine.Modify();
                    end;
                end;
            until SalesLine.Next() = 0;
            Commit();
        end;
    end;

    var
        myInt: Integer;
}