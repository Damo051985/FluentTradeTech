codeunit 60001 "FTT-CST Custom E-mail Notif."
{
    TableNo = "Job Queue Entry";

    trigger OnRun()
    begin
        case UpperCase(Rec."Parameter String") of
            UpperCase('EXPIREDDOCS'):
                EmailExpiredDocAttachments(WorkDate());
        end;
    end;

    local procedure EmailExpiredDocAttachments(NotificationDate: Date)
    var
        DocumentAttachment: Record "Document Attachment";
        SendingEmailAccount: Record "Email Account";
    begin
        DocumentAttachment.Reset();
        DocumentAttachment.SetFilter("Table ID", '%1|%2', Database::Customer, Database::Contact);
        DocumentAttachment.SetCurrentKey("Table ID", "No.");
        DocumentAttachment.SetRange("FTT-CST Notification Date", NotificationDate);
        if DocumentAttachment.FindSet() then begin
            SendingEmailAccount := GetEmailSenderAccount();
            repeat
                DocumentAttachment.SetRange("Table ID", DocumentAttachment."Table ID");
                DocumentAttachment.SetRange("No.", DocumentAttachment."No.");

                NotifyAttachmentExpired(DocumentAttachment, SendingEmailAccount);

                if DocumentAttachment.FindLast() then;
                DocumentAttachment.SetRange("Table ID");
                DocumentAttachment.SetRange("No.");
            until DocumentAttachment.Next() = 0;
        end;
    end;

    local procedure NotifyAttachmentExpired(var DocumentAttachment: Record "Document Attachment"; SendingEmailAccount: Record "Email Account")
    var
        Email: Codeunit Email;
        EmailMessage: Codeunit "Email Message";
    begin
        CreateEmailMessage(DocumentAttachment, EmailMessage);
        Email.Send(EmailMessage, SendingEmailAccount);
    end;

    local procedure CreateEmailMessage(var DocumentAttachment: Record "Document Attachment"; var EmailMessage: Codeunit "Email Message")
    var
        Contact: Record Contact;
        Customer: Record Customer;
        DocAttachmentMgt: Codeunit "FTT-CST Doc. Attachment Mgt.";
        EmailBody: Text;
        EmailRecipients: Text;
        EmailSubject: Text;
    begin
        case DocumentAttachment."Table ID" of
            Database::Customer:
                begin
                    if not Customer.Get(DocumentAttachment."No.") then
                        exit;

                    if Customer."FTT-CST Notif. Mail Gr. Code" <> '' then
                        EmailRecipients := GetContactMailingGroupEmails(Customer."FTT-CST Notif. Mail Gr. Code");

                    if EmailRecipients = '' then
                        exit;

                    EmailSubject := DocAttachmentMgt.GenerateExpiredAttachmentEmailSubject(DocumentAttachment."No.", Customer.TableCaption, Customer.Name);
                    EmailBody := DocAttachmentMgt.GenerateExpiredAttachmentEmailBody(DocumentAttachment, Customer.TableCaption, Customer.Name);
                end;
            Database::Contact:
                begin
                    if not Contact.Get(DocumentAttachment."No.") then
                        exit;

                    if Contact."FTT-CST Notif. Mail Gr. Code" <> '' then
                        EmailRecipients := GetContactMailingGroupEmails(Contact."FTT-CST Notif. Mail Gr. Code");

                    if EmailRecipients = '' then
                        exit;

                    EmailSubject := DocAttachmentMgt.GenerateExpiredAttachmentEmailSubject(DocumentAttachment."No.", Contact.TableCaption, Contact.Name);
                    EmailBody := DocAttachmentMgt.GenerateExpiredAttachmentEmailBody(DocumentAttachment, Contact.TableCaption, Contact.Name);
                end;
        end;
        EmailMessage.Create(EmailRecipients, EmailSubject, EmailBody);
    end;

    local procedure GetEmailSenderAccount() SendingEmailAccount: Record "Email Account";
    var
        MarketingSetup: Record "Marketing Setup";
        EmailAccount: Codeunit "Email Account";
    begin
        MarketingSetup.Get();
        MarketingSetup.TestField("FTT-CST Sending E-mail Acc. Id");

        EmailAccount.GetAllAccounts(true, SendingEmailAccount);
        SendingEmailAccount.SetRange("Account Id", MarketingSetup."FTT-CST Sending E-mail Acc. Id");
        SendingEmailAccount.FindFirst();
    end;

    local procedure GetContactMailingGroupEmails(MailingGroupCode: Code[10]): Text
    var
        Contact: Record Contact;
        ContactMailingGroup: Record "Contact Mailing Group";
        FoundEmails: Text;
    begin
        ContactMailingGroup.Reset();
        ContactMailingGroup.SetRange("Mailing Group Code", MailingGroupCode);
        ContactMailingGroup.SetLoadFields("Contact No.");
        if ContactMailingGroup.FindSet() then
            repeat
                if Contact.Get(ContactMailingGroup."Contact No.") then
                    if Contact."E-Mail" <> '' then
                        if FoundEmails = '' then
                            FoundEmails := Contact."E-Mail"
                        else
                            FoundEmails += ';' + Contact."E-Mail";
            until ContactMailingGroup.Next() = 0;
        exit(FoundEmails);
    end;
}
