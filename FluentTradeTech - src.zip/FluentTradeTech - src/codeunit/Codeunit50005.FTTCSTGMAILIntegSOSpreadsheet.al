codeunit 50005 "GMAIL Integ. SO Spreadsheet"
{
    trigger OnRun()
    begin

    end;

    procedure UpdateCRMTemplatefromSalesOrder(pSalesOrder: Record "Sales Header"; SendEmail: Boolean)
    var
        GenLedgSetup: Record "General Ledger Setup";
        Text001: Text[450];
        FileName: Text;
        SQSalesLine: Record "Sales Line";
        Instreamtest: InStream;
        CrySymbol: Text;
        Currency: Record Currency;
        ListofStartIndex: array[100] of integer;
        ListOfEndIndex: array[100] of integer;
        TotalIndex: Integer;
        lTotalDeleted: Integer;
        lLocation: Record Location;
        FirstRun: Integer;
    begin
        if not GenLedgSetup.Get() then
            exit;

        TestSpreedID := CreateaCopyCRMTemplate();
        commit;
        SheetID := GetSheetIDFromCRMTemplate();

        //>>Dan
        IF (GetAllLocationCode(pSalesOrder)) AND (TempLoc.FINDSET) THEN BEGIN
            repeat
                FirstRun += 1;
                IF FirstRun = 1 THEN BEGIN
                    UpdateSheets(SheetID, TempLoc.Code);
                    SLEEP(5000);
                    TempLoc.Name := FORMAT(SheetID);
                    TempLoc.Modify;
                END ELSE BEGIN
                    AddSheets();
                    Sleep(5000);
                    Evaluate(SheetID, SheetID2);
                    UpdateSheets(SheetID, TempLoc.Code);
                    Sleep(5000);
                    TempLoc.Name := FORMAT(SheetID);
                    TempLoc.Modify;
                END;
            until TempLoc.Next = 0;
        END;
        //<<Dan
        //>>Dan
        TempLoc.Reset;
        IF TempLoc.FINDSET then
            repeat
                Sleep(2000);
                Evaluate(SheetID, TempLoc.name);
                TotalIndex := 0;
                Clear(ListofStartIndex);
                Clear(ListOfEndIndex);
                lTotalDeleted := 0;
                CrySymbol := '';

                //<<Dan
                //UpdateCustName - 
                if not UpdateCRMTemplate(TempLoc.Code + '!A1:A1', pSalesOrder."Ship-to Name") then
                    Error('Error on the Customer Name %1', pSalesOrder."Ship-to Name");
                Sleep(2000);
                //UpdateCurrency
                if pSalesOrder."Currency Code" <> '' then begin
                    CrySymbol := GetCurrencySymbol(pSalesOrder."Currency Code");
                    if not UpdateCRMTemplate(TempLoc.Code + '!A2:A2', pSalesOrder."Currency Code") then
                        Error('Error on the Currency Code %1', pSalesOrder."Currency Code");
                end else begin
                    CrySymbol := GenLedgSetup."Local Currency Symbol";

                    if not UpdateCRMTemplate(TempLoc.Code + '!A2:A2', GenLedgSetup."LCY Code") then
                        Error('Error on the Currency Code %1', GenLedgSetup."LCY Code");
                end;
                Sleep(2000);

                if not UpdateCRMTemplate(TempLoc.Code + '!F7:F7', StrSubstNo('%1', pSalesOrder."FTT-CST Agr. Starting Date")) then
                    Error('Error on the Agreement Period');
                Sleep(2000);

                if not UpdateCRMTemplate(TempLoc.Code + '!F8:F8', StrSubstNo('%1', pSalesOrder."FTT-CST Agr. Ending Date")) then
                    Error('Error on the Agreement Period');
                Sleep(2000);

                UpdateSummary(pSalesOrder, CrySymbol, TotalIndex, ListofStartIndex, ListOfEndIndex, lTotalDeleted);
                Sleep(2000);
                UpdateDetailedLines(pSalesOrder, CrySymbol, TotalIndex, ListofStartIndex, ListOfEndIndex, lTotalDeleted);
                Sleep(2000);
                UpdateFeedLines(pSalesOrder, CrySymbol);
                // Commit();
                // Sleep(2000);
                AdditionalUpdate(pSalesOrder);
                Sleep(2000);
                //Message('%1', CreateJson(SheetID, ListofStartIndex, ListOfEndIndex, TotalIndex));
                DeleteZeroValueInCRMTemplate(CreateJson(SheetID, ListofStartIndex, ListOfEndIndex, TotalIndex));
                Commit();
            until TempLoc.Next = 0; //dan
        IF tempLoc.Count = 0 then
            ERROR('No Line in Document No. %1', pSalesOrder."No.");
        //<<Dan
        //UpdateCrossConnectLines(pSalesOrder, CrySymbol, TotalIndex, ListofStartIndex, ListOfEndIndex, lTotalDeleted);
        if not SendEmail then begin
            FileName := Format('SO-' + pSalesOrder."No." + '_' + pSalesOrder."Ship-to Name");
            //FileName := 'test';
            DownloadCRMTemplate(FileName, SendEmail, Instreamtest);
        end else begin
            DownloadCRMTemplate(FileName, true, Instreamtest);
            Commit();

            pSalesOrder.SalesQuoteExtTemp.ImportStream(Instreamtest, FileName, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet(.xlsx)');
            pSalesOrder.Modify();
            Commit();
        end;
        Commit();

        DeleteCopyCRMTemplate(TestSpreedID);
    end;

    procedure GetCurrencySymbol(pCureCode: Code[20]): Text[10]
    var
        Currency_l: Record Currency;
    begin
        if not Currency_l.get(pCureCode) then
            exit('');

        Currency_l.TestField(Symbol);

        exit(Currency_l.Symbol)
    end;

    procedure UpdateSummary(pSalesQuote2: Record "Sales Header"; pCurrSymbol: Text[10]; var ptotalIndex: integer; var pListofStartIndex: array[100] of integer; var pListOfEndIndex: array[100] of integer; var TotalDeleted: integer)
    var
        SQSalesLine: Record "Sales Line";
        SQSalesLine2: Record "Sales Line";
        TotalInvDiscount: Decimal;
        TextDiscount, TextUpdate : Text[1024];
        SndYrDisc: Decimal;
        C9Value, D9Value, C9Value2 : decimal;
    begin
        //UpdateLCFSYRC - 
        InitializedVariables();
        C9Value := 0;
        D9Value := 0;
        SndYrDisc := 0;
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1|%2|%3|%4', 'DR', 'LICENSE', 'REDUNDANCY', 'FEED');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums("Line Amount");
            C9Value2 := SQSalesLine."Line Amount";

            if not UpdateCRMTemplate(TempLoc.Code + '!C8:C8', pCurrSymbol + Format(C9Value2)) then
                Error('Error on the LCFSYRC');
            Sleep(2000);

        end
        else begin
            TotalDeleted += 1;
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := 7;
            pListOfEndIndex[ptotalIndex] := 8;
        end;
        Sleep(2000);
        //UpdateFSDPYRCHOTCOLD 
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetRange("SDP Items", true);
        SQSalesLine.SetRange("FTT-CST Cost Type", SQSalesLine."FTT-CST Cost Type"::YRC);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1', 'LICENSE');
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums("Line Amount");
            XLValAmt1 := SQSalesLine."Line Amount";

            if not UpdateCRMTemplate(TempLoc.Code + '!C9:C9', pCurrSymbol + Format(XLValAmt1))
               then
                Error('Error on the FSDPYRCHOTCOLD');
            Sleep(2000);
        end else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (8 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (9 - TotalDeleted);
            TotalDeleted += 1;
        end;
        Sleep(2000);
        //UpdateFSDPNRC
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetRange("SDP Items", true);
        SQSalesLine.SetRange("FTT-CST Cost Type", SQSalesLine."FTT-CST Cost Type"::NRC);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1', 'INSTALLATION');
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums("Line Amount");
            XLValAmt3 := SQSalesLine."Line Amount";
            if not UpdateCRMTemplate(TempLoc.Code + '!C10:C10', pCurrSymbol + Format(XLValAmt3)) then
                Error('Error on the FSDPNRC');
            Sleep(2000);
        end else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (9 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (10 - TotalDeleted);
            TotalDeleted += 1;
        end;
        Sleep(2000);
        //UpdateIASNRCSDP
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1', 'INSTALLATION');
        SQSalesLine.SetFilter("FTT-CST Cost Type", '%1', SQSalesLine."FTT-CST Cost Type"::NRC);
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums("Line Amount");
            XLValAmt4 := SQSalesLine."Line Amount";
            if not UpdateCRMTemplate(TempLoc.Code + '!C11:C11', pCurrSymbol + Format(XLValAmt4)) then
                Error('Error on the IASNRCSDP');
            Sleep(2000);
        end
        else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (10 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (11 - TotalDeleted);
            TotalDeleted += 1;
        end;
        Sleep(2000);
        //UpdateIASNRCSDP
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1', 'INSTALLATION');
        SQSalesLine.SetFilter("FTT-CST Cost Type", '%1|%2', SQSalesLine."FTT-CST Cost Type"::YRC, SQSalesLine."FTT-CST Cost Type"::MRC);
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums("Line Amount");
            XLValAmt4 := SQSalesLine."Line Amount";
            if not UpdateCRMTemplate(TempLoc.Code + '!C12:C12', pCurrSymbol + Format(XLValAmt4)) then
                Error('Error on the IASNRCSDP');
            Sleep(2000);
        end
        else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (11 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (12 - TotalDeleted);
            TotalDeleted += 1;
        end;
        Sleep(2000);
        //UpdateHOSTINGLONDINGYRC
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1', 'HOSTING & MANAGEMENT');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums("Line Amount");
            XLValAmt6 := SQSalesLine."Line Amount";
            if not UpdateCRMTemplate(TempLoc.Code + '!C13:C13', pCurrSymbol + Format(XLValAmt6)) then
                Error('Error on the HOSTINGLONDINGYRC');
            Sleep(2000);
        end
        else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (12 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (13 - TotalDeleted);
            TotalDeleted += 1;
        end;

        Sleep(2000);
        //UpdateCONNECTIVITY
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1', 'CROSS CONNECTS');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums("Line Amount");
            XLValAmt8 := SQSalesLine."Line Amount" + GetInternationalLineTotal(pSalesQuote2);

            if not UpdateCRMTemplate(TempLoc.Code + '!C14:C14', pCurrSymbol + Format(XLValAmt8)) then
                Error('Error on the CONNECTIVITY');
            Sleep(2000);

        end else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (13 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (14 - TotalDeleted);
            TotalDeleted += 1;
        end;
        Sleep(2000);

    end;


    procedure UpdateDetailedLines(pSalesQuote2: Record "Sales Header"; pCurrSymbol: Text[10]; var ptotalIndex: integer; var pListofStartIndex: array[100] of integer; var pListOfEndIndex: array[100] of integer; var TotalDeleted: Integer)
    var
        SQSalesLine: Record "Sales Line";
        NotAllZeroValue: Boolean;
        ListofStartIndexTemp: array[100] of integer;
        ListofEndIndexTemp: array[100] of integer;
        totalIndexTemp: integer;
        I: integer;
        TotalCountOfLicense: integer;
        StartLicenseDetIndex: Integer;
        EndLicenseDetIndex: integer;
        TotalRemIndex: Integer;
        TextOption: Text[250];
        LabelInteg: label 'Intergration and full setup of %1 site, one time fee (%2% of total primary %3 site licenses + Redundancy)';
        LabelRedundancy: Label '%1 (%2% of total primary %3 site licenses)';
        LabelDR: Label '%1 (%2% of total primary %3 site licenses)';
        TextOption2: Text[250];
        TextOption3: Text[250];
        TextOption4: Text[250];
        TextOption5: Text[250];
        LabelHardware: label 'Server Hardware (%1 INT, %2 UAT, %3 PROD)';
        LabelSERVER: label 'Server setup (%1 INT, %2 UAT, %3 PROD)';
        TotalOfProdHdware: Integer;
        TotalofUAThardware: integer;
        TotalOfIntegHrdware: Integer;
        TotalofSharedConnectNRC, TotalofSharedConnectNRC2, InterLine : Decimal;
        TotalofSharedConnectMRC, TotalofSharedConnectMRC2 : Decimal;
        TotalofDEDICATEDConnectNRC, TotalofDEDICATEDConnectNRC2 : Decimal;
        TotalofDEDICATEDConnectMRC, TotalofDEDICATEDConnectMRC2 : Decimal;
    begin
        //UpdateLCFSYRC - 
        InitializedVariables();
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1', 'LICENSE');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindSet() then begin
            TotalCountOfLicense := SQSalesLine.Count;
            StartLicenseDetIndex := 21;
            EndLicenseDetIndex := 20;
            repeat
                XLValAmt10 := SQSalesLine."Unit Price";
                XLValQty10 := SQSalesLine."Quantity";
                XLValAmt9 := SQSalesLine."Line Amount";
                if not UpdateCRMTemplate(TempLoc.Code + '!B' + StrSubstNo('%1', StartLicenseDetIndex) + ':B' + StrSubstNo('%1', StartLicenseDetIndex), SQSalesLine.Description) then
                    Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);
                if not UpdateCRMTemplate(TempLoc.Code + '!C' + StrSubstNo('%1', StartLicenseDetIndex) + ':C' + StrSubstNo('%1', StartLicenseDetIndex), (StrSubstNo('%1', XLValQty10))) then
                    Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);
                if not UpdateCRMTemplate(TempLoc.Code + '!D' + StrSubstNo('%1', StartLicenseDetIndex) + ':D' + StrSubstNo('%1', StartLicenseDetIndex), pCurrSymbol + (StrSubstNo('%1', XLValAmt10))) then
                    Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);

                if not UpdateCRMTemplate(TempLoc.Code + '!F' + StrSubstNo('%1', StartLicenseDetIndex) + ':F' + StrSubstNo('%1', StartLicenseDetIndex), StrSubstNo('%1', SQSalesLine."FTT-CST Agreement Date From")) then
                    Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);

                if not UpdateCRMTemplate(TempLoc.Code + '!G' + StrSubstNo('%1', StartLicenseDetIndex) + ':G' + StrSubstNo('%1', StartLicenseDetIndex), StrSubstNo('%1', SQSalesLine."FTT-CST Agreement Date To")) then
                    Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);

                if not UpdateCRMTemplate(TempLoc.Code + '!H' + StrSubstNo('%1', StartLicenseDetIndex) + ':H' + StrSubstNo('%1', StartLicenseDetIndex), StrSubstNo('%1', SQSalesLine."Agreement Period")) then
                    Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);


                if not UpdateCRMTemplate(TempLoc.Code + '!I' + StrSubstNo('%1', StartLicenseDetIndex) + ':I' + StrSubstNo('%1', StartLicenseDetIndex), SQSalesLine."FTT-CST Comments Fluent") then
                    Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);

                if SQSalesLine."FTT-CST Cost Type" = SQSalesLine."FTT-CST Cost Type"::NRC then
                    if not UpdateCRMTemplate(TempLoc.Code + '!F' + StrSubstNo('%1', StartLicenseDetIndex) + ':F' + StrSubstNo('%1', StartLicenseDetIndex), pCurrSymbol + (StrSubstNo('%1', XLValAmt9))) then
                        Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);
                StartLicenseDetIndex += 1;
                EndLicenseDetIndex += 1;

            until SQSalesLine.Next() = 0;

            for I := StartLicenseDetIndex to 38 do begin
                ptotalIndex += 1;
                pListofStartIndex[ptotalIndex] := (EndLicenseDetIndex - TotalDeleted);
                pListOfEndIndex[ptotalIndex] := (I - TotalDeleted);
                StartLicenseDetIndex += 1;
                EndLicenseDetIndex += 1;
                TotalDeleted += 1;
            end;

        end;
        Sleep(2000);
        //UpdateFSDPYRCHOTCOLD 
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("Item Category Code", '%1', 'STANDARD TAKER FEED');
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums(Quantity, "Line Amount");

            if not UpdateCRMTemplate(TempLoc.Code + '!C39:C39', StrSubstNo('%1', SQSalesLine.Quantity)) then
                Error('Error on the LCFSYRC');
            Sleep(2000);

            if not UpdateCRMTemplate(TempLoc.Code + '!D39:D39', pCurrSymbol + StrSubstNo('%1', SQSalesLine."Line Amount")) then
                Error('Error on the LCFSYRC');
            Sleep(2000);

        end else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (38 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (39 - TotalDeleted);
            TotalDeleted += 1;
        end;
        Sleep(2000);
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("Item Category Code", '%1', 'STANDARD MAKER FEED');
        if SQSalesLine.FindSet() then begin

            if not UpdateCRMTemplate(TempLoc.Code + '!C40:C40', StrSubstNo('%1', SQSalesLine.Quantity)) then
                Error('Error on the LCFSYRC');
            Sleep(2000);

            if not UpdateCRMTemplate(TempLoc.Code + '!D40:D40', pCurrSymbol + StrSubstNo('%1', SQSalesLine."Line Amount")) then
                Error('Error on the LCFSYRC');
            Sleep(2000);
        end else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (39 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (40 - TotalDeleted);
            TotalDeleted += 1;
        end;
        Sleep(2000);
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("Item Category Code", '%1', 'NS TAKER FEED');
        if SQSalesLine.FindSet() then begin

            if not UpdateCRMTemplate(TempLoc.Code + '!C41:C41', StrSubstNo('%1', SQSalesLine.Quantity)) then
                Error('Error on the LCFSYRC');
            Sleep(2000);

            if not UpdateCRMTemplate(TempLoc.Code + '!D41:D41', pCurrSymbol + StrSubstNo('%1', SQSalesLine."Line Amount")) then
                Error('Error on the LCFSYRC');
            Sleep(2000);
        end else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (40 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (41 - TotalDeleted);
            TotalDeleted += 1;
        end;
        Sleep(2000);

        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("Item Category Code", '%1', 'NS MAKER FEED');
        if SQSalesLine.FindSet() then begin

            if not UpdateCRMTemplate(TempLoc.Code + '!C42:C42', StrSubstNo('%1', SQSalesLine.Quantity)) then
                Error('Error on the LCFSYRC');
            Sleep(2000);

            if not UpdateCRMTemplate(TempLoc.Code + '!D42:D42', pCurrSymbol + StrSubstNo('%1', SQSalesLine."Line Amount")) then
                Error('Error on the LCFSYRC');
            Sleep(2000);
        end else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (41 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (42 - TotalDeleted);
            TotalDeleted += 1;
        end;
        Sleep(2000);
        //UpdateLCFSYRC - 
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1', 'REDUNDANCY');
        //SQSalesLine.SetFilter("Item Category Code", '%1', 'REDUNDANCY');
        SQSalesLine.SetRange("FTT-CST Cost Type", SQSalesLine."FTT-CST Cost Type"::YRCCalculated);
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindFirst() then begin
            TextOption4 := StrSubstNo(LabelRedundancy, SQSalesLine.Description, SQSalesLine."FTT-CST Redundancy PriceCalc %", SQSalesLine."FTT-CST Sublocation");
            if not UpdateCRMTemplate(TempLoc.Code + '!B20:B20', StrSubstNo('Primary Site, %1', SQSalesLine."FTT-CST Sublocation")) then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            if not UpdateCRMTemplate(TempLoc.Code + '!B13:B13', StrSubstNo('Hosting - %1 %2 - YRC', SQSalesLine."FTT-CST Location Code", SQSalesLine."FTT-CST Sublocation")) then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            if not UpdateCRMTemplate(TempLoc.Code + '!B14:B14', StrSubstNo('Connectivity - %1 %2 - YRC + NRC', SQSalesLine."FTT-CST Location Code", SQSalesLine."FTT-CST Sublocation")) then
                Error('Error on the LCFSYRC');
            Sleep(2000);

            if not UpdateCRMTemplate(TempLoc.Code + '!B44:B44', TextOption4) then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            if not UpdateCRMTemplate(TempLoc.Code + '!E44:E44', '=' + StrSubstNo('E43 * %1', SQSalesLine."FTT-CST Redundancy PriceCalc %") + '%') then
                Error('Error on the LCFSYRC');
            Sleep(2000);
        end else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (43 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (44 - TotalDeleted);
            TotalDeleted += 1;
        end;
        Sleep(2000);
        //---Comment NIMROD
        InitializedVariables();
        //UpdateINSTALLATION - 
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1', 'INSTALLATION');
        SQSalesLine.SetFilter("No.", '1258');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindFirst() then begin
            SQSalesLine.CalcSums(Quantity, "Line Amount");
            XLValAmt1 := SQSalesLine."Unit Price";
            XLValQty1 := SQSalesLine.Quantity;

            if not UpdateCRMTemplate(TempLoc.Code + '!C49:C49', StrSubstNo('%1', XLValQty1)) then
                Error('Error on the LCFSYRC');
            Sleep(2000);


            if not UpdateCRMTemplate(TempLoc.Code + '!D49:D49', pCurrSymbol + Format(XLValAmt1)) then
                Error('Error on the LCFSYRC');
            Sleep(2000);

            if not UpdateCRMTemplate(TempLoc.Code + '!F49:F49', StrSubstNo('%1', SQSalesLine."FTT-CST Cost Type")) then
                Error('Error on the LCFSYRC');
            Sleep(2000);

        end else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (48 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (49 - TotalDeleted);
            TotalDeleted += 1;
        end;

        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1', 'INSTALLATION');
        SQSalesLine.SetFilter("No.", '1314');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindFirst() then begin
            SQSalesLine.CalcSums(Quantity, "Line Amount");
            XLValAmt1 := SQSalesLine."FTT-CST Unit Price";
            XLValQty1 := SQSalesLine.Quantity;

            if not UpdateCRMTemplate(TempLoc.Code + '!C50:C50', StrSubstNo('%1', XLValQty1)) then
                Error('Error on the LCFSYRC');
            Sleep(2000);


            if not UpdateCRMTemplate(TempLoc.Code + '!D50:D50', pCurrSymbol + Format(XLValAmt1)) then
                Error('Error on the LCFSYRC');
            Sleep(2000);

            if not UpdateCRMTemplate(TempLoc.Code + '!E50:E50', pCurrSymbol + Format(SQSalesLine."Line Amount")) then
                Error('Error on the LCFSYRC');
            Sleep(2000);

            if not UpdateCRMTemplate(TempLoc.Code + '!F50:F50', StrSubstNo('%1', SQSalesLine."FTT-CST Cost Type")) then
                Error('Error on the LCFSYRC');
            Sleep(2000);
        end else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (49 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (50 - TotalDeleted);
            TotalDeleted += 1;
        end;

        //UpdateINSTALLATION - 
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1', 'INSTALLATION');
        SQSalesLine.SetFilter("FTT-CST Unit Price", '%1', 0);
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindFirst() then begin
            SQSalesLine.CalcSums(Quantity, "Line Amount");
            XLValAmt1 := SQSalesLine."Line Amount";
            XLValQty1 := SQSalesLine.Quantity;
            TextOption := StrSubstNo(LabelInteg, SQSalesLine."FTT-CST Sublocation", SQSalesLine."FTT-CST Redundancy PriceCalc %", SQSalesLine."FTT-CST Sublocation");
            if not UpdateCRMTemplate(TempLoc.Code + '!B51:B51', TextOption) then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            if not UpdateCRMTemplate(TempLoc.Code + '!C51:C51', '1') then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            if not UpdateCRMTemplate(TempLoc.Code + '!F51:F51', StrSubstNo('%1', SQSalesLine."FTT-CST Cost Type")) then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            //>>Dan
            if not UpdateCRMTemplate(TempLoc.Code + '!H51:H51', SQSalesLine."FTT-CST Comments Fluent") then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            //<<Dan
            IF SQSalesLine."FTT-CST Cost Type" = SQSalesLine."FTT-CST Cost Type"::NRC then begin
                if not UpdateCRMTemplate(TempLoc.Code + '!D51:D51', pCurrSymbol + Format(XLValAmt1)) then
                    Error('Error on the LCFSYRC');
                Sleep(2000);

            end;
        end else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (50 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (51 - TotalDeleted);
            TotalDeleted += 1;
        end;


        //UpdateHOSTING
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("Item Category Code", '%1', 'HOSTING & MANAGEMENT');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums("Line Amount");
            XLValAmt5 := SQSalesLine."FTT-CST Unit Price";
            if not UpdateCRMTemplate(TempLoc.Code + '!C55:C55', StrSubstNo('%1', SQSalesLine.Quantity)) then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            //>>Dan
            if not UpdateCRMTemplate(TempLoc.Code + '!G55:G55', SQSalesLine."FTT-CST Comments Fluent") then
                Error('Error on the LCFSYRC');
            Sleep(2000);

            if not UpdateCRMTemplate(TempLoc.Code + '!D55:D55', pCurrSymbol + Format((XLValAmt5))) then
                Error('Error on the LCFSYRC');
            Sleep(2000);

            if not UpdateCRMTemplate(TempLoc.Code + '!F55:F55', StrSubstNo('%1', SQSalesLine."FTT-CST Cost Type")) then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            //<<Dan
            IF SQSalesLine."FTT-CST Cost Type" = SQSalesLine."FTT-CST Cost Type"::MRC then begin
                //if not UpdateCRMTemplate(TempLoc.Code + '!E67:E67', pCurrSymbol + Format((SQSalesLine."Line Amount" / 12))) then
                if not UpdateCRMTemplate(TempLoc.Code + '!E55:E55', pCurrSymbol + Format((SQSalesLine."Line Amount"))) then
                    Error('Error on the LCFSYRC');
                Sleep(2000);
            end;
            //>> Update 101824
            IF SQSalesLine.Quantity = 0 THEN begin
                ptotalIndex += 1;
                pListofStartIndex[ptotalIndex] := (51 - TotalDeleted);
                pListOfEndIndex[ptotalIndex] := (52 - TotalDeleted);
                TotalDeleted += 1;
            end;
            //<< Update 101824
        end else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (51 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (52 - TotalDeleted);
            TotalDeleted += 1;
        end;
        //>>Dan
        Sleep(2000);
        //UpdateInternationalLine
        // InterLine := 0;

        // SQSalesLine.Reset();
        // SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        // SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        // SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        // SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        // SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        // SQSalesLine.SetFilter("Item Category Code", '%1', 'INTERNATIONAL LINE');
        // SQSalesLine.SetRange("SDP Items", false);
        // if SQSalesLine.FindSet() then begin

        //     StartLicenseDetIndex := 68;
        //     EndLicenseDetIndex := 67;
        //     repeat
        //         //SQSalesLine.CalcSums("Line Amount", Quantity, "FTT-CST Unit Price"); //Dan update 102324
        //         XLValAmt6 := SQSalesLine."FTT-CST Unit Price";
        //         InterLine := SQSalesLine.Quantity;

        //         if not UpdateCRMTemplate(TempLoc.Code + '!B' + StrSubstNo('%1', StartLicenseDetIndex) + ':B' + StrSubstNo('%1', StartLicenseDetIndex), StrSubstNo('%1', SQSalesLine.Description)) then
        //             Error('Error on the LCFSYRC');
        //         Sleep(2000);
        //         if not UpdateCRMTemplate(TempLoc.Code + '!C' + StrSubstNo('%1', StartLicenseDetIndex) + ':C' + StrSubstNo('%1', StartLicenseDetIndex), StrSubstNo('%1', SQSalesLine.Quantity)) then
        //             Error('Error on the LCFSYRC');
        //         Sleep(2000);
        //         //>>Dan
        //         if not UpdateCRMTemplate(TempLoc.Code + '!H' + StrSubstNo('%1', StartLicenseDetIndex) + ':H' + StrSubstNo('%1', StartLicenseDetIndex), SQSalesLine."FTT-CST Comments Fluent") then
        //             Error('Error on the LCFSYRC');
        //         Sleep(2000);
        //         //<<Dan
        //         IF SQSalesLine."FTT-CST Cost Type" = SQSalesLine."FTT-CST Cost Type"::MRC then begin
        //             if not UpdateCRMTemplate(TempLoc.Code + '!E' + StrSubstNo('%1', StartLicenseDetIndex) + ':E' + StrSubstNo('%1', StartLicenseDetIndex), pCurrSymbol + Format(XLValAmt6)) then
        //                 Error('Error on the LCFSYRC');
        //             Sleep(2000);
        //         end else if SQSalesLine."FTT-CST Cost Type" = SQSalesLine."FTT-CST Cost Type"::NRC then begin
        //             if not UpdateCRMTemplate(TempLoc.Code + '!D' + StrSubstNo('%1', StartLicenseDetIndex) + ':D' + StrSubstNo('%1', StartLicenseDetIndex), pCurrSymbol + Format(XLValAmt6)) then
        //                 Error('Error on the LCFSYRC');
        //             Sleep(2000);
        //         end;
        //         StartLicenseDetIndex += 1;
        //         EndLicenseDetIndex += 1;
        //         Sleep(2000);
        //     // IF InterLine = 0 THEN begin
        //     //     ptotalIndex += 1;
        //     //     pListofStartIndex[ptotalIndex] := (67 - TotalDeleted);
        //     //     pListOfEndIndex[ptotalIndex] := (68 - TotalDeleted);
        //     //     TotalDeleted += 1;
        //     // end;
        //     until SQSalesLine.Next() = 0;

        //     for I := StartLicenseDetIndex to 72 do begin
        //         ptotalIndex += 1;
        //         pListofStartIndex[ptotalIndex] := (EndLicenseDetIndex - TotalDeleted);
        //         pListOfEndIndex[ptotalIndex] := (I - TotalDeleted);
        //         StartLicenseDetIndex += 1;
        //         EndLicenseDetIndex += 1;
        //         TotalDeleted += 1;
        //     end;

        // end else begin
        //     //ptotalIndex += 1;
        //     //pListofStartIndex[ptotalIndex] := (67 - TotalDeleted);
        //     //pListOfEndIndex[ptotalIndex] := (68 - TotalDeleted);
        //     //TotalDeleted += 1;
        //     StartLicenseDetIndex := 68;
        //     EndLicenseDetIndex := 67;
        //     for I := StartLicenseDetIndex to 72 do begin
        //         ptotalIndex += 1;
        //         pListofStartIndex[ptotalIndex] := (EndLicenseDetIndex - TotalDeleted);
        //         pListOfEndIndex[ptotalIndex] := (I - TotalDeleted);
        //         StartLicenseDetIndex += 1;
        //         EndLicenseDetIndex += 1;
        //         TotalDeleted += 1;
        //     end;
        // end;
        //<<Dan
        Sleep(2000);
        //UpdateSHAREDCONNECT
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("Item Category Code", '%1', 'SHARED MRC C-C');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums(Quantity);


            //>>Dan Commented
            if not UpdateCRMTemplate(TempLoc.Code + '!C58:C58', StrSubstNo('%1', SQSalesLine.Quantity)) then
                Error('Error on the LCFSYRC');
            if not UpdateCRMTemplate(TempLoc.Code + '!D58:D58', pCurrSymbol + StrSubstNo('%1', SQSalesLine."FTT-CST Unit Price")) then
                Error('Error on the LCFSYRC');
            //Added
            if not UpdateCRMTemplate(TempLoc.Code + '!G58:G58', SQSalesLine."FTT-CST Comments Fluent") then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            //<<Dan

        end else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (57 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (58 - TotalDeleted);
            TotalDeleted += 1;
        end;
        Sleep(2000);
        //UpdateDEDICATEDCONNECT
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("Item Category Code", '%1|%2', 'DEDICATED MRC C-C');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums(Quantity);


            //>>Dan Commented
            if not UpdateCRMTemplate(TempLoc.Code + '!C59:C59', StrSubstNo('%1', SQSalesLine.Quantity)) then
                Error('Error on the LCFSYRC');
            if not UpdateCRMTemplate(TempLoc.Code + '!D59:D59', pCurrSymbol + StrSubstNo('%1', SQSalesLine."FTT-CST Unit Price")) then
                Error('Error on the LCFSYRC');
            //Added
            if not UpdateCRMTemplate(TempLoc.Code + '!G59:G59', SQSalesLine."FTT-CST Comments Fluent") then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            //<<Dan
            //<<Update 101524
        end else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (58 - TotalDeleted); //Mark this change minus 1 up to UpdateHosting for deleting
            pListOfEndIndex[ptotalIndex] := (59 - TotalDeleted);
            TotalDeleted += 1;
        end;
        Sleep(2000);

        //UpdateSHAREDCONNECT
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("Item Category Code", '%1', 'SHARED NRC C-C');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums(Quantity);


            //>>Dan Commented
            if not UpdateCRMTemplate(TempLoc.Code + '!C60:C60', StrSubstNo('%1', SQSalesLine.Quantity)) then
                Error('Error on the LCFSYRC');
            if not UpdateCRMTemplate(TempLoc.Code + '!D60:D60', pCurrSymbol + StrSubstNo('%1', SQSalesLine."FTT-CST Unit Price")) then
                Error('Error on the LCFSYRC');
            //Added
            if not UpdateCRMTemplate(TempLoc.Code + '!G60:G60', SQSalesLine."FTT-CST Comments Fluent") then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            //<<Dan

        end else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (59 - TotalDeleted);
            pListOfEndIndex[ptotalIndex] := (60 - TotalDeleted);
            TotalDeleted += 1;
        end;
        Sleep(2000);

        //UpdateDEDICATEDCONNECT
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("Item Category Code", '%1|%2', 'DEDICATED NRC C-C');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums(Quantity);


            //>>Dan Commented
            if not UpdateCRMTemplate(TempLoc.Code + '!C61:C61', StrSubstNo('%1', SQSalesLine.Quantity)) then
                Error('Error on the LCFSYRC');
            if not UpdateCRMTemplate(TempLoc.Code + '!D61:D61', pCurrSymbol + StrSubstNo('%1', SQSalesLine."FTT-CST Unit Price")) then
                Error('Error on the LCFSYRC');
            //Added
            if not UpdateCRMTemplate(TempLoc.Code + '!G61:G61', SQSalesLine."FTT-CST Comments Fluent") then
                Error('Error on the LCFSYRC');
            Sleep(2000);
            //<<Dan
            //<<Update 101524
        end else begin
            ptotalIndex += 1;
            pListofStartIndex[ptotalIndex] := (60 - TotalDeleted); //Mark this change minus 1 up to UpdateHosting for deleting
            pListOfEndIndex[ptotalIndex] := (61 - TotalDeleted);
            TotalDeleted += 1;
        end;
        Sleep(2000);
    end;

    local procedure GetInternationalLineTotal(pSalesQuote2: Record "Sales Header"): decimal
    var
        SQSalesLine: Record "Sales Line";
    begin
        InterLineAddConn := 0;
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("Item Category Code", '%1', 'INTERNATIONAL LINE');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindSet() then begin
            SQSalesLine.CalcSums("Line Amount");
            InterLineAddConn := SQSalesLine."Line Amount";
        End;
        Exit(InterLineAddConn);
    end;

    local procedure GetYRCPriceFeeds(ItemCode: code[50]; pSalesQuote3: Record "Sales Header"; pLocationCode: code[20]): Decimal
    var
        salesline_l: Record "Sales Line";
    begin
        salesline_l.Reset();
        salesline_l.SetRange("Document Type", pSalesQuote3."Document Type");
        salesline_l.SetRange("Document No.", pSalesQuote3."No.");
        salesline_l.SetRange(Type, salesline_l.Type::Item);
        salesline_l.SetRange("FTT-CST Cost Type", salesline_l."FTT-CST Cost Type"::YRC);
        salesline_l.SetRange("No.", ItemCode);
        salesline_l.SetRange("FTT-CST Location Code", pLocationCode);
        if salesline_l.FindFirst() then
            exit(salesline_l."Line Amount"); //Dan Price only not the amount 
                                             //exit(salesline_l."Unit Price"); //Dan

    end;


    //Nimrod Dan
    procedure UpdateFeedLines(pSalesQuote2: Record "Sales Header"; pCurrSymbol: Text[10])
    var
        CrossConnectLines: Record "FTT-CST Cross Connect Lines";
        CrossConnectLines2: Record "FTT-CST Cross Connect Lines";
        CrossConnectLines3: Record "FTT-CST Cross Connect Lines";
        SQSalesLine: Record "Sales Line";
        lSQ: Record "Sales Line";
        ListofStartIndexTemp: array[100] of integer;
        ListofEndIndexTemp: array[100] of integer;
        totalIndexTemp: integer;
        I: integer;
        TotalCountOfLicense: integer;
        StartLicenseDetIndex: Integer;
        StartLicenseDetIndex2: Integer;
        EndLicenseDetIndex: integer;
        SalesLineItemprice, SalesLineItemprice2, SalesLineItemprice3, SalesLineItemprice4, SalesLineItemprice5 : Decimal;
        SalesLineQty2, SalesLineQty3, SalesLineQty4, SalesLineQty5 : Decimal;
        SalesLineQuantity, SharedConnect, DedicatedConnect : decimal;

    begin
        //UpdateTakerFeeds  //NRD - fix
        InitializedVariables();
        FluentCommet := '';
        SalesLineItemprice4 := 0;
        SalesLineItemprice2 := 0;
        SalesLineItemprice3 := 0;
        SalesLineItemprice5 := 0;
        SalesLineQty4 := 0;
        SalesLineQty2 := 0;
        SalesLineQty3 := 0;
        SalesLineQty5 := 0;
        SharedConnect := 0;
        DedicatedConnect := 0;

        StartLicenseDetIndex := 65;

        //UpdateSHAREDCONNECT
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
        SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("Item Category Code", '%1', 'STANDARD TAKER FEED');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.FindSet() then begin

            repeat
                if not UpdateCRMTemplate(TempLoc.Code + '!B' + StrSubstNo('%1', StartLicenseDetIndex) + ':B' + StrSubstNo('%1', StartLicenseDetIndex), Format(SQSalesLine.Description)) then
                    Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);
                if not UpdateCRMTemplate(TempLoc.Code + '!C' + StrSubstNo('%1', StartLicenseDetIndex) + ':C' + StrSubstNo('%1', StartLicenseDetIndex), 'STANDARD TAKER') then BEGIN
                    Error('Error on the FSDPYRCHOTCOLD');
                    //SharedConnect += CrossConnectLines."Quantity 1";
                End;
                Sleep(2000);
                if not UpdateCRMTemplate(TempLoc.Code + '!D' + StrSubstNo('%1', StartLicenseDetIndex) + ':D' + StrSubstNo('%1', StartLicenseDetIndex), (StrSubstNo('%1', SQSalesLine.Quantity))) then Begin
                    Error('Error on the FSDPYRCHOTCOLD');
                    //DedicatedConnect += CrossConnectLines."Quantity 2";
                End;
                Sleep(2000);
                if not UpdateCRMTemplate(TempLoc.Code + '!E' + StrSubstNo('%1', StartLicenseDetIndex) + ':E' + StrSubstNo('%1', StartLicenseDetIndex), pCurrSymbol + (StrSubstNo('%1', SQSalesLine."Unit Price"))) then
                    Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);

                if not UpdateCRMTemplate(TempLoc.Code + '!F' + StrSubstNo('%1', StartLicenseDetIndex) + ':F' + StrSubstNo('%1', StartLicenseDetIndex), pCurrSymbol + (StrSubstNo('%1', SQSalesLine."Line Amount"))) then
                    Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);

                if not UpdateCRMTemplate(TempLoc.Code + '!G' + StrSubstNo('%1', StartLicenseDetIndex) + ':G' + StrSubstNo('%1', StartLicenseDetIndex), (StrSubstNo('%1', SQSalesLine."FTT-CST Agreement Date From"))) then
                    Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);
                if not UpdateCRMTemplate(TempLoc.Code + '!H' + StrSubstNo('%1', StartLicenseDetIndex) + ':H' + StrSubstNo('%1', StartLicenseDetIndex), (StrSubstNo('%1', SQSalesLine."FTT-CST Agreement Date To"))) then
                    Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);

                if not UpdateCRMTemplate(TempLoc.Code + '!I' + StrSubstNo('%1', StartLicenseDetIndex) + ':I' + StrSubstNo('%1', StartLicenseDetIndex), GetConnectivityTotal(SQSalesLine."No.", pSalesQuote2)) then
                    Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);

                if not UpdateCRMTemplate(TempLoc.Code + '!J' + StrSubstNo('%1', StartLicenseDetIndex) + ':J' + StrSubstNo('%1', StartLicenseDetIndex), (StrSubstNo('%1', SQSalesLine."Agreement Period"))) then
                    Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);

                if not UpdateCRMTemplate(TempLoc.Code + '!K' + StrSubstNo('%1', StartLicenseDetIndex) + ':K' + StrSubstNo('%1', StartLicenseDetIndex), (StrSubstNo('%1', SQSalesLine."FTT-CST Comments Fluent"))) then
                    Error('Error on the FSDPYRCHOTCOLD');
                Sleep(2000);

                StartLicenseDetIndex += 1;
            until SQSalesLine.Next() = 0;


            //UpdateSHAREDCONNECT
            SQSalesLine.Reset();
            SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
            SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
            SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
            SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
            SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
            SQSalesLine.SetFilter("Item Category Code", '%1', 'STANDARD MAKER FEED');
            SQSalesLine.SetRange("SDP Items", false);
            if SQSalesLine.FindSet() then begin
                repeat
                    if not UpdateCRMTemplate(TempLoc.Code + '!B' + StrSubstNo('%1', StartLicenseDetIndex) + ':B' + StrSubstNo('%1', StartLicenseDetIndex), Format(SQSalesLine.Description)) then
                        Error('Error on the FSDPYRCHOTCOLD');
                    Sleep(2000);
                    if not UpdateCRMTemplate(TempLoc.Code + '!C' + StrSubstNo('%1', StartLicenseDetIndex) + ':C' + StrSubstNo('%1', StartLicenseDetIndex), 'STANDARD MAKER') then BEGIN
                        Error('Error on the FSDPYRCHOTCOLD');
                        SharedConnect += CrossConnectLines."Quantity 1";
                    End;
                    Sleep(2000);
                    if not UpdateCRMTemplate(TempLoc.Code + '!D' + StrSubstNo('%1', StartLicenseDetIndex) + ':D' + StrSubstNo('%1', StartLicenseDetIndex), (StrSubstNo('%1', SQSalesLine.Quantity))) then Begin
                        Error('Error on the FSDPYRCHOTCOLD');
                        DedicatedConnect += CrossConnectLines."Quantity 2";
                    End;
                    Sleep(2000);
                    if not UpdateCRMTemplate(TempLoc.Code + '!E' + StrSubstNo('%1', StartLicenseDetIndex) + ':E' + StrSubstNo('%1', StartLicenseDetIndex), pCurrSymbol + (StrSubstNo('%1', SQSalesLine."Unit Price"))) then
                        Error('Error on the FSDPYRCHOTCOLD');
                    Sleep(2000);

                    if not UpdateCRMTemplate(TempLoc.Code + '!F' + StrSubstNo('%1', StartLicenseDetIndex) + ':F' + StrSubstNo('%1', StartLicenseDetIndex), pCurrSymbol + (StrSubstNo('%1', SQSalesLine."Line Amount"))) then
                        Error('Error on the FSDPYRCHOTCOLD');
                    Sleep(2000);

                    if not UpdateCRMTemplate(TempLoc.Code + '!G' + StrSubstNo('%1', StartLicenseDetIndex) + ':G' + StrSubstNo('%1', StartLicenseDetIndex), (StrSubstNo('%1', SQSalesLine."FTT-CST Agreement Date From"))) then
                        Error('Error on the FSDPYRCHOTCOLD');
                    Sleep(2000);
                    if not UpdateCRMTemplate(TempLoc.Code + '!H' + StrSubstNo('%1', StartLicenseDetIndex) + ':H' + StrSubstNo('%1', StartLicenseDetIndex), (StrSubstNo('%1', SQSalesLine."FTT-CST Agreement Date To"))) then
                        Error('Error on the FSDPYRCHOTCOLD');
                    Sleep(2000);

                    if not UpdateCRMTemplate(TempLoc.Code + '!I' + StrSubstNo('%1', StartLicenseDetIndex) + ':I' + StrSubstNo('%1', StartLicenseDetIndex), GetConnectivityTotal(SQSalesLine."No.", pSalesQuote2)) then
                        Error('Error on the FSDPYRCHOTCOLD');
                    Sleep(2000);


                    if not UpdateCRMTemplate(TempLoc.Code + '!J' + StrSubstNo('%1', StartLicenseDetIndex) + ':J' + StrSubstNo('%1', StartLicenseDetIndex), (StrSubstNo('%1', SQSalesLine."Agreement Period"))) then
                        Error('Error on the FSDPYRCHOTCOLD');
                    Sleep(2000);

                    if not UpdateCRMTemplate(TempLoc.Code + '!K' + StrSubstNo('%1', StartLicenseDetIndex) + ':K' + StrSubstNo('%1', StartLicenseDetIndex), (StrSubstNo('%1', SQSalesLine."FTT-CST Comments Fluent"))) then
                        Error('Error on the FSDPYRCHOTCOLD');
                    Sleep(2000);
                    StartLicenseDetIndex += 1;
                until SQSalesLine.Next() = 0;
            end;


            //UpdateSHAREDCONNECT
            SQSalesLine.Reset();
            SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
            SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
            SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
            SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
            SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
            SQSalesLine.SetFilter("Item Category Code", '%1', 'NS TAKER FEED');
            SQSalesLine.SetRange("SDP Items", false);
            if SQSalesLine.FindSet() then begin
                repeat
                    if not UpdateCRMTemplate(TempLoc.Code + '!B' + StrSubstNo('%1', StartLicenseDetIndex) + ':B' + StrSubstNo('%1', StartLicenseDetIndex), Format(SQSalesLine.Description)) then
                        Error('Error on the FSDPYRCHOTCOLD');
                    Sleep(2000);
                    if not UpdateCRMTemplate(TempLoc.Code + '!C' + StrSubstNo('%1', StartLicenseDetIndex) + ':C' + StrSubstNo('%1', StartLicenseDetIndex), 'NON-STANDARD TAKER') then BEGIN
                        Error('Error on the FSDPYRCHOTCOLD');
                        SharedConnect += CrossConnectLines."Quantity 1";
                    End;
                    Sleep(2000);
                    if not UpdateCRMTemplate(TempLoc.Code + '!D' + StrSubstNo('%1', StartLicenseDetIndex) + ':D' + StrSubstNo('%1', StartLicenseDetIndex), (StrSubstNo('%1', SQSalesLine.Quantity))) then Begin
                        Error('Error on the FSDPYRCHOTCOLD');
                        DedicatedConnect += CrossConnectLines."Quantity 2";
                    End;
                    Sleep(2000);
                    if not UpdateCRMTemplate(TempLoc.Code + '!E' + StrSubstNo('%1', StartLicenseDetIndex) + ':E' + StrSubstNo('%1', StartLicenseDetIndex), pCurrSymbol + (StrSubstNo('%1', SQSalesLine."Unit Price"))) then
                        Error('Error on the FSDPYRCHOTCOLD');
                    Sleep(2000);

                    if not UpdateCRMTemplate(TempLoc.Code + '!F' + StrSubstNo('%1', StartLicenseDetIndex) + ':F' + StrSubstNo('%1', StartLicenseDetIndex), pCurrSymbol + (StrSubstNo('%1', SQSalesLine."Line Amount"))) then
                        Error('Error on the FSDPYRCHOTCOLD');
                    Sleep(2000);

                    if not UpdateCRMTemplate(TempLoc.Code + '!G' + StrSubstNo('%1', StartLicenseDetIndex) + ':G' + StrSubstNo('%1', StartLicenseDetIndex), (StrSubstNo('%1', SQSalesLine."FTT-CST Agreement Date From"))) then
                        Error('Error on the FSDPYRCHOTCOLD');
                    Sleep(2000);
                    if not UpdateCRMTemplate(TempLoc.Code + '!H' + StrSubstNo('%1', StartLicenseDetIndex) + ':H' + StrSubstNo('%1', StartLicenseDetIndex), (StrSubstNo('%1', SQSalesLine."FTT-CST Agreement Date To"))) then
                        Error('Error on the FSDPYRCHOTCOLD');
                    Sleep(2000);

                    if not UpdateCRMTemplate(TempLoc.Code + '!I' + StrSubstNo('%1', StartLicenseDetIndex) + ':I' + StrSubstNo('%1', StartLicenseDetIndex), GetConnectivityTotal(SQSalesLine."No.", pSalesQuote2)) then
                        Error('Error on the FSDPYRCHOTCOLD');
                    Sleep(2000);


                    if not UpdateCRMTemplate(TempLoc.Code + '!J' + StrSubstNo('%1', StartLicenseDetIndex) + ':J' + StrSubstNo('%1', StartLicenseDetIndex), (StrSubstNo('%1', SQSalesLine."Agreement Period"))) then
                        Error('Error on the FSDPYRCHOTCOLD');
                    Sleep(2000);

                    if not UpdateCRMTemplate(TempLoc.Code + '!K' + StrSubstNo('%1', StartLicenseDetIndex) + ':K' + StrSubstNo('%1', StartLicenseDetIndex), (StrSubstNo('%1', SQSalesLine."FTT-CST Comments Fluent"))) then
                        Error('Error on the FSDPYRCHOTCOLD');
                    Sleep(2000);
                    StartLicenseDetIndex += 1;
                until SQSalesLine.Next() = 0;
            end;


            //UpdateSHAREDCONNECT
            SQSalesLine.Reset();
            SQSalesLine.SetRange("Document Type", pSalesQuote2."Document Type");
            SQSalesLine.SetRange("Document No.", pSalesQuote2."No.");
            SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
            SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
            SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
            SQSalesLine.SetFilter("Item Category Code", '%1', 'NS MAKER FEED');
            SQSalesLine.SetRange("SDP Items", false);
            if SQSalesLine.FindSet() then begin
                repeat
                    if not UpdateCRMTemplate(TempLoc.Code + '!B' + StrSubstNo('%1', StartLicenseDetIndex) + ':B' + StrSubstNo('%1', StartLicenseDetIndex), Format(SQSalesLine.Description)) then
                        Error('Error on the FSDPYRCHOTCOLD');
                    Sleep(2000);
                    if not UpdateCRMTemplate(TempLoc.Code + '!C' + StrSubstNo('%1', StartLicenseDetIndex) + ':C' + StrSubstNo('%1', StartLicenseDetIndex), 'NON-STANDARD MAKER') then BEGIN
                        Error('Error on the FSDPYRCHOTCOLD');
                        SharedConnect += CrossConnectLines."Quantity 1";
                    End;
                    Sleep(2000);
                    if not UpdateCRMTemplate(TempLoc.Code + '!D' + StrSubstNo('%1', StartLicenseDetIndex) + ':D' + StrSubstNo('%1', StartLicenseDetIndex), (StrSubstNo('%1', SQSalesLine.Quantity))) then Begin
                        Error('Error on the FSDPYRCHOTCOLD');
                        DedicatedConnect += CrossConnectLines."Quantity 2";
                    End;
                    Sleep(2000);
                    if not UpdateCRMTemplate(TempLoc.Code + '!E' + StrSubstNo('%1', StartLicenseDetIndex) + ':E' + StrSubstNo('%1', StartLicenseDetIndex), pCurrSymbol + (StrSubstNo('%1', SQSalesLine."Unit Price"))) then
                        Error('Error on the FSDPYRCHOTCOLD');
                    Sleep(2000);

                    if not UpdateCRMTemplate(TempLoc.Code + '!F' + StrSubstNo('%1', StartLicenseDetIndex) + ':F' + StrSubstNo('%1', StartLicenseDetIndex), pCurrSymbol + (StrSubstNo('%1', SQSalesLine."Line Amount"))) then
                        Error('Error on the FSDPYRCHOTCOLD');
                    Sleep(2000);

                    if not UpdateCRMTemplate(TempLoc.Code + '!G' + StrSubstNo('%1', StartLicenseDetIndex) + ':G' + StrSubstNo('%1', StartLicenseDetIndex), (StrSubstNo('%1', SQSalesLine."FTT-CST Agreement Date From"))) then
                        Error('Error on the FSDPYRCHOTCOLD');
                    Sleep(2000);
                    if not UpdateCRMTemplate(TempLoc.Code + '!H' + StrSubstNo('%1', StartLicenseDetIndex) + ':H' + StrSubstNo('%1', StartLicenseDetIndex), (StrSubstNo('%1', SQSalesLine."FTT-CST Agreement Date To"))) then
                        Error('Error on the FSDPYRCHOTCOLD');
                    Sleep(2000);

                    if not UpdateCRMTemplate(TempLoc.Code + '!I' + StrSubstNo('%1', StartLicenseDetIndex) + ':I' + StrSubstNo('%1', StartLicenseDetIndex), GetConnectivityTotal(SQSalesLine."No.", pSalesQuote2)) then
                        Error('Error on the FSDPYRCHOTCOLD');
                    Sleep(2000);


                    if not UpdateCRMTemplate(TempLoc.Code + '!J' + StrSubstNo('%1', StartLicenseDetIndex) + ':J' + StrSubstNo('%1', StartLicenseDetIndex), (StrSubstNo('%1', SQSalesLine."Agreement Period"))) then
                        Error('Error on the FSDPYRCHOTCOLD');
                    Sleep(2000);

                    if not UpdateCRMTemplate(TempLoc.Code + '!K' + StrSubstNo('%1', StartLicenseDetIndex) + ':K' + StrSubstNo('%1', StartLicenseDetIndex), (StrSubstNo('%1', SQSalesLine."FTT-CST Comments Fluent"))) then
                        Error('Error on the FSDPYRCHOTCOLD');
                    Sleep(2000);
                    StartLicenseDetIndex += 1;
                until SQSalesLine.Next() = 0;
            end;

        end;
    end;

    local Procedure AdditionalUpdate(pSQ: Record "Sales Header");
    var
        SQSalesLine: Record "Sales Line";
        SQSalesLine2: Record "Sales Line";
        TotalInvDiscount: Decimal;
        TextDiscount, TextUpdate : Text[1024];
        SndYrDisc: Decimal;
        C9Value, D9Value, C9Value2 : decimal;
    Begin
        SQSalesLine.Reset();
        SQSalesLine.SetRange("Document Type", pSQ."Document Type");
        SQSalesLine.SetRange("Document No.", pSQ."No.");
        SQSalesLine.SETrange("FTT-CST Location Code", TempLoc.Code); //Dan
        SQSalesLine.SetRange("FTT-CST Optional", SQSalesLine."FTT-CST Optional"::No);
        SQSalesLine.SetRange(Type, SQSalesLine.Type::Item);
        SQSalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '<>%1', 'REDUNDANCY');
        SQSalesLine.SetRange("SDP Items", false);
        if SQSalesLine.Findfirst() then begin
            TextUpdate := StrSubstNo('Primary Site, %1', SQSalesLine."FTT-CST Sublocation");
            UpdateCRMTemplate(TempLoc.Code + '!B20:B20', TextUpdate);
            Sleep(2000);
            TextUpdate := StrSubstNo('Hosting - %1 %2 - YRC', TempLoc.Code, SQSalesLine."FTT-CST Sublocation");
            UpdateCRMTemplate(TempLoc.Code + '!B13:B13', TextUpdate);
            Sleep(2000);
            TextUpdate := StrSubstNo('Connectivity - %1 %2 - YRC + NRC', TempLoc.Code, SQSalesLine."FTT-CST Sublocation");
            UpdateCRMTemplate(TempLoc.Code + '!B14:B14', TextUpdate);
            Sleep(2000);

        End;
    End;

    procedure GetConnectivityTotal(FeedItemNo: code[20]; pSalesQuote2: Record "Sales Header"): Text[1024]
    var
        CrossConnectLines: Record "FTT-CST Cross Connect Lines";
        CrossConnectLines2: Record "FTT-CST Cross Connect Lines";
        TotalSharedText: Text[1024];
        TotalDedicatedText: Text[1024];
        TotalConnectivityText: Text[1024];
        SharedMRC: Integer;
        DedicatedMRC: Integer;
        SharedNRC: Integer;
        DedicatedNRC: Integer;
    begin
        TotalConnectivityText := '';
        TotalSharedText := '';
        TotalDedicatedText := '';
        SharedMRC := 0;
        DedicatedMRC := 0;
        SharedNRC := 0;
        DedicatedNRC := 0;

        CrossConnectLines.Reset();
        CrossConnectLines.SetRange("Document Type", pSalesQuote2."Document Type");
        CrossConnectLines.SetRange("Document No.", pSalesQuote2."No.");
        CrossConnectLines.SetRange("FTT-CST Location Code", TempLoc.Code); //dan
        CrossConnectLines.SetRange(CrossConnectLines."Item No.", FeedItemNo);
        if CrossConnectLines.FindFirst() then BEGIN
            if CrossConnectLines."Quantity 1" <> 0 then
                SharedMRC := CrossConnectLines."Quantity 1";

            if CrossConnectLines."Quantity 2" <> 0 then
                DedicatedMRC := CrossConnectLines."Quantity 2";

            if CrossConnectLines."Quantity 3" <> 0 then
                SharedNRC := CrossConnectLines."Quantity 3";

            if CrossConnectLines."Quantity 4" <> 0 then
                DedicatedNRC := CrossConnectLines."Quantity 4";

            if (SharedMRC <> 0) OR (SharedNRC <> 0) then
                TotalSharedText := StrSubstNo('%1 Shared', (SharedMRC + SharedNRC));

            if (DedicatedMRC <> 0) OR (DedicatedNRC <> 0) then
                TotalDedicatedText := StrSubstNo('%1 Dedicated', (DedicatedMRC + DedicatedNRC));


            TotalConnectivityText := TotalSharedText + ' ' + TotalDedicatedText;
            Commit();
            Exit(TotalConnectivityText);
        End;
        exit('');
    end;

    local procedure GetQuantity(ItemCode: code[50]; pSalesQuote3: Record "Sales Header"; pLocationCode: code[20]): Decimal
    var
        salesline_l: Record "Sales Line";
    begin
        salesline_l.Reset();
        salesline_l.SetRange("Document Type", pSalesQuote3."Document Type");
        salesline_l.SetRange("Document No.", pSalesQuote3."No.");
        salesline_l.SetRange(Type, salesline_l.Type::Item);
        salesline_l.SetRange("FTT-CST Cost Type", salesline_l."FTT-CST Cost Type"::YRC);
        salesline_l.SetRange("No.", ItemCode);
        salesline_l.SetRange("FTT-CST Location Code", pLocationCode);
        if salesline_l.FindFirst() then begin
            FluentCommet := salesline_l."FTT-CST Comments Fluent";
            exit(salesline_l."Quantity");
        End;
    end;

    procedure UpdateCRMTemplate(pTemplateRange: text[250]; pValue: Text[1024]): Boolean
    var
        Url: Text;

        ResponseMessage: HttpResponseMessage;
        JObject: JsonObject;
        Response: HttpResponseMessage;
        ApiResult: Text;
        PostUrl: Text;
        APPName: Text;
        GMAILMGT: Record "GMAIL Maintenance Setup";
        myHttpContent: HttpContent;
        myHttpHeaders: HttpHeaders;
        lHeaders: HttpHeaders;
        request: HttpRequestMessage;
        MyHttpClient: HttpClient;
        MyHttpResponseMessage: HttpResponseMessage;
        myToken: Text;
        myContentHeaders: HttpHeaders;
        Jtoken: JsonToken;
        JArray: JsonArray;
        isSuccess: Boolean;
    begin
        if not GMAILMGT.Get() then
            exit;

        isSuccess := false;
        ClearLastError;

        PostUrl := 'https://sheets.googleapis.com/v4/spreadsheets/' + TestSpreedID + '/values/' + pTemplateRange + '?includeValuesInResponse=true&responseValueRenderOption=FORMATTED_VALUE&valueInputOption=USER_ENTERED';
        myHttpContent.WriteFrom(CreateSHJson(pTemplateRange, pValue));
        request.SetRequestUri(PostUrl);
        myHttpHeaders.Clear();
        lHeaders.Clear();

        myHttpContent.GetHeaders(lHeaders);
        lHeaders.Remove('Content-Type');
        lHeaders.Add('Content-Type', 'application/json');
        myHttpContent.GetHeaders(lHeaders);
        request.GetHeaders(myHttpHeaders);

        myHttpHeaders.Clear();
        myHttpHeaders.Add('Authorization', 'Bearer ' + GMAILMGT."API Token Key");
        myHttpHeaders.Add('Scopes', 'https://www.googleapis.com/auth/drive' +
                                    'https://www.googleapis.com/auth/drive.file' +
                                    'https://www.googleapis.com/auth/spreadsheets');
        request.Content := myHttpContent;
        request.GetHeaders(myHttpHeaders);
        request.Method := 'PUT';

        isSuccess := MyHttpClient.Send(request, MyHttpResponseMessage);
        //Message('%1', MyHttpResponseMessage.HttpStatusCode);
        if isSuccess then begin
            //Message('%1', MyHttpResponseMessage.HttpStatusCode);
            if MyHttpResponseMessage.HttpStatusCode = 404 then
                exit(false);

            MyHttpResponseMessage.Content().ReadAs(myToken);
            JObject.ReadFrom(myToken);

            exit(true);
        end;

        exit(false);
    end;

    procedure GetSheetIDFromCRMTemplate(): Integer
    var
        Url: Text;

        ResponseMessage: HttpResponseMessage;
        JObject: JsonObject;
        Response: HttpResponseMessage;
        ApiResult: Text;
        PostUrl: Text;
        APPName: Text;
        GMAILMGT: Record "GMAIL Maintenance Setup";
        myHttpContent: HttpContent;
        myHttpHeaders: HttpHeaders;
        lHeaders: HttpHeaders;
        request: HttpRequestMessage;
        MyHttpClient: HttpClient;
        MyHttpResponseMessage: HttpResponseMessage;
        myToken: Text;
        myContentHeaders: HttpHeaders;
        Jtoken: JsonToken;
        JArray: JsonArray;
        isSuccess: Boolean;
        lJsonBuff: Record "JSON Buffer";
    begin
        if not GMAILMGT.Get() then
            exit;

        isSuccess := false;
        ClearLastError;

        PostUrl := 'https://sheets.googleapis.com/v4/spreadsheets/' + TestSpreedID;

        request.SetRequestUri(PostUrl);
        myHttpHeaders.Clear();
        lHeaders.Clear();

        myHttpContent.GetHeaders(lHeaders);
        lHeaders.Remove('Content-Type');
        lHeaders.Add('Content-Type', 'application/json');
        myHttpContent.GetHeaders(lHeaders);
        request.GetHeaders(myHttpHeaders);

        myHttpHeaders.Clear();
        myHttpHeaders.Add('Authorization', 'Bearer ' + GMAILMGT."API Token Key");
        myHttpHeaders.Add('Scopes', 'https://www.googleapis.com/auth/drive' +
                          'https://www.googleapis.com/auth/drive.file' +
                          'https://www.googleapis.com/auth/drive.readonly' +
                          'https://www.googleapis.com/auth/spreadsheets.readonly' +
                          'https://www.googleapis.com/auth/spreadsheets');
        request.Content := myHttpContent;
        request.GetHeaders(myHttpHeaders);
        request.Method := 'GET';

        isSuccess := MyHttpClient.Send(request, MyHttpResponseMessage);

        if isSuccess then begin
            MyHttpResponseMessage.Content().ReadAs(myToken);
            JObject.ReadFrom(myToken);

            if JObject.Get('sheets', Jtoken) then
                JArray := Jtoken.AsArray();
            exit(ReadJsonArray(JArray));
        end;

        EXIT(0);
    end;

    local procedure ReadJsonArray(JItemsArray: JsonArray): Integer;
    var
        JItemLineToken: JsonToken;
        JItemLine: JsonObject;
        JItemDesc: JsonToken;
        JsonObject2: JsonObject;
        JSTONtoketn3: JsonToken;
        OutPut: Text;
    begin

        foreach JitemLineToken in JItemsArray do begin

            JItemLine := JItemLineToken.AsObject();
            if JItemLine.Get('properties', JItemDesc) then
                if JItemDesc.IsObject then
                    JItemDesc.WriteTo(OutPut);
            JsonObject2.ReadFrom(OutPut);
            if JsonObject2.Get('sheetId', JSTONtoketn3) then
                EXIT(JSTONtoketn3.AsValue().AsInteger());
        end;
    end;

    procedure CreateaCopyCRMTemplate(): Text[1024]
    var
        Url: Text;

        ResponseMessage: HttpResponseMessage;
        JObject: JsonObject;
        Response: HttpResponseMessage;
        ApiResult: Text;
        PostUrl: Text;
        APPName: Text;
        GMAILMGT: Record "GMAIL Maintenance Setup";
        myHttpContent: HttpContent;
        myHttpHeaders: HttpHeaders;
        lHeaders: HttpHeaders;
        request: HttpRequestMessage;
        MyHttpClient: HttpClient;
        MyHttpResponseMessage: HttpResponseMessage;
        myToken: Text;
        myContentHeaders: HttpHeaders;
        Jtoken: JsonToken;
        JArray: JsonArray;
        isSuccess: Boolean;
    begin
        if not GMAILMGT.Get() then
            exit;

        isSuccess := false;
        ClearLastError;

        PostUrl := 'https://www.googleapis.com/drive/v3/files/' + GMAILMGT."CRM SO Template SHID" + '/copy?enforceSingleParent=true&ignoreDefaultVisibility=true';

        request.SetRequestUri(PostUrl);
        myHttpHeaders.Clear();
        lHeaders.Clear();

        myHttpContent.GetHeaders(lHeaders);
        lHeaders.Remove('Content-Type');
        lHeaders.Add('Content-Type', 'application/json');
        myHttpContent.GetHeaders(lHeaders);
        request.GetHeaders(myHttpHeaders);

        myHttpHeaders.Clear();
        myHttpHeaders.Add('Authorization', 'Bearer ' + GMAILMGT."API Token Key");
        myHttpHeaders.Add('Scopes', 'https://www.googleapis.com/auth/drive' +
                                    'https://www.googleapis.com/auth/drive.file' +
                                    'https://www.googleapis.com/auth/drive.photos.readonly' +
                                    'https://www.googleapis.com/auth/drive.appdata');
        request.Content := myHttpContent;
        request.GetHeaders(myHttpHeaders);
        request.Method := 'POST';

        isSuccess := MyHttpClient.Send(request, MyHttpResponseMessage);

        if isSuccess then begin
            MyHttpResponseMessage.Content().ReadAs(myToken);
            JObject.ReadFrom(myToken);

            if JObject.Get('id', Jtoken) then
                exit(Jtoken.AsValue().AsText());
        end;

        exit('');
    end;

    //>>dan 091024
    procedure AddSheets();
    var
        jObj, JObject, jObject2, jObject3, jObject4 : JsonObject;
        PostUrl: Text;
        GMAILMGT: Record "GMAIL Maintenance Setup";
        Txt: Text;
    begin
        if not GmailMgtSetup.Get() then
            exit;

        jObject.Add('destinationSpreadsheetId', TestSpreedID);
        jObject.WriteTo(txt);

        PostUrl := PostUrls(FALSE);
        PostURLFunction(txt, PostUrl);

    end;

    procedure UpdateSheets(pSheetID: integer; pLocCode: Code[20])
    var
        jObj, JObject, jObject2, jObject3, jObject4 : JsonObject;
        jArr, jArray, jArray2 : JsonArray;
        PostUrl: Text;
        GMAILMGT: Record "GMAIL Maintenance Setup";
        Txt: Text;
    begin

        if not GmailMgtSetup.Get() then
            exit;

        jObject.Add('requests', jArr);
        jObject3.Add('properties', jObject4);
        jObject3.Add('fields', 'title');
        jObject4.Add('sheetId', ForMat(pSheetID));
        jObject4.Add('title', pLocCode);
        jObject2.ADD('updateSheetProperties', jObject3);
        jArr.Add(jObject2);
        jObject.WriteTo(txt);

        PostUrl := PostUrls(True);
        PostURLFunction(txt, PostUrl);
    end;

    procedure PostURLs(pAddSheet: Boolean): Text
    var
        PostURL: Text[1024];
    Begin
        CASE pAddSheet OF
            TRUE:
                PostURL := 'https://sheets.googleapis.com/v4/spreadsheets/' + TestSpreedID + ':batchUpdate';
            Else
                PostUrl := 'https://sheets.googleapis.com/v4/spreadsheets/' + TestSpreedID + '/sheets/' + FORMAT(SheetID) + ':copyTo';
        End;
        Exit(PostUrl)
    End;

    Procedure PostURLFunction(pTxt: Text[1024]; pPostURL: Text[1024])
    var
        ResponseMessage: HttpResponseMessage;
        Response: HttpResponseMessage;
        jObject: JsonObject;
        jArray: JsonArray;
        jToken: JsonToken;
        GMAILMGT: Record "GMAIL Maintenance Setup";
        myHttpContent: HttpContent;
        myHttpHeaders: HttpHeaders;
        lHeaders: HttpHeaders;
        request: HttpRequestMessage;
        MyHttpClient, HttpCli : HttpClient;
        MyHttpResponseMessage: HttpResponseMessage;
        myToken: Text;
        myContentHeaders: HttpHeaders;
        isSuccess: Boolean;
        ResponseTxt: Text;
        j: JsonObject;
    Begin
        isSuccess := false;
        ClearLastError;

        myHttpContent.WriteFrom(ptxt);
        request.SetRequestUri(pPostUrl);
        myHttpHeaders.Clear();
        lHeaders.Clear();

        myHttpContent.GetHeaders(lHeaders);

        lHeaders.Remove('Content-Type');
        lHeaders.Add('Content-Type', 'application/json');
        myHttpContent.GetHeaders(lHeaders);
        request.GetHeaders(myHttpHeaders);
        myHttpHeaders.Clear();

        myHttpHeaders.Add('Authorization', 'Bearer ' + GmailMgtSetup."API Token Key");
        myHttpHeaders.Add('Scopes', 'https://www.googleapis.com/auth/drive' +
                          'https://www.googleapis.com/auth/drive.file' +
                          'https://www.googleapis.com/auth/spreadsheets');
        request.Content := myHttpContent;
        request.GetHeaders(myHttpHeaders);
        request.Method := 'POST';

        isSuccess := MyHttpClient.Send(request, MyHttpResponseMessage);

        SheetID2 := '';
        IF MyHttpResponseMessage.IsSuccessStatusCode() THEN begin
            MyHttpResponseMessage.Content().ReadAs(ResponseTxt);
            j.ReadFrom(ResponseTxt);
            SheetID2 := GetJsonTextField(j, 'sheetId');
        end;
    End;

    ProceDure getJsonTextField(Jobj: JsonObject; pTxt: Text): Text
    Var
        Result: JsonToken;
    Begin
        IF jObj.Get(pTxt, Result) then
            Exit(Result.AsValue().AsText());
    End;

    procedure GetAllLocationCode(pSQ: Record "sales header"): Boolean
    var
        lSQ: Record "sales line";
    Begin
        IF NOT TempLoc.IsTemporary THEN
            Exit(False);

        TempLoc.DELETEALL;
        CLEAR(lSQ);
        lSQ.SetRange("Document Type", pSQ."Document Type");
        lSQ.SetRange("Document No.", pSQ."No.");
        IF lSQ.FINDSET THEN begin
            repeat
                TempLoc.INIT;
                TempLoc.Code := lSQ."FTT-CST Location Code";
                IF TempLoc.Insert THEN;
            until lSQ.Next = 0;
        end Else
            Exit(False);
        Exit(True);
    End;
    //<<Dan 091024
    procedure DeleteCopyCRMTemplate(pText: Text[1024])
    var
        Url: Text;

        ResponseMessage: HttpResponseMessage;
        JObject: JsonObject;
        Response: HttpResponseMessage;
        ApiResult: Text;
        PostUrl: Text;
        APPName: Text;
        GMAILMGT: Record "GMAIL Maintenance Setup";
        myHttpContent: HttpContent;
        myHttpHeaders: HttpHeaders;
        lHeaders: HttpHeaders;
        request: HttpRequestMessage;
        MyHttpClient: HttpClient;
        MyHttpResponseMessage: HttpResponseMessage;
        myToken: Text;
        myContentHeaders: HttpHeaders;
        Jtoken: JsonToken;
        JArray: JsonArray;
        isSuccess: Boolean;

    begin
        if not GMAILMGT.Get() then
            exit;

        isSuccess := false;
        ClearLastError;


        PostUrl := 'https://www.googleapis.com/drive/v3/files/' + TestSpreedID + '?enforceSingleParent=true';

        request.SetRequestUri(PostUrl);
        myHttpHeaders.Clear();
        lHeaders.Clear();

        myHttpContent.GetHeaders(lHeaders);
        lHeaders.Remove('Content-Type');
        lHeaders.Add('Content-Type', 'application/json');
        myHttpContent.GetHeaders(lHeaders);
        request.GetHeaders(myHttpHeaders);

        myHttpHeaders.Clear();
        myHttpHeaders.Add('Authorization', 'Bearer ' + GMAILMGT."API Token Key");
        myHttpHeaders.Add('Scopes', 'https://www.googleapis.com/auth/drive' +
                                    'https://www.googleapis.com/auth/drive.file' +
                                    'https://www.googleapis.com/auth/drive.appdata');
        request.Content := myHttpContent;
        request.GetHeaders(myHttpHeaders);
        request.Method := 'DELETE';

        isSuccess := MyHttpClient.Send(request, MyHttpResponseMessage);
    end;


    local procedure CreateSHJson(pTemplateRange: Text; pValue: text): Text
    var
        MyJobject: JsonObject;
        ThingJObject: JsonArray;
        ThingJObject2: JsonArray;
        JsonData: Text;
    begin

        MyJobject.Add('majorDimension', 'COLUMNS');
        MyJobject.Add('range', pTemplateRange);

        Clear(ThingJObject);
        Clear(ThingJObject2);

        ThingJObject2.Add(pValue);
        ThingJObject.Add(ThingJObject2);
        MyJobject.Add('values', ThingJObject);
        MyJobject.WriteTo(JsonData);

        //Message(JsonData);
        exit(JsonData);
    end;

    procedure DownloadCRMTemplate(pFileName: Text; SendEmail2: Boolean; Var Instreadm2: InStream)
    var

        ResponseMessage: HttpResponseMessage;
        JObject: JsonObject;
        Response: HttpResponseMessage;
        PostUrl: Text;
        GMAILMGT: Record "GMAIL Maintenance Setup";
        myHttpContent: HttpContent;
        myHttpHeaders: HttpHeaders;
        lHeaders: HttpHeaders;
        request: HttpRequestMessage;
        MyHttpClient: HttpClient;
        MyHttpResponseMessage: HttpResponseMessage;
        myToken: Text;
        myContentHeaders: HttpHeaders;
        isSuccess: Boolean;

        TestFileName: Text;
    begin
        if not GMAILMGT.Get() then
            exit;

        isSuccess := false;
        ClearLastError;

        PostUrl := 'https://www.googleapis.com/drive/v3/files/' + TestSpreedID + '/export?mimeType=application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';

        request.SetRequestUri(PostUrl);
        myHttpHeaders.Clear();
        lHeaders.Clear();

        myHttpContent.GetHeaders(lHeaders);
        lHeaders.Remove('Content-Type');
        lHeaders.Add('Content-Type', 'application/json');
        myHttpContent.GetHeaders(lHeaders);
        request.GetHeaders(myHttpHeaders);
        myHttpHeaders.Clear();

        myHttpHeaders.Add('Authorization', 'Bearer ' + GMAILMGT."API Token Key");
        myHttpHeaders.Add('Scopes', 'https://www.googleapis.com/auth/drive' +
                          'https://www.googleapis.com/auth/drive.file' +
                          'https://www.googleapis.com/auth/drive.meet.readonly' +
                          'https://www.googleapis.com/auth/drive.readonly');
        request.Content := myHttpContent;
        request.GetHeaders(myHttpHeaders);
        request.Method := 'GET';
        isSuccess := MyHttpClient.Send(request, MyHttpResponseMessage);

        if isSuccess then begin
            MyHttpResponseMessage.Content().ReadAs(Instreadm2);

            TestFileName := pFileName + '.xlsx';

            If not SendEmail2 then
                DownloadFromStream(Instreadm2, '', '', '', TestFileName);
        end;
    end;

    procedure DeleteZeroValueInCRMTemplate(ptext: text)
    var

        ResponseMessage: HttpResponseMessage;
        JObject: JsonObject;
        Response: HttpResponseMessage;
        PostUrl: Text;
        GMAILMGT: Record "GMAIL Maintenance Setup";
        myHttpContent: HttpContent;
        myHttpHeaders: HttpHeaders;
        lHeaders: HttpHeaders;
        request: HttpRequestMessage;
        MyHttpClient: HttpClient;
        MyHttpResponseMessage: HttpResponseMessage;
        myToken: Text;
        myContentHeaders: HttpHeaders;
        isSuccess: Boolean;

        TestFileName: Text;
    begin
        if not GMAILMGT.Get() then
            exit;

        isSuccess := false;
        ClearLastError;

        PostUrl := 'https://sheets.googleapis.com/v4/spreadsheets/' + TestSpreedID + ':batchUpdate';

        myHttpContent.WriteFrom(ptext);

        request.SetRequestUri(PostUrl);
        myHttpHeaders.Clear();
        lHeaders.Clear();

        myHttpContent.GetHeaders(lHeaders);

        lHeaders.Remove('Content-Type');
        lHeaders.Add('Content-Type', 'application/json');
        myHttpContent.GetHeaders(lHeaders);
        request.GetHeaders(myHttpHeaders);
        myHttpHeaders.Clear();

        myHttpHeaders.Add('Authorization', 'Bearer ' + GMAILMGT."API Token Key");
        myHttpHeaders.Add('Scopes', 'https://www.googleapis.com/auth/drive' +
                          'https://www.googleapis.com/auth/drive.file' +
                          'https://www.googleapis.com/auth/spreadsheets');
        request.Content := myHttpContent;
        request.GetHeaders(myHttpHeaders);
        request.Method := 'POST';
        isSuccess := MyHttpClient.Send(request, MyHttpResponseMessage);

    end;

    local procedure CreateJson(pSheetID2: integer; arraypStartIndex2: array[100] of integer; arraypEndIndex2: array[100] of integer; TotalIndex: integer): Text
    var
        MyJobject: JsonObject;
        ThingJObject: JsonArray;
        ThingJObject3: JsonObject;
        ThingJObject2: JsonObject;
        ThingJObject4: JsonObject;
        JsonData: Text;
        I: integer;
    begin

        Clear(ThingJObject);


        For I := 1 to TotalIndex do begin
            Clear(ThingJObject2);
            clear(ThingJObject3);
            clear(ThingJObject4);


            ThingJObject4.add('sheetId', pSheetID2);
            ThingJObject4.add('dimension', 'ROWS');
            ThingJObject4.add('startIndex', arraypStartIndex2[i]);
            ThingJObject4.add('endIndex', arraypEndIndex2[i]);

            ThingJObject3.Add('range', ThingJObject4);
            ThingJObject2.Add('deleteDimension', ThingJObject3);

            ThingJObject.add(ThingJObject2);
        end;

        MyJobject.Add('requests', ThingJObject);

        MyJobject.WriteTo(JsonData);


        exit(JsonData);
    end;

    local procedure CreateJson2(pSheetID2: integer): Text
    var
        MyJobject: JsonObject;
        ThingJObject: JsonArray;
        ThingJObject3: JsonObject;
        ThingJObject2: JsonObject;
        ThingJObject4: JsonObject;
        JsonData: Text;
    begin
        Clear(ThingJObject);

        Clear(ThingJObject2);
        clear(ThingJObject3);
        clear(ThingJObject4);
        ThingJObject4.add('sheetId', pSheetID2);
        ThingJObject4.add('dimension', 'ROWS');
        ThingJObject4.add('startIndex', 16);
        ThingJObject4.add('endIndex', 17);
        ThingJObject3.Add('range', ThingJObject4);
        ThingJObject2.Add('deleteDimension', ThingJObject3);
        ThingJObject.add(ThingJObject2);

        MyJobject.Add('requests', ThingJObject);
        MyJobject.WriteTo(JsonData);
        exit(JsonData);
    end;

    Local Procedure InitializedVariables()
    var
    Begin
        XLValAmt1 := 0;
        XLValAmt2 := 0;
        XLValAmt3 := 0;
        XLValAmt4 := 0;
        XLValAmt5 := 0;
        XLValAmt6 := 0;
        XLValAmt7 := 0;
        XLValAmt8 := 0;
        XLValAmt9 := 0;
        XLValAmt10 := 0;
        XLValQty1 := 0;
        XLValQty2 := 0;
        XLValQty3 := 0;
        XLValQty4 := 0;
        XLValQty5 := 0;
        XLValQty6 := 0;
        XLValQty7 := 0;
        XLValQty8 := 0;
        XLValQty9 := 0;
        XLValQty10 := 0;
    End;

    var
        TestSpreedID, SheetID2 : text;
        SheetID: integer;
        LocCode: Code[50];
        GmailMgtSetup: Record "GMAIL Maintenance Setup";
        TempLoc: Record Location Temporary;
        XLValQty1, XLValQty2, XLValQty3, XLValQty4, XLValQty5, XLValQty6, XLValQty7, XLValQty8, XLValQty9, XLValQty10 : Decimal;
        XLValAmt1, XLValAmt2, XLValAmt3, XLValAmt4, XLValAmt5, XLValAmt6, XLValAmt7, XLValAmt8, XLValAmt9, XLValAmt10, InterLineAddConn : decimal;
        FluentCommet: Text[250];

}