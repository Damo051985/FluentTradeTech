codeunit 60015 "Commission Reports"
{
    Permissions = TableData "Sales Invoice Header" = rm;
    trigger OnRun()
    var
    Begin
        InsertCustomer();
        InsertInvoiceNo();
        InsertCustomerPerAgreementPeriod();
    End;

    procedure CommissionPerCustomer()
    var
        lSIH: Record "Sales Invoice Header";
        lSIL: Record "Sales Invoice Line";
        lCPC: Record "Commision Per Customer";
        lSP: Record "Salesperson/Purchaser";
        lComEntry: Record "FTT-CST Commission Entries";
        lAmt, lComBase, lComAmt, lComBaseLCY, lComAmtLCY : Decimal;
        lCurr: Record Currency;
        lCUrrExL: Record "Currency Exchange Rate";
        lCust: Record Customer;
        lCurCode: Code[10];
    Begin
        Clear(lCPC);
        IF lCPC.FINDSET THEN begin
            repeat
                lAmt := 0;

                lCurCode := '';
                IF lCust.GET(lCPC."Customer Code") then
                    lCurCode := lCust."Currency Code";

                Clear(lSIH);
                lSIH.SetRange("Sell-to Customer No.", lCPC."Customer Code");
                lSIH.SETRANGE("Inserted in Report", FALSE);
                IF lSIH.FINDSET THEN begin
                    repeat
                        GETCommissionLedgEntries(lComBase, lComAmt, lComBaseLCY, lComAmtLCY, lCPC, lCurCode, lSIH."No.");
                        lCPC."Eligible Currency" += lComBase;
                        lCPC."Eligible LCY" += lComBaseLCY;
                        lCPC."Commision Currency" += lComAmt;
                        lCPC."Commision LCY" += lComAmtLCY;
                        lSIH.CalcFields(Amount);
                        lAmt += lSIH.Amount;
                        lSIH."Inserted in Report" := TRUE;
                        lSIH.MODIFY;
                    until lSIH.Next = 0;
                end;
                if lAmt <> 0 THEN BEGIN
                    lCPC."Invoice Amount Currency" := lCPC."Invoice Amount Currency" + lAmt;
                    lCPC."Invoice Amount LCY" := (lCPC."Invoice Amount Currency" * GetConvertion(lCurCode));
                    lCPC.MODIFY;
                END;
            until lCPC.Next = 0;
        end;
    End;

    Procedure InsertCustomer()
    var
        lTempCust: Record Customer temporary;
        lCust: Record Customer;
        lCPC, lCPC2 : Record "Commision Per Customer";
        lSIH: Record "Sales Invoice Header";
        lSIL: Record "Sales Invoice Line";
        lSP: Record "Salesperson/Purchaser";
    Begin
        IF lTempCust.IsTemporary then
            lTempCust.DeleteAll;

        Clear(lSIH);
        lSIH.SetRange("Inserted in Report", False);
        IF lSIH.FINDSET THEN begin
            repeat
                lTempCust.INIT;
                lTempCust."No." := lSIH."Sell-to Customer No.";
                lTempCust.Name := lSIH."Sell-to Customer Name";
                IF lTempCust.INSERT THEN;
            until lSIH.Next = 0;
        end;

        Clear(lCPC);
        Clear(lTempCust);
        IF lTempCust.FINDSET THEN begin
            repeat
                lCPC.SetRange("Customer Code", lTempCust."No.");
                IF NOT lCPC.FINDFIRST THEN begin
                    lCPC.Init;
                    lCPC."Customer Code" := lTempCust."No.";
                    lCPC."Customer Name" := lTempCust.Name;
                    IF lCust.GET(lTempCust."No.") then BEGIN
                        lCPC."Salesperson Code" := lCust."Salesperson Code";
                        IF lSP.GET(lCPC."Salesperson Code") then
                            lCPC."Salesperson Name" := lSP.Name;
                    End;
                    lCPC.Type := lCPC.Type::Line;
                    lCPC.INSERT;
                end;
            until lTempCust.Next = 0;
        end;
        //>> Need to insert once for Grand Total
        Clear(lCPC2);
        lCPC2.INIT;
        lCPC2."Customer Code" := '';
        lCPC2."Salesperson Code" := '';
        lCPC2.Type := lCPC2.Type::"Grand Total";
        IF lCPC2.INSERT THEN;
        //<< Need to insert once for Grand Total

        CommissionPerCustomer();
    End;

    Local Procedure GetConvertion(pCurCode: Code[20]): decimal
    var
        lCurEx: Record "Currency Exchange Rate";
    Begin
        Clear(lCurEx);
        lCurEx.SETRANGE("Currency Code", pCurCode);
        IF lCurEx.FINDLAST then
            Exit(lCurEx."Exchange Rate Amount");
        EXIT(1);
    End;

    local Procedure GETCommissionLedgEntries(VAR pComBase: decimal; VAR pComAmt: decimal; VAR pComBaseLCY: decimal; VAR pComAmtLCY: decimal; pRec: Record "Commision Per Customer"; pCurCode: Code[10]; pDocNo: Code[20])
    var
        lComEntry: Record "FTT-CST Commission Entries";
    Begin
        pComBase := 0;
        pComBaseLCY := 0;
        pComAmt := 0;
        pComAmtLCY := 0;

        Clear(lComEntry);
        lComEntry.SETRANGE("Sell-to Customer No.", pRec."Customer Code");
        lComEntry.SetRange("Salesperson Code", pRec."Salesperson Code");
        lComEntry.SETRANGE("Document Type", lComEntry."Document Type"::Invoice);
        lComEntry.SETFILTER("Document No.", pDocNo);
        IF (lComEntry.FINDFIRST) THEN begin
            lComEntry.CalcFields("Commission Base", "Commission Amount", "Commission Amount (LCY)");
            pComBase := lComEntry."Commission Base";
            pComBaseLCY := (pComBase * GetConvertion(pCurCode));
            IF lComEntry."Invoice Settled" then begin
                pComAmt := lComEntry."Commission Amount";
                pComAmtLCY := lComEntry."Commission Amount (LCY)";
            ENd;
        end;
    End;

    Procedure InsertInvoiceNo()
    var
        lCust: Record Customer;
        lCPI, lCPI2 : Record "Commision Per Invoice";
        lSIH: Record "Sales Invoice Header";
        lSIL: Record "Sales Invoice Line";
        lSP: Record "Salesperson/Purchaser";
        lAmt, lComBase, lComAmt, lComBaseLCY, lComAmtLCY : Decimal;
        lCurCode: Code[10];
        InvoiceSettled: Boolean;
    Begin

        Clear(lSIH);
        lSIH.SetRange("Inserted in Report 2", FALSE);
        IF lSIH.FINDSET THEN begin
            repeat
                lComBase := 0;
                lComAmt := 0;
                lComBaseLCY := 0;
                lComAmtLCY := 0;

                lCurCode := '';
                IF lCust.GET(lSIH."Sell-to Customer No.") then
                    lCurCode := lCust."Currency Code";

                lSIH.CalcFields(Amount, "Amount Including VAT");
                lCPI.INIT;
                lCPI."Invoice No." := lSIH."No.";
                lCPI."Customer Code" := lSIH."Sell-to Customer No.";
                lCPI."Customer Name" := lSIH."Sell-to Customer Name";
                IF lCust.GET(lSIH."Sell-to Customer No.") then
                    IF lSP.GET(lCust."Salesperson Code") THEN BEGIN
                        lCPI."Salesperson Code" := lSP.Code;
                        lCPI."Salesperson Name" := lSP.Name;
                    End;

                GETCommissionLedgEntriesPerInvoice(lComBase, lComAmt, lComBaseLCY, lComAmtLCY, lSIH, lCurCode, InvoiceSettled);

                lCPI."Invoice Amount Currency" := lSIH.Amount;
                lCPI."Invoice Amount LCY" := (lSIH.Amount * GetConvertion(lCurCode));
                lCPI."Eligible Currency" := lComBase;
                lCPI."Eligible LCY" := lComBaseLCY;
                lCPI.Type := lCPI.Type::Line;
                IF InvoiceSettled then BEGIN
                    lCPI."Invoice Status" := lCPI."Invoice Status"::Paid;
                    lCPI."Commision Currency" := lComAmt;
                    lCPI."Commision LCY" := lComAmtLCY;
                END ELSE BEGIN
                    lCPI."Invoice Status" := lCPI."Invoice Status"::Unpaid;
                    lCPI."Commision Currency" := 0;
                    lCPI."Commision LCY" := 0;
                END;
                IF lCPI.Insert Then;
                lSIH."Inserted in Report 2" := TRUE;
                lSIH.MODIFY;
            until lSIH.Next = 0;
        end;

        UpdateUnpaidPerinvoice();

        //>> Need to insert once for Grand Total
        Clear(lCPI2);
        lCPI2.INIT;
        lCPI2."Invoice No." := '';
        lCPI2."Customer Code" := '';
        lCPI2."Salesperson Code" := '';
        lCPI2.Type := lCPI2.Type::"Grand Total";
        IF lCPI2.INSERT THEN;
        //<< Need to insert once for Grand Total
    End;

    Local Procedure UpdateUnpaidPerinvoice()
    var
        lCPI: Record "Commision Per Invoice";
        lComEntry: Record "FTT-CST Commission Entries";
        lCurCode: Code[10];
    Begin
        Clear(lCPI);
        lCPI.SETRANGE("Invoice Status", lCPI."Invoice Status"::Unpaid);
        IF lCPI.FINDSET THEN begin
            repeat
                Clear(lComEntry);
                lComEntry.SetRange("Document No.", lCPI."Invoice No.");
                IF (lComEntry.FINDFIRST) AND (lComEntry."Invoice Settled") THEN begin
                    lComEntry.CalcFields("Commission Amount", "Commission Amount (LCY)");
                    lCPI."Commision Currency" := lComEntry."Commission Amount";
                    lCPI."Commision LCY" := lComEntry."Commission Amount (LCY)";
                    lCPI."Invoice Status" := lCPI."Invoice Status"::Paid;
                    lCPI.Modify();
                end;
            until lCPI.Next = 0;
        end;
    End;

    local Procedure GETCommissionLedgEntriesPerinvoice(VAR pComBase: decimal; VAR pComAmt: decimal; VAR pComBaseLCY: decimal; VAR pComAmtLCY: decimal; pRec: Record "Sales Invoice Header"; lCurCode: Code[10]; VAR pInvSet: Boolean)
    var
        lComEntry: Record "FTT-CST Commission Entries";
    Begin
        Clear(lComEntry);
        lComEntry.SETRANGE("Document Type", lComEntry."Document Type"::Invoice);
        lComEntry.SETFILTER("Document No.", pRec."No.");
        IF lComEntry.FINDFIRST THEN begin
            lComEntry.CalcFields("Commission Base", "Commission Amount", "Commission Amount (LCY)");
            pComBase := lComEntry."Commission Base";
            pComAmt := lComEntry."Commission Amount";
            pComBaseLCY := (pComBase * GetConvertion(lCurCode));
            pComAmtLCY := lComEntry."Commission Amount (LCY)";
            IF lComEntry."Invoice Settled" then
                pInvSet := TRUE
            Else
                pInvSet := False;
        end;
    End;

    procedure InsertCustomerPerAgreementPeriod()
    var
        lSIH: Record "Sales Invoice Header";
        lSIL: Record "Sales Invoice Line";
        lCNS, lCNS2 : Record "Commision New Sales";
        lSP: Record "Salesperson/Purchaser";
        lComEntry: Record "FTT-CST Commission Entries";
        lCust: Record Customer;
        lCurCode: Code[20];
        lAmt, lComBase, lComAmt, lComBaseLCY, lComAmtLCY : Decimal;
    Begin
        Clear(lSIH);
        lSIH.SETRANGE("Inserted in Report 3", FALSE);
        IF lSIH.FINDSET THEN begin
            repeat
                lComBase := 0;
                lComAmt := 0;
                lComBaseLCY := 0;
                lComAmtLCY := 0;
                lAmt := 0;
                lCurCode := '';

                Clear(lSIL);
                lSIL.SETRANGE("Document No.", lSIH."No.");
                lSIL.SetRange("Agreement Period", 1);
                lSIL.Setrange("FTT-CST Eligible", TRUE);
                IF lSIL.FINDSET THEN begin
                    lSIL.CalcSums("Commission base Amount", "Commission Base Amount (LCY)", "Unit Price", "FTT-CST Unit Price", Amount, "Line Amount");
                    lComBase := lSIL."Commission Base Amount";
                    lComBaseLCY := lSil."Commission Base Amount (LCY)";

                    lCNS.INIT;
                    lCNS."Invoice No." := lSIH."No.";
                    IF lCust.GET(lSIH."Sell-to Customer No.") then BEGIN
                        lCNS."Customer Code" := lCust."No.";
                        lCNS."Customer Name" := lCust.Name;
                        lCurCode := lCust."Currency Code";
                        IF lSP.GET(lCust."Salesperson Code") then begin
                            lCNS."Salesperson Code" := lCust."Salesperson Code";
                            lCNS."Salesperson Name" := lSP.Name;
                        end;
                    End;

                    lCNS."Invoice Amount Currency" := lSIL."Line Amount";
                    lCNS."Invoice Amount LCY" := (lSIL."Line Amount" * GetConvertion(lCurCode));
                    IF (lSIL."FTT-CST Salesp. Comm. Type" = lSIL."FTT-CST Salesp. Comm. Type"::"50") AND (lSIL."Line Amount" <> 0) then BEGIN
                        lCNS."Eligible Currency" := lSIL."Line Amount" / 2;
                        lCNS."Eligible LCY" := (lSIL."Line Amount" * GetConvertion(lCurCode));
                    END else begin
                        lCNS."Eligible Currency" := lSIL."Line Amount";
                        lCNS."Eligible LCY" := (lSIL."Line Amount" * GetConvertion(lCurCode));
                    end;

                    Clear(lComEntry);
                    lComEntry.SETRANGE("Document Type", lComEntry."Document Type"::Invoice);
                    lComEntry.SetFilter("Document No.", lSIH."No.");
                    IF (lComEntry.FINDFIRST) AND (lComEntry."Invoice Settled") then BEGIN
                        lCNS."Invoice Status" := lCNS."Invoice Status"::Paid;
                        lCNS."Commision Currency" := lSIL."Commission Base Amount";
                        lCNS."Commision LCY" := lSIL."Commission Base Amount (LCY)";
                    END ELSE begin
                        lCNS."Invoice Status" := lCNS."Invoice Status"::Unpaid;
                        lCNS."Commision Currency" := 0;
                        lCNS."Commision LCY" := 0;
                    END;

                    lCNS.Type := lCNS.Type::Line;
                    IF lCNS.INSERT THEN;
                    lSIH."Inserted in Report 3" := True;
                    lSIH.Modify;
                end;
            until lSIH.NEXT = 0;
        end;

        UpdateUnpaidPerNewSales();
        //>> Need to insert once for Grand Total
        Clear(lCNS2);
        lCNS2.INIT;
        lCNS2."Invoice No." := '';
        lCNS2."Customer Code" := '';
        lCNS2."Salesperson Code" := '';
        lCNS2.Type := lCNS2.Type::"Grand Total";
        IF lCNS2.INSERT THEN;
        //<< Need to insert once for Grand Total
    End;

    Local Procedure UpdateUnpaidPerNewSales()
    var
        lCPI: Record "Commision Per Invoice";
        lSIH: Record "Sales Invoice Header";
        lSIL: Record "Sales Invoice Line";
        lSP: Record "Salesperson/Purchaser";
        lComEntry: Record "FTT-CST Commission Entries";
        lCurCode: Code[10];
    Begin
        Clear(lCPI);
        lCPI.SETRANGE("Invoice Status", lCPI."Invoice Status"::Unpaid);
        IF lCPI.FINDSET THEN begin
            repeat
                Clear(lComEntry);
                lComEntry.SetRange("Document No.", lCPI."Invoice No.");
                IF (lComEntry.FINDFIRST) AND (lComEntry."Invoice Settled") THEN begin
                    Clear(lSIL);
                    lSIL.SetRange("Document No.", lComEntry."Document No.");
                    IF lSIL.FINDSET THEN begin
                        lSIL.CalcSums("Commission base Amount", "Commission Base Amount (LCY)");
                        lCPI."Commision Currency" := lSIL."Commission base Amount";
                        lCPI."Commision LCY" := lSIL."Commission BASE Amount (LCY)";
                        lCPI."Invoice Status" := lCPI."Invoice Status"::Paid;
                        lCPI.Modify();
                    end;
                end;
            until lCPI.Next = 0;
        end;
    End;

    var
        gTempCust: Record Customer Temporary;
}
