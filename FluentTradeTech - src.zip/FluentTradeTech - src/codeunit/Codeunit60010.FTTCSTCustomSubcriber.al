codeunit 60010 FTTCSTCustomSubcriber
{
    [EventSubscriber(ObjectType::Page, Page::"Document Attachment Factbox", OnBeforeDrillDown, '', false, false)]
    local procedure "Document Attachment Factbox_OnBeforeDrillDown"(DocumentAttachment: Record "Document Attachment"; var RecRef: RecordRef)
    VAR
        Oppor: Record Opportunity;
    begin
        Case DocumentAttachment."Table ID" of
            Database::Opportunity:
                begin
                    RecRef.Open(Database::Opportunity);
                    IF Oppor.GET(DocumentAttachment."No.") THEN
                        RecRef.GetTable(Oppor);
                end;
        End;
    end;

    [EventSubscriber(ObjectType::Page, Page::"Document Attachment Details", OnAfterOpenForRecRef, '', false, false)]
    local procedure "Document Attachment Details_OnAfterOpenForRecRef"(var DocumentAttachment: Record "Document Attachment"; var RecRef: RecordRef; var FlowFieldsEditable: Boolean)
    var
        FldRef: FieldRef;
        RecNo: Code[20];
    begin
        case RecRef.Number of
            Database::Opportunity:
                begin
                    FldRef := RecRef.Field(1);
                    RecNo := FldRef.Value;
                    DocumentAttachment.SetRange("No.", RecNo);
                end;

        End;
    end;

    [EventSubscriber(ObjectType::Table, Database::"Document Attachment", OnAfterInitFieldsFromRecRef, '', false, false)]
    local procedure "Document Attachment_OnAfterInitFieldsFromRecRef"(var DocumentAttachment: Record "Document Attachment"; var RecRef: RecordRef)
    var
        FldRef: FieldRef;
        RecNo: Code[20];
    begin
        case RecRef.Number of
            DATABASE::Opportunity:
                begin
                    FldRef := RecRef.Field(1);
                    RecNo := FldRef.Value;
                    DocumentAttachment.Validate("No.", RecNo);
                end;
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Relationship Performance Mgt.", OnBeforeAddBusinessChartBufferColumn, '', false, false)]
    local procedure "Relationship Performance Mgt._OnBeforeAddBusinessChartBufferColumn"(var BusinessChartBuffer: Record "Business Chart Buffer"; var TempOpportunity: Record Opportunity temporary; var IsHandled: Boolean)
    var
        DescandName: Text[1024];
        Oppor: Record Opportunity;
    begin
        TempOpportunity.CalcFields("Contact Name");
        DescandName := TempOpportunity."Contact Name" + ' - ' + TempOpportunity.Description;
        BusinessChartBuffer.AddColumn(DescandName);
        IsHandled := True;
    end;

    [EventSubscriber(ObjectType::Page, Page::"Update Opportunity", OnUpdateEstimatedValuesOnBeforeModify, '', false, false)]
    local procedure "Update Opportunity_OnUpdateEstimatedValuesOnBeforeModify"(var OpportunityEntry: Record "Opportunity Entry"; SalesHeader: Record "Sales Header")
    Var
        lOppEnt: Record "Opportunity Entry";
    begin

    end;

    [EventSubscriber(ObjectType::Table, Database::"Opportunity Entry", OnBeforeCheckStatus2, '', false, false)]
    local procedure "Opportunity Entry_OnBeforeCheckStatus2"(var OpportunityEntry: Record "Opportunity Entry"; var IsHandled: Boolean)
    var
        lOpp: Record Opportunity;
        lOppEnt: Record "Opportunity Entry";
        lDocAtt: Record "Document Attachment";
        lUserSet: Record "User Setup";
        lCont: Record Contact;
        lCust: Record Customer;
        lSH: Record "Sales Header";
        lHasNDA: Boolean;
        MySesSet: SessionSettings;
    begin
        //>> update 103024
        MySesSet.Init;
        IF MySesSet.ProfileId = 'FTT_SALES_DIRECTOR' THEN
            IF (lUserSet.GET(UserId)) AND (lUserSet."Skip NDA Validation") THEN
                Exit;
        lHasNDA := False;
        Clear(lOpp);
        Clear(lOppEnt);

        IF (OpportunityEntry."Sales Cycle Stage" > 5) AND (OpportunityEntry."Action Type" = OpportunityEntry."Action Type"::Skip) then begin
            IF lOpp.GET(OpportunityEntry."Opportunity No.") THEN
                lOpp.CalcFields("Contact Name");
            Clear(lDocAtt);
            lDocAtt.SETRANGE("Table ID", 5092);
            lDocAtt.SETRANGE("No.", OpportunityEntry."Opportunity No.");
            //lDocAtt.SETFILTER("FTT-CST NDA", '%1', TRUE);
            IF lDocAtt.FINDFIRST THEN
                IF (lDocAtt."FTT-CST NDA") OR (lDocAtt."MSA Document") THEN
                    lHasNDA := TRUE;

            lCont.RESET;
            IF lCont.GET(lOpp."Contact No.") THEN begin
                Clear(lDocAtt);
                lDocAtt.SETRANGE("Table ID", 5050);
                lDocAtt.SETRANGE("No.", lCont."No.");
                //lDocAtt.SETFILTER("FTT-CST NDA", '%1', TRUE);
                IF lDocAtt.FINDFIRST THEN
                    IF (lDocAtt."FTT-CST NDA") OR (lDocAtt."MSA Document") THEN
                        lHasNDA := TRUE;
            end;
            lCust.RESET;
            lCust.SETRANGE(Name, lOpp."Contact Name");
            IF lCust.FINDFIRST THEN BEGIN
                Clear(lDocAtt);
                lDocAtt.SETRANGE("Table ID", 18);
                lDocAtt.SETRANGE("No.", lCust."No.");
                //lDocAtt.SETFILTER("FTT-CST NDA", '%1', TRUE);
                IF lDocAtt.FINDFIRST THEN
                    IF (lDocAtt."FTT-CST NDA") OR (lDocAtt."MSA Document") THEN
                        lHasNDA := TRUE;
            end;
            Clear(lSH);
            lSH.SETRANGE("Opportunity No.", lOpp."No.");
            IF lSH.FINDFIRST then begin
                Clear(lDocAtt);
                lDocAtt.SETRANGE("Table ID", 36);
                lDocAtt.SETRANGE("No.", lSH."No.");
                //DocAtt.SETFILTER("FTT-CST NDA", '%1', TRUE);
                IF lDocAtt.FINDFIRST THEN
                    IF (lDocAtt."FTT-CST NDA") OR (lDocAtt."MSA Document") THEN
                        lHasNDA := True;
            End;
            IF NOT lHasNDA then
                Error('You cannot skip to this stage before you have assigned NDA (or MSA) Document.');

        end;
        //<< update 103024
    end;

    [EventSubscriber(ObjectType::Page, Page::"Document Attachment Factbox", OnBeforeDocumentAttachmentDetailsRunModal, '', false, false)]
    local procedure "Document Attachment Factbox_OnBeforeDocumentAttachmentDetailsRunModal"(var Sender: Page "Document Attachment Factbox"; var DocumentAttachment: Record "Document Attachment"; var RecRef: RecordRef; var DocumentAttachmentDetails: Page "Document Attachment Details")
    Var
        lEmp: Record Employee;
        lFldRef: FieldRef;
    begin
        lFldRef := RecRef.Field(1);
        DocumentAttachmentDetails.VisibleSelectedFields(TRUE, lFldRef.Value);
    end;

    [EventSubscriber(ObjectType::Table, Database::"Approval Entry", OnBeforeMarkAllWhereUserisApproverOrSender, '', false, false)]
    local procedure "Approval Entry_OnBeforeMarkAllWhereUserisApproverOrSender"(var ApprovalEntry: Record "Approval Entry"; var IsHandled: Boolean)
    Var
    begin
        IsHandled := True;
    end;

    Procedure CheckProfileRole()
    var
    Begin
    End;

    Local Procedure InitializedFields()
    var
        lRepRev: Record "Revenue Report";
    Begin
        IF lRepRev.FINDSET THEN
            REPEAT
                lRepRev."ARR - Previous Contracts" := 0;
                lRepRev."ARR - Additional Products" := 0;
                lRepRev."ARR Contract in Progress" := 0;
                lRepRev."NRC Contract in Progress" := 0;
                lRepRev."New Proj. Stage" := '';
                lRepRev.Connectivity := 0;
                lRepRev.Distribution := 0;
                lRepRev."Risk and Others" := 0;
                lRepRev."Other YRC" := 0;
                lRepRev.Modify;
            Until lRepRev.Next = 0;
    End;

    Procedure GETSOPrimaryHosted85percentPrimRen();
    var
        lSH, lSH2, lSH3 : Record "Sales Header";
        lSL: Record "Sales Line";
        lRevRep, lRevRep2 : Record "Revenue Report";
        lTot, lTot2 : decimal;
        lType1, lType2, lType3 : Boolean;
        lCurEx: Record "Currency Exchange Rate";
        lCont: Record Contact;
        lCurCode: Code[20];
        lDocNo, lDocNo2 : Code[250];
    Begin
        InitializedFields();
        Clear(lRevRep);
        lRevRep.SetRange("Line Type", lRevRep."Line Type"::"Over 85 %");
        lRevRep.SetFilter("Salesperson Code", '<>%1', '');
        lRevRep.Setfilter("Customer/Prospect", '<>%1', '');
        IF lRevRep.FINDSET THEN
            REPEAT
                Conn2 := 0;
                Distr2 := 0;
                RiskOth2 := 0;
                OtherYrc2 := 0;
                Conn := 0;
                Distr := 0;
                RiskOth := 0;
                OtherYrc := 0;
                lTot := 0;
                lTot2 := 0;
                lType1 := False;
                lType2 := False;
                lType3 := False;
                lDocNo := '';
                Clear(lSH);
                Clear(lSH2);
                Clear(lSH3);
                lSH.SetCurrentKey("Document Type", "No.");
                lSH.SETRANGE("Document Type", lSH."Document Type"::Order);
                lSH.SetRange("Salesperson Code", lRevRep."Salesperson Code");
                lSH.Setfilter("Sell-to Customer Name", '%1', lRevRep."Customer/Prospect");
                lSH.Setfilter("FTT-CST Order Type", '%1', lSH."FTT-CST Order Type"::Primary);
                IF lSH.FINDSET THEN BEGIN
                    lType1 := TRUE;
                    lCurCode := lSH."Currency Code";
                    REPEAT
                        lDocNo := lDocNo + lSH."No." + '|';
                        lTot := (lTot + GetSOLine(lSH)) - lSH."Invoice Discount Value";
                        GetConnectivity(lSH);
                    UNTIL lSH.NEXT = 0;
                    lDocNo := DELCHR(lDocNo, '>', '|');
                    lRevRep."Document type" := lSH."Document Type"::Order;
                    lRevRep."Document No." := lDocNo;
                    lRevRep.Modify();
                END;
                lSH2.SetCurrentKey("Document Type", "No.");
                lSH2.SETRANGE("Document Type", lSH2."Document Type"::Order);
                lSH2.SetRange("Salesperson Code", lRevRep."Salesperson Code");
                lSH2.Setfilter("Sell-to Customer Name", '%1', lRevRep."Customer/Prospect");
                lSH2.Setfilter("FTT-CST Order Type", '%1', lSH2."FTT-CST Order Type"::Renewal);
                IF lSH2.FINDSET THEN BEGIN
                    lDocNo := '';
                    lTot := 0;
                    lType2 := TRUE;
                    lCurCode := lSH2."Currency Code";
                    Conn := 0;
                    Distr := 0;
                    RiskOth := 0;
                    OtherYrc := 0;
                    REPEAT
                        lDocNo := lDocNo + lSH2."No." + '|';
                        lTot := (lTot + GetSOLine(lSH2)) - lSH2."Invoice Discount Value";
                        GetConnectivity(lSH2);
                    UNTIL lSH2.Next = 0;
                    lDocNo := DELCHR(lDocNo, '>', '|');
                    lRevRep."Document type" := lSH2."Document Type"::Order;
                    lRevRep."Document No." := lDocNo;
                    lRevRep.Modify();
                END;
                lSH3.SetCurrentKey("Document Type", "No.");
                lSH3.SETRANGE("Document Type", lSH3."Document Type"::Order);
                lSH3.SetRange("Salesperson Code", lRevRep."Salesperson Code");
                lSH3.Setfilter("Sell-to Customer Name", '%1', lRevRep."Customer/Prospect");
                lSH3.Setfilter("FTT-CST Order Type", '%1', lSH3."FTT-CST Order Type"::Additions);
                IF lSH3.FINDSET THEN BEGIN
                    lDocNo2 := '';
                    lType3 := TRUE;
                    lCurCode := lSH3."Currency Code";
                    Repeat
                        lDocNo2 := lDocNo2 + lSH3."No." + '|';
                        GetConnectivity2(lSH3);
                        lTot2 := (lTot2 + CompareSHARRAddition(lSH, lSH2, lSH3, lType1, lType2, lType3)) - lSH3."Invoice Discount Value";
                    Until lSH3.Next = 0;
                    lDocNo2 := DELCHR(lDocNo2, '>', '|');
                    lRevRep.DocType2 := lSH3."Document Type"::Order;
                    lRevRep."DocNo.2" := lDocNo2;
                    lRevRep.Modify();
                ENd;
                Clear(lRevRep2);
                IF lRevRep2.GET(lRevRep.Type, lRevRep."Salesperson Code", lRevRep."Line Type"::"Over 85 %", lRevRep."Customer/Prospect") THEN BEGIN
                    lRevRep2.VALIDATE("ARR - Previous Contracts", (lTot * GetConvertion(lCurCode)));
                    lRevRep2.VALIDATE("ARR - Additional Products", (lTot2) * GetConvertion(lCurCode));
                    lRevRep2.Validate(Connectivity, (Conn + Conn2) * GetConvertion(lCurCode));
                    lRevRep2.Validate(Distribution, (Distr + Distr2) * GetConvertion(lCurCode));
                    lRevRep2.validate("Risk and Others", (RiskOth + RiskOth2) * GetConvertion(lCurCode));
                    lRevRep2.Validate("Other YRC", (OtherYrc + OtherYrc2) * GetConvertion(lCurCode));
                    lRevRep2.MODIFY;
                END;
            Until lRevRep.Next = 0;
    End;

    Local procedure CompareSHARRAddition(pSH1: Record "Sales Header"; pSH2: Record "Sales Header"; pSH3: Record "Sales Header"; pT1: Boolean; pT2: Boolean; pT3: Boolean): decimal
    var

    Begin
        IF (pT1) AND (NOT pt2) THEN begin
            IF (pSH1."FTT-CST Agr. Starting Date" >= pSH3."FTT-CST Agr. Ending Date") THEN
                Exit(0)
            ELSE
                Exit(GetSOLine(pSH3));
        end ELSE IF Pt2 THEN BEGIN
            IF (pSH2."FTT-CST Agr. Starting Date" >= pSH3."FTT-CST Agr. Ending Date") THEN
                Exit(0)
            ELSE
                Exit(GetSOLine(pSH3));
        END;
    End;

    Local Procedure GetSOLine(pSH: Record "Sales Header"): Decimal
    var
        lSL: Record "Sales Line";
        lYRC: decimal;
        lSH: Record "Sales Header";
    Begin
        lYRC := 0;
        Clear(lSL);
        lSL.SetRange("Document Type", pSH."Document Type");
        lSL.SetRange("Document No.", pSH."No.");
        lSL.SetRange("FTT-CST Optional", lSL."FTT-CST Optional"::No);
        if lSL.FindSet() then BEGIN
            repeat
                IF lSL."FTT-CST Cost Type" <> lSL."FTT-CST Cost Type"::NRC THEN BEGIN
                    lYRC += lSL."Line Amount";
                END;
            until lSL.next = 0;
        END;
        EXIT(lYRC);
    End;

    Local Procedure GetConvertion(pCurCode: Code[20]): decimal
    var
        lCurEx: Record "Currency Exchange Rate";
        lCont: Record Contact;
        lCurrCode: Code[20];
    Begin
        Clear(lCurEx);
        lCurEx.SETRANGE("Currency Code", pCurCode);
        IF lCurEx.FINDLAST then
            Exit(lCurEx."Exchange Rate Amount");
        EXIT(1);
    End;
    /////////////////////////For 50 %/////////////////////////
    Procedure GETSOPrimaryHosted50percentPrimRen();
    var
        lSH, lSH2, lSH3 : Record "Sales Header";
        lSL: Record "Sales Line";
        lRevRep, lRevRep2 : Record "Revenue Report";
        lTot, lTot2, lEVtot, lEVTot2, lNRC, lYRC : decimal;
        lType1, lType2, lType3 : Boolean;
        i: Integer;
        Opp: Record Opportunity;
        OppEnt: Record "Opportunity Entry";
        EstVal: Record "FTT-CST Estimated Value Mod";
        lDes: Text[100];
        lCurEx: Record "Currency Exchange Rate";
        lCont: Record Contact;
        lCurCode, lOppNo : Code[20];
        lDocNo: Code[250];
        lDiscVal: decimal;
        lWithSQ: Boolean;
    Begin
        Clear(lRevRep);
        lRevRep.SetRange("Line Type", lRevRep."Line Type"::"Over 50 %");
        lRevRep.SetFilter("Salesperson Code", '<>%1', '');
        lRevRep.Setfilter("Customer/Prospect", '<>%1', '');
        IF lRevRep.FINDSET THEN
            REPEAT
                lNRC := 0;
                lYRC := 0;
                lTot := 0;
                lTot2 := 0;
                lType1 := False;
                lType2 := False;
                lType3 := False;
                lWithSQ := False;
                lDocNo := '';
                Conn := 0;
                Distr := 0;
                RiskOth := 0;
                OtherYrc := 0;
                Clear(lSH);
                Clear(lSH2);
                Clear(lSH3);
                Clear(Opp);
                Clear(OppEnt);
                Clear(EstVal);
                Clear(i);
                lEVtot := 0;
                lEVtot2 := 0;
                Opp.SETRANGE("Contact Name", lRevRep."Customer/Prospect");
                Opp.SetFilter("Salesperson Code", '%1', lRevRep."Salesperson Code");
                IF Opp.FINDSET THEN begin
                    REPEAT
                        lDocNo := lDocNo + Opp."No." + '|';
                        IF lCont.Get(Opp."Contact No.") then
                            lCurCode := lCont."Currency Code";
                        OppEnt.SetRange("Opportunity No.", Opp."No.");
                        OppEnt.Setfilter(Active, '%1', TRUE);
                        IF (OppEnt.FINDFIRST) AND ((OppEnt."Probability %" >= 50) AND (OppEnt."Probability %" < 85)) THEN begin
                            lSH2.SetRange("Document Type", lSH2."Document Type"::Quote);
                            lSH2.SETFILTER("Opportunity No.", '%1', OppEnt."Opportunity No.");
                            lSH2.SETFILTER("FTT-CST Final Quote", '%1', True);
                            IF NOT lSH2.FINDFIRST THEN begin
                                EstVal.SetRange("Linked No.", OppEnt."Opportunity No.");
                                EstVal.Setfilter("Linked Source Table ID", '%1', DATABASE::"Opportunity");
                                IF EstVal.FINDSET then begin
                                    FOR i := 1 to 2 Do BEGIN
                                        IF i = 1 then
                                            lEVtot += GetESTValCostType(EstVal, i)
                                        Else
                                            lEVtot2 += GetESTValCostType(EstVal, i);
                                    END;
                                END;
                            end ELSE
                                lWithSQ := True;
                        end;
                    UNTIL (Opp.Next = 0) OR (lWithSQ);
                    lDocNo := DELCHR(lDocNo, '>', '|');
                    lYRC := lEVtot;
                    lNRC := lEVTot2;
                end;

                IF lWithSQ THEN BEGIN
                    lDocNo := '';
                    lSH.SetCurrentKey("Document Type", "No.");
                    lSH.SETRANGE("Document Type", lSH."Document Type"::Quote);
                    lSH.SetRange("Salesperson Code", lRevRep."Salesperson Code");
                    lSH.Setfilter("Sell-to Customer Name", '%1', lRevRep."Customer/Prospect");
                    lSH.SETFILTER("FTT-CST Final Quote", '%1', TRUE);
                    IF lSH.FINDSET THEN begin
                        lCurCode := lSH."Currency Code";
                        lDes := GetNewProjectStage(lSH, 0);
                        Clear(i);
                        REPEAT
                            lDocNo := lDocNo + lSH."No." + '|';
                            GetConnectivity(lSH);
                            FOR i := 1 to 2 DO BEGIN
                                IF i = 1 THEN
                                    lTot := (lTot + GetSOLine2(lSH, i))
                                ELSE
                                    ltot2 := (lTot2 + GetSOLine2(lSH, i));
                            END;
                            lTot := lTot - lSH."Invoice Discount Value";

                        //lTot2 := lTot2 - lSH."Invoice Discount Value";//
                        Until lSH.NEXT = 0;
                        lDocNo := DELCHR(lDocNo, '>', '|');
                    end;
                    lYRC := lTot;
                    lNRC := lTot2;
                END;

                Clear(lRevRep2);
                IF lRevRep2.GET(lRevRep.Type, lRevRep."Salesperson Code", lRevRep."Line Type"::"Over 50 %", lRevRep."Customer/Prospect") THEN BEGIN
                    lRevRep2.VALIDATE("ARR Contract in Progress", (lYRC * GetConvertion(lCurCode)));
                    lRevRep2.VALIDATE("NRC Contract in Progress", (lNRC * GetConvertion(lCurCode)));
                    lRevRep2."New Proj. Stage" := lDes;
                    lRevRep2."DocNo.3" := lDocNo;
                    lRevRep2."DocNo.4" := lDocNo;
                    lRevRep2.DocType3 := lRevRep2.DocType3::Quote;
                    lRevRep2.DocType4 := lRevRep2.DocType3::Quote;
                    lRevRep2.Validate(Connectivity, (lRevRep2.Connectivity + Conn) * GetConvertion(lCurCode));
                    lRevRep2.Validate(Distribution, (lRevRep2.Distribution + Distr) * GetConvertion(lCurCode));
                    lRevRep2.validate("Risk and Others", (lRevRep2."Risk and Others" + RiskOth) * GetConvertion(lCurCode));
                    lRevRep2.Validate("Other YRC", (lRevRep2."Other YRC" + otherYrc) * GetConvertion(lCurCode));
                    lRevRep2.MODIFY;
                END;
            Until lRevRep.Next = 0;
    End;

    Local Procedure GetESTValCostType(pEV: Record "FTT-CST Estimated Value Mod"; pint: Integer): decimal
    var
        lEV: Record "FTT-CST Estimated Value Mod";
        lNRCYRC: decimal;
    Begin
        Clear(lEV);
        lNRCYRC := 0;
        lEV.SetRange("Linked No.", pEV."Linked No.");
        lEv.SEtfilter("Linked Source Table ID", '%1', pEV."Linked Source Table ID");
        IF lEV.FINDSET THEN begin
            repeat
                IF pInt = 1 then BEGIN
                    IF lEV."FTT-CST Cost Type" <> lEV."FTT-CST Cost Type"::NRC THEN
                        lNRCYRC += lEV."Line Amount Total";
                END ELSE
                    IF lEV."FTT-CST Cost Type" = lEV."FTT-CST Cost Type"::NRC THEN
                        lNRCYRC += lEV."Line Amount Total";
            Until lEv.Next = 0;
            Exit(lNrcYrc);
        end;
    End;

    Local Procedure GetSOLine2(pSH: Record "Sales Header"; pint: integer): Decimal
    var
        lSL: Record "Sales Line";
        lYRC: decimal;
        lSH: Record "Sales Header";
    Begin
        lYRC := 0;
        Clear(lSL);
        lSL.SetRange("Document Type", pSH."Document Type");
        lSL.SetRange("Document No.", pSH."No.");
        lSL.SetRange("FTT-CST Optional", lSL."FTT-CST Optional"::No);
        if lSL.FindSet() then BEGIN
            repeat
                IF pInt = 1 THEN BEGIN
                    //YRC
                    IF lSL."FTT-CST Cost Type" <> lSL."FTT-CST Cost Type"::NRC THEN
                        lYRC += lSL."Line Amount";
                END ELSE
                    //NRC
                    IF lSL."FTT-CST Cost Type" = lSL."FTT-CST Cost Type"::NRC THEN
                        lYRC += lSL."Line Amount";
            until lSL.next = 0;
        END;
        EXIT(lYRC);
    End;

    Local Procedure GetNewProjectStage(pSQ: Record "Sales Header"; pInt: integer): Text[100]
    var
        lOpp: Record Opportunity;
        loppE: Record "Opportunity Entry";
        lSH: Record "Sales Header";
        lSCS: Record "Sales Cycle Stage";
        lSC: Record "Sales Cycle";
        lDes: Text[100];
    Begin
        lDes := '';
        IF lOpp.GET(pSQ."Opportunity No.") THEN begin
            loppE.SETRANGE("Opportunity No.", lOpp."No.");
            lOppE.SETFILTER(Active, '%1', TRUE);
            IF loppE.Findfirst then
                lDes := lOppe."Sales Cycle Stage Description";

        end else begin
            IF lSC.GET('AGRMT') THEN
                IF lSCS.GET(lSC.Code, 8) then
                    lDes := lSCS.Description;
        end;
        Exit(ldes);
    End;

    Procedure GetConnectivity(pSH: Record "Sales Header")
    var
        lSL: Record "Sales Line";
        lDimSetEn: Record "Dimension Set Entry";
        lDim: Record Dimension;
        lDimval: Record "Dimension Value";
        lCon: integer;
        lTempEnt: Record "Entry Summary" Temporary;
        lAmt: decimal;
        lOut: Boolean;
    Begin

        IF lTempEnt.IsTemporary THEN
            lTempEnt.Deleteall;

        Clear(lSL);
        lSL.SetRange("Document Type", pSH."Document Type");
        lSL.SetRange("Document No.", pSH."No.");
        lSL.SetRange("FTT-CST Optional", lSL."FTT-CST Optional"::No);
        lSL.Setfilter(lSL."FTT-CST Cost Type", '<>%1', lSL."FTT-CST Cost Type"::NRC);
        IF lSL.FINDSET THEN begin
            repeat
                lDimSetEn.RESET;
                lDimSetEn.SETFILTER("Dimension Code", '%1', '*PRODUCT CAT*');
                lDimSetEn.SETFILTER("Dimension Set ID", '%1', lSL."Dimension Set ID");
                IF lDimSetEn.FindFirst() THEN begin
                    Clear(lDimval);
                    lDimVal.SetRange("Dimension Code", lDimSetEn."Dimension Code");
                    lDimval.SetFilter(Blocked, '%1', FALSE);
                    lDimVal.SetFilter("Dimension Value ID", '%1', lDimSetEn."Dimension Value ID");
                    IF lDimval.FINDFIRST THEN begin
                        Case lDimval."Product Category" of
                            lDimval."Product Category"::Connectivity:
                                Conn += lSl."Line Amount" - lSL."Inv. Discount Amount";
                            lDimval."Product Category"::Distibution:
                                Distr += lSl."Line Amount" - lSL."Inv. Discount Amount";
                            lDimval."Product Category"::OtherYRC:
                                OtherYrc += lSl."Line Amount" - lSL."Inv. Discount Amount";
                            lDimval."Product Category"::RiskOthers:
                                RiskOth += lSl."Line Amount" - lSL."Inv. Discount Amount";
                        End;
                    end;
                end;
            until lSL.next = 0;
        end;
    End;

    Procedure GetConnectivity2(pSH: Record "Sales Header")
    var
        lSL: Record "Sales Line";
        lDimSetEn: Record "Dimension Set Entry";
        lDim: Record Dimension;
        lDimval: Record "Dimension Value";
        lCon: integer;
        lTempEnt: Record "Entry Summary" Temporary;
        lAmt: decimal;
        lOut: Boolean;
    Begin

        IF lTempEnt.IsTemporary THEN
            lTempEnt.Deleteall;

        Clear(lSL);
        lSL.SetRange("Document Type", pSH."Document Type");
        lSL.SetRange("Document No.", pSH."No.");
        lSL.SetRange("FTT-CST Optional", lSL."FTT-CST Optional"::No);
        lSL.Setfilter(lSL."FTT-CST Cost Type", '<>%1', lSL."FTT-CST Cost Type"::NRC);
        IF lSL.FINDSET THEN begin
            repeat
                lDimSetEn.RESET;
                lDimSetEn.SETFILTER("Dimension Code", '%1', '*PRODUCT CAT*');
                lDimSetEn.SETFILTER("Dimension Set ID", '%1', lSL."Dimension Set ID");
                IF lDimSetEn.FindFirst() THEN begin
                    Clear(lDimval);
                    lDimVal.SetRange("Dimension Code", lDimSetEn."Dimension Code");
                    lDimval.SetFilter(Blocked, '%1', FALSE);
                    lDimVal.SetFilter("Dimension Value ID", '%1', lDimSetEn."Dimension Value ID");
                    IF lDimval.FINDFIRST THEN begin
                        Case lDimval."Product Category" of
                            lDimval."Product Category"::Connectivity:
                                Conn2 += lSl."Line Amount" - lSL."Inv. Discount Amount";
                            lDimval."Product Category"::Distibution:
                                Distr2 += lSl."Line Amount" - lSL."Inv. Discount Amount";
                            lDimval."Product Category"::OtherYRC:
                                OtherYrc2 += lSl."Line Amount" - lSL."Inv. Discount Amount";
                            lDimval."Product Category"::RiskOthers:
                                RiskOth2 += lSl."Line Amount" - lSL."Inv. Discount Amount";
                        End;
                    end;
                end;
            until lSL.next = 0;
        end;
    End;

    Procedure GetTotals()
    var
        lRevRep, lRevRep2 : Record "Revenue Report";
        lTot: Decimal;
    Begin
        Clear(lRevRep);
        lRevRep.SETRANGE(Type, lRevRep.Type::Total);
        IF lRevRep.FindSet() THEN begin
            repeat
                Clear(lRevRep2);
                lRevRep2.RESET;
                lRevRep2.SETFILTER(Type, '%1|%2|%3', lRevRep2.Type::Hosted, lRevRep2.Type::NonHosted, lRevRep2.Type::Unknown);
                IF lRevRep."Line Type" = lRevRep."Line Type"::"Over 50 %" then BEGIN
                    lRevRep2.SetRange("Line Type", lRevRep2."Line Type"::"Over 50 %")
                END ELSE BEGIN
                    lRevRep2.SetRange("Line Type", lRevRep2."Line Type"::"Over 85 %");
                END;
                IF lRevRep2.FINDSET THEN begin
                    lRevRep2.CalcSums("ARR - Previous Contracts");
                    lRevRep."ARR - Previous Contracts" := lRevRep2."ARR - Previous Contracts";
                    lRevRep2.CalcSums("ARR - Additional Products");
                    lRevRep."ARR - Additional Products" := lRevRep2."ARR - Additional Products";
                    lRevRep2.CalcSums("ARR Contract in Progress");
                    lRevRep."ARR Contract in Progress" := lRevRep2."ARR Contract in Progress";
                    lRevRep2.CalcSums("NRC Contract in Progress");
                    lRevRep."NRC Contract in Progress" := lRevRep2."NRC Contract in Progress";
                    lRevRep2.CalcSums("ARR Total Revenue");
                    lRevRep."ARR Total Revenue" := lRevRep2."ARR Total Revenue";
                    lRevRep2.CalcSums("NRC Total Revenue");
                    lRevRep."NRC Total Revenue" := lRevRep2."NRC Total Revenue";
                    lRevRep2.CalcSums("Connectivity");
                    lRevRep."Connectivity" := lRevRep2."Connectivity";
                    lRevRep2.CalcSums("Distribution");
                    lRevRep."Distribution" := lRevRep2."Distribution";
                    lRevRep2.CalcSums("Risk and Others");
                    lRevRep."Risk and Others" := lRevRep2."Risk and Others";
                    lRevRep2.CalcSums("Other YRC");
                    lRevRep."Other YRC" := lRevRep2."Other YRC";
                    lRevRep.MODIFY;
                end;
            until lRevRep.Next = 0;
        end;
    End;
    /////////////////////////For 85 ARR NRC Contract in Progress %/////////////////////////
    Procedure GETSOPrimaryHosted85percentPrimRen2();
    var
        lSH, lSH2, lSH3, lSH4 : Record "Sales Header";
        lSL: Record "Sales Line";
        lRevRep, lRevRep2 : Record "Revenue Report";
        lTot, lTot2, lEVtot, lEVTot2, lNRC, lYRC : decimal;
        lType1, lType2, lType3, lWithSQ : Boolean;
        i: Integer;
        Opp: Record Opportunity;
        OppEnt: Record "Opportunity Entry";
        EstVal: Record "FTT-CST Estimated Value Mod";
        lDes: Text[100];
        lCurEx: Record "Currency Exchange Rate";
        lCont: Record Contact;
        lCurCode, lOppNo, lOppNo2 : Code[20];
        lDiscVal: decimal;
        lDocNo: Code[250];
        HasOpp: Boolean;
    Begin
        Clear(lRevRep);
        lRevRep.SetRange("Line Type", lRevRep."Line Type"::"Over 85 %");
        lRevRep.SetFilter("Salesperson Code", '<>%1', '');
        lRevRep.Setfilter("Customer/Prospect", '<>%1', '');
        IF lRevRep.FINDSET THEN
            REPEAT
                lNRC := 0;
                lYRC := 0;
                lTot := 0;
                lTot2 := 0;
                lType1 := False;
                lType2 := False;
                lType3 := False;
                lWithSQ := False;
                HasOpp := False;
                Conn := 0;
                Distr := 0;
                RiskOth := 0;
                OtherYrc := 0;
                Conn3 := 0;
                Distr3 := 0;
                RiskOth3 := 0;
                OtherYrc3 := 0;
                lDocNo := '';
                Clear(lSH);
                Clear(lSH2);
                Clear(lSH3);

                Clear(Opp);
                Clear(OppEnt);
                Clear(EstVal);
                Clear(i);
                lEVtot := 0;
                lEVtot2 := 0;
                Opp.SETRANGE("Contact Name", lRevRep."Customer/Prospect");
                Opp.SetFilter("Salesperson Code", '%1', lRevRep."Salesperson Code");
                IF Opp.FINDSET THEN begin
                    REPEAT
                        IF NOT HasOpp then
                            HasOpp := FindSalesOrder(Opp);
                        lDocNo := lDocNo + Opp."No." + '|';
                        IF lCont.Get(Opp."Contact No.") then
                            lCurCode := lCont."Currency Code";
                        OppEnt.SetRange("Opportunity No.", Opp."No.");
                        OppEnt.Setfilter(Active, '%1', TRUE);
                        IF (OppEnt.FINDFIRST) AND ((OppEnt."Probability %" >= 85)) THEN begin
                            lSH2.SetRange("Document Type", lSH2."Document Type"::Quote);
                            lSH2.SETFILTER("Opportunity No.", '%1', OppEnt."Opportunity No.");
                            lSH2.SETFILTER("FTT-CST Final Quote", '%1', True);
                            IF NOT lSH2.FINDFIRST THEN begin
                                EstVal.SetRange("Linked No.", OppEnt."Opportunity No.");
                                EstVal.Setfilter("Linked Source Table ID", '%1', DATABASE::"Opportunity");
                                IF EstVal.FINDSET then begin
                                    FOR i := 1 to 2 Do BEGIN
                                        IF i = 1 then
                                            lEVtot += GetESTValCostType(EstVal, i)
                                        Else
                                            lEVtot2 += GetESTValCostType(EstVal, i);
                                    END;
                                END;
                            end ELSE
                                lWithSQ := True;
                        end;
                    UNTIL (Opp.Next = 0) OR (lWithSQ);
                    lDocNo := DELCHR(lDocNo, '>', '|');
                    lYRC := lEVtot;
                    lNRC := lEVTot2;
                end;

                IF lWithSQ THEN BEGIN
                    lDocNo := '';
                    lSH.SetCurrentKey("Document Type", "No.");
                    lSH.SETRANGE("Document Type", lSH."Document Type"::Quote);
                    lSH.SetRange("Salesperson Code", lRevRep."Salesperson Code");
                    lSH.Setfilter("Sell-to Customer Name", '%1', lRevRep."Customer/Prospect");
                    lSH.SETFILTER("FTT-CST Final Quote", '%1', TRUE);
                    IF lSH.FINDSET THEN begin
                        lCurCode := lSH."Currency Code";
                        lDes := GetNewProjectStage(lSH, 0);
                        Clear(i);
                        REPEAT
                            lDocNo := lDocNo + lSH."No." + '|';
                            GetConnectivity(lSH);
                            FOR i := 1 to 2 DO BEGIN
                                IF i = 1 THEN
                                    lTot := (lTot + GetSOLine2(lSH, i))
                                ELSE
                                    ltot2 := (lTot2 + GetSOLine2(lSH, i));
                            END;
                            lTot := lTot - lSH."Invoice Discount Value";
                        //lTot2 := lTot2 - lSH."Invoice Discount Value";
                        Until lSH.NEXT = 0;
                        lDocNo := DELCHR(lDocNo, '>', '|');
                    end;
                    lYRC := lTot;
                    lNRC := lTot2;
                END;

                Clear(lRevRep2);
                IF lRevRep2.GET(lRevRep.Type, lRevRep."Salesperson Code", lRevRep."Line Type"::"Over 85 %", lRevRep."Customer/Prospect") THEN BEGIN
                    IF (HasOpp) THEN
                        lRevRep2.VALIDATE("ARR Contract in Progress", 0)
                    else
                        lRevRep2.VALIDATE("ARR Contract in Progress", (lYRC * GetConvertion(lCurCode)));
                    lRevRep2.VALIDATE("NRC Contract in Progress", (lNRC * GetConvertion(lCurCode)));
                    lRevRep2."New Proj. Stage" := lDes;
                    lRevRep2."DocNo.3" := lDocNo;
                    lRevRep2."DocNo.4" := lDocNo;
                    lRevRep2.DocType3 := lRevRep2.DocType3::Quote;
                    lRevRep2.DocType4 := lRevRep2.DocType3::Quote;
                    Conn3 := Conn * GetConvertion(lCurCode);
                    Distr3 := Distr * GetConvertion(lCurCode);
                    RiskOth3 := RiskOth * GetConvertion(lCurCode);
                    OtherYrc3 := otherYrc * GetConvertion(lCurCode);
                    lRevRep2.Validate(Connectivity, (lRevRep2.Connectivity + Conn3));
                    lRevRep2.Validate(Distribution, (lRevRep2.Distribution + Distr3));
                    lRevRep2.validate("Risk and Others", (lRevRep2."Risk and Others" + RiskOth3));
                    lRevRep2.Validate("Other YRC", (lRevRep2."Other YRC" + otherYrc3));
                    lRevRep2.MODIFY;
                END;
            Until lRevRep.Next = 0;
    End;

    Local Procedure FindSalesOrder(pOpp: Record Opportunity): Boolean
    var
        lSH: Record "Sales Header";
    Begin
        Clear(lSH);
        lSH.SetRange("Document Type", lSH."Document Type"::Order);
        lSH.SETRANGE("Opportunity No.", pOpp."No.");
        IF lSH.FINDFIRST THEN
            Exit(true);
        Exit(False);
    End;

    var
        Conn, Distr, RiskOth, OtherYrc, Conn2, Distr2, RiskOth2, OtherYrc2, Conn3, Distr3, RiskOth3, OtherYrc3 : Decimal;
        gTotal: array[10] of decimal;
}
