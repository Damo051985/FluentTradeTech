codeunit 60008 "FTT-CST CalculateRedundancy"
{
    procedure CalculateRedundancy(DocumentType: Enum "Sales Document Type"; DocumentNo: Code[20])
    var
        Item: Record Item;
        ItemCategory: Record "Item Category";
        SalesReceivablesSetup: Record "Sales & Receivables Setup";
        ItemNo: Code[20];
        UnitPrice: Decimal;
    begin
        SalesReceivablesSetup.Get();
        if SalesReceivablesSetup."FTT-CST Redundancy Category" = '' then
            Error(RedundancyCategoryExistsErr, SalesReceivablesSetup.FieldCaption("FTT-CST Redundancy Category"));

        ItemCategory.SetRange("FTT-CST Redundancy Base Item", true);
        if ItemCategory.IsEmpty() then
            Error(RedundancyBaseItemTrueNotExistsErr, ItemCategory.FieldCaption("FTT-CST Redundancy Base Item"));

        ItemNo := ItemListLookUp(SalesReceivablesSetup."FTT-CST Redundancy Category");
        if ItemNo = '' then
            exit;

        Item.Get(ItemNo);
        UnitPrice := CalculateUnitPrice(DocumentType, DocumentNo, Item."FTT-CST Redundancy PriceCalc %", ItemNo);
        CreateDocumentLine(DocumentType, DocumentNo, ItemNo, UnitPrice, Item."FTT-CST Cost Type"); //NRD
    end;

    procedure CalculateDR(DocumentType: Enum "Sales Document Type"; DocumentNo: Code[20])
    var
        Item: Record Item;
        ItemCategory: Record "Item Category";
        SalesReceivablesSetup: Record "Sales & Receivables Setup";
        ItemNo: Code[20];
        UnitPrice: Decimal;
    begin
        SalesReceivablesSetup.Get();
        if SalesReceivablesSetup."FTT-CST DR Category" = '' then
            Error(RedundancyCategoryExistsErr, SalesReceivablesSetup.FieldCaption("FTT-CST DR Category"));

        ItemCategory.SetRange("FTT-CST DR Base Item", true);
        if ItemCategory.IsEmpty() then
            Error(RedundancyBaseItemTrueNotExistsErr, ItemCategory.FieldCaption("FTT-CST DR Base Item"));

        ItemNo := ItemListLookUp(SalesReceivablesSetup."FTT-CST DR Category");
        if ItemNo = '' then
            exit;

        Item.Get(ItemNo);
        UnitPrice := CalculateUnitPrice(DocumentType, DocumentNo, Item."FTT-CST Redundancy PriceCalc %", ItemNo);
        CreateDocumentLine(DocumentType, DocumentNo, ItemNo, UnitPrice, Item."FTT-CST Cost Type"); //NRD
    end;

    procedure CalculateInt(DocumentType: Enum "Sales Document Type"; DocumentNo: Code[20])
    var
        Item: Record Item;
        ItemCategory: Record "Item Category";
        SalesReceivablesSetup: Record "Sales & Receivables Setup";
        ItemNo: Code[20];
        UnitPrice: Decimal;
    begin
        SalesReceivablesSetup.Get();
        if SalesReceivablesSetup."FTT-CST Integration Category" = '' then
            Error(RedundancyCategoryExistsErr, SalesReceivablesSetup.FieldCaption("FTT-CST Integration Category"));

        ItemCategory.SetRange("FTT-CST  Integration Base Item", true);
        if ItemCategory.IsEmpty() then
            Error(RedundancyBaseItemTrueNotExistsErr, ItemCategory.FieldCaption("FTT-CST  Integration Base Item"));

        ItemNo := ItemListLookUp(SalesReceivablesSetup."FTT-CST Integration Category");
        if ItemNo = '' then
            exit;

        Item.Get(ItemNo);
        UnitPrice := CalculateUnitPrice(DocumentType, DocumentNo, Item."FTT-CST Redundancy PriceCalc %", ItemNo);
        CreateDocumentLine(DocumentType, DocumentNo, ItemNo, UnitPrice, Item."FTT-CST Cost Type"); //NRD
    end;

    local procedure CreateDocumentLine(DocumentType: Enum "Sales Document Type"; DocumentNo: Code[20]; ItemNo: Code[20]; UnitPrice: Decimal; CostType2: Enum "FTT-CST Cost Type")
    var
        SalesLine: Record "Sales Line";
        SalesLineLast2: Record "Sales Line";
        Item_l: Record Item;
    begin
        SalesLine.Init();
        SalesLine."Document Type" := DocumentType;
        SalesLine."Document No." := DocumentNo;
        SalesLine."Line No." := GetLineNo(DocumentType, DocumentNo, SalesLineLast2);
        SalesLine.Validate(Type, "Sales Line Type"::Item);
        SalesLine.Validate("No.", ItemNo);
        SalesLine.Validate("Unit Price", UnitPrice);
        SalesLine.Validate(Quantity, 1);
        //NRD
        if Item_l.Get(ItemNo) then
            SalesLine."FTT-CST Parent Item Cat. Code" := Item_l."Item Category Code";

        //NRD
        SalesLine."FTT-CST Location Code" := SalesLineLast2."FTT-CST Location Code";
        SalesLine.ValidateShortcutDimCode(3, SalesLineLast2."FTT-CST Location Code");
        SalesLine."FTT-CST Sublocation" := SalesLineLast2."FTT-CST Sublocation";
        SalesLine."FTT-CST Component Option" := SalesLineLast2."FTT-CST Component Option";
        SalesLine."FTT-CST Cost Type" := CostType2;
        SalesLine."FTT-CST Agreement Date From" := SalesLineLast2."FTT-CST Agreement Date From";
        SalesLine."FTT-CST Agreement Date To" := SalesLineLast2."FTT-CST Agreement Date To";
        //NRD
        SalesLine.Insert(true);

    end;

    local procedure CalculateUnitPrice(DocumentType: Enum "Sales Document Type"; DocumentNo: Code[20]; RedundancyPrice: Decimal; ItemNo: code[20]): Decimal
    var
        Item: Record Item;
        pItem: Record Item;
        ItemCategoty: Record "Item Category";
        pItemCategoty: Record "Item Category";
        SalesLine: Record "Sales Line";
        TotalAmount: Decimal;
        SalesReceivables: Record "Sales & Receivables Setup";
    begin
        SalesReceivables.GET();
        SalesLine.SetRange(Type, "Sales Line Type"::Item);
        SalesLine.SetRange("Document Type", DocumentType);
        SalesLine.SetRange("Document No.", DocumentNo);
        if not SalesLine.FindSet() then
            exit(0);
        if not pItem.GET(ItemNo) then
            exit(0);
        pItemCategoty.get(pItem."Item Category Code");

        repeat
            Item.Get(SalesLine."No.");
            if Item."Item Category Code" <> '' then begin
                ItemCategoty.Get(Item."Item Category Code");

                if (pItem."FTT-CST Redundancy PriceCalc %" <> 0) and (pItemCategoty.code = SalesReceivables."FTT-CST Redundancy Category") then
                    if (ItemCategoty."FTT-CST Redundancy Base Item") then
                        TotalAmount += SalesLine."Line Amount";

                if (pItem."FTT-CST Redundancy PriceCalc %" <> 0) and (pItemCategoty.code = SalesReceivables."FTT-CST DR Category") then
                    if ItemCategoty."FTT-CST DR Base Item" then
                        TotalAmount += SalesLine."Line Amount";

                if (pItem."FTT-CST Integr PriceCalc %" <> 0) and (pItemCategoty.code = SalesReceivables."FTT-CST Integration Category") then begin
                    RedundancyPrice := pItem."FTT-CST Integr PriceCalc %";
                    if ItemCategoty."FTT-CST  Integration Base Item" then
                        TotalAmount += SalesLine."Line Amount";
                end;

            end;
        until SalesLine.Next() = 0;

        exit(TotalAmount * (RedundancyPrice / 100));
    end;

    local procedure GetLineNo(DocumentType: Enum "Sales Document Type"; DocumentNo: Code[20]; var SalesLineLast: record "Sales Line"): Integer
    var
        SalesLine: Record "Sales Line";
    begin
        SalesLine.SetRange("Document Type", DocumentType);
        SalesLine.SetRange("Document No.", DocumentNo);
        if SalesLine.FindLast() then begin
            SalesLineLast := SalesLine;
            exit(SalesLine."Line No." + 10000);
        end;
        exit(10000);
    end;

    procedure ItemListLookUp(RedundancyCategory: Code[20]): Code[20]
    var
        Item: Record Item;
        ItemModify: Record Item;
        ItemList: Page "Item List";
        ItemCategory: record "Item Category";
        PageDialog: page "FTT-CST Dialog";
        SalesReceivables: Record "Sales & Receivables Setup";
        PriceCalcPerc: Decimal;
        DefPriceCalcPerc: Decimal;
    begin
        ItemCategory.Get(RedundancyCategory);
        SalesReceivables.Get();
        Item.SetRange("Item Category Code", RedundancyCategory);
        ItemModify.SetRange("Item Category Code", RedundancyCategory);

        if ItemModify.FindSet() then
            repeat
                if ItemModify."FTT-CST Red. Backup PCalc %" <> 0 then begin
                    ItemModify."FTT-CST Redundancy PriceCalc %" := ItemModify."FTT-CST Red. Backup PCalc %";
                    ItemModify.Modify();
                end;
                if ItemModify."FTT-CST Backup Integr. Calc %" <> 0 then begin
                    ItemModify."FTT-CST Integr PriceCalc %" := ItemModify."FTT-CST Backup Integr. Calc %";
                    ItemModify.Modify();
                end;
            until ItemModify.next = 0;
        Commit();


        if (SalesReceivables."FTT-CST DR Category" = RedundancyCategory) or (SalesReceivables."FTT-CST Redundancy Category" = RedundancyCategory) then
            ItemList.SetVisibility(true, false) else
            ItemList.SetVisibility(false, true);

        ItemList.LookupMode(true);
        ItemList.SetTableView(Item);

        if ItemList.RunModal = Action::LookupOK then begin
            ItemList.GetRecord(Item);

            if ItemCategory."FTT-CST DR Base Item" or ItemCategory."FTT-CST Redundancy Base Item" then
                Item.TestField("FTT-CST Redundancy PriceCalc %");
            if ItemCategory.Code = SalesReceivables."FTT-CST Integration Category" then begin
                ItemModify.Get(Item."No.");
                PageDialog.SetValue(ItemModify."FTT-CST Integr PriceCalc %");
                if PageDialog.RunModal() = Action::OK then;
                PageDialog.GetValue(PriceCalcPerc);
                if DefPriceCalcPerc <> PriceCalcPerc then begin
                    ItemModify."FTT-CST Integr PriceCalc %" := PriceCalcPerc;
                    ItemModify.Modify();
                end;
            end else begin
                ItemModify.get(Item."No.");
                PageDialog.SetValue2(item."FTT-CST Redundancy PriceCalc %", Item."No.");
                if PageDialog.RunModal() = Action::OK then;
                PageDialog.GetValue(PriceCalcPerc);
                if DefPriceCalcPerc <> PriceCalcPerc then begin
                    ItemModify."FTT-CST Redundancy PriceCalc %" := PriceCalcPerc;
                    ItemModify.Modify();
                end;
            end;

            exit(Item."No.");
        end;
        exit('');
    end;

    var
        RedundancyBaseItemTrueNotExistsErr: Label 'There are no item categories specified for the %1. Specify the %1 checkbox on the Item Categories page for at least one category and try again.';
        RedundancyCategoryExistsErr: Label 'The item category is not specified on the Sales & Receivables Setup page in the %1 field. Please fill out this field and try again.';
}
