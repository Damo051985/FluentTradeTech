codeunit 60003 "FTT-CST ReportMng"
{
    procedure ReportPricingIndicationTemplateSaveToWord(PriceListHeader: Record "Price List Header")
    var
        PricingIndTemplate: Report "FTT-CST Pricing Ind. Template";
        FileManagement: Codeunit "File Management";
        TempBlob: Codeunit "Temp Blob";
        OutStr: OutStream;
        XmlParameters: Text;
    begin
        XmlParameters := Report.RunRequestPage(Report::"FTT-CST Pricing Ind. Template",
            StrSubstNo(ReportPricingIndicationParametrsLbl,
                PriceListHeader.Code,
                Format(WorkDate(), 0, '<Year4>-<Month,2>-<Day,2>'),
                PriceListHeader.Description)
            );
        if XmlParameters = '' then
            exit;

        TempBlob.CreateOutStream(OutStr);
        PricingIndTemplate.SaveAs(XmlParameters, ReportFormat::Word, OutStr);
        FileManagement.BLOBExport(TempBlob, ReportPricingIndicationNameLbl, true);
    end;

    procedure ReportPricingProposalTemplateSaveToWord(SalesHeader: Record "Sales Header")
    var
        SalesReceivablesSetup: Record "Sales & Receivables Setup";
        PricingPropTemplate: Report "FTT-CST Pricing Prop. Template";
        FileManagement: Codeunit "File Management";
        TempBlob: Codeunit "Temp Blob";
        WorkDescriptionInStream: InStream;
        OutStr: OutStream;
        WorkDescriptionLine: Text;
        XmlParameters: Text;
    begin
        SalesReceivablesSetup.Get();
        SalesReceivablesSetup.TestField("FTT-CST Item Region Dim. Code");

        SalesHeader.CalcFields("Work Description");
        SalesHeader."Work Description".CreateInStream(WorkDescriptionInStream, TextEncoding::UTF8);
        WorkDescriptionInStream.Read(WorkDescriptionLine);
        XmlParameters := Report.RunRequestPage(Report::"FTT-CST Pricing Prop. Template",
            StrSubstNo(ReportPricingProposalParametrsLbl,
                SalesHeader."Document Type".AsInteger(),
                SalesHeader."No.",
                Format(WorkDate(), 0, '<Year4>-<Month,2>-<Day,2>'),
                WorkDescriptionLine)
            );
        if XmlParameters = '' then
            exit;

        TempBlob.CreateOutStream(OutStr);
        PricingPropTemplate.SaveAs(XmlParameters, ReportFormat::Word, OutStr);
        FileManagement.BLOBExport(TempBlob, ReportPricingProposalNameLbl, true);
    end;

    var
        ReportPricingIndicationNameLbl: Label 'Pricing Indication Template.docx';
        ReportPricingIndicationParametrsLbl: Label '<?xml version="1.0" standalone="yes"?><ReportParameters name="FTTCST Pricing Ind. Template" id="60000"><Options><Field name="SalesPriceListCode">%1</Field><Field name="PricingIndicationDate">%2</Field><Field name="ProjectDescription">%3</Field></Options><DataItems><DataItem name="PriceListHeader">VERSION(1) SORTING(Field1)</DataItem><DataItem name="PriceListLine">VERSION(1) SORTING(Field1,Field2)</DataItem></DataItems></ReportParameters>';
        ReportPricingProposalNameLbl: Label 'Pricing Proposal Template.docx';
        ReportPricingProposalParametrsLbl: Label '<?xml version="1.0" standalone="yes"?><ReportParameters name="FTT-CST Pricing Prop. Template" id="60001"><Options><Field name="DocumentType">%1</Field><Field name="DocumentNo">%2</Field><Field name="PricingPropositionDate">%3</Field><Field name="ShowVAT"></Field><Field name="ProjectDescription">%4</Field></Options></ReportParameters>';
}