codeunit 50001 "Fluent Custom Subscriber"
{
    Permissions = tabledata "Email Outbox" = r,
                  tabledata "Sales Invoice Line" = rm,
                  tabledata "Cust. Ledger Entry" = rm,
                  tabledata "Sales Cr.Memo Line" = rm;

    trigger OnRun()
    begin

    end;
    //Add new selection for Signature in ENUM(Report Selection Usage Sales)
    [EventSubscriber(ObjectType::Page, Page::"Report Selection - Sales", OnSetUsageFilterOnAfterSetFiltersByReportUsage, '', false, false)]
    local procedure "Report Selection - Sales_OnSetUsageFilterOnAfterSetFiltersByReportUsage"(var Rec: Record "Report Selections"; ReportUsage2: Option)
    begin

        case ReportUsage2 of
            Enum::"Report Selection Usage Sales"::Signature:
                Rec.SetRange(Usage, Enum::"Report Selection Usage"::Signature);
        end;
    end;

    procedure ReadInternalFieldInEmailOutbox(id: BigInteger): Guid
    var
        RecRef: RecordRef;
        FldRef: FieldRef;
    begin
        RecRef.Open(Database::"Email Outbox");
        FldRef := RecRef.Field(1); // Field Id 
        FldRef.SetRange(id);
        FldRef := RecRef.Field(3);//Field Message Id
        if RecRef.FindFirst() then
            exit(FldRef.Value);
    end;


    //Get the Word Custom layout from Report Selection Sales to be used in the email body as signature
    procedure GenerateSignatureEmailBodyReport(UserSetup2: Record "User setup") BodyText: Text
    var
        ReportLayoutSelection: Record "Report Layout Selection";
        TempBlob: Codeunit "Temp Blob";
        UserSetup2RecordRef: RecordRef;
        ReportInStream: InStream;
        ReportOutStream: OutStream;
        LayoutCode: Code[20];
        ReportId: Integer;
    begin
        TempBlob.CreateOutStream(ReportOutStream);
        UserSetup2RecordRef := SetUserSetup2RecordRef(UserSetup2);
        ReportLayoutSelection := GetUserSetupReportandLayoutCode(ReportId, LayoutCode, false);

        ReportLayoutSelection.SetTempLayoutSelected(LayoutCode);
        Report.SaveAs(ReportId, '', ReportFormat::Html, ReportOutStream, UserSetup2RecordRef);
        ReportLayoutSelection.SetTempLayoutSelected('');

        TempBlob.CreateInStream(ReportInStream);
        ReportInStream.ReadText(BodyText);

    end;

    //Make a record ref as return variable
    procedure SetUserSetup2RecordRef(UserSetup2: Record "User Setup") ReturnRecordRef: RecordRef
    var
        rec_UserSetup2: Record "User setup";
    begin
        if rec_UserSetup2.Get(UserSetup2."User ID") then
            ReturnRecordRef.GetTable(rec_UserSetup2);
    end;

    //Get Report ID and Layout from Report Selection Sales
    procedure GetUserSetupReportandLayoutCode(var ReportId: Integer; var LayoutCode: Code[20]; IsAttachment: Boolean) ReportLayoutSelection: Record "Report Layout Selection"
    var
        Reportselections: Record "Report Selections";
    begin
        Reportselections.Reset();
        Reportselections.SetRange(Usage, Reportselections.Usage::Signature);
        if IsAttachment then
            Reportselections.SetRange("Use for Email Attachment", true)
        else
            Reportselections.SetRange("Use for Email Body", true);
        if Reportselections.Findfirst() then begin
            LayoutCode := Reportselections."Email Body Layout Code";
            ReportId := Reportselections."Report ID";
            if ReportLayoutSelection.Get(ReportId, CompanyName) then;
        end;
    end;

    [EventSubscriber(ObjectType::Table, Database::"Transformation Rule", OnTransformation, '', false, false)]
    local procedure "Transformation Rule_OnTransformation"(TransformationCode: Code[20]; InputText: Text; var OutputText: Text)
    var
        decMultiplyby100: Decimal;
    begin
        if TransformationCode = 'MULTIPLYBY100' then begin
            if Evaluate(decMultiplyby100, InputText) then
                OutputText := Format(decMultiplyby100 * 100);
        end;

    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Email Address Lookup", 'OnGetSuggestedAddresses', '', false, false)]
    local procedure SuggestedAddressesFromContacts(TableId: Integer; SystemId: Guid; var Address: Record "Email Address Lookup")
    var
        Contact_Sub: Record Contact;
        Employee_Sub: Record Employee;
        CompanyNo: Code[20];
    begin
        case TableId of
            Database::Contact:
                begin
                    if not Contact_Sub.GetBySystemId(SystemId) then
                        exit;

                    if not InsertAddressFromBCLEEntity(Contact_Sub, Address) then
                        InsertAddressFromEmployeeLEEntity(Address);


                end;
            else
                exit;
        end;
    end;

    local procedure InsertAddressFromBCLEEntity(var pContactSub: Record Contact; var Address: Record "Email Address Lookup"): Boolean
    begin
        if ((pContactSub."E-Mail" <> '') and not Address.Get(pContactSub."E-Mail", pContactSub.Name, Enum::"Email Address Entity"::Contact)) then begin
            Address.Name := pContactSub.Name;
            Address."E-Mail Address" := pContactSub."E-Mail";
            Address."Source Table Number" := Database::Contact;
            Address."Source System Id" := pContactSub.SystemId;
            Address."Entity type" := Enum::"Email Address Entity"::Contact;
            Address.Insert();
            exit(true);
        end;

        exit(false);
    end;

    local procedure InsertAddressFromEmployeeLEEntity(var Address: Record "Email Address Lookup")
    var
        RecEmployee: Record Employee;
    begin
        RecEmployee.Reset();
        RecEmployee.SetFilter("E-Mail", '<>%1', '');
        if RecEmployee.FindSet() then
            repeat
                if not Address.Get(RecEmployee."E-Mail", RecEmployee."First Name", Enum::"Email Address Entity"::Employee) then begin
                    Address.Name := RecEmployee."First Name" + ' ' + RecEmployee."Last Name";
                    Address."E-Mail Address" := RecEmployee."E-Mail";
                    Address."Source Table Number" := Database::Employee;
                    Address."Source System Id" := RecEmployee.SystemId;
                    Address."Entity type" := Enum::"Email Address Entity"::Employee;
                    Address.Department := RecEmployee.Department;
                    Address.Insert();
                end;
            until RecEmployee.Next() = 0;

    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Document-Mailing", 'OnBeforeSendEmail', '', false, false)]
    local procedure DocumentMailing_OnBeforeSendEmail(var ReportUsage: Integer; var TempEmailItem: Record "Email Item"; var IsFromPostedDoc: Boolean; var PostedDocNo: Code[20])
    begin
        If IsFromPostedDoc And (ReportUsage = Enum::"Report Selection Usage"::"S.Quote".AsInteger()) then begin
            SendCRMTemplateAttachments(PostedDocNo, TempEmailItem);
        end;
    end;


    local procedure SendCRMTemplateAttachments(SalesQuoteNo: Code[20]; var TempEmailItem: Record "Email Item")
    var

        codGmailIntegSpread: Codeunit "GMAIL Integ.Spreadsheet";
        recSalesQuote: Record "Sales Header";
        recSalesQuote2: Record "Sales Header";
        FileName: text;
        InstreamGet: InStream;
        TenantMedia: Record "Tenant Media";
    begin
        if SalesQuoteNo = '' then
            exit;

        recSalesQuote2.Reset();
        recSalesQuote2.SetRange("No.", SalesQuoteNo);
        recSalesQuote2.SetRange("Document Type", recSalesQuote2."Document Type"::Quote);
        if recSalesQuote2.FindFirst() then begin
            if TenantMedia.Get(recSalesQuote2.SalesQuoteExtTemp.MediaId) then begin
                TenantMedia.CalcFields(Content);
                if TenantMedia.Content.HasValue then begin
                    FileName := Format('SQ-' + recSalesQuote2."No." + '_' + recSalesQuote2."Ship-to Name");
                    TenantMedia.Content.CreateInStream(InstreamGet);
                    TempEmailItem.AddAttachment(InstreamGet, Format(FileName + '.xlsx'));
                end;
            end;
        end;
    end;

    [EventSubscriber(ObjectType::Table, Database::"Sales Line", OnUpdateUnitPriceOnBeforeFindPrice, '', false, false)]
    local procedure "Sales Line_OnUpdateUnitPriceOnBeforeFindPrice"(SalesHeader: Record "Sales Header"; var SalesLine: Record "Sales Line"; CalledByFieldNo: Integer; CallingFieldNo: Integer; var IsHandled: Boolean; xSalesLine: Record "Sales Line")
    begin
        if SalesLine."FTT-CST Cost Type" = SalesLine."FTT-CST Cost Type"::MRC then
            SalesLine."Unit Price" := xSalesLine."Unit Price";
    end;


    [EventSubscriber(ObjectType::Table, Database::"Sales Line", OnUpdateUnitPriceByFieldOnBeforeValidateUnitPrice, '', false, false)]
    local procedure "Sales Line_OnUpdateUnitPriceByFieldOnBeforeValidateUnitPrice"(var SalesLine: Record "Sales Line"; xSalesLine: Record "Sales Line"; CalledByFieldNo: Integer; CurrFieldNo: Integer; var Handled: Boolean)
    begin

        if SalesLine."FTT-CST Cost Type" = SalesLine."FTT-CST Cost Type"::MRC then
            SalesLine."Unit Price" := xSalesLine."Unit Price";

    end;


    [EventSubscriber(ObjectType::Table, Database::"Sales Line", OnUpdateUnitPriceByFieldOnAfterFindPrice, '', false, false)]
    local procedure "Sales Line_OnUpdateUnitPriceByFieldOnAfterFindPrice"(SalesHeader: Record "Sales Header"; var SalesLine: Record "Sales Line"; CalledByFieldNo: Integer; CallingFieldNo: Integer)
    begin
        if SalesLine."Document Type" = SalesLine."Document Type"::Quote then begin

            if SalesLine."FTT-CST Cost Type" = SalesLine."FTT-CST Cost Type"::YRC then
                SalesLine.Validate("Unit Price", SalesLine."FTT-CST Unit Price")
            else if SalesLine."FTT-CST Parent Item Cat. Code" = 'HARDWARE' then begin
                SalesLine.Validate("Unit Price", SalesLine."FTT-CST Unit Price");
            end;

            if SalesLine."FTT-CST Cost Type" = SalesLine."FTT-CST Cost Type"::MRC then
                SalesLine.Validate("Unit Price", SalesLine."Unit Price");

        end else if SalesLine."Document Type" = SalesLine."Document Type"::Order then begin

            if SalesLine."FTT-CST Cost Type" = SalesLine."FTT-CST Cost Type"::YRC then
                SalesLine.Validate("Unit Price", SalesLine."FTT-CST Unit Price")
            else if SalesLine."FTT-CST Parent Item Cat. Code" = 'HARDWARE' then begin
                SalesLine.Validate("Unit Price", SalesLine."FTT-CST Unit Price");
            end;

            if SalesLine."FTT-CST Cost Type" = SalesLine."FTT-CST Cost Type"::MRC then
                SalesLine.Validate("Unit Price", SalesLine."Unit Price");
        end;
    end;

    [EventSubscriber(ObjectType::Page, Page::"Update Opportunity", OnUpdateEstimatedValuesOnBeforeModify, '', false, false)]
    local procedure "Update Opportunity_OnUpdateEstimatedValuesOnBeforeModify"(var OpportunityEntry: Record "Opportunity Entry"; SalesHeader: Record "Sales Header")
    var
        RecEstValueMod: Record "FTT-CST Estimated Value Mod";
    begin
        RecEstValueMod.Reset();
        RecEstValueMod.SetRange("Linked No.", OpportunityEntry."Opportunity No.");
        if RecEstValueMod.FindSet() then
            RecEstValueMod.CalcSums("Line Amount Total");

        OpportunityEntry."Estimated Value (LCY)" := RecEstValueMod."Line Amount Total";
    end;

    //COMMISSION ---------------------------------------------------------------

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Sales-Post", OnAfterPostSalesDoc, '', false, false)]
    local procedure "Sales-Post_OnAfterPostSalesDoc"(var SalesHeader: Record "Sales Header"; var GenJnlPostLine: Codeunit "Gen. Jnl.-Post Line"; SalesShptHdrNo: Code[20]; RetRcpHdrNo: Code[20]; SalesInvHdrNo: Code[20]; SalesCrMemoHdrNo: Code[20]; CommitIsSuppressed: Boolean; InvtPickPutaway: Boolean; var CustLedgerEntry: Record "Cust. Ledger Entry"; WhseShip: Boolean; WhseReceiv: Boolean; PreviewMode: Boolean)
    var
        SalesInvoiceLine: Record "Sales Invoice Line";
        LineCommBaseLCY: Decimal;
        LineCommBase: Decimal;
        LineAmount: Decimal;
        CommPercent: Decimal;
        Item: Record Item;
        FTTCSTSalespCommRate: Record "FTT-CST Salesp. Comm. Rate";
        SalesInvoiceHeader: Record "Sales Invoice Header";
        ItemCommisionValue: Integer;
        CommissionAgrmhdr: Record "FTT-CST Comm. Agrm. Header";
        CommissionAgrmLines: Record "FTT-CST Comm. Agrm. Lines";
        TotalLineComms: Decimal;
        TotalLineComms2: Decimal;
    begin

        if not SalesInvoiceHeader.get(SalesInvHdrNo) then
            exit;

        CommissionAgrmhdr.Reset();
        CommissionAgrmhdr.SetRange("Salesperson Type", CommissionAgrmhdr."Salesperson Type"::Salesperson);
        CommissionAgrmhdr.SetRange("Type No.", SalesInvoiceHeader."Salesperson Code");
        //CommissionAgrmhdr.SetRange("Agreement Period", SalesInvoiceHeader."FTT-CST Agr. Period Number");
        CommissionAgrmhdr.SetFilter("Agr. Ending Date", '>%1', SalesInvoiceHeader."Posting Date");
        CommissionAgrmhdr.SetRange(Status, CommissionAgrmhdr.Status::Activated);
        if CommissionAgrmhdr.FindFirst() then begin
            TotalLineComms := 0;
            SalesInvoiceLine.SetRange("Document No.", SalesInvoiceHeader."No.");
            SalesInvoiceLine.SetRange(Type, "Sales Line Type"::Item);

            if not SalesInvoiceLine.FindSet() then
                exit;
            repeat

                LineCommBaseLCY := 0;
                LineCommBase := 0;
                LineAmount := 0;
                Item.Get(SalesInvoiceLine."No.");
                if Item."FTT-CST Eligible" then begin

                    CommissionAgrmLines.Reset();
                    CommissionAgrmLines.SetRange("Agreement No.", CommissionAgrmhdr."Agreement No.");
                    CommissionAgrmLines.SetRange("Item Category Type", CommissionAgrmLines."Item Category Type"::"Parent Item Category");
                    CommissionAgrmLines.SetRange("Category No.", SalesInvoiceLine."FTT-CST Parent Item Cat. Code");
                    CommissionAgrmLines.SetRange("Agreement Period", SalesInvoiceLine."Agreement Period");
                    if CommissionAgrmLines.FindSet() then begin
                        CommPercent := CommissionAgrmLines."Commission %";
                        ItemCommisionValue := cduCommMgt.GetPercentFromEnum(Item);
                        // if Item."FTT-CST Coeffficient" then
                        //     LineAmount := SalesInvoiceLine.Amount / 2
                        // else
                        //     LineAmount := SalesInvoiceLine.Amount;
                        LineAmount := SalesInvoiceLine.Amount;
                        if SalesInvoiceHeader."Currency Code" = '' then begin
                            LineCommBaseLCY := LineAmount * (CommissionAgrmLines."Commission %" / 100) * (ItemCommisionValue / 100);
                            LineCommBase := LineAmount * (CommissionAgrmLines."Commission %" / 100) * (ItemCommisionValue / 100);
                        end else begin
                            LineCommBase := LineAmount * (CommissionAgrmLines."Commission %" / 100) * (ItemCommisionValue / 100);
                            LineCommBaseLCY := (LineAmount * (CommissionAgrmLines."Commission %" / 100) * (ItemCommisionValue / 100)) / SalesInvoiceHeader."Currency Factor";
                        end;
                        SalesInvoiceLine."FTT-CST Eligible" := true;
                        SalesInvoiceLine."Commission Base Amount" := Round(LineCommBase, 0.01, '=');
                        SalesInvoiceLine."Commission Base Amount (LCY)" := Round(LineCommBaseLCY, 0.01, '=');
                        SalesInvoiceLine."FTT-CST Salesp. Comm. Type" := Item."FTT-CST Salesp. Comm. Type";
                        SalesInvoiceLine."Commission Agreement No." := CommissionAgrmLines."Agreement No.";
                        SalesInvoiceLine."Commission Rate %" := CommPercent;
                        SalesInvoiceLine.Modify();
                        TotalLineComms += Round(LineCommBaseLCY, 0.01, '=');
                        TotalLineComms2 += Round(LineCommBase, 0.01, '=');
                    end;
                end;
            until SalesInvoiceLine.Next() = 0;
            Commit();


            cduCommMgt.InsertCommissionEntryperSalesPerson(CustLedgerEntry, CommPercent, '', TotalLineComms, CommissionAgrmhdr."Agreement No.", TotalLineComms2);

            //CustLedgerEntry.Modify();
        end;
    end;



    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Sales-Post", OnAfterPostSalesDoc, '', false, false)]
    local procedure "Sales-Post_OnAfterPostSalesDoc2"(var SalesHeader: Record "Sales Header"; var GenJnlPostLine: Codeunit "Gen. Jnl.-Post Line"; SalesShptHdrNo: Code[20]; RetRcpHdrNo: Code[20]; SalesInvHdrNo: Code[20]; SalesCrMemoHdrNo: Code[20]; CommitIsSuppressed: Boolean; InvtPickPutaway: Boolean; var CustLedgerEntry: Record "Cust. Ledger Entry"; WhseShip: Boolean; WhseReceiv: Boolean; PreviewMode: Boolean)
    var
        SalesCrMemoLine: Record "Sales Cr.Memo Line";
        LineCommBaseLCY: Decimal;
        LineCommBase: Decimal;
        Item: Record Item;
        FTTCSTSalespCommRate: Record "FTT-CST Salesp. Comm. Rate";
        SalesCrmMemoHeader: Record "Sales Cr.Memo Header";
        ItemCommisionValue: Integer;
        LineAmount: Decimal;
        CommPercent: Decimal;
        CommissionAgrmhdr: record "FTT-CST Comm. Agrm. Header";
        CommissionAgrmhLines: Record "FTT-CST Comm. Agrm. Lines";
        AgreementSetup: Record "FTT-CST Commission Agr. Setup";
        TotalLineComms: Decimal;
        TotalLineComms2: Decimal;
    begin

        if not AgreementSetup.Get() then
            exit;

        if AgreementSetup."Credit Memo Adjustment" then begin
            if not SalesCrmMemoHeader.get(SalesCrMemoHdrNo) then
                exit;

            CommissionAgrmhdr.Reset();
            CommissionAgrmhdr.SetRange("Salesperson Type", CommissionAgrmhdr."Salesperson Type"::Salesperson);
            CommissionAgrmhdr.SetRange("Type No.", SalesCrmMemoHeader."Salesperson Code");
            //CommissionAgrmhdr.SetRange("Agreement Period", SalesCrmMemoHeader."FTT-CST Agr. Period Number");
            CommissionAgrmhdr.SetFilter("Agr. Ending Date", '>%1', SalesCrmMemoHeader."Posting Date");
            CommissionAgrmhdr.SetRange(Status, CommissionAgrmhdr.Status::Activated);
            if CommissionAgrmhdr.FindFirst() then begin
                TotalLineComms := 0;
                SalesCrMemoLine.SetRange("Document No.", SalesCrmMemoHeader."No.");
                SalesCrMemoLine.SetRange(Type, "Sales Line Type"::Item);
                if not SalesCrMemoLine.FindSet() then
                    exit;
                repeat
                    LineCommBaseLCY := 0;
                    LineCommBase := 0;
                    Item.Get(SalesCrMemoLine."No.");
                    if Item."FTT-CST Eligible" then begin
                        CommissionAgrmhLines.Reset();
                        CommissionAgrmhLines.SetRange("Agreement No.", CommissionAgrmhdr."Agreement No.");
                        CommissionAgrmhLines.SetRange("Category No.", SalesCrMemoLine."FTT-CST Parent Item Cat. Code");
                        CommissionAgrmhLines.SetRange("Item Category Type", CommissionAgrmhLines."Item Category Type"::"Parent Item Category");
                        CommissionAgrmhLines.SetRange("Agreement Period", SalesCrMemoLine."Agreement Period");
                        if CommissionAgrmhLines.FindSet() then begin
                            CommPercent := CommissionAgrmhLines."Commission %";
                            ItemCommisionValue := cduCommMgt.GetPercentFromEnum(Item);
                            // if Item."FTT-CST Coeffficient" then
                            //     LineAmount := SalesCrMemoLine.Amount / 2
                            // else
                            //     LineAmount := SalesCrMemoLine.Amount;
                            LineAmount := SalesCrMemoLine.Amount;
                            if SalesCrmMemoHeader."Currency Code" = '' then begin
                                LineCommBaseLCY := LineAmount * (CommissionAgrmhLines."Commission %" / 100) * (ItemCommisionValue / 100) * (-1);
                                LineCommBase := LineAmount * (CommissionAgrmhLines."Commission %" / 100) * (ItemCommisionValue / 100) * (-1);
                            end else begin
                                LineCommBase := LineAmount * (CommissionAgrmhLines."Commission %" / 100) * (ItemCommisionValue / 100) * (-1);
                                LineCommBaseLCY := (LineAmount * (CommissionAgrmhLines."Commission %" / 100) * (ItemCommisionValue / 100)) / SalesCrmMemoHeader."Currency Factor" * (-1);
                            end;
                            SalesCrMemoLine."FTT-CST Eligible" := true;
                            SalesCrMemoLine."Commission Base Amount" := Round(LineCommBase, 0.01, '=');
                            SalesCrMemoLine."Commission Base Amount (LCY)" := Round(LineCommBaseLCY, 0.01, '=');
                            SalesCrMemoLine."FTT-CST Salesp. Comm. Type" := Item."FTT-CST Salesp. Comm. Type";
                            SalesCrMemoLine."Commission Agreement No." := CommissionAgrmhLines."Agreement No.";
                            SalesCrMemoLine."Commission Rate %" := CommPercent;
                            SalesCrMemoLine.Modify();
                            TotalLineComms += Round(LineCommBaseLCY, 0.01, '=');
                            TotalLineComms2 += Round(LineCommBase, 0.01, '=');
                        end;
                    end;
                until SalesCrMemoLine.Next() = 0;
                Commit();

                cduCommMgt.InsertCommissionPerSalesPersonCM(CustLedgerEntry, CommPercent, SalesCrmMemoHeader."Applies-to Doc. No.", TotalLineComms, CommissionAgrmhdr."Agreement No.", TotalLineComms2);
                //CustLedgerEntry.Modify();
            end;
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Purch.-Post", 'OnAfterPurchInvHeaderInsert', '', true, true)]
    local procedure "Purch.-Post_OnAfterPurchInvHeaderInsert"
    (
        var PurchInvHeader: Record "Purch. Inv. Header";
        var PurchHeader: Record "Purchase Header";
        PreviewMode: Boolean
    )

    var
        CommWSHeader: Record "Commission Worksheet Header";
        CommSVHeader: Record "Commission SV. Worksht. Header";
        CommMgnt: Codeunit "FTT-CST Commission Mgt.";
        PurchaseInvoice: Codeunit "Purch. Post Invoice";
        PurchaseInvoiceEvnts: Codeunit "Purch. Post Invoice Events";
    begin
        if (PurchHeader."Comm. Document No." <> '') AND (PurchHeader."Document Type" = PurchHeader."Document Type"::Invoice) then begin
            CommWSHeader.Reset();
            CommWSHeader.SetRange("Document No.", PurchHeader."Comm. Document No.");
            CommWSHeader.SetRange("Comm. PI No.", PurchHeader."No.");
            if CommWSHeader.FindFirst() then begin
                CommWSHeader."Comm. Payable Doc. No." := PurchInvHeader."No.";
                CommWSHeader.Status := CommWSHeader.Status::"Payable Posted";
                CommWSHeader.Modify();
            end;

            CommSVHeader.Reset();
            CommSVHeader.SetRange("Document No.", PurchHeader."Comm. Document No.");
            CommSVHeader.SetRange("Comm. PI No.", PurchHeader."No.");
            if CommSVHeader.FindFirst() then begin
                CommSVHeader."Comm. Payable Doc. No." := PurchInvHeader."No.";
                CommSVHeader.Status := CommWSHeader.Status::"Payable Posted";
                CommSVHeader.Modify();
            end;
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Gen. Jnl.-Post Line", 'OnBeforeInsertGlEntry', '', true, true)]
    local procedure OnBeforeInsertGLEntry(var GenJnlLine: Record "Gen. Journal Line"; var GLEntry: Record "G/L Entry")
    var
        CommMgnt: Codeunit "FTT-CST Commission Mgt.";
    begin
        GLEntry."Comm. Document No." := GenJnlLine."Comm. Document No.";
        CommMgnt.UpdateCommLedgerEntriesAppliedEntries;

    end;


    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Purch.-Post", 'OnBeforePostBalancingEntry', '', true, true)]
    local procedure OnBeforePostBalancingEntry(var GenJnlLine: Record "Gen. Journal Line"; var VendLedgEntry: Record "Vendor Ledger Entry"; var PurchHeader: Record "Purchase Header")

    begin
        GenJnlLine."Comm. Document No." := PurchHeader."Comm. Document No.";
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Purch.-Post", 'OnBeforePostVendorEntry', '', true, true)]
    local procedure OnBeforePostVendorEntry(var GenJnlLine: Record "Gen. Journal Line"; var PurchHeader: Record "Purchase Header")

    begin
        GenJnlLine."Comm. Document No." := PurchHeader."Comm. Document No.";
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Gen. Jnl.-Post Line", 'OnAfterFinishPosting', '', true, true)]
    local procedure UpdateCommWorksheetPayment(var GenJournalLine: Record "Gen. Journal Line"; var GlobalGLEntry: Record "G/L Entry")
    var
        CommWSHeader: Record "Commission Worksheet Header";
        CommWSLines: Record "Commission Worksheet Lines";
        CommSVHeader: Record "Commission SV. Worksht. Header";
        CommSVLines: Record "Commission SV. Worksheet Lines";
        CommMgnt: Codeunit "FTT-CST Commission Mgt.";
    begin
        if GenJournalLine."Comm. Document No." <> '' then begin
            CommWSHeader.Reset();
            CommWSHeader.SetRange("Document No.", GenJournalLine."Comm. Document No.");
            CommWSHeader.SetRange(CommWSHeader."Comm. Payment Doc. No.", GenJournalLine."Document No.");
            if CommWSHeader.FindFirst() then begin
                CommWSHeader.Status := CommWSHeader.Status::"Payment Posted";
                CommWSHeader.Modify();
                Commit();

                CommWSLines.Reset();
                CommWSLines.SetRange("Document No.", CommWSHeader."Document No.");
                CommWSLines.SetFilter("Application Amount", '<>%1', 0);
                if CommWSLines.FindSet() then
                    repeat
                        CommMgnt.InsertApplicationEntryPayment(CommWSLines, GenJournalLine."Document No.", GenJournalLine."Posting Date", GenJournalLine."Currency Code");
                        Commit();
                    until CommWSLines.Next() = 0;
            end else begin
                CommSVHeader.Reset();
                CommSVHeader.SetRange("Document No.", GenJournalLine."Comm. Document No.");
                CommSVHeader.SetRange("Comm. Payment Doc. No.", GenJournalLine."Document No.");
                if CommSVHeader.FindFirst() then begin
                    CommSVHeader.Status := CommSVHeader.Status::"Payment Posted";
                    CommSVHeader.Modify();
                    Commit();

                    CommSVLines.Reset();
                    CommSVLines.SetRange("Document No.", CommSVHeader."Document No.");
                    CommSVLines.SetFilter("Application Amount", '<>%1', 0);
                    if CommSVLines.FindSet() then
                        repeat
                            CommMgnt.InsertApplicationEntryPaymentSV(CommSVLines, GenJournalLine."Document No.", GenJournalLine."Posting Date", GenJournalLine."Currency Code");
                            Commit();
                        until CommSVLines.Next() = 0;
                end;
            end;
        end;
    end;

    // To keep the Sales Orde even all lines have been shipped and invoiced already
    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Sales-Post", 'OnBeforeFinalizePosting', '', false, false)]
    local procedure KeepSalesOrdersAfterInvoiced(var EverythingInvoiced: Boolean)
    begin
        EverythingInvoiced := false;
    end;

    var

        GlobalUnitPrice: Decimal;
        cduCommMgt: Codeunit "FTT-CST Commission Mgt.";

}
