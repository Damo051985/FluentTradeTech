codeunit 60007 "FTT-CST RecurringItemSalesMng"
{
    procedure CheckItemSalesType(SalesLine: Record "Sales Line"; ItemSalesType: Enum "FTT-CST Stn. Item Sales Type"): Boolean
    var
        StnItemSalesCode: Record "FTT-CST Stn. Item Sales Code";
    begin
        SalesLine.TestField("No.");

        if SalesLine.Type <> "Sales Line Type"::Item then
            exit(false);
        if SalesLine."Document Type" = "Sales Document Type"::"Blanket Order" then
            exit(false);
        if SalesLine."Document Type" = "Sales Document Type"::"Return Order" then
            exit(false);

        SetFilterStnItemSalesCode(SalesLine, StnItemSalesCode, ItemSalesType);
        exit(not StnItemSalesCode.IsEmpty());
    end;

    procedure CheckItemPriceType(PriceListLine: Record "Price List Line"; ItemSalesType: Enum "FTT-CST Stn. Item Sales Type"): Boolean
    var
        StnItemSalesCode: Record "FTT-CST Stn. Item Sales Code";
    begin
        PriceListLine.TestField("Asset No.");

        if PriceListLine."Asset Type" <> "Price Asset Type"::Item then
            exit(false);

        StnItemSalesCode.SetRange("Item No.", PriceListLine."Asset No.");
        StnItemSalesCode.SetRange("Insert Rec. Lines On Pr. List", ItemSalesType);
        if ItemSalesType in ["FTT-CST Stn. Item Sales Type"::"Always Ask", "FTT-CST Stn. Item Sales Type"::Automatic] then
            StnItemSalesCode.SetRange("Currency Code", PriceListLine."Currency Code");
        exit(not StnItemSalesCode.IsEmpty());
    end;

    procedure InsertSalesLines(var SalesLine: Record "Sales Line"; ItemSalesType: Enum "FTT-CST Stn. Item Sales Type")
    var
        StnItemSalesCode: Record "FTT-CST Stn. Item Sales Code";
        SalesHeader: Record "Sales Header";
        StnItemSalesCodes: Page "FTT-CST Stn. Item Sales Codes";
    begin
        SalesLine.TestField("No.");
        SalesHeader.Get(SalesLine."Document Type", SalesLine."Document No.");

        StnItemSalesCode.FilterGroup := 2;
        StnItemSalesCode.SetRange("Item No.", SalesLine."No.");
        StnItemSalesCode.FilterGroup := 0;

        case ItemSalesType of
            "FTT-CST Stn. Item Sales Type"::"Always Ask":
                if not Confirm(StrSubstNo(AlwaysAskConf, SalesLine."No.")) then
                    exit;
            "FTT-CST Stn. Item Sales Type"::Automatic:
                begin
                    SetFilterStnItemSalesCode(SalesLine, StnItemSalesCode, ItemSalesType);
                    if StnItemSalesCode.FindSet() then
                        repeat
                            ApplyStdCodesToSalesLines(SalesHeader, SalesLine."No.", SalesLine."Currency Code", SalesLine."Unit Price", StnItemSalesCode);
                        until StnItemSalesCode.Next() = 0;
                    exit;
                end;
        end;

        StnItemSalesCodes.SetTableView(StnItemSalesCode);
        StnItemSalesCodes.LookupMode(true);
        if StnItemSalesCodes.RunModal() = Action::LookupOK then begin
            StnItemSalesCodes.GetSelected(StnItemSalesCode);
            if StnItemSalesCode.FindSet() then
                repeat
                    ApplyStdCodesToSalesLines(SalesHeader, SalesLine."No.", SalesLine."Currency Code", SalesLine."Unit Price", StnItemSalesCode);
                until StnItemSalesCode.Next() = 0;
        end;
    end;

    procedure InsertPriceLines(var PriceListLine: Record "Price List Line"; ItemSalesType: Enum "FTT-CST Stn. Item Sales Type")
    var
        StnItemSalesCode: Record "FTT-CST Stn. Item Sales Code";
        StnItemSalesCodes: Page "FTT-CST Stn. Item Sales Codes";
    begin
        PriceListLine.TestField("Asset No.");

        StnItemSalesCode.FilterGroup := 2;
        StnItemSalesCode.SetRange("Item No.", PriceListLine."Asset No.");
        StnItemSalesCode.FilterGroup := 0;

        case ItemSalesType of
            "FTT-CST Stn. Item Sales Type"::"Always Ask":
                if not Confirm(StrSubstNo(AlwaysAskConf, PriceListLine."Asset No.")) then
                    exit;
            "FTT-CST Stn. Item Sales Type"::Automatic:
                begin
                    StnItemSalesCode.SetRange("Insert Rec. Lines On Pr. List", ItemSalesType);
                    if ItemSalesType in ["FTT-CST Stn. Item Sales Type"::"Always Ask", "FTT-CST Stn. Item Sales Type"::Automatic] then
                        StnItemSalesCode.SetRange("Currency Code", PriceListLine."Currency Code");
                    if StnItemSalesCode.FindSet() then
                        repeat
                            ApplyStdCodesToPriceLines(PriceListLine, StnItemSalesCode);
                        until StnItemSalesCode.Next() = 0;
                    exit;
                end;
        end;

        ExchangeRateDate := 0D;
        StnItemSalesCodes.SetTableView(StnItemSalesCode);
        StnItemSalesCodes.LookupMode(true);
        if StnItemSalesCodes.RunModal() = Action::LookupOK then begin
            StnItemSalesCodes.GetSelected(StnItemSalesCode);
            if StnItemSalesCode.FindSet() then
                repeat
                    ApplyStdCodesToPriceLines(PriceListLine, StnItemSalesCode);
                until StnItemSalesCode.Next() = 0;
        end;
    end;

    local procedure ApplyStdCodesToPriceLines(
        PriceListLine: Record "Price List Line";
        StnItemSalesCode: Record "FTT-CST Stn. Item Sales Code")
    var
        Item: Record Item;
        PriceListLineNew: Record "Price List Line";
        Resource: Record Resource;
        StdSalesCode: Record "Standard Sales Code";
        StdSalesLine: Record "Standard Sales Line";
        CalculatedTypeExist: Boolean;
        CalculationBasisSumPrice: Decimal;
        ExchRate: Decimal;
        i: Integer;
    begin
        StnItemSalesCode.TestField(Code);
        StnItemSalesCode.TestField("Item No.", PriceListLine."Asset No.");
        StdSalesCode.Get(StnItemSalesCode.Code);
        if StdSalesCode."Currency Code" <> PriceListLine."Currency Code" then
            Error(CurrencyCodeErr, PriceListLine.FieldCaption("Currency Code"), PriceListLine."Currency Code",
                StdSalesCode.TableCaption, StdSalesCode.FieldCaption(Code), StnItemSalesCode.Code, StnItemSalesCode."Currency Code");

        if PriceListLine."Currency Code" <> '' then
            ExchRate := GetExchRate(PriceListLine."Currency Code");

        StdSalesLine.SetRange("Standard Sales Code", StnItemSalesCode.Code);
        StdSalesLine.SetFilter(Type, '%1|%2|%3', "Sales Line Type"::Item, "Sales Line Type"::"G/L Account", "Sales Line Type"::Resource);

        CalculatedTypeExist := IsCalculatedTypeExist(StnItemSalesCode.Code);
        CalculationBasisSumPrice := PriceListLine."Unit Price";

        StdSalesLine.LockTable();
        for i := StartInt to EndInt do begin
            case i of
                1:
                    StdSalesLine.SetRange("FTT-CST Lines Calc. Type", "FTT-CST UnitPriceCalcType"::"Calculation Basis");
                2:
                    StdSalesLine.SetRange("FTT-CST Lines Calc. Type", "FTT-CST UnitPriceCalcType"::Calculated);
                3:
                    StdSalesLine.SetRange("FTT-CST Lines Calc. Type", "FTT-CST UnitPriceCalcType"::" ");
            end;

            if StdSalesLine.FindSet() then
                repeat
                    StdSalesLine.TestField("No.");

                    PriceListLineNew.TransferFields(PriceListLine);
                    PriceListLineNew."Line No." := GetNextLineNo(PriceListLine);
                    case StdSalesLine.Type of
                        "Sales Line Type"::Item:
                            PriceListLineNew.Validate("Asset Type", "Price Asset Type"::Item);
                        "Sales Line Type"::"G/L Account":
                            PriceListLineNew.Validate("Asset Type", "Price Asset Type"::"G/L Account");
                        "Sales Line Type"::Resource:
                            PriceListLineNew.Validate("Asset Type", "Price Asset Type"::Resource);
                    end;

                    PriceListLineNew.Validate("Asset No.", StdSalesLine."No.");
                    if StdSalesLine."Variant Code" <> '' then
                        PriceListLineNew.Validate("Variant Code", StdSalesLine."Variant Code");
                    if StdSalesLine."Unit of Measure Code" <> '' then
                        PriceListLineNew.Validate("Unit of Measure Code", StdSalesLine."Unit of Measure Code");
                    if StdSalesLine.Description <> '' then
                        PriceListLineNew.Description := StdSalesLine.Description;

                    case PriceListLineNew."Asset Type" of
                        "Price Asset Type"::Item:
                            begin
                                Item.Get(PriceListLineNew."Asset No.");
                                if PriceListLine."Currency Code" = '' then
                                    PriceListLineNew.Validate("Unit Price", Item."Unit Price")
                                else
                                    PriceListLineNew.Validate("Unit Price", Round(Item."Unit Price" * ExchRate, 0.01, '='));
                                PriceListLineNew.Validate("Price Includes VAT", Item."Price Includes VAT");
                            end;
                        "Price Asset Type"::"G/L Account":
                            begin
                                PriceListLineNew.Validate("Unit Price", StdSalesLine."Amount Excl. VAT");
                                PriceListLineNew.Validate("Price Includes VAT", false);
                            end;
                        "Price Asset Type"::Resource:
                            begin
                                Resource.Get(PriceListLineNew."Asset No.");
                                if PriceListLine."Currency Code" = '' then
                                    PriceListLineNew.Validate("Unit Price", Resource."Unit Price")
                                else
                                    PriceListLineNew.Validate("Unit Price", Round(Resource."Unit Price" * ExchRate, 0.01, '='));
                                PriceListLineNew.Validate("Price Includes VAT", false);
                            end;
                    end;

                    PriceListLineNew.Insert(true);
                    if CalculatedTypeExist then begin
                        if StdSalesLine."FTT-CST Lines Calc. Type" = "FTT-CST UnitPriceCalcType"::"Calculation Basis" then
                            CalculationBasisSumPrice += PriceListLineNew."Unit Price";
                        if StdSalesLine."FTT-CST Lines Calc. Type" = "FTT-CST UnitPriceCalcType"::Calculated then begin
                            PriceListLineNew.Validate("Unit Price", CalculationBasisSumPrice * (StdSalesLine."FTT-CST Price Percentage, %" / 100));
                            PriceListLineNew.Modify(true);
                        end;
                    end;
                until StdSalesLine.Next() = 0;
        end;
    end;

    local procedure ApplyStdCodesToSalesLines(
        var SalesHeader: Record "Sales Header";
        ItemNo: Code[20];
        CurrencyCode: Code[10];
        UnitPrice: Decimal;
        StnItemSalesCode: Record "FTT-CST Stn. Item Sales Code")
    var
        Currency: Record Currency;
        SalesLine: Record "Sales Line";
        StandardCustomerSalesCode: Record "Standard Customer Sales Code";
        StdSalesCode: Record "Standard Sales Code";
        StdSalesLine: Record "Standard Sales Line";
        CalculatedTypeExist: Boolean;
        CalculationBasisSumPrice: Decimal;
        Factor: Integer;
        i: Integer;
    begin
        Currency.Initialize(SalesHeader."Currency Code");

        StnItemSalesCode.TestField(Code);
        StnItemSalesCode.TestField("Item No.", ItemNo);
        StdSalesCode.Get(StnItemSalesCode.Code);
        if StdSalesCode."Currency Code" <> CurrencyCode then
            Error(CurrencyCodeErr, SalesHeader.FieldCaption("Currency Code"), CurrencyCode,
                StdSalesCode.TableCaption, StdSalesCode.FieldCaption(Code), StnItemSalesCode.Code, StnItemSalesCode."Currency Code");
        StdSalesLine.SetRange("Standard Sales Code", StnItemSalesCode.Code);
        SalesLine."Document Type" := SalesHeader."Document Type";
        SalesLine."Document No." := SalesHeader."No.";
        SalesLine.SetRange("Document Type", SalesHeader."Document Type");
        SalesLine.SetRange("Document No.", SalesHeader."No.");
        if SalesHeader."Prices Including VAT" then
            Factor := 1
        else
            Factor := 0;

        CalculatedTypeExist := IsCalculatedTypeExist(StnItemSalesCode.Code);
        CalculationBasisSumPrice := UnitPrice;

        SalesLine.LockTable();
        StdSalesLine.LockTable();
        for i := StartInt to EndInt do begin
            case i of
                1:
                    StdSalesLine.SetRange("FTT-CST Lines Calc. Type", "FTT-CST UnitPriceCalcType"::"Calculation Basis");
                2:
                    StdSalesLine.SetRange("FTT-CST Lines Calc. Type", "FTT-CST UnitPriceCalcType"::Calculated);
                3:
                    StdSalesLine.SetRange("FTT-CST Lines Calc. Type", "FTT-CST UnitPriceCalcType"::" ");
            end;
            if StdSalesLine.FindSet() then
                repeat
                    SalesLine.Init();
                    SalesLine.SetSalesHeader(SalesHeader);
                    SalesLine."Line No." := 0;
                    SalesLine.Validate(Type, StdSalesLine.Type);
                    if StdSalesLine.Type = StdSalesLine.Type::" " then begin
                        SalesLine.Validate("No.", StdSalesLine."No.");
                        SalesLine.Description := StdSalesLine.Description;
                        SalesLine."Sell-to Customer No." := SalesHeader."Sell-to Customer No.";
                    end else
                        if not StdSalesLine.EmptyLine() then begin
                            StdSalesLine.TestField("No.");
                            SalesLine.Validate("No.", StdSalesLine."No.");
                            if StdSalesLine."Variant Code" <> '' then
                                SalesLine.Validate("Variant Code", StdSalesLine."Variant Code");
                            SalesLine.Validate(Quantity, StdSalesLine.Quantity);
                            if StdSalesLine."Unit of Measure Code" <> '' then
                                SalesLine.Validate("Unit of Measure Code", StdSalesLine."Unit of Measure Code");
                            if StdSalesLine.Description <> '' then
                                SalesLine.Validate(Description, StdSalesLine.Description);
                            if (StdSalesLine.Type = StdSalesLine.Type::"G/L Account") or
                               (StdSalesLine.Type = StdSalesLine.Type::"Charge (Item)")
                            then
                                SalesLine.Validate(
                                  "Unit Price",
                                  Round(StdSalesLine."Amount Excl. VAT" *
                                    (SalesLine."VAT %" / 100 * Factor + 1), Currency."Unit-Amount Rounding Precision"));
                        end;

                    SalesLine."Shortcut Dimension 1 Code" := StdSalesLine."Shortcut Dimension 1 Code";
                    SalesLine."Shortcut Dimension 2 Code" := StdSalesLine."Shortcut Dimension 2 Code";

                    CombineDimensions(SalesLine, StdSalesLine);
                    if StdSalesLine.InsertLine() then begin
                        SalesLine."Line No." := StandardCustomerSalesCode.GetNextLineNo(SalesLine);
                        SalesLine.Insert(true);
                        SalesLine.AutoAsmToOrder();
                        StandardCustomerSalesCode.InsertExtendedText(SalesLine, SalesHeader);
                    end;

                    if CalculatedTypeExist then begin
                        if StdSalesLine."FTT-CST Lines Calc. Type" = "FTT-CST UnitPriceCalcType"::"Calculation Basis" then
                            CalculationBasisSumPrice += SalesLine."Unit Price";
                        if StdSalesLine."FTT-CST Lines Calc. Type" = "FTT-CST UnitPriceCalcType"::Calculated then begin
                            SalesLine.Validate("Unit Price", CalculationBasisSumPrice * (StdSalesLine."FTT-CST Price Percentage, %" / 100));
                            SalesLine.Modify(true);
                        end;
                    end;
                until StdSalesLine.Next() = 0;
        end;
    end;

    local procedure CombineDimensions(var SalesLine: Record "Sales Line"; StdSalesLine: Record "Standard Sales Line")
    var
        DimensionManagement: Codeunit DimensionManagement;
        DimensionSetIDArr: array[10] of Integer;
    begin
        DimensionSetIDArr[1] := SalesLine."Dimension Set ID";
        DimensionSetIDArr[2] := StdSalesLine."Dimension Set ID";

        SalesLine."Dimension Set ID" :=
          DimensionManagement.GetCombinedDimensionSetID(
            DimensionSetIDArr, SalesLine."Shortcut Dimension 1 Code", SalesLine."Shortcut Dimension 2 Code");
    end;

    local procedure SetFilterStnItemSalesCode(
        SalesLine: Record "Sales Line";
        var StnItemSalesCode: Record "FTT-CST Stn. Item Sales Code";
        ItemSalesType: Enum "FTT-CST Stn. Item Sales Type")
    begin
        StnItemSalesCode.SetRange("Item No.", SalesLine."No.");
        case SalesLine."Document Type" of
            "Sales Document Type"::Quote:
                StnItemSalesCode.SetRange("Insert Rec. Lines On Quotes", ItemSalesType);
            "Sales Document Type"::Order:
                StnItemSalesCode.SetRange("Insert Rec. Lines On Orders", ItemSalesType);
            "Sales Document Type"::Invoice:
                StnItemSalesCode.SetRange("Insert Rec. Lines On Invoices", ItemSalesType);
            "Sales Document Type"::"Credit Memo":
                StnItemSalesCode.SetRange("Insert Rec. Lines On Cr. Memos", ItemSalesType);
        end;

        if ItemSalesType in ["FTT-CST Stn. Item Sales Type"::"Always Ask", "FTT-CST Stn. Item Sales Type"::Automatic] then
            StnItemSalesCode.SetRange("Currency Code", SalesLine."Currency Code");
    end;

    local procedure GetExchRate(CurrencyCode: Code[10]): Decimal
    var
        CurrencyExchangeRate: Record "Currency Exchange Rate";
        ExchangeRateDialog: Page "FTT-CST ExchangeRateDate";
    begin
        if ExchangeRateDate = 0D then begin
            if ExchangeRateDialog.RunModal() = Action::Cancel then
                exit;
            ExchangeRateDate := ExchangeRateDialog.GetExchangeRateDate();
        end;

        CurrencyExchangeRate.SetRange("Currency Code", CurrencyCode);
        CurrencyExchangeRate.SetFilter("Starting Date", '<=%1', ExchangeRateDate);
        CurrencyExchangeRate.FindLast();
        exit(CurrencyExchangeRate."Exchange Rate Amount" / CurrencyExchangeRate."Relational Exch. Rate Amount");
    end;

    local procedure GetNextLineNo(PriceListLine: Record "Price List Line"): Integer
    begin
        PriceListLine.SetRange("Price List Code", PriceListLine."Price List Code");
        if PriceListLine.FindLast() then
            exit(PriceListLine."Line No." + 10000);

        exit(10000);
    end;

    local procedure IsCalculatedTypeExist(StandardSalesCode: Code[10]): Boolean
    var
        StdSalesLine: Record "Standard Sales Line";
    begin
        StdSalesLine.SetRange("Standard Sales Code", StandardSalesCode);
        StdSalesLine.SetRange("FTT-CST Lines Calc. Type", "FTT-CST UnitPriceCalcType"::Calculated);

        if StdSalesLine.FindSet() then begin
            StartInt := 1;
            EndInt := 3;
            exit(true);
        end else begin
            StartInt := 4;
            EndInt := 4;
            exit(false);
        end;
    end;

    var
        ExchangeRateDate: Date;
        EndInt: Integer;
        StartInt: Integer;
        AlwaysAskConf: Label 'Recurring sales lines exist for item %1. Do you want to insert them on this document?', Comment = '%1 - Field Value';
        CurrencyCodeErr: Label '%1 must be equal to ''''%2'''' in %3: %4=%5. Current value is ''''%6''''.', Comment = '%1 - Field Value, %2 - Field Value, %3 - Table Caption, %4 - Field Caption, %5 - Fileld Caption, %6 - Field Value';
}
