controladdin OAuthReDirect
{
    StartupScript = 'src/OAuth2/JavaScript/GMAIL_startup.js';
    Scripts = 'src/OAuth2/JavaScript/GMAIL_OAuth.js';
    MaximumHeight = 1;
    MaximumWidth = 1;
    MinimumHeight = 1;
    MinimumWidth = 1;
    event RedirectReceived(Code: Text; State: Text);
    event ControlReady();
    event TimerTic();
    procedure LaunchURLinNewWindow(URL: Text);
    procedure StartTimer();
    procedure CloseCurrentWindow();
    procedure CloseWindow();
}