report 60001 "FTT-CST Pricing Prop. Template"
{
    Caption = 'Pricing Proposal Template';
    DefaultLayout = RDLC;
    RDLCLayout = './layout/Pricing Proposal Template.rdlc';

    dataset
    {
        dataitem(SalesHeader; "Sales Header")
        {
            DataItemTableView = sorting("Document Type", "No.");

            column(CompanyLogo; CompanyInformation.Picture)
            {
            }
            column(ClientNameValue; SalesHeader."Sell-to Customer Name")
            {
            }
            column(FluenPricingPlatformLbl; FluenPricingPlatformLbl)
            {
            }
            column(PricingPropositionDate; PricingPropositionDate)
            {
            }
            column(ProjectDescription; ProjectDescription)
            {
            }
            column(CompanyAddressValue; CompanyInformation.Address)
            {
            }
            column(CompanyAddress2Value; CompanyInformation."Address 2")
            {
            }
            column(CompanyCityValue; CompanyInformation.City)
            {
            }
            column(CompanyCountryValue; CountryRegion.Name)
            {
            }
            column(CompanyPostCodeValue; CompanyInformation."Post Code")
            {
            }
            column(CompanyPhoneNoValue; CompanyInformation."Phone No.")
            {
            }
            column(CompanyHomePageValue; CompanyInformation."Home Page")
            {
            }
            column(StrictlyConfidential; StrictlyConfidentialLbl)
            {
            }
            column(CurrencyCodeValue; CurrencyCodeValue)
            {
            }
            column(CurrencySymbolValue; CurrencySymbolValue)
            {
            }
            column(ShowVAT; ShowVAT)
            {
            }
            dataitem(SalesLine; "Sales Line")
            {
                DataItemLink = "Document No." = field("No."), "Document Type" = field("Document Type");
                DataItemTableView = sorting("Document Type", "Document No.", "Line No.");

                column(RegionDimensionCode; RegionDimensionValueCode)
                {
                }
                column(RegionDimensionValue; RegionDimensionValueName)
                {
                }
                column(Type; SalesLine.Type)
                {
                }
                column(ItemNo; SalesLine."No.")
                {
                }
                column(ItemDescriptionValue; SalesLine.Description)
                {
                }
                column(ItemCategoryValue; ItemCategoryValue)
                {
                }
                column(PeriodValue; PeriodValue)
                {
                }
                column(Quantity; SalesLine.Quantity)
                {
                }
                column(Price; SalesLine."Unit Price" - (SalesLine."Unit Price" * SalesLine."Line Discount %" / 100))
                {
                }
                column(VATPercent; Format(SalesLine."VAT %") + '%')
                {
                }
                column(LineTotal; LineTotal)
                {
                }

                trigger OnAfterGetRecord()
                begin
                    LineTotal := SalesLine.Amount;

                    if ShowVAT then
                        LineTotal := SalesLine."Amount Including VAT";

                    GetDimension();
                    GetItemCategory();
                    GetPeriodValue();
                end;
            }

            trigger OnPreDataItem()
            begin
                SalesHeader.SetRange("Document Type", DocumentType);
                SalesHeader.SetRange("No.", DocumentNo);
            end;

            trigger OnAfterGetRecord()
            begin
                GetCurrencyValue();
            end;
        }
    }

    requestpage
    {
        layout
        {
            area(Content)
            {
                group(Option)
                {
                    field(DocumentType; DocumentType)
                    {
                        ApplicationArea = All;
                        Caption = 'Document Type';

                        trigger OnValidate()
                        begin
                            DocumentNo := '';
                        end;
                    }
                    field(DocumentNo; DocumentNo)
                    {
                        ApplicationArea = All;
                        Caption = 'No.';

                        trigger OnLookup(var Text: Text): Boolean
                        begin
                            LookupDocNo();
                        end;

                        trigger OnValidate()
                        begin
                            ValidateDocNo();
                        end;
                    }
                    field(PricingPropositionDate; PricingPropositionDate)
                    {
                        ApplicationArea = All;
                        Caption = 'Pricing Proposition Date';
                    }
                    field(ShowVAT; ShowVAT)
                    {
                        ApplicationArea = All;
                        Caption = 'Show VAT';
                    }
                    field(ProjectDescription; ProjectDescription)
                    {
                        ApplicationArea = All;
                        Caption = 'Project Description';
                        MultiLine = true;
                    }
                }
            }
        }
    }

    trigger OnInitReport()
    begin
        CompanyInformation.SetAutoCalcFields(Picture);
        CompanyInformation.Get();
        CountryRegion.Get(CompanyInformation."Country/Region Code");

        SalesReceivablesSetup.Get();
    end;

    trigger OnPreReport()
    begin
        if DocumentNo = '' then
            Error(SalesDocumentNoErr);
    end;

    local procedure LookupDocNo()
    var
        SalesHeader: Record "Sales Header";
    begin
        SalesHeader.FilterGroup := 0;
        SalesHeader.SetRange("Document Type", DocumentType);
        SalesHeader.FilterGroup := 2;
        if Page.RunModal(0, SalesHeader) = Action::LookupOK then
            DocumentNo := SalesHeader."No.";
    end;

    local procedure ValidateDocNo()
    var
        SalesHeader: Record "Sales Header";
    begin
        SalesHeader.Get(DocumentType, DocumentNo);
    end;

    local procedure GetCurrencyValue()
    var
        Currency: Record Currency;
        GeneralLedgerSetup: Record "General Ledger Setup";
    begin
        if SalesHeader."Currency Code" = '' then begin
            GeneralLedgerSetup.Get();
            CurrencyCodeValue := GeneralLedgerSetup."LCY Code";
            CurrencySymbolValue := GeneralLedgerSetup."Local Currency Symbol";
        end else begin
            Currency.Get(SalesHeader."Currency Code");
            CurrencyCodeValue := Currency."ISO Code";
            CurrencySymbolValue := Currency.Symbol;
        end;
    end;

    local procedure GetDimension()
    var
        DimensionSetEntry: Record "Dimension Set Entry";
    begin
        DimensionSetEntry.SetRange("Dimension Set ID", SalesLine."Dimension Set ID");
        DimensionSetEntry.SetRange("Dimension Code", SalesReceivablesSetup."FTT-CST Item Region Dim. Code");
        if DimensionSetEntry.FindSet() then begin
            RegionDimensionValueCode := DimensionSetEntry."Dimension Value Code";
            DimensionSetEntry.CalcFields("Dimension Value Name");
            RegionDimensionValueName := DimensionSetEntry."Dimension Value Name";
        end else begin
            RegionDimensionValueCode := '';
            RegionDimensionValueName := '';
        end;
    end;

    local procedure GetItemCategory()
    var
        ItemCategory: Record "Item Category";
    begin
        if SalesLine.Type <> "Sales Line Type"::Item then begin
            ItemCategoryValue := '';
            exit;
        end;

        if not ItemCategory.Get(SalesLine."Item Category Code") then begin
            ItemCategoryValue := '';
            exit;
        end;

        ItemCategoryValue := ItemCategory.Description;
    end;

    local procedure GetPeriodValue()
    var
        Item: Record Item;
    begin
        if SalesLine.Type <> "Sales Line Type"::Item then begin
            PeriodValue := '';
            exit;
        end;

        Item.Get(SalesLine."No.");
        if Item."FTT-CST Cost Type" = "FTT-CST Cost Type"::NRC then begin
            PeriodValue := '';
            exit;
        end;

        if (SalesLine."FTT-CST Agreement Date From" = 0D) or (SalesLine."FTT-CST Agreement Date To" = 0D) then begin
            PeriodValue := '';
            exit;
        end;

        PeriodValue := StrSubstNo(PeriodValueLbl,
            Format(SalesLine."FTT-CST Agreement Date From", 0, '<Month Text,3>'),
            Format(Date2DMY(SalesLine."FTT-CST Agreement Date From", 3)),
            Format(SalesLine."FTT-CST Agreement Date To", 0, '<Month Text,3>'),
            Format(Date2DMY(SalesLine."FTT-CST Agreement Date To", 3)));
    end;

    var
        CompanyInformation: Record "Company Information";
        CountryRegion: Record "Country/Region";
        SalesReceivablesSetup: Record "Sales & Receivables Setup";
        ShowVAT: Boolean;
        DocumentNo: Code[20];
        RegionDimensionValueCode: Code[20];
        PricingPropositionDate: Date;
        LineTotal: Decimal;
        DocumentType: Enum "Sales Document Type";
        FluenPricingPlatformLbl: Label 'Fluent pricing proposal';
        PeriodValueLbl: Label '%1 %2 through %3 %4';
        SalesDocumentNoErr: Label 'No. should be filled';
        StrictlyConfidentialLbl: Label 'STRICTLY CONFIDENTIAL';
        CurrencyCodeValue: Text;
        CurrencySymbolValue: Text;
        PeriodValue: Text;
        RegionDimensionValueName: Text[50];
        ItemCategoryValue: Text[100];
        ProjectDescription: Text[250];
}
