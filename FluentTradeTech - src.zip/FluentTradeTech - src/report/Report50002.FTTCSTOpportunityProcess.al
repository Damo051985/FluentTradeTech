report 50002 "Create Opport. from Email"
{
    Caption = 'Create Opport. from Email';
    ProcessingOnly = true;

    dataset
    {
        dataitem(SourceEmail; "GMAIL Inbound/Outbound")
        {
            DataItemTableView = sorting(EntryNo) order(ascending);
            trigger OnAfterGetRecord()
            begin
                CreateNewOpportunity();
                Commit();
                CreateNewLinkFromEmailOppor(gcodOpport, SourceEmail);
                Commit();
                CreateNewLinkFromEmailContact(SourceEmail);
            end;

            // trigger OnPreDataItem()
            // begin
            //     ContactNoNotEmpty();
            //     DescriptionNoNotEmpty();
            // end;
        }
    }

    requestpage
    {

        layout
        {
            area(content)
            {
                group(filter)
                {
                    Caption = 'Filter';
                    field(SourceContactNo; ContactNo)
                    {
                        ApplicationArea = Basic, Suite;
                        Caption = 'Contact No.';
                        NotBlank = true;
                        ShowMandatory = true;
                        trigger OnLookup(var Text: Text): Boolean
                        begin
                            LookupContactDoc();
                        end;

                        trigger OnValidate()
                        begin
                            ValidateContactNo();
                        end;

                    }
                    field(SourceContactName; ContactName)
                    {
                        ApplicationArea = Basic, Suite;
                        Caption = 'Contact Name';
                        Editable = false;

                    }
                    field(SourceDescription; Description)
                    {
                        ApplicationArea = Basic, Suite;
                        Caption = 'Description';
                        ShowMandatory = true;
                    }
                }
            }
        }

    }


    trigger OnPreReport()
    begin
        if ContactNo = '' then
            Error(ContactNoMissingErr);

        if Description = '' then
            Error(DescriptionNoMissingErr);

    end;

    trigger OnPostReport()
    var
        pagOpportunityCard: Page "Opportunity Card";
        recOpportunity: Record Opportunity;
    begin
        Message(StrSubstNo(SuccessMsg, gcodOpport));
        Commit();

        if not Confirm(StrSubstNo(CONFIRM01, gcodOpport), false, 0) then
            exit;

        clear(pagOpportunityCard);

        recOpportunity.Reset();
        recOpportunity.SetRange("No.", gcodOpport);
        if recOpportunity.FindFirst() then begin
            pagOpportunityCard.SetTableView(recOpportunity);
            pagOpportunityCard.Run();
        end;
    end;

    var
        ContactNo: Code[10];
        ContactName: Text[1024];
        SuccessMsg: Label 'The new Opportunity No. %1 has been created successfully.';
        ContactNoMissingErr: Label 'You must specify a Contact No. for the new Opportunity.';
        Description: Text[1024];
        DescriptionNoMissingErr: Label 'You must specify a Description for the new Opportunity.';
        ContactNoNotExist: Label 'This Contact No. %1 does not exist.';
        gcodOpport: Code[20];
        CONFIRM01: Label 'Do you want to open this %1 Opportunity document?';

    local procedure LookupContactDoc()
    var
        recContact: Record Contact;
    begin
        if PAGE.RunModal(0, recContact) = ACTION::LookupOK then
            ContactNo := recContact."No.";
    end;

    procedure SetDefaultContact(pCode: code[50])
    var
        l_contact: Record Contact;
    begin
        ContactNo := pCode;
        if l_contact.get(pCode) then
            ContactName := l_contact.Name;
    end;

    local procedure ValidateContactNo()
    var
        recContact: Record Contact;
    begin
        if not recContact.Get(ContactNo) then
            Error(StrSubstNo(ContactNoNotExist, ContactNo));

        ContactName := recContact.Name;
    end;

    local procedure CreateNewOpportunity()
    var
        recOpportunity: Record Opportunity;
        codOpport: Code[20];
    begin
        recOpportunity.Init();
        recOpportunity.Description := Description;
        recOpportunity.Validate("Contact No.", ContactNo);
        if recOpportunity.Insert(true) then
            gcodOpport := recOpportunity."No.";

    end;

    local procedure CreateNewLinkFromEmailOppor(pOpporCode: Code[20]; pGmailInbox: Record "GMAIL Inbound/Outbound")
    var
        recEmailRelatoion2: Record "GMAIL Email Relation";
        recEmailRelatoion4: Record "GMAIL Email Relation";

    begin

        if pOpporCode <> '' then begin
            recEmailRelatoion2.Init();
            recEmailRelatoion4.Reset();

            if recEmailRelatoion4.FindLast() then
                recEmailRelatoion2.EntryNo := recEmailRelatoion4.EntryNo + 1
            else
                recEmailRelatoion2.EntryNo := 1;

            recEmailRelatoion2."Email Type" := pGmailInbox."Email Type";
            recEmailRelatoion2."Inbox Entry No." := pGmailInbox.EntryNo;
            recEmailRelatoion2."Thread ID" := pGmailInbox."Thread ID";

            recEmailRelatoion2."Linked Document Type" := recEmailRelatoion2."Linked Document Type"::Opportunity;
            recEmailRelatoion2.validate("Linked Document No.", pOpporCode);

            recEmailRelatoion2."Date Received" := pGmailInbox."Date Received";
            recEmailRelatoion2."Date Sent" := pGmailInbox."Date Received";
            recEmailRelatoion2.Subject := pGmailInbox.Subject;
            recEmailRelatoion2."GMAIL Inbox ID" := pGmailInbox."GMAIL Inbox ID";
            recEmailRelatoion2.Insert(true);
            Commit();
        end;
    end;

    local procedure CreateNewLinkFromEmailContact(pGmailInbox: Record "GMAIL Inbound/Outbound")
    var
        recEmailRelatoion2: Record "GMAIL Email Relation";
        recEmailRelatoion4: Record "GMAIL Email Relation";

    begin

        if ContactNo <> '' then begin
            recEmailRelatoion2.Reset();
            recEmailRelatoion2.SetRange("GMAIL Inbox ID", pGmailInbox."GMAIL Inbox ID");
            recEmailRelatoion2.SetRange("Linked Document Type", recEmailRelatoion2."Linked Document Type"::Contact);
            recEmailRelatoion2.SetRange("Linked Document No.", ContactNo);
            if not recEmailRelatoion2.FindFirst() then begin
                recEmailRelatoion2.Init();
                recEmailRelatoion4.Reset();

                if recEmailRelatoion4.FindLast() then
                    recEmailRelatoion2.EntryNo := recEmailRelatoion4.EntryNo + 1
                else
                    recEmailRelatoion2.EntryNo := 1;

                recEmailRelatoion2."Email Type" := pGmailInbox."Email Type";
                recEmailRelatoion2."Inbox Entry No." := pGmailInbox.EntryNo;
                recEmailRelatoion2."Thread ID" := pGmailInbox."Thread ID";

                recEmailRelatoion2."Linked Document Type" := recEmailRelatoion2."Linked Document Type"::Contact;
                recEmailRelatoion2.Validate("Linked Document No.", ContactNo);

                recEmailRelatoion2."Date Received" := pGmailInbox."Date Received";
                recEmailRelatoion2."Date Sent" := pGmailInbox."Date Received";
                recEmailRelatoion2.Subject := pGmailInbox.Subject;
                recEmailRelatoion2."GMAIL Inbox ID" := pGmailInbox."GMAIL Inbox ID";
                recEmailRelatoion2.Insert(true);
                Commit();
            end;
        end;


    end;


}

