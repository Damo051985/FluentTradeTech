report 50003 "Commission Worksheet Calc"
{
    ProcessingOnly = true;
    Permissions = tabledata "Sales Invoice Header" = rimd;
    requestpage
    {
        layout
        {
            area(Content)
            {
                group(General)
                {
                    Caption = '';
                    field(AgreementCode; codAggreementCode)
                    {
                        ApplicationArea = All;
                        Caption = 'Commission Agreement No.';
                        TableRelation = "FTT-CST Comm. Agrm. Header"."Agreement No." where(Status = filter(Activated), "Salesperson Type" = filter(Salesperson));
                    }
                    // field(codSalesPersonCode; codSalesPersonCode)
                    // {
                    //     ApplicationArea = All;
                    //     Caption = 'Salesperson Code';
                    //     TableRelation = "FTT-CST Comm. Agrm. Header"."Type No." where(Status = filter(Activated), "Salesperson Type" = filter(Salesperson));
                    // }
                    field(dateInvoiceDateFrom; dateInvoiceDateFrom)
                    {
                        ApplicationArea = All;
                        Caption = 'Invoice Date from';
                    }
                    field(dateInvoiceDateTo; dateInvoiceDateTo)
                    {
                        ApplicationArea = All;
                        Caption = 'Invoice Date to';
                    }
                }

            }


        }
        trigger OnOpenPage()
        var

        begin

            if recCommWSHeader."Invoice Date From" <> 0D then
                dateInvoiceDateFrom := recCommWSHeader."Invoice Date From";
            if recCommWSHeader."Invoice Date To" <> 0D then
                dateInvoiceDateTo := recCommWSHeader."Invoice Date To";
        end;


    }
    trigger OnPreReport()
    var
        recCommWSHeader2: Record "Commission Worksheet Header";
        recCommWSHeader3: Record "Commission Worksheet Header";
        recSalesInvHeader: Record "Sales Invoice Header";
        recCommCustLedgEntry: Record "FTT-CST Commission Entries";
        recCommWSSalesInvLine: Record "Commission Worksheet Lines";
        recCommAggreementHdrt: Record "FTT-CST Comm. Agrm. Header";
        recSalespeopple: record "Salesperson/Purchaser";
        windows: Dialog;
        LineCount: Integer;
        TotalCount: Integer;
        CommSetup: Record "FTT-CST Commission Agr. Setup";
        CommPercent: Decimal;
    begin
        CommPercent := 0;
        if not CommSetup.Get() then
            exit;

        if not recCommAggreementHdrt.get(codAggreementCode) then
            exit;

        windows.Open('Calculating #1#############\' +
          '@2@@@@@@@@@@@@@@@@@@');

        recCommWSHeader2.Reset();
        recCommWSHeader2.SetRange("Document No.", recCommWSHeader."Document No.");
        if recCommWSHeader2.FindFirst() then begin
            recCommCustLedgEntry.Reset();
            recCommCustLedgEntry.SetFilter("Salesperson Code", recCommAggreementHdrt."Type No.");
            recCommCustLedgEntry.SetFilter("Document Date", '%1..%2', dateInvoiceDateFrom, dateInvoiceDateTo);
            recCommCustLedgEntry.SetRange(open, true);
            recCommCustLedgEntry.SetRange("Invoice Settled", true);
            recCommCustLedgEntry.SetFilter("Document Type", '%1', recCommCustLedgEntry."Document Type"::Invoice);

            if recCommCustLedgEntry.FindSet() then begin
                TotalCount := recCommCustLedgEntry.Count;
                repeat
                    CommPercent := recCommCustLedgEntry."Commission %";
                    recCommCustLedgEntry.CalcFields(recCommCustLedgEntry."Commission Amount (LCY)", recCommCustLedgEntry."Commission Base", recCommCustLedgEntry."Rem. Commission Amount (LCY)", recCommCustLedgEntry."Commission Amount", recCommCustLedgEntry."Rem. Commission Amount");
                    windows.Update(1, recCommCustLedgEntry."Document No.");
                    LineCount := LineCount + 1;
                    windows.Update(2, Round(LineCount / TotalCount * 10000, 1));
                    if recSalesInvHeader.get(recCommCustLedgEntry."Document No.") then
                        if (not recSalesInvHeader.Cancelled) then begin
                            recCommWSSalesInvLine.Reset();
                            recCommWSSalesInvLine.SetRange("Comm. Entry No.", recCommCustLedgEntry."Entry No.");
                            recCommWSSalesInvLine.SetRange("Inv, Document No.", recCommCustLedgEntry."Document No.");
                            recCommWSSalesInvLine.SetRange("Document Type", recCommCustLedgEntry."Document Type");
                            recCommWSSalesInvLine.SetRange("Sell-to Customer Name", recCommCustLedgEntry."Sell-to Customer Name");
                            if not recCommWSSalesInvLine.FindFirst() then begin
                                recCommWSSalesInvLine.Init();
                                recCommWSSalesInvLine."Document No." := recCommWSHeader2."Document No.";
                                recCommWSSalesInvLine."Line No." += 10000;
                                recCommWSSalesInvLine."Document Type" := recCommCustLedgEntry."Document Type";
                                recCommWSSalesInvLine."Inv, Document No." := recCommCustLedgEntry."Document No.";
                                recCommWSSalesInvLine."Commission %" := recCommCustLedgEntry."Commission %";
                                recCommWSSalesInvLine."Document Date" := recCommCustLedgEntry."Document Date";
                                recCommWSSalesInvLine."Sell-to Customer Name" := recCommCustLedgEntry."Sell-to Customer Name";
                                recCommWSSalesInvLine."Currency Code" := recCommCustLedgEntry."Currency Code";
                                recCommWSSalesInvLine."Commission Amount (LCY)" := recCommCustLedgEntry."Commission Amount (LCY)";
                                recCommWSSalesInvLine."Commission Base" := recCommCustLedgEntry."Commission Base";
                                recCommWSSalesInvLine."Commission Amount" := recCommCustLedgEntry."Commission Amount";
                                recCommWSSalesInvLine."Rem. Commission Amount" := recCommCustLedgEntry."Rem. Commission Amount";
                                recCommWSSalesInvLine."Rem. Commission Amount (LCY)" := recCommCustLedgEntry."Rem. Commission Amount (LCY)";
                                recCommWSSalesInvLine."Comm. Entry No." := recCommCustLedgEntry."Entry No.";
                                recCommWSSalesInvLine."Commission Agreement No." := recCommCustLedgEntry."Commission Agreement No.";
                                if recCommAggreementHdrt."Settlement Type" = recCommAggreementHdrt."Settlement Type"::"Full Payment" then
                                    recCommWSSalesInvLine."Application Amount" := recCommCustLedgEntry."Rem. Commission Amount"
                                else if recCommAggreementHdrt."Settlement Type" = recCommAggreementHdrt."Settlement Type"::"Partial Payment" then
                                    recCommWSSalesInvLine."Application Amount" := recCommCustLedgEntry."Rem. Commission Amount" / 2
                                else
                                    recCommWSSalesInvLine."Application Amount" := 0;
                                if recCommWSSalesInvLine.Insert() then begin
                                    Commit();
                                    recSalesInvHeader."Commission Computed" := true;
                                    recSalesInvHeader.Modify();
                                end;

                            end else begin
                                recCommWSHeader3.Reset();
                                recCommWSHeader3.SetRange("Document No.", recCommWSSalesInvLine."Document No.");
                                if recCommWSHeader3.FindFirst() then begin
                                    if (recCommWSHeader3.Status <> recCommWSHeader3.Status::"Payable Reversed") AND (recCommWSHeader3.Status <> recCommWSHeader3.Status::"Payment Reversed") AND (recCommWSHeader3.Status <> recCommWSHeader3.Status::"Payment Posted") then begin
                                        if not Confirm('Document No. %1 is still in-progress to this Commission Workshet No. %2. \ Do you want to skip this record?', False, recCommCustLedgEntry."Document No.", recCommWSSalesInvLine."Document No.") then
                                            exit;
                                    end else begin
                                        recCommWSSalesInvLine.Init();
                                        recCommWSSalesInvLine."Document No." := recCommWSHeader2."Document No.";
                                        recCommWSSalesInvLine."Line No." += 10000;
                                        recCommWSSalesInvLine."Document Type" := recCommCustLedgEntry."Document Type";
                                        recCommWSSalesInvLine."Inv, Document No." := recCommCustLedgEntry."Document No.";
                                        recCommWSSalesInvLine."Commission %" := recCommCustLedgEntry."Commission %";
                                        recCommWSSalesInvLine."Document Date" := recCommCustLedgEntry."Document Date";
                                        recCommWSSalesInvLine."Sell-to Customer Name" := recCommCustLedgEntry."Sell-to Customer Name";
                                        recCommWSSalesInvLine."Currency Code" := recCommCustLedgEntry."Currency Code";
                                        recCommWSSalesInvLine."Commission Amount (LCY)" := recCommCustLedgEntry."Commission Amount (LCY)";
                                        recCommWSSalesInvLine."Commission Base" := recCommCustLedgEntry."Commission Base";
                                        recCommWSSalesInvLine."Rem. Commission Amount (LCY)" := recCommCustLedgEntry."Rem. Commission Amount (LCY)";
                                        recCommWSSalesInvLine."Commission Amount" := recCommCustLedgEntry."Commission Amount";
                                        recCommWSSalesInvLine."Rem. Commission Amount" := recCommCustLedgEntry."Rem. Commission Amount";
                                        recCommWSSalesInvLine."Commission Agreement No." := recCommCustLedgEntry."Commission Agreement No.";
                                        if recCommAggreementHdrt."Settlement Type" = recCommAggreementHdrt."Settlement Type"::"Full Payment" then
                                            recCommWSSalesInvLine."Application Amount" := recCommCustLedgEntry."Rem. Commission Amount"
                                        else if recCommAggreementHdrt."Settlement Type" = recCommAggreementHdrt."Settlement Type"::"Partial Payment" then
                                            recCommWSSalesInvLine."Application Amount" := recCommCustLedgEntry."Rem. Commission Amount" / 2
                                        else
                                            recCommWSSalesInvLine."Application Amount" := 0;
                                        if recCommWSSalesInvLine.Insert() then begin
                                            Commit();
                                            recSalesInvHeader."Commission Computed" := true;
                                            recSalesInvHeader.Modify();
                                        end;
                                    end;
                                end;
                            end;
                        end;
                until recCommCustLedgEntry.Next() = 0;

                Commit();

                if not recSalespeopple.get(recCommAggreementHdrt."Type No.") then
                    exit;

                recCommWSSalesInvLine.Reset();
                recCommWSSalesInvLine.SetRange("Document No.", recCommWSHeader."Document No.");
                IF NOT recCommWSSalesInvLine.IsEmpty then begin
                    recCommWSHeader."Commission Agreement No." := recCommAggreementHdrt."Agreement No.";
                    recCommWSHeader."Agreement Period" := recCommAggreementHdrt."Agreement Period";
                    recCommWSHeader."Settlement Type" := recCommAggreementHdrt."Settlement Type";
                    recCommWSHeader.validate("Vendor No.  (SalesPerson)", recSalespeopple."Comm. Vendor No.");
                    recCommWSHeader."Invoice Date From" := dateInvoiceDateFrom;
                    recCommWSHeader."Payment Method Code" := recCommAggreementHdrt."Payment Method Code";
                    recCommWSHeader."PDC Bank Account No." := recCommAggreementHdrt."PDC Bank Account No.";
                    recCommWSHeader."Invoice Date To" := dateInvoiceDateTo;
                    recCommWSHeader."Commission %" := CommPercent;
                    recCommWSHeader.Status := recCommWSHeader.Status::Calculated;
                    recCommWSHeader.Modify();
                end;
            end else
                Error('No Record found!');
        end;
    end;

    //GlobalVar
    var

        codAggreementCode: Code[50];
        codSalesPersonCode: Code[20];
        recCommWSHeader: Record "Commission Worksheet Header";
        CommMgnt: Codeunit "FTT-CST Commission Mgt.";
        dateInvoiceDateFrom: Date;
        dateInvoiceDateTo: Date;

    procedure SetCommWorksheet(var CommWSHeader: Record "Commission Worksheet Header")
    begin
        recCommWSHeader := CommWSHeader;
    end;
}
