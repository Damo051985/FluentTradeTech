report 60000 "FTT-CST Pricing Ind. Template"
{
    ApplicationArea = All;
    Caption = 'Pricing Indication Template';
    DefaultLayout = RDLC;
    RDLCLayout = './layout/Pricing Indication Template.rdlc';

    dataset
    {
        dataitem(PriceListHeader; "Price List Header")
        {
            DataItemTableView = sorting(Code);
            column(CompanyLogo; CompanyInformation.Picture)
            {
            }
            column(ClientNameValue; ClientNameValue)
            {
            }
            column(FluenPricingIndicationLbl; FluenPricingIndicationLbl)
            {
            }
            column(PricingIndicationDate; PricingIndicationDate)
            {
            }
            column(ProjectDescription; ProjectDescription)
            {
            }
            column(CompanyAddressValue; CompanyInformation.Address)
            {
            }
            column(CompanyAddress2Value; CompanyInformation."Address 2")
            {
            }
            column(CompanyCityValue; CompanyInformation.City)
            {
            }
            column(CompanyCountryValue; CountryRegion.Name)
            {
            }
            column(CompanyPostCodeValue; CompanyInformation."Post Code")
            {
            }
            column(CompanyPhoneNoValue; CompanyInformation."Phone No.")
            {
            }
            column(CompanyHomePageValue; CompanyInformation."Home Page")
            {
            }
            column(StrictlyConfidential; StrictlyConfidentialLbl)
            {
            }
            column(CurrencyCodeValue; CurrencyCodeValue)
            {
            }
            column(CurrencySymbolValue; CurrencySymbolValue)
            {
            }
            dataitem(PriceListLine; "Price List Line")
            {
                DataItemLink = "Price List Code" = field(Code);
                DataItemTableView = sorting("Price List Code") where("Asset Type" = filter(Item),
                    "Amount Type" = filter(<> Discount));

                column(ItemCategoryValue; ItemCategoryValue)
                {
                }
                column(FTTCSTOptionalForPI; PriceListLine."FTT-CST Optional for PI")
                {
                }
                column(ItemNo; PriceListLine."Asset No.")
                {
                }
                column(ItemTextValue; ItemTextValue)
                {
                }
                column(ItemNRCPriceValue; ItemNRCPriceValue)
                {
                }
                column(ItemMRCPriceValue; ItemMRCPriceValue)
                {
                }
                column(ItemYRCPriceValue; ItemYRCPriceValue)
                {
                }

                trigger OnAfterGetRecord()
                begin
                    GetItemCategoryValue();
                    GetEntityTextValue();
                    GetItemPriceValue();
                end;
            }

            trigger OnPreDataItem()
            begin
                PriceListHeader.SetRange(Code, SalesPriceListCode);
            end;

            trigger OnAfterGetRecord()
            begin
                GetClientNameValue();
                GetCurrencyValue();
            end;
        }
    }
    requestpage
    {
        layout
        {
            area(Content)
            {
                group(Option)
                {
                    field(SalesPriceListCode; SalesPriceListCode)
                    {
                        ApplicationArea = All;
                        Caption = 'Sales Price List Code';
                        TableRelation = "Price List Header".Code where("Source Group" = filter(Customer), "Price Type" = filter(Sale));
                    }
                    field(PricingIndicationDate; PricingIndicationDate)
                    {
                        ApplicationArea = All;
                        Caption = 'Pricing Indication Date';
                    }
                    field(ProjectDescription; ProjectDescription)
                    {
                        ApplicationArea = All;
                        Caption = 'Project Description';
                        MultiLine = true;
                    }
                }
            }
        }
    }

    trigger OnInitReport()
    begin
        CompanyInformation.SetAutoCalcFields(Picture);
        CompanyInformation.Get();
        CountryRegion.Get(CompanyInformation."Country/Region Code");
    end;

    trigger OnPreReport()
    begin
        if SalesPriceListCode = '' then
            Error(SalesPriceListCodeErr);
    end;

    local procedure GetItemCategoryValue()
    var
        Item: Record Item;
        ItemCategory: Record "Item Category";
        ItemCategoryValueFound: Boolean;
    begin
        Item.Get(PriceListLine."Asset No.");
        if Item."Item Category Code" = '' then begin
            ItemCategoryValue := Item.Description;
            exit;
        end;

        ItemCategory.Get(Item."Item Category Code");
        while not ItemCategoryValueFound do
            if ItemCategory.Indentation = 0 then begin
                ItemCategoryValue := ItemCategory.Description;
                ItemCategoryValueFound := true;
            end else
                ItemCategory.Get(ItemCategory."Parent Category");
    end;

    local procedure GetClientNameValue()
    var
        Contact: Record Contact;
        Customer: Record Customer;
        PriceListHeaderLocal: Record "Price List Header";
    begin
        PriceListHeaderLocal.Get(PriceListHeader.Code);
        case PriceListHeaderLocal."Source Type" of
            "Price Source Type"::Customer:
                begin
                    Customer.Get(PriceListHeaderLocal."Source No.");
                    ClientNameValue := Customer.Name;
                end;
            "Price Source Type"::Contact:
                begin
                    Contact.Get(PriceListHeaderLocal."Source No.");
                    ClientNameValue := Contact.Name;
                end;
            else
                ClientNameValue := '';
        end;
    end;

    local procedure GetCurrencyValue()
    var
        Currency: Record Currency;
        GeneralLedgerSetup: Record "General Ledger Setup";
    begin
        if PriceListHeader."Currency Code" = '' then begin
            GeneralLedgerSetup.Get();
            CurrencyCodeValue := GeneralLedgerSetup."LCY Code";
            CurrencySymbolValue := GeneralLedgerSetup."Local Currency Symbol";
        end else begin
            Currency.Get(PriceListHeader."Currency Code");
            CurrencyCodeValue := Currency."ISO Code";
            CurrencySymbolValue := Currency.Symbol;
        end;
    end;

    local procedure GetEntityTextValue()
    var
        EntityText: Record "Entity Text";
        Item: Record Item;
        EntityTextCodeunit: Codeunit "Entity Text";
    begin
        Item.Get(PriceListLine."Asset No.");

        ItemTextValue := '';

        EntityText.SetRange(Company, CompanyName);
        EntityText.SetRange("Source Table Id", 27);
        EntityText.SetRange("Source System Id", Item.SystemId);
        EntityText.SetRange(Scenario, 0);
        if EntityText.FindSet() then
            ItemTextValue := EntityTextCodeunit.GetText(EntityText);
    end;

    local procedure GetItemPriceValue()
    var
        Currency: Record Currency;
        GeneralLedgerSetup: Record "General Ledger Setup";
        Item: Record Item;
        UnitPriceText: Text;
    begin
        Item.Get(PriceListLine."Asset No.");

        if PriceListLine."Unit Price" = 0 then
            UnitPriceText := EmptyUnitPriceLbl
        else
            if PriceListHeader."Currency Code" = '' then begin
                GeneralLedgerSetup.Get();
                UnitPriceText := GeneralLedgerSetup."Local Currency Symbol" + ' ' + Format(PriceListLine."Unit Price");
            end else begin
                Currency.Get(PriceListHeader."Currency Code");
                UnitPriceText := Currency.Symbol + ' ' + Format(PriceListLine."Unit Price");
            end;

        case Item."FTT-CST Cost Type" of
            "FTT-CST Cost Type"::NRC:
                begin
                    ItemNRCPriceValue := UnitPriceText;
                    ItemMRCPriceValue := '';
                    ItemYRCPriceValue := '';
                end;
            "FTT-CST Cost Type"::MRC:
                begin
                    ItemNRCPriceValue := '';
                    ItemMRCPriceValue := UnitPriceText;
                    ItemYRCPriceValue := '';
                end;
            "FTT-CST Cost Type"::YRC:
                begin
                    ItemNRCPriceValue := '';
                    ItemMRCPriceValue := '';
                    ItemYRCPriceValue := UnitPriceText;
                end;
        end;
    end;

    var
        CompanyInformation: Record "Company Information";
        CountryRegion: Record "Country/Region";
        SalesPriceListCode: Code[20];
        PricingIndicationDate: Date;
        EmptyUnitPriceLbl: Label 'Total to be determined by precise requirements';
        FluenPricingIndicationLbl: Label 'Fluent pricing indication';
        SalesPriceListCodeErr: Label 'Sales Price List Code should be filled';
        StrictlyConfidentialLbl: Label 'STRICTLY CONFIDENTIAL';
        ClientNameValue: Text;
        CurrencyCodeValue: Text;
        CurrencySymbolValue: Text;
        ItemCategoryValue: Text;
        ItemMRCPriceValue: Text;
        ItemNRCPriceValue: Text;
        ItemTextValue: Text;
        ItemYRCPriceValue: Text;
        ProjectDescription: Text[250];
}