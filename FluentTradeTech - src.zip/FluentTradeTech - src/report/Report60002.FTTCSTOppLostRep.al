report 60002 "Opportunity Lost Report"
{
    ApplicationArea = Basic, Suite;
    Caption = 'Revenue Report';
    UsageCategory = ReportsAndAnalysis;
    DefaultLayout = RDLC;
    RDLCLayout = './layout/Opportunity Lost Report.rdlc';


    dataset
    {
        dataitem(Opportunity; Opportunity)
        {
            DataItemTableView = WHERE("Status" = FILTER(Lost));
            column(ActivateFirstStage; "Activate First Stage")
            {
            }
            column(CalcdCurrentValueLCY; "Calcd. Current Value (LCY)")
            {
            }
            column(CampaignDescription; "Campaign Description")
            {
            }
            column(CampaignNo; "Campaign No.")
            {
            }
            column(ChancesofSuccess; "Chances of Success %")
            {
            }
            column(Closed; Closed)
            {
            }
            column(Comment; Comment)
            {
            }
            column(Completed; "Completed %")
            {
            }
            column(ContactCompanyName; "Contact Company Name")
            {
            }
            column(ContactCompanyNo; "Contact Company No.")
            {
            }
            column(ContactName; "Contact Name")
            {
            }
            column(ContactNo; "Contact No.")
            {
            }
            column(CoupledtoDataverse; "Coupled to Dataverse")
            {
            }
            column(CreationDate; "Creation Date")
            {
            }
            column(CurrentSalesCycleStage; "Current Sales Cycle Stage")
            {
            }
            column(DateClosed; "Date Closed")
            {
            }
            column(Description; Description)
            {
            }
            column(EstimatedClosingDate; "Estimated Closing Date")
            {
            }
            column(EstimatedValueLCY; "Estimated Value (LCY)")
            {
            }
            column(FTTCSTNotifMailGrCode; "FTT-CST Notif. Mail. Gr. Code")
            {
            }
            column(FTTCSTOnHold; "FTT-CST OnHold")
            {
            }
            column(No; "No.")
            {
            }
            column(NoSeries; "No. Series")
            {
            }
            column(NoofInteractions; "No. of Interactions")
            {
            }
            column(Priority; Priority)
            {
            }
            column(Probability; "Probability %")
            {
            }
            column(SalesCycleCode; "Sales Cycle Code")
            {
            }
            column(SalesDocumentNo; "Sales Document No.")
            {
            }
            column(SalesDocumentType; "Sales Document Type")
            {
            }
            column(SalespersonCode; "Salesperson Code")
            {
            }
            column(SalespersonName; "Salesperson Name")
            {
            }
            column(SegmentDescription; "Segment Description")
            {
            }
            column(SegmentNo; "Segment No.")
            {
            }
            column(Status; Status)
            {
            }
            column(WizardCampaignDescription; "Wizard Campaign Description")
            {
            }
            column(WizardChancesofSuccess; "Wizard Chances of Success %")
            {
            }
            column(WizardContactName; "Wizard Contact Name")
            {
            }
            column(WizardEstimatedClosingDate; "Wizard Estimated Closing Date")
            {
            }
            column(WizardEstimatedValueLCY; "Wizard Estimated Value (LCY)")
            {
            }
            column(WizardStep; "Wizard Step")
            {
            }
            trigger OnAfterGetRecord()
            var
            Begin

            End;

            Trigger OnPreDataItem()
            var
            Begin
                Calcfields(Comment, "Current Sales Cycle Stage", "Estimated Value (LCY)", "Probability %", "Calcd. Current Value (LCY)", "Chances of Success %", "Completed %", "Contact Name", "Salesperson Name", "Campaign Description", "Estimated Closing Date", "No. of Interactions");
            End;
        }
    }
    requestpage
    {
        layout
        {
            area(Content)
            {
                group(GroupName)
                {
                }
            }
        }
        actions
        {
            area(Processing)
            {
            }
        }
    }
    Var
        Opp: record Opportunity;
}
