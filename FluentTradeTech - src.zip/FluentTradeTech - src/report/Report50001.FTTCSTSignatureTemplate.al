report 50001 "Signature Template"
{
    DefaultLayout = Word;
    WordLayout = './src/Report/Layout/signature2.docx';
    UseRequestPage = false;
    dataset
    {
        dataitem(datUserSetup; "User Setup")
        {
            column(Full_Name; UserfullName)
            {

            }
            column(MobileNo; 'Mobile No.: ' + UserPhoneNo)
            {

            }
            column(Emailid; 'Email: ' + UserEmailID)
            {

            }
            column(Position; UserJobPosition)
            {

            }
            column(CompanyPicture; recCompanyInfo.Picture)
            {

            }
            column(CompanyName; recCompanyInfo.Name)
            {

            }
            column(SincereLyMes; SincereMessage)
            {

            }

        }
    }


    trigger OnPreReport()
    var
        UserSetup: Record "User Setup";
    begin
        recCompanyInfo.Get;
        recCompanyInfo.CalcFields(Picture);
        if not UserSetup.Get(UserId) then
            exit;

        UserfullName := UserSetup."Full Name";
        UserPhoneNo := UserSetup."Phone No.";
        UserEmailID := UserSetup."E-Mail";
        UserJobPosition := UserSetup."Job Position";
        SincereMessage := UserSetup."Last Remark Message";
    end;

    var
        recCompanyInfo: Record "Company Information";
        UserfullName: Text[250];
        UserPhoneNo: Text[30];
        UserEmailID: Text[100];
        UserJobPosition: Text[250];
        SincereMessage: Text[250];
}