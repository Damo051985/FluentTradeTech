tableextension 60011 "FTT-CST SalesReceivablesSetup" extends "Sales & Receivables Setup"
{
    fields
    {
        field(60000; "MSA Control in SO Posting"; Boolean)
        {
            Caption = 'MSA Control in SO Posting';
            DataClassification = CustomerContent;
        }
        field(60001; "FTT-CST Item Region Dim. Code"; Code[20])
        {
            Caption = 'Item Region Dimension Code';
            DataClassification = CustomerContent;
            TableRelation = Dimension.Code;
        }
        field(60002; "FTT-CST Redundancy Category"; Code[20])
        {
            Caption = 'Redundancy Item Category';
            DataClassification = CustomerContent;
            TableRelation = "Item Category".Code;
            trigger OnValidate()
            begin
                UpdateRedundancyCategory();
            end;
        }
        field(60003; "FTT-CST DR Category"; Code[20])
        {
            Caption = 'DR Item Category';
            DataClassification = CustomerContent;
            TableRelation = "Item Category".Code;
            trigger OnValidate()
            begin
                UpdateDRCategory();
            end;
        }
        field(60004; "FTT-CST Integration Category"; Code[20])
        {
            Caption = 'Integration Item Category';
            DataClassification = CustomerContent;
            TableRelation = "Item Category".Code;
            trigger OnValidate()
            begin
                //UpdateDRCategory();
            end;
        }
        field(60005; "FTT-CST Shared MRC CC Category"; Code[20])
        {
            Caption = 'Shared MRC Cross Connect Category';
            DataClassification = CustomerContent;
            TableRelation = "Item Category".Code;
            trigger OnValidate()
            begin
            end;
        }
        field(60006; "FTT-CST Shared NRC CC Category"; Code[20])
        {
            Caption = 'Shared NRC Cross Connect Category';
            DataClassification = CustomerContent;
            TableRelation = "Item Category".Code;
            trigger OnValidate()
            begin
            end;
        }
        field(60007; "FTT-CST Ded. NRC CC Category"; Code[20])
        {
            Caption = 'Dedicated NRC Cross Connect Category';
            DataClassification = CustomerContent;
            TableRelation = "Item Category".Code;
            trigger OnValidate()
            begin
            end;
        }
        field(60008; "FTT-CST Ded. MRC CC Category"; Code[20])
        {
            Caption = 'Dedicated MRC Cross Connect Category';
            DataClassification = CustomerContent;
            TableRelation = "Item Category".Code;
            trigger OnValidate()
            begin
            end;
        }
        //Hosting and management
        field(60009; "FTT-CST Hosting and management"; Code[20])
        {
            Caption = 'Hosting and management Category';
            DataClassification = CustomerContent;
            TableRelation = "Item Category".Code;
            trigger OnValidate()
            begin
            end;
        }
        //Servers set up
        field(60010; "FTT-CST Servers Set Up"; Code[20])
        {
            Caption = 'Servers Set Up';
            DataClassification = CustomerContent;
            TableRelation = "Item Category".Code;
            trigger OnValidate()
            begin
            end;
        }
        field(60011; "FTT-CST HARDWARE"; code[20])
        {
            Caption = 'Hardware Category';
            DataClassification = CustomerContent;
            TableRelation = "Item Category".Code;
        }
        field(60012; "FTT-CST STANDARD TAKER FEED"; code[20])
        {
            Caption = 'STANDARD TAKER FEED Category';
            DataClassification = CustomerContent;
            TableRelation = "Item Category".Code;
        }
        field(60013; "FTT-CST NS TAKER FEED"; code[20])
        {
            Caption = 'NS TAKER FEED Category';
            DataClassification = CustomerContent;
            TableRelation = "Item Category".Code;
        }
        //STANDARD MAKER FEED
        field(60014; "FTT-CST STANDARD MAKER FEED"; code[20])
        {
            Caption = 'STANDARD MAKER FEED Category';
            DataClassification = CustomerContent;
            TableRelation = "Item Category".Code;
        }
        field(60015; "FTT-CST NS MAKER FEED"; code[20])
        {
            Caption = 'NS MAKER FEED Category';
            DataClassification = CustomerContent;
            TableRelation = "Item Category".Code;
        }
        field(60018; "FTT-CST LICENSE"; code[20])
        {
            Caption = 'LICENSE Category';
            DataClassification = CustomerContent;
            TableRelation = "Item Category".Code;
        }
        field(60019; "FTT-CST Parent CROSS CONNECT"; code[20])
        {
            Caption = 'Parent CROSS CONNECT Category';
            DataClassification = CustomerContent;
            TableRelation = "Item Category".Code;
        }
        field(60020; "FTT-CST Parent FEED"; code[20])
        {
            Caption = 'Parent Feed Category';
            DataClassification = CustomerContent;
            TableRelation = "Item Category".Code;
        }
        field(60021; "FTT-CST INTERNATIONAL Line"; code[20])
        {
            Caption = 'INTERNATIONAL Line Category';
            DataClassification = CustomerContent;
            TableRelation = "Item Category".Code;
        }


    }

    local procedure UpdateRedundancyCategory()
    var
        ItemCategory: Record "Item Category";
    begin
        if Rec."FTT-CST Redundancy Category" = '' then
            exit;

        ItemCategory.Get(Rec."FTT-CST Redundancy Category");
        if ItemCategory."FTT-CST Redundancy Base Item" then begin
            if not Dialog.Confirm(StrSubstNo(UpdateRedundancyCategoryConfirm,
                    ItemCategory.Code,
                    ItemCategory.FieldCaption("FTT-CST Redundancy Base Item"),
                    Rec.FieldCaption("FTT-CST Redundancy Category")
                )) then
                Error('');
            ItemCategory."FTT-CST Redundancy Base Item" := false;
            ItemCategory.Modify();
        end;
    end;

    local procedure UpdateDRCategory()
    var
        ItemCategory: Record "Item Category";
    begin
        if Rec."FTT-CST DR Category" = '' then
            exit;

        ItemCategory.Get(Rec."FTT-CST DR Category");
        if ItemCategory."FTT-CST DR Base Item" then begin
            if not Dialog.Confirm(StrSubstNo(UpdateRedundancyCategoryConfirm,
                    ItemCategory.Code,
                    ItemCategory.FieldCaption("FTT-CST Redundancy Base Item"),
                    Rec.FieldCaption("FTT-CST Redundancy Category")
                )) then
                Error('');
            ItemCategory."FTT-CST Redundancy Base Item" := false;
            ItemCategory.Modify();
        end;
    end;

    var
        UpdateRedundancyCategoryConfirm: Label 'For the category %1, the %2 check-box is selected. If you specify it as %3, the %2 check-box will be cleared. Do you want to continue?';
}
