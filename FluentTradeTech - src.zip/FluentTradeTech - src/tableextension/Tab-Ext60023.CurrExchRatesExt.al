tableextension 60023 "CurrExchRates-Ext" extends "Currency Exchange Rate"
{
    fields
    {
        field(50000; "FTTCST Updated to Rate"; Boolean)
        {
            Caption = 'Updated to Rate';
            DataClassification = ToBeClassified;
        }
    }
}
