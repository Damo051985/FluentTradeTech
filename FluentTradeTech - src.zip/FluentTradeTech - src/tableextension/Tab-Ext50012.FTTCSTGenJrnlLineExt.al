tableextension 50012 "FTT-CST Gen. Jrnl Line Ext." extends "Gen. Journal Line"
{
    fields
    {
        field(60005; "Comm. Document No."; code[20])
        {
            DataClassification = ToBeClassified;
        }

    }

    keys
    {
        // Add changes to keys here
    }

    fieldgroups
    {
        // Add changes to field groups here
    }

    var
        myInt: Integer;
}