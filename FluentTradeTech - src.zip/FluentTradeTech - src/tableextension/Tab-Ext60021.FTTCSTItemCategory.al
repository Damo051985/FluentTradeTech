tableextension 60021 "FTT-CST ItemCategory" extends "Item Category"
{
    fields
    {
        field(60000; "FTT-CST Redundancy Base Item"; Boolean)
        {
            Caption = 'Redundancy Base Item';
            DataClassification = CustomerContent;

            trigger OnValidate()
            begin
                UpdateRedundancyBaseItem();
            end;
        }
        field(60001; "FTT-CST DR Base Item"; Boolean)
        {
            Caption = 'DR Base Item';
            DataClassification = CustomerContent;

            trigger OnValidate()
            begin
                UpdateRedundancyBaseItem();
            end;
        }
        field(60002; "FTT-CST  Integration Base Item"; Boolean)
        {
            Caption = 'Integration Base Item';
            DataClassification = CustomerContent;

            trigger OnValidate()
            begin
                //IVS No needs for UpdateRedundancyBaseItem();
            end;
        }
    }

    local procedure UpdateRedundancyBaseItem()
    var
        SalesReceivablesSetup: Record "Sales & Receivables Setup";
    begin
        if not Rec."FTT-CST Redundancy Base Item" then
            exit;

        SalesReceivablesSetup.Get();
        if SalesReceivablesSetup."FTT-CST Redundancy Category" <> Rec.Code then
            exit;

        Error(UpdateRedundancyBaseItemErr, Rec.Code, SalesReceivablesSetup.FieldCaption("FTT-CST Redundancy Category"));
    end;

    local procedure UpdateDRBaseItem()
    var
        SalesReceivablesSetup: Record "Sales & Receivables Setup";
    begin
        if not Rec."FTT-CST DR Base Item" then
            exit;

        SalesReceivablesSetup.Get();
        if SalesReceivablesSetup."FTT-CST DR Category" <> Rec.Code then
            exit;

        Error(UpdateRedundancyBaseItemErr, Rec.Code, SalesReceivablesSetup.FieldCaption("FTT-CST DR Category"));
    end;

    var
        UpdateRedundancyBaseItemErr: Label 'The category %1 is indicated as %2 on the Sales & Receivables Setup page.';
}
