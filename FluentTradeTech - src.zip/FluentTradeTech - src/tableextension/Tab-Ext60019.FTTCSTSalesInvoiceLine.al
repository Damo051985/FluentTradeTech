tableextension 60019 "FTT-CST Sales Invoice Line" extends "Sales Invoice Line"
{
    fields
    {
        field(60000; "FTT-CST Cost Type"; Enum "FTT-CST Cost Type")
        {
            Caption = 'Cost Type';
            DataClassification = CustomerContent;
            Editable = false;
        }
        field(60001; "FTT-CST Agreement Date From"; Date)
        {
            Caption = 'Agreement Starting Date';
            DataClassification = CustomerContent;
            Editable = false;
        }
        field(60002; "FTT-CST Agreement Date To"; Date)
        {
            Caption = 'Agreement Ending Date';
            DataClassification = CustomerContent;
            Editable = false;
        }
        field(60003; "FTT-CST Copied Document Type"; Enum "Sales Document Type From")
        {
            Caption = 'Copied Document Type';
            DataClassification = CustomerContent;
        }
        field(60004; "FTT-CST Copied Document No."; Code[20])
        {
            Caption = 'Copied Document No.';
        }
        field(60005; "FTT-CST Copied Line No."; Integer)
        {
            Caption = 'Copied Line No.';
        }
        field(60007; "FTT-CST Delivery PROD Date"; Date)
        {
            Caption = 'Delivery PROD Date';
            DataClassification = CustomerContent;
        }
        field(60008; "FTT-CST Delivery UAT Date"; Date)
        {
            Caption = 'Delivery UAT Date';
            DataClassification = CustomerContent;

        }
        field(60009; "FTT-CST Optional"; Option)
        {
            OptionMembers = No,Yes;
            Caption = 'Optional';

        }

        field(60010; "FTT-CST Parent Item Cat. Code"; Code[20])
        {
            Caption = 'Parent Item Category Code';
            TableRelation = "Item Category";
        }
        field(60011; "FTT-CST Comments"; text[250])
        {
            Caption = 'Internal Comments';
        }
        field(60012; "FTT-CST Unit Price"; Decimal)
        {
            AutoFormatExpression = GetCurrencyCode();
            AutoFormatType = 2;
            CaptionClass = GetCaptionClass(FieldNo("Unit Price"));
            Caption = 'Unit Price Optional';
        }
        field(60013; "FTT-CST Use for Discount"; Boolean)
        {
            Caption = 'Use for discount';
        }
        field(60014; "FTT-CST Comments Fluent"; text[250])
        {
            Caption = 'Fluent Comments';
        }
        field(60015; "FTT-CST DR"; Option)
        {
            Caption = 'DR';
            OptionMembers = No,Yes;
        }
        field(60016; "FTT-CST Redundancy"; Option)
        {
            Caption = 'Redundancy';
            OptionMembers = No,Yes;
        }
        field(60017; "FTT-CST Redundancy PriceCalc %"; decimal)
        {
            Caption = 'Price Rec %';

        }
        field(60018; "FTT-CST Location Code"; code[20])
        {
            Caption = 'Location Code';
        }
        field(60019; "FTT-CST Location Type"; enum "FTT-CST Location Type")
        {
            Caption = 'Location Type';
        }
        field(60020; "FTT-CST Component Option"; Option)
        {
            Caption = 'Location Type';
            DataClassification = CustomerContent;
            OptionMembers = Blank,Hosted,NonHosted,Unknown;
            OptionCaption = '. . . . . . .,Hosted,Non Hosted,Unknown';
        }
        field(60021; "FTT-CST Sublocation"; Option)
        {
            DataClassification = ToBeClassified;
            OptionMembers = Blank,LD4,LD42,NY2,NY4,NY6,TY3,SG1,None;
            OptionCaption = '. . . . . . .,LD 4,LD 4.2,NY 2,NY 4,NY 6,TY 3,SG 1, None';
            Caption = 'Sublocation';
        }
        field(60022; "FTT-CST Qty"; Decimal)
        {
            Caption = 'Qty from Dependancy';
        }
        field(60023; "FTT-CST Order Type"; Option)
        {
            OptionMembers = Primary,Renewal,Additions;
            OptionCaption = 'Primary,Renewal,Additions';
            DataClassification = CustomerContent;
            Caption = 'Order Type';
        }
        field(60024; "FTT-CST Primary Order"; Code[20])
        {
            TableRelation = "Sales Header"."No.";
            DataClassification = CustomerContent;
            Caption = 'Primary Order No.';
        }
        field(60025; "FTT-CST Main Order No."; code[20])
        {
            TableRelation = "Sales Header"."No.";
            DataClassification = CustomerContent;
            Caption = 'Main Order No.';
        }
        field(60026; "FTT-CST Use for Renewal"; Boolean)
        {
            Caption = 'Use for Renewal';
        }
        //NRD
        field(60027; "SDP Items"; Boolean)
        {
            DataClassification = ToBeClassified;
        }
        field(60028; "isRedundancyCalculated"; Boolean)
        {
            DataClassification = ToBeClassified;
        }
        field(60029; "isIntegCalculated"; Boolean)
        {
            DataClassification = ToBeClassified;
        }
        field(60030; "isDRCalculated"; Boolean)
        {
            DataClassification = ToBeClassified;
        }
        field(60031; "FTT-CST Integration"; Option)
        {
            Caption = 'Integration';
            OptionMembers = No,Yes;
        }
        field(60032; "Commission Base Amount (LCY)"; Decimal) //NRD
        {
            DataClassification = ToBeClassified;
        }
        field(60033; "FTT-CST Salesp. Comm. Type"; Enum "FTT-CST SalespCommType") //NRD
        {
            Caption = 'Salesperson Commission Type';
            DataClassification = CustomerContent;
        }
        field(60034; "FTT-CST Eligible"; Boolean) //NRD
        {
            Caption = 'Eligible';
            DataClassification = CustomerContent;
        }
        field(60035; "Commission Base Amount"; Decimal) //NRD
        {
            DataClassification = ToBeClassified;
        }
        field(60036; "Agreement Period"; Integer) //nrd
        {
            DataClassification = ToBeClassified;
        }
        field(60037; "Commission Agreement No."; code[50]) //nrd
        {
            DataClassification = ToBeClassified;
            TableRelation = "FTT-CST Comm. Agrm. Header"."Agreement No.";
        }
        field(60039; "Commission Rate %"; Decimal) //nrd
        {
            DataClassification = ToBeClassified;
        }

    }
}
