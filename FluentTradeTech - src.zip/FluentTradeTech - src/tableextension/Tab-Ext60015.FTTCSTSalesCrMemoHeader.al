tableextension 60015 "FTT-CST Sales CrMemo Header" extends "Sales Cr.Memo Header"
{
    fields
    {
        field(60003; "FTT-CST Agr. Period Number"; Integer)
        {
            Caption = 'Agreement Period Number';
            DataClassification = CustomerContent;
        }
        field(60004; "Total Comm. Base Amt. (LCY)"; Decimal)
        {
            FieldClass = FlowField;
            Caption = 'Total Commission Base Amount (LCY)';
            CalcFormula = sum("Sales Cr.Memo Line"."Commission Base Amount (LCY)" where("Document No." = field("No.")));

        }
        field(60005; "Total Comm. Base Amt."; Decimal)
        {
            FieldClass = FlowField;
            Caption = 'Total Commission Base Amount';
            CalcFormula = sum("Sales Cr.Memo Line"."Commission Base Amount" where("Document No." = field("No.")));

        }
    }
}
