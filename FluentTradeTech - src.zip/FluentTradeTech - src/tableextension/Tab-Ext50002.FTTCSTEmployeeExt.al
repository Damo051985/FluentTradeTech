tableextension 50002 "Employee Table ext." extends Employee
{
    fields
    {
        // Add changes to table fields here
        field(50001; "Department"; Enum "Department Filter")
        {
            DataClassification = ToBeClassified;
        }
        field(50005; "Emergency Contact No."; Text[250])
        {
            DataClassification = ToBeClassified;
            caption = 'Emergency Contact No.';
        }
        field(50010; "Allergies"; Code[20])
        {
            DataClassification = ToBeClassified;
            caption = 'Allergies';
        }
    }

    keys
    {
        // Add changes to keys here
    }

    fieldgroups
    {
        // Add changes to field groups here
    }

    var
        myInt: Integer;
}