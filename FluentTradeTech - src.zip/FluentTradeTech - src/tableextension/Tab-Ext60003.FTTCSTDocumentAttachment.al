tableextension 60003 "FTT-CST Document Attachment" extends "Document Attachment"
{
    fields
    {
        field(60000; "FTT-CST Expiration Date"; Date)
        {
            Caption = 'Expiration Date';
            DataClassification = CustomerContent;

            trigger OnValidate()
            begin
                if "FTT-CST Expiration Date" <> 0D then
                    case true of
                        Format("FTT-CST Notification Period") <> '':
                            CalcNotificationDate();
                        ("FTT-CST Notification Date" <> 0D) and (Format("FTT-CST Notification Period") = ''):
                            CalcNotificationPeriod();
                    end;
            end;
        }
        field(60001; "FTT-CST Notification Period"; DateFormula)
        {
            Caption = 'Notification Period';
            DataClassification = CustomerContent;

            trigger OnValidate()
            begin
                if Format("FTT-CST Notification Period") = '' then
                    "FTT-CST Notification Date" := 0D
                else
                    if "FTT-CST Expiration Date" <> 0D then
                        CalcNotificationDate();
            end;
        }
        field(60002; "FTT-CST Notification Date"; Date)
        {
            Caption = 'Notification Date';
            DataClassification = CustomerContent;

            trigger OnValidate()
            begin
                if "FTT-CST Notification Date" = 0D then
                    Clear("FTT-CST Notification Period")
                else
                    if "FTT-CST Expiration Date" <> 0D then
                        CalcNotificationPeriod();
            end;
        }
        field(60003; "MSA Document"; Boolean)
        {
            Caption = 'MSA';
            DataClassification = CustomerContent;
            trigger OnValidate()
            var
                lDocAtt: Record "Document Attachment";
            Begin

            End;
        }
        field(60004; "FTT-CST SOW Document"; Boolean)
        {
            Caption = 'SOW';
            DataClassification = CustomerContent;
            trigger OnValidate()
            var
                lDocAtt: Record "Document Attachment";
            Begin

            End;
        }
        field(60005; "FTT-CST Table Name"; code[20])
        {
            Caption = 'Table Name';
            DataClassification = CustomerContent;
        }
        field(60006; "FTT-CST Customer No."; code[20])
        {
            Caption = 'Customer No.';
            DataClassification = CustomerContent;
            TableRelation =
            IF ("FTT-SCT Record Type" = CONST(Customer)) Customer
            ELSE
            IF ("FTT-SCT Record Type" = CONST("Contact")) Contact;
        }
        field(60008; "FTT-CST Customer Name"; Text[100])
        {
            Caption = 'Customer Name';
            DataClassification = CustomerContent;
        }

        field(60007; "FTT-SCT Record Type"; enum "FTT-CST DocumentAttachmentType")
        {
            Caption = 'Entity Type';
            DataClassification = CustomerContent;
        }
        field(60009; "FTT-CST Starting Date"; Date)
        {
            Caption = 'Starting Date';
            DataClassification = CustomerContent;
        }
        field(60010; "FTT-CST Final Document"; Boolean) //NRD
        {
            Caption = 'Final Document';
            DataClassification = ToBeClassified;
        }
        field(60011; "FTT-CST Google Drive Link"; Text[1024]) //NRD
        {
            Caption = 'Google Drive Link';
            DataClassification = ToBeClassified;
        }
        //>>dan 082924
        field(60012; "FTT-CST Employee"; Code[20])
        {
            Caption = 'Employee';
            DataClassification = ToBeClassified;
            TableRelation = Employee;
        }
        Field(60020; "FTT-CST NDA"; Boolean)
        {
            Caption = 'NDA';
            DataClassification = CustomerContent;
            trigger OnValidate()
            var
                lDocAtt: Record "Document Attachment";
            Begin

            End;
        }
        Field(60025; "FTT-CST Document Type"; Option)
        {
            Caption = 'Document Type';
            OptionMembers = "Others","SOW","MSA","NDA","Employment Contract","Medical Contract";
            OptionCaption = 'Others,SOW,MSA,NDA,Employment Contract,Medical Contract';
            DataClassification = CustomerContent;
            trigger OnValidate()
            var
                lDocAtt: Record "Document Attachment";
            Begin

            End;
        }
        field(60030; "FTT-CST Others"; Boolean)
        {
            Caption = 'Others';
            DataClassification = CustomerContent;
            trigger OnValidate()
            var
                lDocAtt: Record "Document Attachment";
            Begin

            End;
        }
        field(60040; "FTT-CST Contact Name"; Text[100])
        {
            Caption = 'Contact Name';
            DataClassification = CustomerContent;
            Editable = False;
            trigger OnValidate()
            var

            Begin

            End;
        }
        field(60050; "FTT-CST Document Name"; Text[240])
        {
            Caption = 'Document Name';
            DataClassification = CustomerContent;
            Editable = True;
        }
        field(60055; "FTT-CST Serial Number"; Text[240])
        {
            Caption = 'Serial Number';
            DataClassification = CustomerContent;
            Editable = True;
        }
        field(60060; "Employment Contract"; Boolean)
        {
            Caption = 'Employment Contract';
            DataClassification = CustomerContent;
            Editable = True;
        }
        field(60065; "Medical Contract"; Boolean)
        {
            Caption = 'Medical Contract';
            DataClassification = CustomerContent;
            Editable = True;
        }
        field(60070; "From Employee"; Boolean)
        {
            Caption = 'From Employee';
            DataClassification = CustomerContent;
            Editable = False;
        }
        //<<dan 082924
    }
    keys
    {
        key(NewKey1; "FTT-SCT Record Type")
        { }
    }

    local procedure CalcNotificationDate()
    begin
        "FTT-CST Notification Date" := CalcDate("FTT-CST Notification Period", "FTT-CST Expiration Date");
    end;

    local procedure CalcNotificationPeriod()
    var
        DaysCount: Integer;
    begin
        DaysCount := "FTT-CST Notification Date" - "FTT-CST Expiration Date";
        Evaluate("FTT-CST Notification Period", Format(DaysCount) + 'D');
    end;
    //>>Dan 102224
    Local Procedure GetContactName()
    var
        lCont: Record Contact;
        lOpp: Record Opportunity;
        lSH: Record "Sales Header";
        lCust: Record Customer;
        lEmp: Record Employee;
    Begin
        case
            Rec."Table ID" of
            5050:
                begin
                    IF lCont.GET(Rec."No.") then
                        Rec."FTT-CST Contact Name" := lCont.Name;
                end;
            5092:
                begin
                    IF lOpp.Get(Rec."No.") then
                        IF lCont.GET(lOpp."Contact No.") then
                            Rec."FTT-CST Contact Name" := lCont."Name";
                end;
            36:
                begin
                    IF lSH.GET(Rec."Document Type", Rec."No.") then
                        IF lCont.GET(lSH."Sell-to Contact No.") then
                            Rec."FTT-CST Contact Name" := lCont.Name;
                end;
            18:
                begin
                    IF lCust.GET(Rec."No.") then
                        IF lCont.GET(lCust."Primary Contact No.") then
                            Rec."FTT-CST Contact Name" := lCont.Name
                        ELSE
                            Rec."FTT-CST Contact Name" := lCust.Name;
                end;
            5200:
                Begin
                    Rec."From Employee" := TRUE;
                    IF lEmp.GET(Rec."No.") then
                        Rec."FTT-CST Contact Name" := lEmp.FullName();
                End;

        End;
    End;

    Trigger OnInsert()
    var
    Begin
        GetContactName();
    End;
    //<<Dan 102224
}
