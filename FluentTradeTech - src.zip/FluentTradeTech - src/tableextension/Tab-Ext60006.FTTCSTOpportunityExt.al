tableextension 60006 "FTT-CST Opportunity Ext" extends Opportunity
{
    fields
    {
        field(60000; "FTT-CST Notif. Mail. Gr. Code"; Code[10])
        {
            Caption = 'Notification Mailing Group Code';
            DataClassification = CustomerContent;
            TableRelation = "Mailing Group".Code;
        }
        field(60001; "FTT-CST OnHold"; boolean)
        {
            Caption = 'On Hold';
            DataClassification = CustomerContent;
        }
        field(60010; "FTT-CST Contact No."; Code[20])
        {
            Caption = 'Contact No.';
            DataClassification = CustomerContent;
            trigger OnLookup()
            var
                Cont: Record Contact;
            Begin
                IF Cont.GET("Contact No.") AND (Status <> Status::"Not Started") THEN BEGIN
                    Cont.SETRANGE("Company No.", Cont."Company No.");
                    Validate("Salesperson Code", Cont."Salesperson Code");
                END;
                Cont.SETRANGE(Type, Cont.Type::Company); //Dan
                Cont.SETFILTER("No. Series", '%1', '*CONT*');
                IF PAGE.RUNMODAL(0, Cont) = ACTION::LookupOK THEN BEGIN
                    xRec."Contact No." := "Contact No.";
                    VALIDATE("Contact No.", Cont."No.");
                    xRec."FTT-CST Contact No." := "Contact No.";
                    VALIDATE("FTT-CST Contact No.", Cont."No.");
                END;

            End;
        }
        //>>010625 update
        field(60011; "FTT-CST Currency"; Code[20])
        {
            Caption = 'Currency';
            DataClassification = CustomerContent;
        }
        //<<010625 Update
        modify("Sales Cycle Code")
        {
            trigger OnAfterValidate()
            var
                SalesCycleStage: Record "Sales Cycle Stage";
                DlgMsg: Label '%1 was updated. Do you want to update notification mailing group for the %2 with the default one?';
            begin
                //if SalesCycleStage.GET('AGRMT') THEN begin
                //    Rec."Sales Cycle Code" := SalesCycleStage."Sales Cycle Code";
                //    Rec.Modify();
                //end;

                if Rec."FTT-CST Notif. Mail. Gr. Code" = '' then
                    FillNotifMailGrCode()
                else
                    if Rec."Sales Cycle Code" <> xRec."Sales Cycle Code" then
                        if Dialog.Confirm(StrSubstNo(DlgMsg, Rec.FieldCaption("Sales Cycle Code"), Rec.TableCaption())) then
                            FillNotifMailGrCode();
            end;
        }

        modify("Contact No.")
        {
            trigger OnAfterValidate()
            var
                Contact: record Contact;
            begin
                Contact.Get("Contact No.");
                Validate("Salesperson Code", Contact."Salesperson Code");
                "FTT-CST Currency" := Contact."Currency Code"; //010625 Update
            end;
        }

    }
    trigger OnBeforeInsert()
    var
        SalesCycle: Record "Sales Cycle";
        CodeSalesCycle: code[10];
    begin
        Evaluate(CodeSalesCycle, 'AGRMT');
        if SalesCycle.GET(CodeSalesCycle) THEN begin
            Rec."Sales Cycle Code" := SalesCycle.Code;
            //Rec.Modify();
        end;
    end;
    //nrd
    trigger OnBeforeDelete()
    var
        recUserSetup: Record "User Setup";
    begin
        if not recUserSetup.Get(UserId) then
            exit;

        recUserSetup.TestField("Salespers./Purch. Code");

        if recUserSetup."Salespers./Purch. Code" <> rec."Salesperson Code" then
            Error('Deletion is not allowed if it''s not your tagged as Sales Person');
    end;
    //  
    procedure FillNotifMailGrCode()
    var
        SalesCycle: Record "Sales Cycle";
    begin
        if SalesCycle.Get(Rec."Sales Cycle Code") then
            Rec."FTT-CST Notif. Mail. Gr. Code" := SalesCycle."FTT-CST Default Mailing Group";
    end;

    procedure FTTCSTCreateQuote(var SalesQuoteNo: code[20])
    var
        Cont: Record Contact;
        ContactBusinessRelation: Record "Contact Business Relation";
        SalesHeader: Record "Sales Header";
        NewCustTemplateCode: Code[20];
        recCustomer: Record Customer;
    begin
        Cont.Get("Contact No.");

        if (Cont.Type = Cont.Type::Person) and (Cont."Company No." <> '') then
            Cont.Get(Cont."Company No.");

        if Cont.Type = Cont.Type::Company then begin
            ContactBusinessRelation.SetRange("Contact No.", Cont."No.");
            ContactBusinessRelation.SetRange("Link to Table", ContactBusinessRelation."Link to Table"::Customer);
            if ContactBusinessRelation.IsEmpty() then
                NewCustTemplateCode := GetNewCustomerTemplateCode(Cont);
        end;

        TestField(Status, Status::"In Progress");

        SalesHeader.SetRange("Sell-to Contact No.", "Contact No.");
        SalesHeader.Init();
        SalesHeader."Document Type" := SalesHeader."Document Type"::Quote;

        SalesHeader.Insert(true);
        SalesHeader.Validate("Salesperson Code", "Salesperson Code");
        SalesHeader.Validate("Campaign No.", "Campaign No.");
        SalesHeader."Opportunity No." := "No.";
        SalesHeader."Order Date" := GetEstimatedClosingDate();
        SalesHeader."Shipment Date" := SalesHeader."Order Date";
        SalesHeader.Validate("FTT-CST Agr. Starting Date", Today);

        if NewCustTemplateCode <> '' then
            SalesHeader.Validate("Sell-to Customer Templ. Code", NewCustTemplateCode);
        SalesHeader.Modify();
        "Sales Document Type" := "Sales Document Type"::Quote;
        "Sales Document No." := SalesHeader."No.";
        SalesQuoteNo := SalesHeader."No.";
        Modify();

        //nrd
        if recCustomer.get(SalesHeader."Sell-to Customer No.") then begin
            recCustomer.Prospect := true;
            recCustomer.Modify();
        end;
        //+   

        //NRD
        if not confirm('Do you want to add all lines from Estimated Sales Value(LCY) to this Sales Quote %1?', false, SalesQuoteNo) then
            exit;

        CreateSalesLinesFromEstValue(SalesHeader);
        Commit();
        //NRD - 05112024
        UpdateCrossConnectFromOpportunity(SalesHeader);
        Commit();
        //NRD
    end;

    local procedure UpdateCrossConnectFromOpportunity(pSalesheader: Record "Sales Header")
    var
        recCrossConnecTemp: Record "FTT-CST Cross ConnectLnsTemp";
        recCrossConnect: Record "FTT-CST Cross Connect Lines";
        recCrossConnectHdr: Record "FTT-CST Cross Connect Hdr";
        DocType: enum "Sales Document Type";
    begin
        DocType := DocType::Quote;

        recCrossConnectHdr.Reset();
        recCrossConnectHdr.SetRange("Document Type", DocType);
        recCrossConnectHdr.SetRange("Document No.", pSalesheader."No.");
        if not recCrossConnectHdr.FindFirst() then begin
            recCrossConnectHdr.Init();
            recCrossConnectHdr."Document Type" := DocType;
            recCrossConnectHdr."Document No." := pSalesheader."No.";
            recCrossConnectHdr.validate("Customer No.", pSalesheader."Sell-to Customer No.");
            recCrossConnectHdr."Cross Connect Status" := recCrossConnectHdr."Cross Connect Status"::"Line Inserted";
            IF recCrossConnectHdr.Insert() THEN begin
                Commit();

                recCrossConnecTemp.Reset();
                recCrossConnecTemp.SetRange("Document Type", recCrossConnecTemp."Document Type"::Quote);
                recCrossConnecTemp.SetRange("Document No.", pSalesheader."Opportunity No.");
                if recCrossConnecTemp.FindSet() then
                    repeat
                        recCrossConnect.Init();
                        recCrossConnect.TransferFields(recCrossConnecTemp);
                        recCrossConnect."Document No." := pSalesheader."No.";
                        recCrossConnect.Insert();
                    until recCrossConnecTemp.Next() = 0
            end;
        end;
    end;

    procedure CreateSalesLinesFromEstValue(pSalesHeader: Record "Sales Header")
    var
        Rec_lSalesLine: Record "Sales Line";
        Rec_lEstValueLCY: Record "FTT-CST Estimated Value Mod";
        LineNo: Integer;
        ItemSt: Record Item;
        DimensionValues: Record "Dimension Value";
        RecItemCategory: Record "Item Category";
    begin
        Rec_lSalesLine.SetRange("Document Type", pSalesHeader."Document Type");
        Rec_lSalesLine.SetRange("Document No.", pSalesHeader."No.");
        IF Rec_lSalesLine.FindLast() THEN
            LineNo := Rec_lSalesLine."Line No." else
            LineNo := 0;

        Rec_lEstValueLCY.Reset();
        Rec_lEstValueLCY.SetRange("Linked No.", rec."No.");
        if Rec_lEstValueLCY.FindSet() then
            repeat
                Rec_lSalesLine.Init();
                Rec_lSalesLine."Line No." := LineNo + 10000;
                Rec_lSalesLine."Document No." := pSalesHeader."No.";
                Rec_lSalesLine."Document Type" := pSalesHeader."Document Type";
                Rec_lSalesLine.Validate("Sell-to Customer No.", pSalesHeader."Sell-to Customer No.");
                Rec_lSalesLine.Validate("Customer Price Group", pSalesHeader."Customer Price Group");
                Rec_lSalesLine.Validate("Customer Disc. Group", pSalesHeader."Customer Disc. Group");
                Rec_lSalesLine.Validate("Currency Code", pSalesHeader."Currency Code");
                Rec_lSalesLine.Validate(Type, Rec_lSalesLine.Type::Item);
                Rec_lSalesLine.Validate("No.", Rec_lEstValueLCY."Item No.");
                if Rec_lEstValueLCY."FTT-CST Cost Type" = Rec_lEstValueLCY."FTT-CST Cost Type"::MRC then
                    Rec_lSalesLine.Validate("Unit Price", (Rec_lEstValueLCY."Line Amount Total" / Rec_lEstValueLCY.Quantity)) //NRD
                else
                    Rec_lSalesLine.Validate("Unit Price", Rec_lEstValueLCY."Unit Price Excl. VAT");
                Rec_lSalesLine.insert();

                //SalesLine."Allow Line Disc." := SalesHeader."Allow Line Disc.";
                Rec_lSalesLine."Transaction Type" := pSalesHeader."Transaction Type";
                Rec_lSalesLine."Transport Method" := pSalesHeader."Transport Method";
                Rec_lSalesLine."Bill-to Customer No." := pSalesHeader."Bill-to Customer No.";
                Rec_lSalesLine."Price Calculation Method" := pSalesHeader."Price Calculation Method";
                Rec_lSalesLine."Gen. Bus. Posting Group" := pSalesHeader."Gen. Bus. Posting Group";
                Rec_lSalesLine."VAT Bus. Posting Group" := pSalesHeader."VAT Bus. Posting Group";


                if Rec_lEstValueLCY.Quantity > 1 then begin
                    Rec_lSalesLine.Quantity := Rec_lEstValueLCY.Quantity;
                    Rec_lSalesLine."FTT-CST Qty" := Rec_lEstValueLCY.Quantity;
                end else begin
                    Rec_lSalesLine.Quantity := 1;
                    Rec_lSalesLine."FTT-CST Qty" := 1;

                end;

                LineNo := Rec_lSalesLine."Line No.";
                Rec_lSalesLine."FTT-CST Comments" := Rec_lEstValueLCY."FTT-CST Comments";

                Rec_lSalesLine.Validate("FTT-CST Optional", Rec_lEstValueLCY."FTT-CST Optional");
                if Rec_lEstValueLCY."FTT-CST Optional" = Rec_lEstValueLCY."FTT-CST Optional"::Yes then
                    Rec_lSalesLine.Validate(Quantity, Rec_lSalesLine.Quantity);

                if ItemSt.Get(Rec_lEstValueLCY."Item No.") then;

                Rec_lSalesLine."FTT-CST Use for Discount" := ItemSt."Allow Invoice Disc.";
                Rec_lSalesLine."Allow Line Disc." := ItemSt."Allow Invoice Disc.";
                Rec_lSalesLine."Allow Invoice Disc." := ItemSt."Allow Invoice Disc.";

                if RecItemCategory.Get(Rec_lEstValueLCY."Item Category Coede") then begin //NRD
                    if RecItemCategory."Parent Category" IN ['TAKER FEED', 'MAKER FEED'] then begin
                        Rec_lSalesLine."FTT-CST Parent Item Cat. Code" := 'FEED';
                    end else begin
                        if RecItemCategory."Parent Category" <> '' then
                            Rec_lSalesLine."FTT-CST Parent Item Cat. Code" := RecItemCategory."Parent Category" //NRD
                        else
                            Rec_lSalesLine."FTT-CST Parent Item Cat. Code" := Rec_lEstValueLCY."Item Category Coede"; //NRD
                    end;
                end;


                Rec_lSalesLine."FTT-CST Comments Fluent" := Rec_lEstValueLCY."FTT-CST Comments";
                if Rec_lEstValueLCY."DR/Redundancy/Integ PriceCalc%" <> 0 then begin
                    Rec_lSalesLine."FTT-CST DR" := Rec_lSalesLine."FTT-CST DR"::No;
                    Rec_lSalesLine."FTT-CST Redundancy" := Rec_lSalesLine."FTT-CST Redundancy"::No;
                    Rec_lSalesLine."FTT-CST Redundancy PriceCalc %" := Rec_lEstValueLCY."DR/Redundancy/Integ PriceCalc%";
                    Rec_lSalesLine."Unit Price" := Rec_lEstValueLCY."Line Amount Total";
                    Rec_lSalesLine."FTT-CST Unit Price" := Rec_lEstValueLCY."Unit Price Excl. VAT";
                end else begin
                    Rec_lSalesLine."FTT-CST DR" := Rec_lSalesLine."FTT-CST DR"::Yes;
                    Rec_lSalesLine."FTT-CST Redundancy" := Rec_lSalesLine."FTT-CST Redundancy"::Yes;
                    Rec_lSalesLine."FTT-CST Redundancy PriceCalc %" := 0;
                end;

                Rec_lSalesLine."FTT-CST Integration" := Rec_lSalesLine."FTT-CST Integration"::Yes;

                Rec_lSalesLine."FTT-CST Location Code" := Rec_lEstValueLCY."Region Code";
                Rec_lSalesLine."FTT-CST Location Type" := Rec_lSalesLine."FTT-CST Location Type"::Current;
                Rec_lSalesLine."FTT-CST Component Option" := Rec_lEstValueLCY."FTT-CST Component Option";
                Rec_lSalesLine."FTT-CST Sublocation" := Rec_lEstValueLCY."FTT-CST Sublocation";
                Rec_lSalesLine."Shortcut Dimension 1 Code" := pSalesHeader."Shortcut Dimension 1 Code";
                Rec_lSalesLine."Shortcut Dimension 2 Code" := pSalesHeader."Shortcut Dimension 2 Code";
                Rec_lSalesLine."FTT-CST Use for Renewal" := true;

                if Rec_lEstValueLCY."FTT-CST Cost Type" = Rec_lEstValueLCY."FTT-CST Cost Type"::MRC then
                    Rec_lSalesLine."FTT-CST Unit Price" := Rec_lEstValueLCY."Unit Price Excl. VAT";
                //Rec_lSalesLine."Unit Price" := Rec_lEstValueLCY."Line Amount Total";
                // end else begin
                //     Rec_lSalesLine."Unit Price" := Rec_lEstValueLCY."Unit Price Excl. VAT";
                //     Rec_lSalesLine."FTT-CST Unit Price" := Rec_lEstValueLCY."Unit Price Excl. VAT";
                // end;

                Rec_lSalesLine.Validate("FTT-CST Cost Type", ItemSt."FTT-CST Cost Type");
                Rec_lSalesLine."SDP Items" := ItemSt."SDP Items"; //NRD
                Rec_lSalesLine.isRedundancyCalculated := false;  //NRD
                Rec_lSalesLine.isDRCalculated := false;  //NRD
                Rec_lSalesLine.isIntegCalculated := false;  //NRD

                Rec_lSalesLine.ValidateShortcutDimCode(3, Rec_lEstValueLCY."Region Code");
                //Add Dimesnsion for Sublocation
                DimensionValues.Reset;
                DimensionValues.SetRange("FTT-CST Sublocation", Rec_lEstValueLCY."FTT-CST Sublocation");
                if DimensionValues.FindFirst() then
                    Rec_lSalesLine.ValidateShortcutDimCode(4, DimensionValues.Code);

                if (Rec_lSalesLine."FTT-CST Cost Type" = Rec_lSalesLine."FTT-CST Cost Type"::NRC) then // AND (SalesLine."FTT-CST Parent Item Cat. Code" = 'HARDWARE') then //NRD - Fixed the Unit Price and Line amount
                    Rec_lSalesLine.Validate(Quantity, Rec_lSalesLine.Quantity)
                else
                    Rec_lSalesLine.Validate(Quantity, Rec_lSalesLine.Quantity);

                if Rec_lSalesLine.Modify() then;

            until Rec_lEstValueLCY.Next() = 0;
        Commit();

    end;

    local procedure GetEstimatedClosingDate(): Date
    var
        OppEntry: Record "Opportunity Entry";
    begin
        OppEntry.SetCurrentKey(Active, "Opportunity No.");
        OppEntry.SetRange(Active, true);
        OppEntry.SetRange("Opportunity No.", "No.");
        if OppEntry.FindFirst() then
            exit(OppEntry."Estimated Close Date");
    end;

    local procedure GetNewCustomerTemplateCode(Cont: Record Contact) CustTemplateCode: Code[20]
    var
        CustTemplate: Record "Customer Templ.";
        CustomerTemplMgt: Codeunit "Customer Templ. Mgt.";
        IsHandled: Boolean;
    begin
        if GuiAllowed then begin
            CustTemplateCode := Cont.ChooseNewCustomerTemplate();
            if CustTemplateCode <> '' then
                Cont.CreateCustomerFromTemplate(CustTemplateCode)
            else
                if Confirm(UpdateSalesQuoteWithCustTemplateQst) then
                    if CustomerTemplMgt.SelectCustomerTemplate(CustTemplate) then
                        CustTemplateCode := CustTemplate.Code;
        end;
    end;

    var
        UpdateSalesQuoteWithCustTemplateQst: Label 'Do you want to update the sales quote with a customer template?';
        Text011: Label 'A sales quote has already been assigned to this opportunity.';
}