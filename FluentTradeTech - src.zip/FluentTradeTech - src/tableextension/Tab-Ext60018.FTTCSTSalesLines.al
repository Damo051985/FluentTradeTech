tableextension 60018 "FTT-CST Sales Lines" extends "Sales Line"
{
    fields
    {
        field(60000; "FTT-CST Cost Type"; Enum "FTT-CST Cost Type")
        {
            Caption = 'Cost Type';
            DataClassification = CustomerContent;
            Editable = false;
        }
        field(60001; "FTT-CST Agreement Date From"; Date)
        {
            Caption = 'Estimated Contract Date';
            DataClassification = CustomerContent;

            trigger OnValidate()
            begin
                if not CheckDates() then
                    ShowErrorDate();
            end;
        }
        field(60002; "FTT-CST Agreement Date To"; Date)
        {
            Caption = 'Agreement Ending Date';
            DataClassification = CustomerContent;

            trigger OnValidate()
            begin
                if not CheckDates() then
                    ShowErrorDate();
            end;
        }
        field(60003; "FTT-CST Copied Document Type"; Enum "Sales Document Type From")
        {
            Caption = 'Copied Document Type';
            DataClassification = CustomerContent;
        }
        field(60004; "FTT-CST Copied Document No."; Code[20])
        {
            Caption = 'Copied Document No.';
        }
        field(60005; "FTT-CST Copied Line No."; Integer)
        {
            Caption = 'Copied Line No.';
        }
        field(60007; "FTT-CST Delivery PROD Date"; Date)
        {
            Caption = 'Delivery PROD Date';
            DataClassification = CustomerContent;

            trigger OnValidate()
            begin
                if not CheckDates() then
                    ShowErrorDate();
            end;
        }
        field(60008; "FTT-CST Delivery UAT Date"; Date)
        {
            Caption = 'Delivery UAT Date';
            DataClassification = CustomerContent;

            trigger OnValidate()
            begin
                if not CheckDates() then
                    ShowErrorDate();
            end;
        }
        field(60009; "FTT-CST Optional"; Option)
        {
            OptionMembers = No,Yes;
            Caption = 'Optional';
            trigger OnValidate()
            begin
                Validate("FTT-CST Unit Price", "Unit Price");
                if "FTT-CST Optional" = "FTT-CST Optional"::Yes then begin
                    if "Unit Price" <> 0 then
                        Validate("Unit Price", 0.1)
                    else
                        Validate("Unit Price", 0);
                end;
            end;
        }

        field(60010; "FTT-CST Parent Item Cat. Code"; Code[20])
        {
            Caption = 'Parent Item Category Code';
            TableRelation = "Item Category";
        }
        field(60011; "FTT-CST Comments"; text[250])
        {
            Caption = 'Internal Comments';
        }
        field(60012; "FTT-CST Unit Price"; Decimal)
        {
            AutoFormatExpression = Rec."Currency Code";
            AutoFormatType = 2;
            CaptionClass = GetCaptionClass(FieldNo("Unit Price"));
            Caption = 'Unit Price Optional';

            trigger OnValidate()
            begin
                //Validate("Line Discount %");
            end;
        }
        field(60013; "FTT-CST Use for Discount"; Boolean)
        {
            Caption = 'Use for discount';
        }
        field(60014; "FTT-CST Comments Fluent"; text[250])
        {
            Caption = 'Fluent Comments';
        }
        field(60015; "FTT-CST DR"; Option)
        {
            Caption = 'DR';
            OptionMembers = No,Yes;
        }
        field(60016; "FTT-CST Redundancy"; Option)
        {
            Caption = 'Redundancy';
            OptionMembers = No,Yes;
        }
        field(60017; "FTT-CST Redundancy PriceCalc %"; decimal)
        {
            Caption = 'Price Rec %';

        }
        field(60018; "FTT-CST Location Code"; code[20])
        {
            Caption = 'Location Code';
        }
        field(60019; "FTT-CST Location Type"; enum "FTT-CST Location Type")
        {
            Caption = 'Location Type';
        }
        field(60020; "FTT-CST Component Option"; Option)
        {
            Caption = 'Location Type';
            DataClassification = CustomerContent;
            OptionMembers = Blank,Hosted,NonHosted,Unknown;
            OptionCaption = '. . . . . . .,Hosted,Non Hosted,Unknown';
        }
        field(60021; "FTT-CST Sublocation"; Option)
        {
            DataClassification = ToBeClassified;
            OptionMembers = Blank,LD4,LD42,NY2,NY4,NY6,TY3,SG1,None;
            OptionCaption = '. . . . . . .,LD 4,LD 4.2,NY 2,NY 4,NY 6,TY 3,SG 1, None';
            Caption = 'Sublocation';
        }
        field(60022; "FTT-CST Qty"; Decimal)
        {
            Caption = 'Qty from Dependancy';
        }
        field(60023; "FTT-CST Order Type"; Option)
        {
            OptionMembers = Primary,Renewal,Additions;
            OptionCaption = 'Primary,Renewal,Additions';
            DataClassification = CustomerContent;
            Caption = 'Order Type';
        }
        field(60024; "FTT-CST Primary Order"; Code[20])
        {
            TableRelation = "Sales Header"."No.";
            DataClassification = CustomerContent;
            Caption = 'Primary Order No.';
        }
        field(60025; "FTT-CST Main Order No."; code[20])
        {
            TableRelation = "Sales Header"."No.";
            DataClassification = CustomerContent;
            Caption = 'Main Order No.';
        }
        field(60026; "FTT-CST Use for Renewal"; Boolean)
        {
            Caption = 'Use for Renewal';
        }
        //NRD
        field(60027; "SDP Items"; Boolean)
        {
            DataClassification = ToBeClassified;
        }
        field(60028; "isRedundancyCalculated"; Boolean)
        {
            DataClassification = ToBeClassified;
        }
        field(60029; "isIntegCalculated"; Boolean)
        {
            DataClassification = ToBeClassified;
        }
        field(60030; "isDRCalculated"; Boolean)
        {
            DataClassification = ToBeClassified;
        }
        field(60031; "FTT-CST Integration"; Option)
        {
            Caption = 'Integration';
            OptionMembers = No,Yes;
        }
        field(60036; "Agreement Period"; Integer)
        {
            DataClassification = ToBeClassified;
            InitValue = 1;
        }
        field(60037; "Commission Agreement No."; code[50])
        {
            DataClassification = ToBeClassified;
            TableRelation = "FTT-CST Comm. Agrm. Header"."Agreement No.";
        }
        field(60038; "Separated Seq."; Integer) //NRD commission
        {
            DataClassification = ToBeClassified;
            InitValue = 0;
        }
        field(60040; "Commission Base Amount"; Decimal) //NRD
        {
            DataClassification = ToBeClassified;
        }
        field(60045; "FTT-CST Year"; Integer) //NRD
        {
            DataClassification = ToBeClassified;
        }

        modify("No.")
        {
            trigger OnAfterValidate()
            var
                Item: Record Item;
            begin
                // if Type <> "Sales Line Type"::Item then
                //     exit;
                // Item.Get(Rec."No.");
                //Rec."FTT-CST Cost Type" := Item."FTT-CST Cost Type";
                //rec.Modify()
            end;
        }
        modify(Type)
        {
            trigger OnAfterValidate()
            var
                SalesHeader: Record "Sales Header";
            begin
                if Rec.Type <> "Sales Line Type"::Item then begin
                    Rec."FTT-CST Agreement Date From" := 0D;
                    Rec."FTT-CST Agreement Date To" := 0D;
                end else begin
                    SalesHeader.Get(Rec."Document Type", Rec."Document No.");
                    Rec.Validate("FTT-CST Agreement Date From", SalesHeader."FTT-CST Agr. Starting Date");
                    Rec.Validate("FTT-CST Agreement Date To", SalesHeader."FTT-CST Agr. Ending Date");
                end;
            end;
        }
    }

    trigger OnAfterInsert()
    var
        SalesHeader: Record "Sales Header";
    begin
        if SalesHeader.Get(Rec."Document Type", Rec."Document No.") then begin
            Rec.Validate("FTT-CST Agreement Date From", SalesHeader."FTT-CST Agr. Starting Date");
            Rec.Validate("FTT-CST Agreement Date To", SalesHeader."FTT-CST Agr. Ending Date");
            Rec."FTT-CST Main Order No." := SalesHeader."FTT-CST Main Order No.";
            Rec."FTT-CST Primary Order" := SalesHeader."FTT-CST Primary Order";
            Rec."FTT-CST Order Type" := SalesHeader."FTT-CST Order Type";
            Rec."FTT-CST Use for Renewal" := true;
            Rec."FTT-CST Year" := GetYEar(SalesHeader."FTT-CST Agr. Starting Date");
            Rec.Modify();
        end;
    end;
    //NRD

    Local Procedure GetYear(AgrStartDate: Date): INteger;
    var
        YearInt: Integer;
    Begin
        YearInt := Date2DMY(AgrStartDate, 3);
        Exit(YearInt);
    End;

    trigger OnAfterDelete()
    var
        CrossConnectLines: Record "FTT-CST Cross Connect Lines";
    begin

        if (rec.Type = rec.Type::Item) and (rec."No." IN ['1101', '1103']) then begin
            CrossConnectLines.Reset();
            if rec."Document Type" = rec."Document Type"::Order then
                CrossConnectLines.SetRange("Document Type", CrossConnectLines."Document Type"::Order)
            else if rec."Document Type" = rec."Document Type"::Quote then
                CrossConnectLines.SetRange("Document Type", CrossConnectLines."Document Type"::Quote);
            CrossConnectLines.SetRange("Document No.", rec."Document No.");
            CrossConnectLines.SetRange("FTT-CST Location Code", rec."FTT-CST Location Code");
            CrossConnectLines.SetFilter("Quantity 1", '<>%1', 0);
            CrossConnectLines.SetFilter("Quantity 3", '<>%1', 0);
            if CrossConnectLines.FindSet() then
                CrossConnectLines.DeleteAll();
        end;

        if (rec.Type = rec.Type::Item) and (rec."No." IN ['1102', '1104']) then begin
            CrossConnectLines.Reset();
            if rec."Document Type" = rec."Document Type"::Order then
                CrossConnectLines.SetRange("Document Type", CrossConnectLines."Document Type"::Order)
            else if rec."Document Type" = rec."Document Type"::Quote then
                CrossConnectLines.SetRange("Document Type", CrossConnectLines."Document Type"::Quote);
            CrossConnectLines.SetRange("Document No.", rec."Document No.");
            CrossConnectLines.SetRange("FTT-CST Location Code", rec."FTT-CST Location Code");
            CrossConnectLines.SetFilter("Quantity 2", '<>%1', 0);
            CrossConnectLines.SetFilter("Quantity 4", '<>%1', 0);
            if CrossConnectLines.FindSet() then
                CrossConnectLines.DeleteAll();
        end;

    end;
    //NRD
    procedure CheckDates(): Boolean
    begin
        if ((Rec."FTT-CST Agreement Date From" = 0D) and (Rec."FTT-CST Delivery PROD Date" = 0D) and (rec."FTT-CST Delivery UAT Date" = 0D))
        or (Rec."FTT-CST Agreement Date To" = 0D) then
            exit(true);

        if Rec."FTT-CST Agreement Date From" > Rec."FTT-CST Agreement Date To" then
            exit(false);

        exit(true);
    end;

    local procedure ShowErrorDate()
    begin
        Error(DateErr, Rec.FieldCaption("FTT-CST Agreement Date From"), Rec.FieldCaption("FTT-CST Agreement Date To"));
    end;

    var
        DateErr: Label '%1 can not be more %2', Comment = '%1 - StartDate, %2 - EndDate';
}
