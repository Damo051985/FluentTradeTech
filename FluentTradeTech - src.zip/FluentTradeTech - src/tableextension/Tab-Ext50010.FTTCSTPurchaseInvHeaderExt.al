tableextension 50010 "FTT-CST Purchase Inv Hdr. Ext" extends "Purch. Inv. Header"
{
    fields
    {
        field(60005; "Comm. Document No."; code[20])
        {
            DataClassification = ToBeClassified;
        }
    }

    keys
    {
        // Add changes to keys here
    }

    fieldgroups
    {
        // Add changes to field groups here
    }

    var
        myInt: Integer;
}