tableextension 60010 "FTT-CST StandardSalesCode" extends "Standard Sales Code"
{
    fields
    {
        modify("Currency Code")
        {
            trigger OnAfterValidate()
            var
                StnItemSalesCode: Record "FTT-CST Stn. Item Sales Code";
            begin
                StnItemSalesCode.SetRange(Code, Code);
                StnItemSalesCode.ModifyAll("Currency Code", "Currency Code");
            end;
        }
    }
}
