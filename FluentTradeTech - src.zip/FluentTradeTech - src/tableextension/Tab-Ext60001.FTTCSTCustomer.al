tableextension 60001 "FTT-CST Customer" extends Customer
{
    fields
    {
        field(60000; "FTT-CST Notif. Mail Gr. Code"; Code[10])
        {
            Caption = 'Notification Mailing Group Code';
            DataClassification = CustomerContent;
            TableRelation = "Mailing Group".Code;
        }

        field(60010; "No. of Opportunities"; Integer)
        {
            CalcFormula = Count("Opportunity Entry" WHERE(Active = CONST(true),
            "Contact Company No." = CONST('OCBC')));
            Caption = 'No. of Opportunities';
            Editable = false;
            FieldClass = FlowField;
        }

        field(60011; "Company No."; Code[20])
        {
            Caption = 'Company No.';
            Editable = false;
        }
        field(60012; "Prospect"; Boolean) //NRD
        {
            DataClassification = ToBeClassified;
        }
    }
}
