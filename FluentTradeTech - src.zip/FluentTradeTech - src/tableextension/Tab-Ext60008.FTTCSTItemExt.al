tableextension 60008 "FTT-CST ItemExt" extends Item
{
    fields
    {
        field(60000; "FTT-CST Cost Type"; Enum "FTT-CST Cost Type")
        {
            Caption = 'Cost Type';
            DataClassification = CustomerContent;

            trigger OnValidate()
            var
                SalesLine: Record "Sales Line";
            begin
                if Rec."FTT-CST Cost Type" = xRec."FTT-CST Cost Type" then
                    exit;

                SalesLine.SetRange(Type, "Sales Line Type"::Item);
                SalesLine.SetRange("No.", Rec."No.");
                if not SalesLine.FindSet() then
                    exit;

                if not Confirm(StrSubstNo(ChangeCostTypeLbl, Rec."No.")) then
                    Error('');

                SalesLine.ModifyAll("FTT-CST Cost Type", Rec."FTT-CST Cost Type");
            end;
        }
        field(60001; "FTT-CST Salesp. Comm. Type"; Enum "FTT-CST SalespCommType")
        {
            Caption = 'Salesperson Commission Type';
            DataClassification = CustomerContent;
        }
        field(60002; "FTT-CST Redundancy PriceCalc %"; Decimal)
        {
            Caption = 'Redundancy/DR Price Calculation %';
            DataClassification = CustomerContent;
            MinValue = 0;
            trigger OnValidate()
            begin

            end;
        }
        field(60003; "FTT-CST Red. Backup PCalc %"; Decimal)
        {
            Caption = 'Redundancy/DR Price Calculation %';
            DataClassification = CustomerContent;
            MinValue = 0;
            trigger OnValidate()
            begin
                Validate("FTT-CST Redundancy PriceCalc %", "FTT-CST Red. Backup PCalc %");
            end;

        }
        field(60004; "FTT-CST Integr PriceCalc %"; Decimal)
        {
            Caption = 'Integration Price Calculation %';
            DataClassification = CustomerContent;
            MinValue = 0;
        }
        field(60005; "FTT-CST Backup Integr. Calc %"; Decimal)
        {
            Caption = 'Integration Price Calculation %';
            DataClassification = CustomerContent;
            MinValue = 0;
            trigger OnValidate()
            begin
                Validate("FTT-CST Integr PriceCalc %", Rec."FTT-CST Backup Integr. Calc %");
            end;
        }
        field(60006; "FTT-CST Component Option"; Option)
        {
            Caption = 'Compoment Option';
            DataClassification = CustomerContent;
            OptionMembers = Hosted,NonHosted,Unknown;
            OptionCaption = 'Hosted,Non Hosted,Unknown';
        }
        field(60007; "FTT-CST Location Code"; code[20])
        {
            Caption = 'Region Code';
            DataClassification = CustomerContent;
            TableRelation = "Dimension Value".Code WHERE("Global Dimension No." = CONST(3),
                                                                  "Dimension Value Type" = CONST(Standard),
                                                                  Blocked = CONST(false));
        }
        field(60008; "FTT-CST Type of Site"; Option)
        {
            DataClassification = ToBeClassified;
            OptionMembers = Primary,Redundancy,DR;
            OptionCaption = 'Primary,Redundancy,DR';
            Caption = 'Type of Site';
        }
        field(60010; "FTT-CST Mark"; Boolean)
        {
            Caption = 'Mark';
        }


        field(60009; "FTT-CST Connectivity"; Option)
        {
            DataClassification = ToBeClassified;
            OptionMembers = Yes,No;
            OptionCaption = 'Yes,No';
            Caption = 'Connectivity';
        }
        field(60011; "FTT-CST Quantity"; Integer)
        {
            Caption = 'Quantity';
        }
        field(60012; "FTT-CST Comments Fluent"; text[250])
        {
            Caption = 'Comments Fluent';
        }
        field(60013; "FTT-CST Shared CC NOT Allowed"; Boolean)
        {
            Caption = 'Shared CC Not Allowed';
        }
        //NRD - to have a separate computation for SDP Item
        field(60014; "SDP Items"; Boolean)
        {
            Caption = 'Tag as SDP Item';
        }
        //>>dan 081524
        field(60015; "FTT License Type"; Option)
        {
            DataClassification = ToBeClassified;
            OptionMembers = "License per site","License per strategy","Global license";
            OptionCaption = 'License per site,License per strategy,Global license';
            Caption = 'License Type';
        }
        Modify("Unit Price")
        {
            Caption = 'Unit Price USD';
        }
        //<<dan 081524
        field(60016; "FTT-CST Eligible"; Boolean) //NRD
        {
            Caption = 'Eligible';
            DataClassification = CustomerContent;
            trigger OnValidate()
            begin
                if rec."FTT-CST Cost Type" = rec."FTT-CST Cost Type"::NRC then
                    Error('NRC Cost Type is not allowed to get a commission from this item.');

            end;
        }
        field(60017; "FTT-CST Coeffficient"; Boolean) //NRD
        {
            Caption = 'Coeffficient';
            DataClassification = CustomerContent;
        }
    }
    //>>Dan
    trigger OnInsert()
    Var

    Begin
        Rec."Base Unit of Measure" := 'PCS';
        Rec."Sales Unit of Measure" := 'PCS';
    End;

    trigger OnAfterInsert()
    var
    Begin
        InsertIUOM();
    End;

    local Procedure InsertIUOM()
    var
        ItemUOM: Record "Item Unit of Measure";
    Begin
        IF NOT ItemUOM.GET(Rec."No.", 'PCS') THEN begin
            ItemUOM.INIT;
            ItemUom."Item No." := Rec."No.";
            ItemUOM.VALIDATE(Code, 'PCS');
            ItemUOM.Validate("Qty. per Unit of Measure", 1);
            IF ItemUom.INSERT THEN;
        end;
    End;
    //<<dan
    var
        ChangeCostTypeLbl: Label 'If you change Cost Type, this information in the existing sales lines with item %1 will be changed. Do you want to continue?', Comment = '%1 - Item No.';
}
