tableextension 50013 "FTT-CST GenLeger Ext." extends "G/L Entry"
{
    fields
    {
        field(60005; "Comm. Document No."; code[20])
        {
            DataClassification = ToBeClassified;
        }

    }

    keys
    {
        // Add changes to keys here
    }

    fieldgroups
    {
        // Add changes to field groups here
    }

    var
        myInt: Integer;
}