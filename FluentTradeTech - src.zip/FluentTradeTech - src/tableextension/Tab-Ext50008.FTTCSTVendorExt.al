tableextension 50008 "FTT-CST Vendor Ext." extends Vendor
{
    fields
    {
        field(50001; "Vendor Commission"; Boolean)
        {
            DataClassification = ToBeClassified;
        }
    }

    keys
    {
        // Add changes to keys here
    }

    fieldgroups
    {
        // Add changes to field groups here
    }

    var
        myInt: Integer;
}