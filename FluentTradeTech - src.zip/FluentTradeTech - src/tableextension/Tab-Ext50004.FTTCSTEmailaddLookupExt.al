tableextension 50004 "Email Address Lookup Ext." extends "Email Address Lookup"
{
    fields
    {
        field(50001; "Department"; Enum "Department Filter")
        {
            DataClassification = ToBeClassified;
        }
    }

    keys
    {
        // Add changes to keys here
    }

    fieldgroups
    {
        // Add changes to field groups here
    }

    var
        myInt: Integer;
}