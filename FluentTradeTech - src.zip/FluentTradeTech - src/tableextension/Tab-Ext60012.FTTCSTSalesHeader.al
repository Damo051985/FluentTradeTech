tableextension 60012 "FTT-CST SalesHeader" extends "Sales Header"
{
    fields
    {

        field(60000; "Invoice without MSA"; Boolean)
        {
            Caption = 'Invoice without MSA';
            DataClassification = CustomerContent;
        }
        field(60001; "FTT-CST Agr. Starting Date"; Date)
        {
            //Caption = 'Since Go Live';
            Caption = 'Estimated Contract Date';
            DataClassification = CustomerContent;

            trigger OnValidate()
            begin
                ValidateStartingDate();
            end;
        }
        field(60002; "FTT-CST Agr. Ending Date"; Date)
        {
            Caption = 'Agreement Ending Date';
            DataClassification = CustomerContent;

            trigger OnValidate()
            begin
                ValidateEndingDate();
            end;
        }
        field(60003; "FTT-CST Agr. Period Number"; Integer)
        {
            Caption = 'Agreement Period Number';
            DataClassification = CustomerContent;
            InitValue = 1;
            MinValue = 1;
        }
        field(60004; "FTT-CST Component Option"; Option)
        {
            Caption = 'Compoment Option';
            DataClassification = CustomerContent;
            OptionMembers = Hosted,NonHosted,Unknown;
            OptionCaption = 'Hosted,Non Hosted,Unknown';
        }
        field(60005; "FTT-CST Location Code"; code[20])
        {
            Caption = 'Location Code';
            DataClassification = CustomerContent;
            TableRelation = Location;
        }
        field(60006; "FTT-CST Type of Site"; Option)
        {
            DataClassification = ToBeClassified;
            OptionMembers = Primary,Redundancy,DR;
            OptionCaption = 'Primary,Redundancy,DR';
        }


        field(60007; "FTT-CST Connectivity"; Option)
        {
            DataClassification = ToBeClassified;
            OptionMembers = Yes,No;
            OptionCaption = 'Yes,No';
        }
        field(60008; "FTT-CST Region Code"; Code[20])
        {
            Caption = 'Region Code';

        }
        field(60009; "FTT-CST Contract Length"; integer)
        {
            Caption = 'Contract Length';
            trigger OnValidate()
            begin
                ValidateSinceGoLiveDate();
            end;

        }
        field(60010; "FTT-CST Order Type"; Option)
        {
            OptionMembers = Primary,Renewal,Additions;
            OptionCaption = 'Primary,Renewal,Additions';
            DataClassification = CustomerContent;
            Caption = 'Order Type';
        }
        field(60011; "FTT-CST Primary Order"; Code[20])
        {
            TableRelation = "Sales Header"."No.";
            DataClassification = CustomerContent;
            Caption = 'Primary Order No.';
        }
        field(60012; "FTT-CST Main Order No."; code[20])
        {
            TableRelation = "Sales Header"."No.";
            DataClassification = CustomerContent;
            Caption = 'Main Order No.';
        }
        field(60013; "FTT-CST Use for Renewal"; Boolean)
        {
            Caption = 'Use for Renewal';
        }
        field(60014; "FTT-CST Final Quote"; Boolean) //NRD
        {
            Caption = 'Final Quote';
        }
        field(60015; "SalesQuoteExtTemp"; Media)
        {
            DataClassification = ToBeClassified;
        }
        field(60016; "Commission Computed"; Boolean)
        {
            DataClassification = ToBeClassified;
        }
        field(60050; "Service Now"; Text[1024])
        {
            DataClassification = ToBeClassified;
            Caption = 'ServiceNow Ticket';
        }
        field(60051; "Payment Status"; Option)
        {
            DataClassification = ToBeClassified;
            Caption = 'Deployment Status';
            Optionmembers = " ",Approved,"Not Approved","In Progress";
            OptionCaption = ' ,Approved,Not Approved,In Progress';
        }
        field(60052; "Include To Cust. Evolution"; Boolean)
        {
            DataClassification = ToBeClassified;
            Caption = 'Include to Customer Evolution';
        }
        field(60053; "Document Comments"; Text[1024]) //NRD - Not Used
        {
            DataClassification = ToBeClassified;

        }
    }

    local procedure ValidateStartingDate()
    begin
        UpdateAgreementDateSaleLine(true);

        if Rec."FTT-CST Agr. Starting Date" = 0D then
            exit;

        if Rec."FTT-CST Agr. Ending Date" = 0D then
            exit;

        if Rec."FTT-CST Agr. Starting Date" > Rec."FTT-CST Agr. Ending Date" then
            FieldError(Rec."FTT-CST Agr. Starting Date", StrSubstNo(StartingDateErr, Rec.FieldCaption("FTT-CST Agr. Ending Date")));
    end;

    local procedure ValidateEndingDate()
    begin
        UpdateAgreementDateSaleLine(false);

        if Rec."FTT-CST Agr. Ending Date" = 0D then
            exit;

        if Rec."FTT-CST Agr. Starting Date" = 0D then
            exit;

        if Rec."FTT-CST Agr. Ending Date" < Rec."FTT-CST Agr. Starting Date" then
            FieldError(Rec."FTT-CST Agr. Ending Date", StrSubstNo(EndingDateErr, Rec.FieldCaption("FTT-CST Agr. Starting Date")));
    end;

    procedure ValidateSinceGoLiveDate()
    Expr1: Text;
    begin
        //UpdateAgreementDateSaleLine(true);

        if Rec."FTT-CST Agr. Starting Date" = 0D then
            exit;
        if rec."FTT-CST Contract Length" > 0 then
            Expr1 := '<' + Format(rec."FTT-CST Contract Length" * 12) + 'M>';
        Rec.Validate("FTT-CST Agr. Ending Date", CalcDate(Expr1, "FTT-CST Agr. Starting Date"));

        if Rec."FTT-CST Agr. Ending Date" = 0D then
            exit;

        if Rec."FTT-CST Agr. Starting Date" > Rec."FTT-CST Agr. Ending Date" then
            FieldError(Rec."FTT-CST Agr. Starting Date", StrSubstNo(StartingDateErr, Rec.FieldCaption("FTT-CST Agr. Ending Date")));

        UpdateAgreementDateSaleLine(true);
        UpdateAgreementDateSaleLine(false);
    end;

    local procedure UpdateAgreementDateSaleLine(IsStartingDate: Boolean)
    var
        SalesLine: Record "Sales Line";
        ShowMessage: Boolean;
    begin
        SalesLine.SetRange("Document Type", Rec."Document Type");
        SalesLine.SetRange("Document No.", Rec."No.");
        SalesLine.SetRange(Type, "Sales Line Type"::Item);

        if IsStartingDate then
            SalesLine.SetFilter("FTT-CST Agreement Date From", '<>%1', 0D)
        else
            SalesLine.SetFilter("FTT-CST Agreement Date To", '<>%1', 0D);

        if not SalesLine.FindSet() then
            exit;

        //IsStartingDate thenUpdateAgreementDateSaleLineCnf
        //    if not Dialog.Confirm(StrSubstNo(UpdateAgreementDateSaleLineCnf,
        //                                    Rec.FieldCaption("FTT-CST Agr. Starting Date"),
        //                                    SalesLine.FieldCaption("FTT-CST Agreement Date From"))) then
        //    exit;

        //if not IsStartingDate then
        //    if not Dialog.Confirm(StrSubstNo(UpdateAgreementDateSaleLineCnf,
        //                                    Rec.FieldCaption("FTT-CST Agr. Ending Date"),
        //SalesLine.FieldCaption("FTT-CST Agreement Date To"))) then
        //        exit;

        repeat
            case IsStartingDate of
                true:
                    begin
                        SalesLine."FTT-CST Agreement Date From" := Rec."FTT-CST Agr. Starting Date";
                        if SalesLine.CheckDates() then
                            SalesLine.Modify()
                        else
                            ShowMessage := true;
                    end;
                false:
                    begin
                        SalesLine."FTT-CST Agreement Date To" := Rec."FTT-CST Agr. Ending Date";
                        if SalesLine.CheckDates() then
                            SalesLine.Modify()
                        else
                            ShowMessage := true;
                    end;
            end;
        until SalesLine.Next() = 0;

        if ShowMessage then
            Message(UpdateDatesMsg);
    end;

    procedure UpdateQuantity()
    begin
        CheckAgreementDatesLineAndUpdateQuantity(0D, 0D, false);
    end;

    procedure UpdateQuantity2(StartingDate: Date; EndingDate: Date)
    begin

        CheckAgreementDatesLineAndUpdateQuantity(StartingDate, EndingDate, false);
    end;

    procedure UpdateQuantity3()
    begin
        CheckAgreementDatesLineAndUpdateQuantity2(0D, 0D, false);
    end;

    local procedure CheckAgreementDatesLineAndUpdateQuantity(StartingDate: Date; EndingDate: Date; UpdateQtyInvoice: Boolean)
    var
        Item: Record Item;
        SalesLine: Record "Sales Line";
        UpdateDone: Boolean;
        DiffDate: Decimal;
        QuanityPrev: Decimal;
    begin
        UpdateDone := false;

        SalesLine.SetRange("Document Type", Rec."Document Type");
        SalesLine.SetRange("Document No.", Rec."No.");
        SalesLine.SetRange(Type, "Sales Line Type"::Item);
        SalesLine.SetFilter("Line Amount", '=%1', 0); //NRD
        if not UpdateQtyInvoice then begin
            SalesLine.SetFilter("FTT-CST Agreement Date From", '<>%1', StartingDate);
            SalesLine.SetFilter("FTT-CST Agreement Date To", '<>%1', EndingDate);
        end else begin
            SalesLine.SetFilter("FTT-CST Agreement Date From", '<=%1', StartingDate);
            SalesLine.SetFilter("FTT-CST Agreement Date To", '>=%1', EndingDate);
        end;


        if not SalesLine.FindSet(true) then
            Error(NothingUpdateErr);

        repeat
            Item.Get(SalesLine."No.");
            if not UpdateQtyInvoice then begin
                if SalesLine."FTT-CST Delivery PROD Date" <> 0D then
                    DiffDate := GetDiffDate(SalesLine."FTT-CST Delivery PROD Date", SalesLine."FTT-CST Agreement Date To", Item."FTT-CST Cost Type");
                if (SalesLine."FTT-CST Delivery UAT Date" <> 0D) and (SalesLine."FTT-CST Delivery PROD Date" = 0D) then
                    DiffDate := GetDiffDate(SalesLine."FTT-CST Delivery UAT Date", SalesLine."FTT-CST Agreement Date To", Item."FTT-CST Cost Type");
                if (SalesLine."FTT-CST Delivery UAT Date" = 0D) and (SalesLine."FTT-CST Delivery PROD Date" = 0D) then
                    DiffDate := GetDiffDate(SalesLine."FTT-CST Agreement Date From", SalesLine."FTT-CST Agreement Date To", Item."FTT-CST Cost Type");
            end
            else
                DiffDate := GetDiffDate(StartingDate, EndingDate, Item."FTT-CST Cost Type");

            if DiffDate <> 0 then begin
                if UpdateQtyInvoice then begin
                    if (SalesLine."Qty. to Ship" <> DiffDate) or (SalesLine."Qty. to Invoice" <> DiffDate) then
                        UpdateDone := true;
                    SalesLine.Validate("Qty. to Ship", DiffDate);
                    SalesLine.Validate("Qty. to Invoice", DiffDate);
                end else begin
                    if SalesLine.Quantity <> DiffDate then
                        UpdateDone := true;

                    if SalesLine."FTT-CST Cost Type" = SalesLine."FTT-CST Cost Type"::MRC then begin
                        QuanityPrev := SalesLine.Quantity;

                        SalesLine.Validate("Unit Price", SalesLine."Unit Price" * DiffDate);
                        if SalesLine."FTT-CST Optional" = SalesLine."FTT-CST Optional"::Yes then begin
                            SalesLine.Validate("FTT-CST Unit Price", salesline."Unit Price");
                            SalesLine.Validate("Unit Price", 0.1);
                        end;
                    end
                    else
                        //    SalesLine.Validate(Quantity, DiffDate * SalesLine."FTT-CST Qty");
                        //SalesLine.Validate(Quantity, SalesLine."FTT-CST Qty");
                        SalesLine.Validate(Quantity, SalesLine."FTT-CST Qty" * DiffDate);
                    //27.05.2024 Modified according to Request from Alex
                end;
                SalesLine.Modify(true);
            end;
        until SalesLine.Next() = 0;

        if not UpdateDone then
            Message(NothingUpdateLbl)
        else
            if UpdateQtyInvoice then
                Message(FinishUpdateForInvLbl)
            else
                Message(FinishUpdateForAgrLbl);

        UpdateDRRedundancyLines(SalesLine);

    end;

    local procedure CheckAgreementDatesLineAndUpdateQuantity2(StartingDate: Date; EndingDate: Date; UpdateQtyInvoice: Boolean)
    var
        Item: Record Item;
        SalesLine: Record "Sales Line";
        UpdateDone: Boolean;
        DiffDate: Decimal;
        QuanityPrev: Decimal;
        UnitPriceMRC: Decimal;
    begin
        UpdateDone := false;

        SalesLine.SetRange("Document Type", Rec."Document Type");
        SalesLine.SetRange("Document No.", Rec."No.");
        SalesLine.SetRange(Type, "Sales Line Type"::Item);
        //alesLine.SetFilter("Line Amount", '=%1', 0); //NRD
        if not UpdateQtyInvoice then begin
            SalesLine.SetFilter("FTT-CST Agreement Date From", '<>%1', StartingDate);
            SalesLine.SetFilter("FTT-CST Agreement Date To", '<>%1', EndingDate);
        end else begin
            SalesLine.SetFilter("FTT-CST Agreement Date From", '<=%1', StartingDate);
            SalesLine.SetFilter("FTT-CST Agreement Date To", '>=%1', EndingDate);
        end;


        if not SalesLine.FindSet(true) then
            Error(NothingUpdateErr);

        repeat
            Item.Get(SalesLine."No.");
            if not UpdateQtyInvoice then begin
                if SalesLine."FTT-CST Delivery PROD Date" <> 0D then
                    DiffDate := GetDiffDate(SalesLine."FTT-CST Delivery PROD Date", SalesLine."FTT-CST Agreement Date To", Item."FTT-CST Cost Type");
                if (SalesLine."FTT-CST Delivery UAT Date" <> 0D) and (SalesLine."FTT-CST Delivery PROD Date" = 0D) then
                    DiffDate := GetDiffDate(SalesLine."FTT-CST Delivery UAT Date", SalesLine."FTT-CST Agreement Date To", Item."FTT-CST Cost Type");
                if (SalesLine."FTT-CST Delivery UAT Date" = 0D) and (SalesLine."FTT-CST Delivery PROD Date" = 0D) then
                    DiffDate := GetDiffDate(SalesLine."FTT-CST Agreement Date From", SalesLine."FTT-CST Agreement Date To", Item."FTT-CST Cost Type");
            end
            else
                DiffDate := GetDiffDate(StartingDate, EndingDate, Item."FTT-CST Cost Type");

            if DiffDate <> 0 then begin
                if UpdateQtyInvoice then begin
                    if (SalesLine."Qty. to Ship" <> DiffDate) or (SalesLine."Qty. to Invoice" <> DiffDate) then
                        UpdateDone := true;
                    SalesLine.Validate("Qty. to Ship", DiffDate);
                    SalesLine.Validate("Qty. to Invoice", DiffDate);
                end else begin
                    if SalesLine.Quantity <> DiffDate then
                        UpdateDone := true;

                    if SalesLine."FTT-CST Cost Type" = SalesLine."FTT-CST Cost Type"::MRC then begin
                        QuanityPrev := SalesLine.Quantity;
                        UnitPriceMRC := ((SalesLine."FTT-CST Unit Price" * QuanityPrev) * DiffDate) / QuanityPrev;

                        SalesLine.Validate("Unit Price", UnitPriceMRC);
                        if SalesLine."FTT-CST Optional" = SalesLine."FTT-CST Optional"::Yes then begin
                            SalesLine.Validate("FTT-CST Unit Price", salesline."Unit Price");
                            SalesLine.Validate("Unit Price", 0.01);
                        end;
                    end
                    else
                        //    SalesLine.Validate(Quantity, DiffDate * SalesLine."FTT-CST Qty");
                        //SalesLine.Validate(Quantity, SalesLine."FTT-CST Qty");
                        SalesLine.Validate(Quantity, SalesLine."FTT-CST Qty" * DiffDate);
                    //27.05.2024 Modified according to Request from Alex
                end;
                SalesLine.Modify(true);
            end;
        until SalesLine.Next() = 0;

        if not UpdateDone then
            Message(NothingUpdateLbl)
        else
            if UpdateQtyInvoice then
                Message(FinishUpdateForInvLbl)
            else
                Message(FinishUpdateForAgrLbl);

        UpdateDRRedundancyLines(SalesLine);

    end;

    Local procedure UpdateDRRedundancyLines(var pSalesLine: Record "Sales Line");
    var
        Item: Record item;
        ItemCategory: record "Item Category";
        SalesLine: Record "Sales Line";
        CalcType: Enum "FTT-CST Calc Type";
        SalesReceivables: Record "Sales & Receivables Setup";
        CalcUnitPrice: Decimal; //NRD
    begin
        CalcUnitPrice := 0;
        SalesReceivables.Get();
        SalesLine.Reset();
        SalesLine.SetRange("Document Type", pSalesLine."Document Type");
        SalesLine.SetRange("Document No.", pSalesLine."Document No.");
        SalesLine.SetFilter("Line Amount", '=%1', 0);
        if SalesLine.FindSet() then
            repeat
                //if SalesLine.DR then CalcType := CalcType::DR;
                //if SalesLine. then CalcType := CalcType::Redundency;

                if Item.Get(SalesLine."No.") then begin
                    if Item."FTT-CST Redundancy PriceCalc %" <> 0 then
                        if ItemCategory.get(Item."Item Category Code") then begin
                            if ItemCategory.Code = SalesReceivables."FTT-CST DR Category" then
                                CalcType := CalcType::DR;
                            if ItemCategory.Code = SalesReceivables."FTT-CST Redundancy Category" then
                                CalcType := CalcType::Redundency;
                            if ItemCategory.Code = SalesReceivables."FTT-CST Integration Category" then
                                CalcType := CalcType::Integration;

                            //if (ItemCategory."FTT-CST Redundancy Base Item" OR ItemCategory."FTT-CST DR Base Item") then begin
                            CalcUnitPrice := CalculateUnitPrice(SalesLine."Document Type", SalesLine."Document No.", Item."FTT-CST Redundancy PriceCalc %", Item."No.", SalesLine."FTT-CST Redundancy PriceCalc %", CalcType, SalesLine."FTT-CST Location Code");

                            SalesLine.VALIDATE("Unit Price", CalcUnitPrice);
                            if SalesLine."FTT-CST Optional" = SalesLine."FTT-CST Optional"::Yes then begin
                                SalesLine."FTT-CST Unit Price" := CalcUnitPrice;
                                SalesLine.Validate("Unit Price", 0.1);
                            end;
                            SalesLine.Modify();
                            //end;
                        end;
                    if item."FTT-CST Integr PriceCalc %" <> 0 then
                        if ItemCategory.get(Item."Item Category Code") then begin
                            if ItemCategory.Code = SalesReceivables."FTT-CST DR Category" then
                                CalcType := CalcType::DR;
                            if ItemCategory.Code = SalesReceivables."FTT-CST Redundancy Category" then
                                CalcType := CalcType::Redundency;
                            if ItemCategory.Code = SalesReceivables."FTT-CST Integration Category" then
                                CalcType := CalcType::Integration;
                            //if (ItemCategory."FTT-CST Redundancy Base Item" OR ItemCategory."FTT-CST DR Base Item") then begin
                            CalcUnitPrice := CalculateUnitPrice(SalesLine."Document Type", SalesLine."Document No.", Item."FTT-CST Redundancy PriceCalc %", Item."No.", SalesLine."FTT-CST Redundancy PriceCalc %", CalcType, SalesLine."FTT-CST Location Code");
                            SalesLine.VALIDATE("Unit Price", CalcUnitPrice);
                            if SalesLine."FTT-CST Optional" = SalesLine."FTT-CST Optional"::Yes then begin
                                SalesLine."FTT-CST Unit Price" := CalcUnitPrice;
                                SalesLine.Validate("Unit Price", 0.1);
                            end;
                            SalesLine.Modify();
                            //end;
                        end;
                end;
            until SalesLine.next = 0;

        SalesLine.Reset();
        SalesLine.SetRange("Document Type", pSalesLine."Document Type");
        SalesLine.SetRange("Document No.", pSalesLine."Document No.");
        SalesLine.SetRange(isDRCalculated, false);
        SalesLine.SetRange(isIntegCalculated, false);
        SalesLine.SetRange(isRedundancyCalculated, false);
        if SalesLine.FindSet() then begin
            SalesLine.ModifyAll(isRedundancyCalculated, true);
            SalesLine.ModifyAll(isIntegCalculated, true);
            SalesLine.ModifyAll(isDRCalculated, true);
        end;
        // SalesLine.Reset();
        // SalesLine.SetRange("Document Type", pSalesLine."Document Type");
        // SalesLine.SetRange("Document No.", pSalesLine."Document No.");

        // if SalesLine.FindSet() then
        //     repeat
        //         if Item.Get(SalesLine."No.") then begin
        //             if Item."FTT-CST Redundancy PriceCalc %" <> 0 then
        //                 if ItemCategory.get(Item."Item Category Code") then begin
        //                     if ItemCategory.Code = SalesReceivables."FTT-CST DR Category" then
        //                         CalcType := CalcType::DR;
        //                     if ItemCategory.Code = SalesReceivables."FTT-CST Redundancy Category" then
        //                         CalcType := CalcType::Redundency;
        //                     if ItemCategory.Code = SalesReceivables."FTT-CST Integration Category" then
        //                         CalcType := CalcType::Integration;
        //                     //if (ItemCategory."FTT-CST Redundancy Base Item" OR ItemCategory."FTT-CST DR Base Item") then begin
        //                     SalesLine.VALIDATE("Unit Price", CalculateUnitPrice(SalesLine."Document Type", SalesLine."Document No.", Item."FTT-CST Redundancy PriceCalc %", Item."No.", SalesLine."FTT-CST Redundancy PriceCalc %", CalcType, SalesLine."FTT-CST Location Code"));
        //                     if SalesLine."FTT-CST Optional" = SalesLine."FTT-CST Optional"::Yes then begin
        //                         SalesLine."FTT-CST Unit Price" := CalculateUnitPrice(SalesLine."Document Type", SalesLine."Document No.", Item."FTT-CST Redundancy PriceCalc %", Item."No.", SalesLine."FTT-CST Redundancy PriceCalc %", CalcType, SalesLine."FTT-CST Location Code");
        //                         SalesLine.Validate("Unit Price", 0.01);
        //                     end;
        //                     SalesLine.Modify();
        //                     //end;
        //                 end;
        //             if item."FTT-CST Integr PriceCalc %" <> 0 then
        //                 if ItemCategory.get(Item."Item Category Code") then begin
        //                     if ItemCategory.Code = SalesReceivables."FTT-CST DR Category" then
        //                         CalcType := CalcType::DR;
        //                     if ItemCategory.Code = SalesReceivables."FTT-CST Redundancy Category" then
        //                         CalcType := CalcType::Redundency;
        //                     if ItemCategory.Code = SalesReceivables."FTT-CST Integration Category" then
        //                         CalcType := CalcType::Integration;

        //                     //if (ItemCategory."FTT-CST Redundancy Base Item" OR ItemCategory."FTT-CST DR Base Item") then begin
        //                     SalesLine.VALIDATE("Unit Price", CalculateUnitPrice(SalesLine."Document Type", SalesLine."Document No.", Item."FTT-CST Redundancy PriceCalc %", Item."No.", SalesLine."FTT-CST Redundancy PriceCalc %", CalcType, SalesLine."FTT-CST Location Code"));
        //                     if SalesLine."FTT-CST Optional" = SalesLine."FTT-CST Optional"::Yes then begin
        //                         SalesLine."FTT-CST Unit Price" := CalculateUnitPrice(SalesLine."Document Type", SalesLine."Document No.", Item."FTT-CST Redundancy PriceCalc %", Item."No.", SalesLine."FTT-CST Redundancy PriceCalc %", CalcType, SalesLine."FTT-CST Location Code");
        //                         SalesLine.Validate("Unit Price", 0.01);
        //                     end;
        //                     SalesLine.Modify();
        //                     //end;
        //                 end;
        //         end;
        //     until SalesLine.next = 0;
    end;

    local procedure GetDiffDate(StartingDate: Date; EndingDate: Date; FTTCSTCostType: Enum "FTT-CST Cost Type"): Decimal
    var
        GeneralLedgerSetup: Record "General Ledger Setup";
        DiffDate: Decimal;
        DiffM: Integer;
        DiffY: Integer;
    begin
        if FTTCSTCostType = "FTT-CST Cost Type"::NRC then
            exit(DiffDate);
        if FTTCSTCostType = "FTT-CST Cost Type"::YRCCalculated then
            exit(DiffDate);

        DiffM := Date2DMY(EndingDate, 2) - Date2DMY(StartingDate, 2);
        DiffY := Date2DMY(EndingDate, 3) - Date2DMY(StartingDate, 3);
        DiffDate := 12 * DiffY + DiffM;
        if Date2DMY(EndingDate, 1) > Date2DMY(StartingDate, 1) then
            DiffDate += 1;

        if DiffDate = 0 then
            DiffDate := 1;

        if FTTCSTCostType = "FTT-CST Cost Type"::YRC then
            DiffDate := DiffDate / 12;

        if FTTCSTCostType = "FTT-CST Cost Type"::MRC then
            DiffDate := DiffDate;

        GeneralLedgerSetup.Get();
        DiffDate := Round(DiffDate, GeneralLedgerSetup."Unit-Amount Rounding Precision");
        exit(DiffDate);


    end;

    // local procedure CalculateUnitPrice(DocumentType: Enum "Sales Document Type"; DocumentNo: Code[20];
    //                                                      RedundancyPrice: Decimal;
    //                                                      ItemNo: code[20];
    //                                                      pSalesLine: record "Sales Line"): Decimal
    // var
    //     Item: Record Item;
    //     Item2: Record Item;
    //     ItemCategoty: Record "Item Category";
    //     ItemCategoty2: Record "Item Category";
    //     SalesLine: Record "Sales Line";
    //     TotalAmount: Decimal;
    //     SalesReceivables: record "Sales & Receivables Setup";
    // begin
    //     SalesReceivables.GET();
    //     SalesLine.SetRange(Type, "Sales Line Type"::Item);
    //     SalesLine.SetRange("Document Type", DocumentType);
    //     SalesLine.SetRange("Document No.", DocumentNo);
    //     if not SalesLine.FindSet() then
    //         exit(0);
    //     Item2.get(ItemNo);
    //     ItemCategoty2.get(Item2."Item Category Code");
    //     if (ItemCategoty2.code = SalesReceivables."FTT-CST Integration Category") then
    //         RedundancyPrice := item2."FTT-CST Integr PriceCalc %" else
    //         RedundancyPrice := item2."FTT-CST Redundancy PriceCalc %";
    //     repeat
    //         Item.Get(SalesLine."No.");
    //         if Item."Item Category Code" <> '' then begin
    //             ItemCategoty.Get(Item."Item Category Code");

    //             if not (ItemCategoty2.code = SalesReceivables."FTT-CST Integration Category") then
    //                 if (ItemCategoty."FTT-CST Redundancy Base Item" or ItemCategoty."FTT-CST DR Base Item") and (item."FTT-CST Redundancy PriceCalc %" = 0) then
    //                     if ((SalesLine."FTT-CST DR" = SalesLine."FTT-CST DR"::Yes) or (SalesLine."FTT-CST Redundancy" = SalesLine."FTT-CST Redundancy"::Yes)) then
    //                         TotalAmount += SalesLine."Line Amount";

    //             if (ItemCategoty2.code = SalesReceivables."FTT-CST Integration Category") then begin
    //                 if (ItemCategoty."FTT-CST Redundancy Base Item" or ItemCategoty."FTT-CST DR Base Item") or (ItemCategoty.Code = SalesReceivables."FTT-CST DR Category")
    //                 or (ItemCategoty.Code = SalesReceivables."FTT-CST Redundancy Category") then begin

    //                     TotalAmount += SalesLine."Line Amount";
    //                     RedundancyPrice := item2."FTT-CST Integr PriceCalc %";
    //                     //RedundancyPrice := SalesLine."FTT-CST Redundancy PriceCalc %";
    //                 end;
    //             end;
    //         end;
    //     until SalesLine.Next() = 0;

    //     exit(TotalAmount * (RedundancyPrice / 100));
    // end;

    local procedure CalculateUnitPrice(DocumentType: Enum "Sales Document Type"; DocumentNo: Code[20];
                                                         RedundancyPrice: Decimal;
                                                         ItemNo: code[20];
                                                         PricePerc: Decimal;
                                                         CalcType: Enum "FTT-CST Calc Type";
                                                         pLocationCode: code[20]): Decimal
    var
        Item: Record Item;
        Item2: Record Item;
        ItemCategoty: Record "Item Category";
        ItemCategoty2: Record "Item Category";
        SalesLine: Record "Sales Line";
        SalesLine2: Record "Sales Line";
        TotalAmount: Decimal;
        SalesReceivables: record "Sales & Receivables Setup";
        TotalAmountforInteg2: Decimal; //NRD
    begin
        TotalAmountforInteg2 := 0;
        SalesReceivables.GET();
        SalesLine.SetRange(Type, "Sales Line Type"::Item);
        SalesLine.SetRange("Document Type", DocumentType);
        SalesLine.SetRange("Document No.", DocumentNo);
        SalesLine.SetFilter("FTT-CST Location Code", '%1', pLocationCode);
        //SalesLine.SetRange("FTT-CST Integration", SalesLine."FTT-CST Integration"::Yes); //NRD
        SalesLine.SetRange(isDRCalculated, false); //NRD
        SalesLine.SetRange(isRedundancyCalculated, false); //NRD
        SalesLine.SetRange(isIntegCalculated, false); //NRD
        SalesLine2.CopyFilters(SalesLine);
        if not SalesLine.FindSet() then
            exit(0);
        Item2.get(ItemNo);
        ItemCategoty2.get(Item2."Item Category Code");
        if (ItemCategoty2.code = SalesReceivables."FTT-CST Integration Category") then
            RedundancyPrice := item2."FTT-CST Integr PriceCalc %" else
            RedundancyPrice := item2."FTT-CST Redundancy PriceCalc %";
        RedundancyPrice := PricePerc;
        repeat
            Item.Get(SalesLine."No.");
            if Item."Item Category Code" <> '' then begin
                ItemCategoty.Get(Item."Item Category Code");

                if not (ItemCategoty2.code = SalesReceivables."FTT-CST Integration Category") then begin
                    if (ItemCategoty."FTT-CST Redundancy Base Item" or ItemCategoty."FTT-CST DR Base Item") and (item."FTT-CST Redundancy PriceCalc %" = 0) then
                        if CalcType = CalcType::DR then begin
                            if ((SalesLine."FTT-CST DR" = SalesLine."FTT-CST DR"::Yes)) then
                                TotalAmount += SalesLine."Line Amount";

                            if ((SalesLine."FTT-CST DR" = SalesLine."FTT-CST DR"::Yes) AND (SalesLine."FTT-CST Integration" = SalesLine."FTT-CST Integration"::No)) then
                                TotalAmountforInteg2 += SalesLine."Line Amount";
                        end;
                    if CalcType = CalcType::Redundency then begin
                        if ((SalesLine."FTT-CST Redundancy" = SalesLine."FTT-CST Redundancy"::Yes)) then
                            TotalAmount += SalesLine."Line Amount";

                        if ((SalesLine."FTT-CST Redundancy" = SalesLine."FTT-CST Redundancy"::Yes) AND (SalesLine."FTT-CST Integration" = SalesLine."FTT-CST Integration"::No)) then
                            TotalAmountforInteg2 += SalesLine."Line Amount";
                    end
                end else begin
                    if (ItemCategoty."FTT-CST Redundancy Base Item" or ItemCategoty."FTT-CST DR Base Item") or (ItemCategoty.Code = SalesReceivables."FTT-CST DR Category")
                        or (ItemCategoty.Code = SalesReceivables."FTT-CST Redundancy Category") then begin
                        if (SalesLine."FTT-CST Location Code" = pLocationCode) AND (SalesLine."FTT-CST Integration" = SalesLine."FTT-CST Integration"::Yes) then begin //NRD
                            TotalAmount += SalesLine."Line Amount";
                            RedundancyPrice := PricePerc;
                        end;
                    end;
                end;

                // if (ItemCategoty2.code = SalesReceivables."FTT-CST Integration Category") then begin
                //     if (ItemCategoty."FTT-CST Redundancy Base Item" or ItemCategoty."FTT-CST DR Base Item") or (ItemCategoty.Code = SalesReceivables."FTT-CST DR Category")
                //     or (ItemCategoty.Code = SalesReceivables."FTT-CST Redundancy Category") then begin
                //         if (SalesLine."FTT-CST Location Code" = pLocationCode) then
                //             TotalAmount += SalesLine."Line Amount";
                //         RedundancyPrice := PricePerc;
                //     end;
                // end;
            end;


        until SalesLine.Next() = 0;

        // if SalesLine2.FindSet() then
        //     repeat
        //         SalesLine2.isDRCalculated := true;
        //         SalesLine2.isIntegCalculated := true;
        //         SalesLine2.isRedundancyCalculated := true;
        //         SalesLine2.Modify();
        //     until SalesLine2.Next() = 0;



        if CalcType = CalcType::DR then
            TotalAmountforIntegDR := TotalAmountforInteg2 * (RedundancyPrice / 100)
        else if CalcType = CalcType::Redundency then
            TotalAmountforIntegRED := TotalAmountforInteg2 * (RedundancyPrice / 100);

        if CalcType = CalcType::Integration then
            exit(Abs((TotalAmount - (TotalAmountforIntegDR + TotalAmountforIntegRED)) * (RedundancyPrice / 100)))
        else
            exit(TotalAmount * (RedundancyPrice / 100));


    end;

    trigger OnInsert()
    var
        UserSetup: Record "User Setup";
    begin
        if not UserSetup.Get(UserId) then
            exit;

        if not UserSetup."Permission to Create Sales" then
            Error('Account %1 is not allowed to create Sales Transaction!', UserSetup."User ID");

        If rec."FTT-CST Order Type" = rec."FTT-CST Order Type"::Primary then begin
            rec."FTT-CST Main Order No." := '';
            rec."FTT-CST Primary Order" := '';
        end;
        Rec."FTT-CST Use for Renewal" := true;
    end;

    trigger OnModify()
    var
        SalesLines: record "Sales Line";
    begin
        SalesLines.SetRange("Document Type", rec."Document Type");
        SalesLines.SetRange("Document No.", rec."No.");
        if xRec."FTT-CST Order Type" <> rec."FTT-CST Order Type" then
            SalesLines.ModifyAll("FTT-CST Order Type", rec."FTT-CST Order Type");
        if xRec."FTT-CST Primary Order" <> Rec."FTT-CST Primary Order" then
            SalesLines.ModifyAll("FTT-CST Primary Order", rec."FTT-CST Primary Order");

    end;

    var
        EndingDateErr: Label 'should be more than or equal to %1', Comment = '%1 - Field Caption';
        FinishUpdateForAgrLbl: Label 'Quantity of Items was successfully updated';
        FinishUpdateForInvLbl: Label 'Qty. to Ship and Qty. to Invoice of Items were successfully updated';
        NothingUpdateErr: Label 'There is nothing to update.';
        NothingUpdateLbl: Label 'There is nothing to update';
        StartingDateErr: Label 'should be less than or equal to %1', Comment = '%1 - Field Caption';
        UpdateAgreementDateSaleLineCnf: Label 'You have modified %1. \\ Do you want to update %2 for lines?';
        UpdateDatesMsg: Label 'Some lines are not updated.';
        TotalAmountforInteg: Decimal; //NRD
        TotalAmountforIntegDR: Decimal; //NRD
        TotalAmountforIntegRED: Decimal; //NRD
}
