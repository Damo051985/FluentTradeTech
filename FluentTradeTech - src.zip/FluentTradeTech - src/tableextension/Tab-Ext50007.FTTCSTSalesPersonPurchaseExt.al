tableextension 50007 "FTT-CST SalesPerson Ext" extends "Salesperson/Purchaser"
{
    fields
    {
        field(50001; "Comm. Vendor No."; code[20])
        {
            DataClassification = ToBeClassified;
            TableRelation = Vendor."No." where("Vendor Commission" = filter(true));
        }
        field(50010; "User ID"; code[50])
        {
            Caption = 'User ID';
            DataClassification = ToBeClassified;
            TableRelation = "User Setup"."User ID";
        }
    }

    keys
    {
        // Add changes to keys here
    }

    fieldgroups
    {
        // Add changes to field groups here
    }

    var
        myInt: Integer;
}