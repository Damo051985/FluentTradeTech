tableextension 60016 "FTT-CST Team" extends Team
{
    fields
    {
        field(60000; "FTT-CST Supervisor Code"; Code[20])
        {
            Caption = 'Supervisor Code';
            DataClassification = CustomerContent;
            TableRelation = "Salesperson/Purchaser"."Code";
        }
        field(60001; "FTT-CST Supervisor Reward, %"; Decimal)
        {
            Caption = 'Supervisor Reward, %';
            DataClassification = CustomerContent;
            MinValue = 0;
        }
    }
}
