tableextension 50005 "ActivCueExt" extends "Activities Cue"
{
    fields
    {
        field(50001; "Ongoing Sales Credit Memo"; Integer)
        {
            CalcFormula = count("Sales Header" where("Document Type" = filter("Credit Memo")));
            Caption = 'Ongoing Sales Credit Memos';
            FieldClass = FlowField;
        }
        field(50002; "Ongoing Sales Return Order"; Integer)
        {
            CalcFormula = count("Sales Header" where("Document Type" = filter("Return Order")));
            Caption = 'Ongoing Sales Return Orders';
            FieldClass = FlowField;
        }
    }

    keys
    {
        // Add changes to keys here
    }

    fieldgroups
    {
        // Add changes to field groups here
    }

    var
        myInt: Integer;
}