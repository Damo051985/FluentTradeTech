tableextension 60017 "FTT-CST CustLedger Entry" extends "Cust. Ledger Entry"
{
    fields
    {
        field(60000; "FTT-CST Comm. Base Am. (LCY)"; Decimal)
        {
            Caption = 'Commission Base Amount (LCY)';
            DataClassification = CustomerContent;
        }
        field(60001; "FTT-CST Temp Remaining Amount"; Decimal)
        {
            Caption = 'Temp Remaining Amount';
            DataClassification = CustomerContent;
        }
    }
}
