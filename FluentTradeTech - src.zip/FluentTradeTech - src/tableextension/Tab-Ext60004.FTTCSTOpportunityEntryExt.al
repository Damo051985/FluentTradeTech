tableextension 60004 "FTT-CST Opportunity Entry Ext" extends "Opportunity Entry"
{
    fields
    {
        field(60000; "FTT-CST Opportunity Notif."; Boolean)
        {
            Caption = 'Opportunity Notification';
            DataClassification = CustomerContent;
        }

        field(60001; "FTT-CST Company Name"; text[100])
        {
            Caption = 'Company Name';
        }
        field(60002; "FTT-CST Sales Quote No."; Code[20])
        {
            Caption = 'ssSales Quote No.';
        }
        field(60003; "FTT-CST Sales Order No."; code[20])
        {
            Caption = 'Sales Order No.';
        }
        field(60004; "FTT-CST Estimated Value (LCY)"; Decimal) //NRD - Replicate the Original field
        {
            DataClassification = ToBeClassified;
            Caption = 'Estimated Value (LCY)';

        }
        field(60005; "FTT Calcd. Current Value (LCY)"; Decimal) //NRD - Replicate the Original field
        {
            DataClassification = ToBeClassified;
            Caption = 'Calcd. Current Value (LCY)';
        }
        field(60006; "FTT Updated"; Boolean) //NRD -
        {
            DataClassification = ToBeClassified;
        }
        field(60007; "Estimated Value - Currency"; Code[20])
        {
            DataClassification = ToBeClassified;
        }
    }


    trigger OnBeforeInsert()
    var
        SalesCycleStage: Record "Sales Cycle Stage";
    begin
        if SalesCycleStage.Get(Rec."Sales Cycle Code", Rec."Sales Cycle Stage") then
            Rec."FTT-CST Opportunity Notif." := SalesCycleStage."FTT-CST Create Opp. Notif.";
    end;

    trigger OnAfterInsert()
    var
        Opportunity: Record Opportunity;
        SalesCycleStageNotificationMgt: Codeunit "FTT-CST Sal Cycle St Notif Mgt";
    begin
        if Opportunity.Get(Rec."Opportunity No.") then
            if Opportunity.Closed then begin
                Rec."FTT-CST Opportunity Notif." := true;
                Rec.Modify();
            end;
        if Rec."FTT-CST Opportunity Notif." then
            SalesCycleStageNotificationMgt.EmailSalesCycleStageNotification(Rec);
    end;

    //NRD - Est. Sales Value is finalized
    procedure CheckEstValue()
    var
        recEstValueMod: record "FTT-CST Estimated Value Mod";
    begin
        recEstValueMod.SetRange("Linked No.", rec."Opportunity No.");
        if recEstValueMod.FindSet() then
            recEstValueMod.ModifyAll(Completed, true);
        Commit();
    end;

    //NRD - Est. Sales Value is not finalized
    procedure CheckEstValue2()
    var
        recEstValueMod: record "FTT-CST Estimated Value Mod";
    begin
        recEstValueMod.Reset();
        recEstValueMod.SetRange("Linked No.", rec."Opportunity No.");
        recEstValueMod.SetFilter(Completed, '%1', false);
        if recEstValueMod.FindSet() then
            recEstValueMod.DeleteAll();
        Commit();
    end;


}