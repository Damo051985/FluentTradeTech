tableextension 60002 "FTT-CST Marketing Setup" extends "Marketing Setup"
{
    fields
    {
        field(60000; "FTT-CST Sending E-mail Acc. Id"; Guid)
        {
            Caption = 'Sending E-mail Account Id';
            DataClassification = CustomerContent;
        }
        field(60001; "FTT-CST Sending E-mail Account"; Text[250])
        {
            Caption = 'Sending E-mail Account';
            DataClassification = CustomerContent;

            trigger OnValidate()
            begin
                if "FTT-CST Sending E-mail Account" = '' then
                    Clear("FTT-CST Sending E-mail Acc. Id");
            end;

            trigger OnLookup()
            var
                ChosenEmailAccount: Record "Email Account";
                EmailAccounts: Page "Email Accounts";
            begin
                Clear(EmailAccounts);
                EmailAccounts.EnableLookupMode();
                if EmailAccounts.RunModal() = Action::LookupOK then begin
                    EmailAccounts.GetAccount(ChosenEmailAccount);
                    "FTT-CST Sending E-mail Acc. Id" := ChosenEmailAccount."Account Id";
                    "FTT-CST Sending E-mail Account" := ChosenEmailAccount.Name;
                end;
            end;
        }
        field(60002; "FTT-CST Def. Mailing Group"; Code[10])
        {
            Caption = 'Default Mailing Group';
            DataClassification = CustomerContent;
            TableRelation = "Mailing Group".Code;
        }
        field(60003; "FTT-CST Def. Attach. Not. Per."; DateFormula)
        {
            Caption = 'Default Attachm. Notif. Period';
            DataClassification = CustomerContent;
        }
    }
}
