tableextension 50011 "FTT-CST Purch.CrMemo Hdr Ext." extends "Purch. Cr. Memo Hdr."
{
    fields
    {
        field(60005; "Comm. Document No."; code[20])
        {
            DataClassification = ToBeClassified;
        }
    }

    keys
    {
        // Add changes to keys here
    }

    fieldgroups
    {
        // Add changes to field groups here
    }

    var
        myInt: Integer;
}