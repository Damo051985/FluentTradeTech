
tableextension 50003 "User Setup Ext. Attached" extends "User Setup"
{
    fields
    {
        field(50001; "Job Position"; Text[250])
        {
            DataClassification = ToBeClassified;
        }
        field(50002; "Full Name"; Text[250])
        {
            DataClassification = ToBeClassified;

        }
        field(50003; "Email Signature Included"; Boolean)
        {
            DataClassification = ToBeClassified;
        }
        field(50004; "Last Remark Message"; Text[250])
        {
            DataClassification = ToBeClassified;
        }
        field(50005; "GMAIL Admin Access"; Boolean)
        {
            DataClassification = ToBeClassified;
        }
        field(50006; "Sales Quote Admin"; Boolean) //Use for Final Quote
        {
            DataClassification = ToBeClassified;
        }
        field(50007; "Permission to Create Sales"; Boolean)
        {
            DataClassification = ToBeClassified;
        }
        field(50008; "Prospect Visibilty"; Boolean)
        {
            DataClassification = ToBeClassified;
        }
        field(50010; "Skip NDA Validation"; Boolean)
        {
            DataClassification = ToBeClassified;
        }
        field(50011; "Commission Full Access"; Boolean) // NRD-Commission
        {
            DataClassification = ToBeClassified;
        }

    }

    var
        myInt: Integer;
}