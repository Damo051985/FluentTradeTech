tableextension 60007 "FTT-CST Sales Cycle Stage Ext" extends "Sales Cycle Stage"
{
    fields
    {
        field(60000; "FTT-CST Create Opp. Notif."; Boolean)
        {
            Caption = 'Create Opportunity Notification';
            DataClassification = CustomerContent;
        }
        //nrd
        field(60001; "Required Estimated Value"; Boolean)
        {
            Caption = 'Required Estimated Sales Value(LCY)';
            DataClassification = ToBeClassified;

        }
        //nrd
    }
}