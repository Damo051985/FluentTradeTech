tableextension 60014 "FTT-CST Sales Invoice Header" extends "Sales Invoice Header"
{
    fields
    {
        field(60001; "FTT-CST Agr. Starting Date"; Date)
        {
            Caption = 'Agreement Starting Date';
            DataClassification = CustomerContent;
        }
        field(60002; "FTT-CST Agr. Ending Date"; Date)
        {
            Caption = 'Agreement Ending Date';
            DataClassification = CustomerContent;
        }
        field(60003; "FTT-CST Agr. Period Number"; Integer)
        {
            Caption = 'Agreement Period Number';
            DataClassification = CustomerContent;
        }
        field(60004; "Total Comm. Base Amt. (LCY)"; Decimal)
        {
            FieldClass = FlowField;
            Caption = 'Total Commission Base Amount (LCY)';
            CalcFormula = sum("Sales Invoice Line"."Commission Base Amount (LCY)" where("Document No." = field("No.")));

        }
        field(60005; "Total Comm. Base Amt"; Decimal)
        {
            FieldClass = FlowField;
            Caption = 'Total Commission Base Amount';
            CalcFormula = sum("Sales Invoice Line"."Commission Base Amount" where("Document No." = field("No.")));

        }
        field(60016; "Commission Computed"; Boolean)
        {
            DataClassification = ToBeClassified;
        }
        field(60017; "Supervisor Computed"; Boolean)
        {
            DataClassification = ToBeClassified;
        }
        Field(60020; "Inserted in Report"; Boolean)
        {
            DataClassification = ToBeClassified;
            Caption = 'Inserted In Report';
        }
        Field(60025; "Inserted in Report 2"; Boolean)
        {
            DataClassification = ToBeClassified;
            Caption = 'Inserted In Report';
        }
        Field(60030; "Inserted in Report 3"; Boolean)
        {
            DataClassification = ToBeClassified;
            Caption = 'Inserted In Report';
        }
    }
}
