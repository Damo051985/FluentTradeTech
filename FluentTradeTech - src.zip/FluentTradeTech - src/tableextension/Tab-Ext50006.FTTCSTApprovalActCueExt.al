tableextension 50006 "ApprovalActExtTable" extends 9144
{
    fields
    {
        field(50001; "Requests Rejected for Approval"; Integer)
        {
            CalcFormula = count("Approval Entry" where("Sender ID" = field("User ID Filter"),
                                                        Status = filter(Rejected)));
            Caption = 'Requests Rejected for Approval';
            FieldClass = FlowField;
        }
        field(50002; "Requests Approved"; Integer)
        {
            //CalcFormula = count("Approval Entry" where("Approver ID" = field("User ID Filter"),
            //Status = filter(Approved)));
            CalcFormula = count("Approval Entry" Where(Status = filter(Approved)));
            Caption = 'Requests Approved';
            FieldClass = FlowField;
        }
    }

    keys
    {
        // Add changes to keys here
    }

    fieldgroups
    {
        // Add changes to field groups here
    }

    var
        myInt: Integer;
}