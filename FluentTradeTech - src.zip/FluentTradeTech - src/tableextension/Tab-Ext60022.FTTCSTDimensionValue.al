tableextension 60022 "FTT-CST Dimension Value" extends "Dimension Value"
{
    fields
    {
        Field(60001; "FTT-CST Sublocation"; Option)
        {
            DataClassification = ToBeClassified;
            OptionMembers = Blank,LD4,LD42,NY2,NY4,NY6,TY3,SG1,None;
            OptionCaption = '. . . . . . .,LD 4,LD 4.2,NY 2,NY 4,NY 6,TY 3,SG 1, None';
            Caption = 'Sublocation';
        }
        //>>Dan
        Field(60002; "Product Category"; Option)
        {
            DataClassification = ToBeClassified;
            OptionMembers = " ",Connectivity,Distibution,RiskOthers,OtherYRC;
            OptionCaption = ' ,Connectivity,Distribution,Risk & Others,Other YRC';
            Caption = 'Product Category';
        }
        //<<Dan
    }
    keys
    {
        key(SublKey; "FTT-CST Sublocation")
        {
        }
    }
}
