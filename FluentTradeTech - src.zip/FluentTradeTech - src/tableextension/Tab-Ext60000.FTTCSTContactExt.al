tableextension 60000 "FTT-CST ContactExt" extends Contact
{
    fields
    {
        field(60000; "FTT-CST Subsidiary No."; Code[20])
        {
            Caption = 'Subsidiary No.';
            DataClassification = ToBeClassified;
            TableRelation = if ("Company No." = const(''))
            Contact."No." where(Type = const("Subsidiary Company"))
            else
            Contact."No." where(Type = const("Subsidiary Company"), "Company No." = field("Company No."));
            trigger OnValidate()
            begin
                SubsidiaryNoOnValidate();
            end;
        }
        field(60001; "FTT-CST Subsidiary Name"; Text[100])
        {
            Caption = 'Subsidiary Name';
            DataClassification = ToBeClassified;
            Editable = false;
            TableRelation = if ("Company No." = const(''))
            Contact.Name where(Type = const("Subsidiary Company"))
            else
            Contact.Name where(Type = const("Subsidiary Company"), "Company No." = field("Company No."));
            trigger OnValidate()
            begin
                SubsidiaryNameOnValidate();
            end;
        }
        field(60002; "FTT-CST Subsidiary Type"; Integer)
        {
            Caption = 'Subsidiary Type';
            DataClassification = ToBeClassified;
            Editable = false;
        }
        field(60003; "FTT-CST Notif. Mail Gr. Code"; Code[10])
        {
            Caption = 'Notification Mailing Group Code';
            DataClassification = CustomerContent;
            TableRelation = "Mailing Group".Code;
        }

        field(60004; "FTT-CST No. of Opportunities"; Integer)
        {
            FieldClass = FlowField;
            CalcFormula = Count("Opportunity Entry" WHERE(Active = CONST(true),
                                                           "Contact Company No." = FIELD("Company No."),
                                                           "Estimated Close Date" = FIELD("Date Filter"),
                                                           "Contact No." = FIELD(FILTER("Lookup Contact No.")),
                                                           "Action Taken" = FIELD("Action Taken Filter")));
            Caption = 'No. of Opportunities';
            Editable = false;
        }
        //NRD
        field(60005; "Prospect Type"; Option)
        {
            OptionCaption = ' ,BUY-SIDE,GLOBAL BANK,INST BROKER, REGIONAL BANK,VENUE EXCHANGE,VENDOR';
            OptionMembers = " ","BUY-SIDE","GLOBAL BANK","INST BROKER","REGIONAL BANK","VENUE EXCHANGE",VENDOR;
        }
        //+
        field(60007; "FTT-CST ContBusinessRelation"; Enum "FTT-CST Contbusiness Relation")  //NRD
        {
            Caption = 'Contact Business Relation';
            Editable = false;
        }
        //>>Dan
        field(60010; "FTT-CST Role"; Text[80])  //NRD
        {
            Caption = 'Role';
            Editable = True;
            DataClassification = CustomerContent;
        }
        //<<Dan
    }
    //nrd
    trigger OnBeforeDelete()
    var
        recUserSetup: Record "User Setup";
    begin
        if not recUserSetup.Get(UserId) then
            exit;

        recUserSetup.TestField("Salespers./Purch. Code");

        if recUserSetup."Salespers./Purch. Code" <> rec."Salesperson Code" then
            Error('Deleted is Not allowed if it''s not your a salesperson');
    end;
    //  


    local procedure SubsidiaryNoOnValidate()
    var
        Contact: Record Contact;
    begin
        CheckUnloggedSubsidiarySegments();
        if "FTT-CST Subsidiary No." = '' then begin
            "FTT-CST Subsidiary Name" := '';
            exit;
        end;

        Contact.Get("FTT-CST Subsidiary No.");

        "FTT-CST Subsidiary Name" := Contact.Name;

        if Type <> Type::Person then
            exit;

        Validate("Company No.", Contact."Company No.");
    end;

    local procedure CheckUnloggedSubsidiarySegments()
    var
        SegLine: Record "Segment Line";
        SegmentLineErr: Label 'You cannot change ''%1'' because one or more unlogged segments are assigned to the contact.';
    begin
        SegLine.Reset();
        SegLine.SetRange("Contact No.", "No.");
        if not SegLine.IsEmpty() then
            Error(SegmentLineErr, FieldCaption("FTT-CST Subsidiary No."));
    end;

    local procedure SubsidiaryNameOnValidate()
    begin
        Validate("FTT-CST Subsidiary No.");
    end;
}
