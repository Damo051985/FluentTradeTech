tableextension 60009 "FTT-CST PriceListLineExt" extends "Price List Line"
{
    fields
    {
        field(60000; "FTT-CST Optional for PI"; Boolean)
        {
            Caption = 'Optional for Pricing Indication';
            DataClassification = CustomerContent;
        }
    }
}
