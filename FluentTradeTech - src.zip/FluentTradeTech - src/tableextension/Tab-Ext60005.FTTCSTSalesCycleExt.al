tableextension 60005 "FTT-CST Sales Cycle Ext" extends "Sales Cycle"
{
    fields
    {
        field(60000; "FTT-CST Default Mailing Group"; Code[10])
        {
            Caption = 'Default Mailing Group';
            DataClassification = CustomerContent;
            TableRelation = "Mailing Group".Code;
        }
        /* >> for preparation
        field(60010; "FTT-CST Active"; Boolean)
        {
            Caption = 'Active';
            DataClassification = CustomerContent;
            trigger OnValidate()
            var
                lSC: Record "Sales Cycle";
                lLb: Label 'Sales Cycle %1 already active. Uncheck %1 to proceed!';
            Begin
                Clear(lSC);
                lSC.SetRange("FTT-CST Active", TRUE);
                IF lSC.FINDFIRST then
                    Error(StrSubstNo(llb, lSC.Code));
            End;
        }
        */ //<< for preparation
    }
}
