tableextension 50001 "Sales RespCenter Ext." extends "Responsibility Center"
{
    fields
    {
        field(50001; "Sales Manager ID"; Code[50])
        {
            DataClassification = ToBeClassified;
            TableRelation = User."User Name";
            ValidateTableRelation = false;
            trigger OnValidate()
            var
                RecSalesRep: record "Responsibility Center";
            begin
                RecSalesRep.Reset();
                RecSalesRep.SetRange("Sales Manager ID", rec."Sales Manager ID");
                if RecSalesRep.FindFirst() then
                    Error('%1 was already assigned to %2 Responsibility Code', rec."Sales Manager ID", RecSalesRep.Code);
            end;
        }
    }
}