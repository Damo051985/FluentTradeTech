tableextension 60013 "FTT-CST StandardSalesLine" extends "Standard Sales Line"
{
    fields
    {
        field(60000; "FTT-CST Lines Calc. Type"; Enum "FTT-CST UnitPriceCalcType")
        {
            Caption = 'Lines Calc. Type';
            DataClassification = CustomerContent;

            trigger OnValidate()
            begin
                "FTT-CST Price Percentage, %" := 0;
            end;
        }
        field(60001; "FTT-CST Price Percentage, %"; Decimal)
        {
            Caption = 'Price Percentage, %';
            DataClassification = CustomerContent;
            MinValue = 0;
        }
    }
}
