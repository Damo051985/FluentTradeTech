enum 60000 "FTT-CST Cost Type"
{
    Extensible = true;

    value(0; NRC)
    {
        Caption = 'NRC';
    }
    value(1; MRC)
    {
        Caption = 'MRC';
    }
    value(2; YRC)
    {
        Caption = 'YRC';
    }
    value(3; YRCCalculated)
    {
        Caption = 'YRC Calculated';
    }
}
