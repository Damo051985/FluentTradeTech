enum 60005 "FTT-CST Calc Type"
{
    Extensible = true;

    value(0; Redundency)
    {
        Caption = 'Redundancy';
    }
    value(1; DR)
    {
        Caption = 'DR';
    }
    value(2; Integration)
    {
        Caption = 'Integration';
    }
}