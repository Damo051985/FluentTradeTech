enum 50001 "Related Document Type"
{
    Extensible = true;

    value(0; " ")
    {
    }
    value(1; "Opportunity")
    {
    }
    value(2; "Customer")
    {
    }
    value(3; "Contact")
    {
    }
}