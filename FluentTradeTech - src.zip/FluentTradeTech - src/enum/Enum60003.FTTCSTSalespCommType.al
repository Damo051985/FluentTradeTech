enum 60003 "FTT-CST SalespCommType"
{
    Extensible = true;

    value(0; "100")
    {
        Caption = '100%';
    }
    value(1; "50")
    {
        Caption = '50%';
    }
    value(2; "0")
    {
        Caption = '0%';
    }
}
