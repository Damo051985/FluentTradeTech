enum 60004 "FTT-CST DocumentAttachmentType"
{
    Extensible = true;

    value(0; "Customer")
    {
        Caption = 'Customer';
    }
    value(1; "Contact")
    {
        Caption = 'Contact';
    }
}