enum 50003 "FTT-CST Contbusiness Relation"
{
    Extensible = true;
    AssignmentCompatibility = true;

    value(0; None)
    {
        Caption = 'None';
    }
    value(1; Customer)
    {
        Caption = 'Customer';
    }
    value(2; Vendor)
    {
        Caption = 'Vendor';
    }
    value(3; "Bank Account")
    {
        Caption = 'Bank Account';
    }
    value(4; Employee)
    {
        Caption = 'Employee';
    }

}