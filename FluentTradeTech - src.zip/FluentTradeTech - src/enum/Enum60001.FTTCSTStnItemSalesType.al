enum 60001 "FTT-CST Stn. Item Sales Type"
{
    Extensible = true;

    value(0; Manual)
    {
        Caption = 'Manual';
    }
    value(1; Automatic)
    {
        Caption = 'Automatic';
    }
    value(2; "Always Ask")
    {
        Caption = 'Always Ask';
    }
}
