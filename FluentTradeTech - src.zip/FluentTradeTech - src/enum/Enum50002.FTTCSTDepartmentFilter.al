enum 50002 "Department Filter"
{
    Extensible = true;

    value(0; " ")
    {
    }
    value(1; "Sales")
    {
    }
    value(2; "Research and Development")
    {
    }
    value(3; "Finance and Operation")
    {
    }
    value(4; HR)
    {
    }

}