enum 60006 "FTT-CST Location Type"
{
    Extensible = true;

    value(0; Current)
    {
        Caption = 'Current';
    }
    value(1; All)
    {
        Caption = 'All';
    }
}