enum 60002 "FTT-CST UnitPriceCalcType"
{
    Extensible = true;

    value(0; " ")
    {
        Caption = ' ';
    }
    value(1; "Calculation Basis")
    {
        Caption = 'Calculation Basis';
    }
    value(2; Calculated)
    {
        Caption = 'Calculated';
    }
}
