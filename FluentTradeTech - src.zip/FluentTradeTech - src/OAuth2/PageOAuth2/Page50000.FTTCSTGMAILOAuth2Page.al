page 50000 "GMAIL OAuth2 Login Page"
{
    ApplicationArea = all;
    Caption = 'OAuth 2.0 Token Generation';
    UsageCategory = Administration;
    layout
    {
        area(Content)
        {
            label(Warning)
            {
                Caption = 'Please allow popups from this page.';
                ApplicationArea = all;
            }
            usercontrol(oa; OAuthReDirect)
            {
                ApplicationArea = All;
                trigger ControlReady()
                var

                    TypeHelper: Codeunit "Type Helper";
                    URL: Text;
                    URL2: Text;
                    URL3: Text;
                    AuthorizationEndpoint: Text;
                    TokenEndpoint: Text;
                    ClientID: Text;
                    ClientSecret: Text;
                    AppCallbackUrl: Text;
                    StateValue: Text;
                    GMAILMgtSetup: Record "GMAIL Maintenance Setup";


                begin
                    if not GMAILMgtSetup.Get() then
                        exit;

                    AuthorizationEndpoint := GMAILMgtSetup."Authorization URL";
                    TokenEndpoint := GMAILMgtSetup."Token URL";
                    AppCallbackUrl := GMAILMgtSetup."CallBack URL";
                    AppCallbackUrl := TypeHelper.UrlEncode(AppCallbackUrl);
                    ClientID := GMAILMgtSetup."Client ID";
                    ClientSecret := GMAILMgtSetup."Client Secret ID";

                    StateValue := State();

                    URL := AuthorizationEndpoint + '?' +
                           'response_type=code' +
                           '&client_id=' + ClientID +
                           '&redirect_uri=' + AppCallbackUrl +
                           '&state=' + StateValue +
                           '&scope=' + GMAILMgtSetup.Scopes +
                           '&access_type=offline';

                    URL2 := TokenEndpoint + '?' +
                            'grant_type=authorization_code' +
                            '&code=AUTH_CODE_HERE' +
                            '&redirect_uri=' + AppCallbackUrl +
                            '&client_id=' + ClientID +
                            '&client_secret=' + ClientSecret;



                    CurrPage.oa.LaunchURLinNewWindow(URL);

                    IsolatedStorage.Set('OAUTH-STATE', StateValue);
                    IsolatedStorage.Set('OAUTH-URL2', URL2);
                    if IsolatedStorage.Delete('OAUTH-TOKEN') then;
                    CurrPage.oa.StartTimer();
                end;

                trigger TimerTic()
                var
                    GMAILMgtSetup2: Page "GMAIL Maintenance Setup";
                begin
                    if IsolatedStorage.Contains('OAUTH-TOKEN') then begin
                        CurrPage.oa.CloseWindow();
                        GMAILMgtSetup2.UpdateTokenDetails();
                        //Sleep(1000);
                        //Page.run(50004);
                        CurrPage.Close();

                        //Page.run(50005);

                    end;
                end;
            }
        }
    }
    procedure State(): Text
    begin
        exit(format(Random(1000000), 0, 9) + format(Random(1000000), 0, 9) + format(Random(1000000), 0, 9));
    end;


}