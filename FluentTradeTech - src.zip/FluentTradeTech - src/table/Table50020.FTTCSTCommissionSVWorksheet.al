table 50020 "Commission SV. Worksht. Header"
{
    DataClassification = ToBeClassified;
    DataCaptionFields = "Document No.";

    fields
    {
        field(1; "Document No."; Code[20])
        {
            DataClassification = ToBeClassified;
            Editable = false;
        }

        field(4; "Assigned User ID"; Code[50])
        {
            DataClassification = ToBeClassified;
            TableRelation = User;
        }
        field(5; "Creation Date"; Date)
        {
            DataClassification = ToBeClassified;

        }
        field(6; "Commission Agreement No."; code[20])
        {
            DataClassification = ToBeClassified;
            Caption = 'Commission Agreement No.';
            TableRelation = "FTT-CST Comm. Agrm. Header"."Agreement No.";
        }

        field(7; "Settlement Type"; Option)
        {
            OptionMembers = "Invoice","Partial Payment","Full Payment";
            OptionCaption = 'Invoice,Partial Payment,Full Payment';
        }

        field(8; "Agreement Period"; Integer)
        {
            Caption = 'Agreement Period';
        }
        field(9; "PDC Bank Account No."; Code[50])
        {
            DataClassification = ToBeClassified;
            TableRelation = "Bank Account"."No.";
        }
        field(10; "Payment Method Code"; Code[20])
        {
            DataClassification = ToBeClassified;
            TableRelation = "Payment Method";
        }

        field(13; "Supervisor Reward %"; Decimal)
        {
            DataClassification = ToBeClassified;
        }
        field(14; "Total SV. Reward Amount (LCY)"; Decimal)
        {
            FieldClass = FlowField;
            CalcFormula = sum("Commission SV. Worksheet Lines"."Supervisor Reward Amount (LCY)" where("Document No." = field("Document No.")));
        }
        field(15; "Total SV. Reward Amount"; Decimal)
        {
            FieldClass = FlowField;
            CalcFormula = sum("Commission SV. Worksheet Lines"."Supervisor Reward Amount" where("Document No." = field("Document No.")));
        }
        field(20; "Vendor No.  (SalesPerson)"; Code[20])
        {
            DataClassification = ToBeClassified;
            TableRelation = Vendor."No.";
            trigger OnValidate()
            var
                Vendor: Record Vendor;
            begin
                Vendor.Reset();
                Vendor.SetRange("No.", "Vendor No.  (SalesPerson)");
                if Vendor.FindFirst() then begin
                    "Vendor Name (SalesPerson)" := Vendor.Name;
                end;
            end;
        }
        field(21; "Vendor Name (SalesPerson)"; Text[50])
        {
            DataClassification = ToBeClassified;
        }
        field(22; "Comm. Payable Doc. No."; Code[20])
        {
            DataClassification = ToBeClassified;
        }
        field(23; "Comm. Payment Doc. No."; Code[20])
        {
            DataClassification = ToBeClassified;
        }
        field(24; Status; Option)
        {
            DataClassification = ToBeClassified;
            OptionMembers = "Open","Calculated","Payable Posted","Released","Payment Posted","Payable Created","Payment Created","Payable Reversed","Payment Reversed","**Refer to Journal Status";
        }
        field(25; "No. Series"; Code[20])
        {
            DataClassification = ToBeClassified;
        }
        field(28; "Comm. PI No."; Code[20])
        {
            DataClassification = ToBeClassified;
        }
        field(29; "Payable Due Date"; Date)
        {
            DataClassification = ToBeClassified;
        }

        field(41; "Payment Reversal No."; Code[30])
        {
            DataClassification = ToBeClassified;
        }
        field(42; "Payable Reversal No."; Code[30])
        {
            DataClassification = ToBeClassified;
        }
        field(45; "Invoice Date From"; Date)
        {
            DataClassification = ToBeClassified;
        }
        field(46; "Invoice Date To"; Date)
        {
            DataClassification = ToBeClassified;
        }
        field(48; "Total Application Amount"; Decimal)
        {
            FieldClass = FlowField;
            CalcFormula = sum("Commission SV. Worksheet Lines"."Application Amount" where("Document No." = field("Document No.")));
        }

    }

    keys
    {
        key(Key1; "Document No.")
        {
            Clustered = true;
        }
    }

    var
        myInt: Integer;

    trigger OnInsert()
    begin

        IF "Document No." = '' THEN BEGIN
            if not CommSetup.Get() then
                exit;
            CommSetup.TestField("Comm. SV Nos.");

            "Document No." := NoSeriesMgt.GetNextNo(CommSetup."Comm. SV Nos.");
        end;

        Status := Status::Open;
        "Creation Date" := Today;
        "Assigned User ID" := UserId;
    end;


    var
        recSalesReceivableSetup: Record "Sales & Receivables Setup";
        VarCommWorkSheetDocNo: Code[20];
        NoSeriesMgt: Codeunit "No. Series";
        CommSetup: Record "FTT-CST Commission Agr. Setup";


}