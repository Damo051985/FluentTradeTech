table 60000 "FTT-CST Stn. Item Sales Code"
{
    Caption = 'Standard Item Sales Code';
    DataClassification = CustomerContent;

    fields
    {
        field(1; "Item No."; Code[20])
        {
            Caption = 'Item No.';
            DataClassification = CustomerContent;
            TableRelation = Item."No.";
        }
        field(2; "Code"; Code[10])
        {
            Caption = 'Code';
            DataClassification = CustomerContent;
            TableRelation = "Standard Sales Code".Code;

            trigger OnValidate()
            begin
                GetDataStandardSalesCode();
            end;
        }
        field(3; Description; Text[100])
        {
            Caption = 'Description';
            DataClassification = CustomerContent;
            Editable = false;
        }
        field(4; "Currency Code"; Code[10])
        {
            Caption = 'Currency Code';
            DataClassification = CustomerContent;
            Editable = false;
        }
        field(5; "Insert Rec. Lines On Pr. List"; Enum "FTT-CST Stn. Item Sales Type")
        {
            Caption = 'Insert Rec. Lines On Price List';
            DataClassification = CustomerContent;
        }
        field(6; "Insert Rec. Lines On Quotes"; Enum "FTT-CST Stn. Item Sales Type")
        {
            Caption = 'Insert Rec. Lines On Quotes';
            DataClassification = CustomerContent;
        }
        field(7; "Insert Rec. Lines On Orders"; Enum "FTT-CST Stn. Item Sales Type")
        {
            Caption = 'Insert Rec. Lines On Orders';
            DataClassification = CustomerContent;
        }
        field(8; "Insert Rec. Lines On Invoices"; Enum "FTT-CST Stn. Item Sales Type")
        {
            Caption = 'Insert Rec. Lines On Invoices';
            DataClassification = CustomerContent;
        }
        field(9; "Insert Rec. Lines On Cr. Memos"; Enum "FTT-CST Stn. Item Sales Type")
        {
            Caption = 'Insert Rec. Lines On Cr. Memos';
            DataClassification = CustomerContent;
        }
    }
    keys
    {
        key(PK; "Item No.", "Code")
        {
            Clustered = true;
        }
    }

    local procedure GetDataStandardSalesCode()
    var
        StandardSalesCode: Record "Standard Sales Code";
    begin
        StandardSalesCode.Get(Rec.Code);
        Rec.Description := StandardSalesCode.Description;
        Rec."Currency Code" := StandardSalesCode."Currency Code";
    end;
}
