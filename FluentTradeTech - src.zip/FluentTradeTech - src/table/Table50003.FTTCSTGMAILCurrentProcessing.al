table 50003 "GMAIL Current Processing"
{
    DataClassification = ToBeClassified;

    fields
    {
        field(1; "EMAIL ID"; text[100])
        {
            DataClassification = ToBeClassified;

        }
    }

    keys
    {
        key(Key1; "EMAIL ID")
        {
            Clustered = true;
        }
    }

    fieldgroups
    {
        // Add changes to field groups here
    }

    var
        myInt: Integer;

    trigger OnInsert()
    begin

    end;

    trigger OnModify()
    begin

    end;

    trigger OnDelete()
    begin

    end;

    trigger OnRename()
    begin

    end;

}