table 60018 "Email Mailing Group Code"
{
    Caption = 'Email Mailing Group Code';
    DataClassification = ToBeClassified;

    fields
    {
        field(10; "Mailing Group Code"; Code[30])
        {
            Caption = 'Mailing Group Code';
        }
        field(20; Description; Text[100])
        {
            Caption = 'Description';
        }
    }
    keys
    {
        key(PK; "Mailing Group Code")
        {
            Clustered = true;
        }
    }
    Trigger OnDelete()
    var
        lMailGrp: Record "Email Mailing Group";
    Begin
        Clear(lMailGrp);
        lMailGrp.SetRange("Mailing Group Code", "Mailing Group Code");
        IF lMailGrp.FINDSET then
            lMailGrp.DELETEALL;
    End;
}
