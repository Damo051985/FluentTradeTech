table 50004 "GMAIL Email Relation"
{
    DataClassification = ToBeClassified;
    Permissions = tabledata "Sent Email" = rid;
    fields
    {
        field(1; EntryNo; Integer)
        {
            DataClassification = ToBeClassified;

        }
        field(2; "Email Type"; Option)
        {
            OptionMembers = "Inbox","Sent";
            OptionCaption = 'Inbox,Sent';
        }
        field(3; "Inbox Entry No."; Integer)
        {
            DataClassification = ToBeClassified;
            TableRelation = "Gmail Inbound/Outbound".EntryNo where("Email Type" = field("Email Type"));

        }

        field(5; "Linked Document No."; Code[50])
        {
            Caption = 'Linked No.';
            TableRelation = if ("Linked Document Type" = const("Opportunity")) "Opportunity"
            else
            if ("Linked Document Type" = const(Customer)) Customer else
            if ("Linked Document Type" = const(Contact)) Contact;

            trigger OnValidate()
            var
                RecRef: RecordRef;
                FldRef: FieldRef;
                RecGmailInbox: Record "Gmail Inbound/Outbound";
                recContact: Record Contact;
                recOpporunity: Record Opportunity;
                recCustomer: Record Customer;
            begin
                TestField("Linked Document Type");

                case "Linked Document Type" of
                    "Linked Document Type"::Contact:
                        begin
                            if not recContact.get("Linked Document No.") then
                                exit;

                            Description := recContact.Name;
                        end;
                    "Linked Document Type"::Customer:
                        begin
                            if not recCustomer.get("Linked Document No.") then
                                exit;

                            Description := recCustomer.Name;
                        end;
                    "Linked Document Type"::Opportunity:
                        begin
                            if not recOpporunity.get("Linked Document No.") then
                                exit;

                            Description := recOpporunity.Description;
                        end;

                end;
                if "Email Type" = "Email Type"::Sent then begin
                    if not RecGmailInbox.Get("Inbox Entry No.") then
                        exit;


                    "Sent From" := RecGmailInbox."Sent From";
                    "Sent To" := RecGmailInbox."Sent To";
                    Subject := RecGmailInbox.Subject;
                    "Date Received" := RecGmailInbox."Date Received";
                    "Date Sent" := RecGmailInbox."Date Received";
                end else begin
                    if not RecGmailInbox.Get("Inbox Entry No.") then
                        exit;


                    "Sent From" := RecGmailInbox."Sent From";
                    "Sent To" := RecGmailInbox."Sent To";
                    Subject := RecGmailInbox.Subject;
                    "Date Received" := RecGmailInbox."Date Received";
                end;
            end;
        }
        field(6; "Linked Document Type"; Enum "Related Document Type")
        {
            Caption = 'Related Document Type';
            DataClassification = ToBeClassified;

        }
        field(7; "Subject"; Text[1024])
        {
            DataClassification = ToBeClassified;
        }
        field(8; "Date Sent"; Date)
        {
            DataClassification = ToBeClassified;
            Caption = 'Sent';
        }
        field(9; "Date Received"; Date)
        {
            DataClassification = ToBeClassified;
            Caption = 'Received';
        }
        field(10; "Date Created"; Date)
        {
            DataClassification = ToBeClassified;
        }
        field(11; "Created by User"; Code[50])
        {
            DataClassification = ToBeClassified;
        }
        field(12; "Sent From"; text[250])
        {
            DataClassification = ToBeClassified;

        }
        field(13; "Sent To"; text[1024])
        {
            DataClassification = ToBeClassified;
        }
        field(14; "Thread ID"; Text[250])
        {
            DataClassification = ToBeClassified;
        }
        field(15; "Description"; Text[1024])
        {
            Caption = 'Name';
            DataClassification = ToBeClassified;
        }
        field(16; "GMAIL Inbox ID"; Text[250])
        {
            DataClassification = ToBeClassified;
            TableRelation = "Gmail Inbound/Outbound"."GMAIL Inbox ID" where("Email Type" = field("Email Type"));

        }
        field(17; "Estimated Sales Value (LCY)"; Decimal)
        {
            Caption = 'Estimated Sales Value (LCY)';
            DataClassification = ToBeClassified;
        }
        field(20; "FTT-CST Contact"; Text[250])
        {
            DataClassification = ToBeClassified;
            Caption = 'Contact';
        }
    }

    keys
    {
        key(Key1; EntryNo)
        {
            Clustered = true;
        }
        key(Key3; "Linked Document Type")
        {

        }
        key(Key4; "Email Type", "Inbox Entry No.", EntryNo, "GMAIL Inbox ID")
        {

        }
        key(Key5; "Email Type", "GMAIL Inbox ID", EntryNo)
        {

        }
    }

    fieldgroups
    {
        // Add changes to field groups here
    }

    var
        myInt: Integer;


    trigger OnInsert()
    begin
        "Created by User" := UserId;
        "Date Created" := today;

    end;

    trigger OnModify()
    begin

    end;

    trigger OnDelete()
    var
        reclEstValue: Record "FTT-CST Estimated Value Mod";
    begin
        reclEstValue.Reset();
        reclEstValue.SetRange("Original Opportunity No.", Rec."Linked Document No.");
        reclEstValue.SetRange("Linked No.", rec."GMAIL Inbox ID");
        if reclEstValue.FindSet() then
            reclEstValue.DeleteAll();
    end;

    trigger OnRename()
    begin

    end;

}