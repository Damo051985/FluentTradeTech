table 50017 "FTT-CST Super Dtld. Ledg. Ent."
{
    DataClassification = ToBeClassified;
    Caption = 'Detailed Supervisor Ledger Entry';
    fields
    {
        field(1; "Entry No."; Integer)
        {
            DataClassification = ToBeClassified;
            AutoIncrement = true;
        }
        field(2; "Entry Type"; Option)
        {
            OptionMembers = "Initial Entry","Application","Adjustment";
            OptionCaption = 'Initial Entry,Application,Adjustment';
        }
        field(3; "Posting Date"; date)
        {
            DataClassification = ToBeClassified;
        }
        field(4; "Document Type"; enum "Gen. Journal Document Type")
        {
            DataClassification = ToBeClassified;
        }
        field(5; "Document No."; code[50])
        {
            DataClassification = ToBeClassified;
        }
        field(6; "Customer No."; code[20])
        {
            DataClassification = ToBeClassified;
            TableRelation = Customer."No." where(Prospect = const(false));
        }
        field(7; "Commission Amount (LCY)"; Decimal)
        {
            DataClassification = ToBeClassified;
        }
        field(8; "Currency Code"; Code[20])
        {
            DataClassification = ToBeClassified;
            TableRelation = Currency.Code;
        }
        field(9; "Created By"; code[20])
        {
            DataClassification = ToBeClassified;

        }
        field(10; "Supv. Ledger Entry No."; Integer)
        {
            DataClassification = ToBeClassified;
            TableRelation = "FTT-CST SV Ledger Entry"."Entry No.";
        }
        field(11; "Supervisor Reward Amount (LCY)"; Decimal)
        {
            DataClassification = ToBeClassified;
        }
        field(12; "Salesperson Code"; Code[20])
        {
            DataClassification = ToBeClassified;
            TableRelation = "Salesperson/Purchaser".Code;
        }
        field(13; "Supervisor Reward Amount"; Decimal)
        {
            DataClassification = ToBeClassified;
        }
        field(14; "Commission Amount"; Decimal)
        {
            DataClassification = ToBeClassified;
        }


    }

    keys
    {
        key(Key1; "Entry No.")
        {
            Clustered = true;
        }
        key(key2; "Supv. Ledger Entry No.", "Posting Date")
        {

        }
    }

    fieldgroups
    {
        // Add changes to field groups here
    }

    var
        myInt: Integer;

    trigger OnInsert()
    begin

    end;

    trigger OnModify()
    begin

    end;

    trigger OnDelete()
    begin

    end;

    trigger OnRename()
    begin

    end;

}