table 60015 LostOpportunityTable
{
    Caption = 'Lost Opportunity';
    DataClassification = ToBeClassified;

    fields
    {
        field(20; Prospect; Code[20])
        {
            Caption = 'Prospect';
            DataClassification = CustomerContent;
            TableRelation = Contact;
            ValidateTableRelation = False;
            Editable = True;
            trigger OnValidate()
            var
                Cont: Record Contact;
            begin
                IF Cont.GET(Rec.Prospect) then
                    Name := Cont.Name;
            end;
        }
        field(30; Name; Text[100])
        {
            Caption = 'Name';
            DataClassification = CustomerContent;
            Editable = False;
        }
        field(40; Description; Text[100])
        {
            Caption = 'Description';
            DataClassification = CustomerContent;
        }
        field(50; "Lost to"; Text[100])
        {
            Caption = 'Lost to';
            DataClassification = CustomerContent;
        }
        field(60; Salesperson; Code[20])
        {
            Caption = 'Salesperson';
            DataClassification = CustomerContent;
            TableRelation = "Salesperson/Purchaser";
            trigger OnValidate()
            var
                SP: Record "Salesperson/Purchaser";
                lOpp: Record Opportunity;
                lOpEnt: Record "Opportunity Entry";
            Begin
                IF SP.GET(Rec.Salesperson) then
                    "Salesperson Name" := SP.Name;
                Clear(lOpp);
                lOpp.SETRANGE("Contact No.", Rec.Prospect);
                lopp.SETFILTER("Salesperson Code", Salesperson);
                IF lOpp.FINDLAST then begin
                    Rec.Description := lOpp.Description;
                    Rec."Closing Date" := lOpp."Estimated Closing Date";
                    Rec."Doc. No." := lOpp."No.";
                    Clear(lOpEnt);
                    lOpEnt.SETRANGE("Opportunity No.", lOpp."No.");
                    lOpEnt.SetFilter(Active, '%1', TRUE);
                    IF lOpEnt.FINDFIRST THEN begin
                        Rec."Closing Date" := lOpEnt."Estimated Close Date";
                        Rec."Current Sales Cycle Stage" := lOpEnt."Sales Cycle Stage Description";
                    end;
                end;
            End;
        }
        field(70; "Salesperson Name"; Text[100])
        {
            Caption = 'Salesperson Name';
            DataClassification = CustomerContent;
            Editable = False;
        }
        field(80; "Current Sales Cycle Stage"; Text[250])
        {
            Caption = 'Current Sales Cycle Stage';
            DataClassification = CustomerContent;
        }
        field(90; "Closing Date"; Date)
        {
            Caption = 'Closing Date';
            DataClassification = CustomerContent;
        }
        field(100; "Total Revenue"; Decimal)
        {
            Caption = 'Total Revenue';
            DataClassification = CustomerContent;
            DecimalPlaces = 2 : 2;
        }
        field(105; "Total Revenue 2"; Decimal)
        {
            Caption = 'Total Revenue';
            DataClassification = CustomerContent;
            DecimalPlaces = 2 : 2;
        }
        field(110; "Line Type"; Option)
        {
            Caption = 'Line Type';
            OptionCaption = '...,Header,Line,Total';
            OptionMembers = " ",Header,Line,Total;
            DataClassification = CustomerContent;
        }
        field(120; "Doc. No."; Code[1024])
        {
            Caption = 'Document No.';
            DataClassification = CustomerContent;
        }
        field(130; "Grand Total"; decimal)
        {
            Caption = 'Grand Total';
            FieldClass = FlowField;
            CalcFormula = Sum("LostOpportunityTable"."Total Revenue" where("Line Type" = Filter(Line)));
            DecimalPlaces = 2 : 2;
        }
    }
    keys
    {
        key(PK; Prospect, Salesperson)
        {
            Clustered = true;
        }
    }
    Trigger OnInsert()
    var
        lLOpp: Record LostOpportunity;
    Begin

    End;

    Local Procedure GetTotalRevenue()
    var
        lopp: Record Opportunity;
        lopEnt: Record "Opportunity Entry";
        lSH: Record "Sales Header";
        lSL: Record "Sales Line";
        lWithSQ: Boolean;
    Begin

    End;

    var
        gtot: Decimal;
}
