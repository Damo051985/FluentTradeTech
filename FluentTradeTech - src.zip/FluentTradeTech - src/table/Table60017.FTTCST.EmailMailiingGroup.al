table 60017 "Email Mailing Group"
{
    Caption = 'Email Mailiing Group';
    DataClassification = ToBeClassified;

    fields
    {
        field(10; "Mailing Group Code"; Code[30])
        {
            Caption = 'Mailing Group Code';
        }
        field(20; Description; Text[100])
        {
            Caption = 'Description';
        }
        field(30; "User ID"; Code[50])
        {
            Caption = 'Employee ID';
            TableRelation = Employee."No.";
            trigger OnValidate()
            var
                lEmp: Record Employee;
            begin
                IF lEmp.GET("User ID") then begin
                    "User Name" := lEmp."First Name" + ' ' + lEmp."Last Name";
                    "Email" := lEmp."Company E-Mail";
                END;
            end;
        }
        field(40; "User Name"; Text[100])
        {
            Caption = 'User Name';
        }
        field(50; Email; Text[50])
        {
            Caption = 'Email';
        }
        field(60; Active; Boolean)
        {
            Caption = 'Blocked';
        }
        field(70; Comment; Text[250])
        {
            Caption = 'Comment';
        }
        field(80; "Send By"; Option)
        {
            Caption = 'Send By';
            OptionCaption = ' ,CC,BCC';
            OptionMembers = " ","CC","BCC";
        }
    }
    keys
    {
        key(PK; "Mailing Group Code", "User ID")
        {
            Clustered = true;
        }
    }
}
