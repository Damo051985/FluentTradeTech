table 50011 "FTT-CST Commission Agr. Setup"
{
    DataClassification = ToBeClassified;
    Caption = 'Commission Agreement Setup';
    DataCaptionFields = "Page Caption";
    fields
    {
        field(1; "Primary Key"; Guid)
        {
            DataClassification = ToBeClassified;
        }
        field(6; "Page Caption"; Text[250])
        {
            DataClassification = ToBeClassified;
            InitValue = 'Commission Agreement Setup';
            Caption = 'Commission Agreement Setup';
        }

        field(8; "Comm. Vendor No."; code[20])
        {
            DataClassification = ToBeClassified;
            TableRelation = Vendor."No.";

        }
        field(9; "Comm. Agreement Nos."; code[20])
        {
            DataClassification = ToBeClassified;
            TableRelation = "No. Series".Code;
        }
        field(10; "Credit Memo Adjustment"; Boolean)
        {
            DataClassification = ToBeClassified;
        }
        field(11; "Claimed Journal Batch"; code[20])
        {
            DataClassification = ToBeClassified;
            TableRelation = "Gen. Journal Batch".Name WHERE("Journal Template Name" = field("Claimed Jornal Template"));
            Caption = 'Claimed Journal Batch';
        }
        field(12; "Claimed Jornal Template"; code[20])
        {
            DataClassification = ToBeClassified;
            TableRelation = "Gen. Journal Template".Name;
            Caption = 'Claimed Journal Template';
        }
        field(13; "PI Create/Post"; Boolean)
        {
            DataClassification = ToBeClassified;
            Caption = 'Create & Post Purchase Invoice';

        }
        field(14; "Payable G/L Account No."; code[20])
        {
            DataClassification = ToBeClassified;
            TableRelation = "G/L Account"."No.";
        }
        field(15; "Create & Post Payment"; Boolean)
        {
            DataClassification = ToBeClassified;
        }
        field(16; "Comm. WS Nos."; code[20])
        {
            DataClassification = ToBeClassified;
            TableRelation = "No. Series".Code;
            Caption = 'Comm. Worksheet Nos.';
        }
        field(17; "Comm. SV Nos."; code[20])
        {
            DataClassification = ToBeClassified;
            TableRelation = "No. Series".Code;
            Caption = 'Comm. Supervisor Worksheet Nos.';
        }
        field(18; "Claimed SV Journal Batch"; code[20])
        {
            DataClassification = ToBeClassified;
            TableRelation = "Gen. Journal Batch".Name WHERE("Journal Template Name" = field("Claimed SV Jornal Template"));
            Caption = 'Claimed Supervisor Journal Batch';
        }
        field(19; "Claimed SV Jornal Template"; code[20])
        {
            DataClassification = ToBeClassified;
            TableRelation = "Gen. Journal Template".Name;
            Caption = 'Claimed Supervisor Journal Template';
        }
        field(20; "Default Currency Code"; code[20])
        {
            DataClassification = ToBeClassified;
            TableRelation = Currency.Code;
            Caption = 'Default Currency for Commission Claim';
        }


    }

    keys
    {
        key(Key1; "Primary Key")
        {
            Clustered = true;
        }
    }

    var
        myInt: Integer;

    trigger OnInsert()
    begin

    end;

    trigger OnModify()
    begin

    end;

    trigger OnDelete()
    begin

    end;

    trigger OnRename()
    begin

    end;

}