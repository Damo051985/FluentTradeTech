table 60002 "FTT-CST Commision Entry"
{
    //NRD - PERMANENT DISABLED
    Caption = 'FTT-CST Commision Entry';
    DataClassification = CustomerContent;

    fields
    {
        field(1; "Entry No."; Integer)
        {
            AutoIncrement = true;
            Caption = 'Entry No.';
        }
        field(2; "Salesperson Code"; Code[20])
        {
            Caption = 'Salesperson Code';
            TableRelation = "Salesperson/Purchaser".Code;
        }
        field(3; "Commission Beneficiary Code"; Code[20])
        {
            Caption = 'Commission Beneficiary Code';
            TableRelation = "Salesperson/Purchaser".Code;
        }
        field(4; "Created Date"; Date)
        {
            Caption = 'Created Date';
        }
        field(5; "Commission Amount (LCY)"; Decimal)
        {
            Caption = 'Commission Amount (LCY)';
        }
        field(6; "Cust. Ledger Entry No."; Integer)
        {
            Caption = 'Cust. Ledger Entry No.';
            TableRelation = "Cust. Ledger Entry";
        }
    }
    keys
    {
        key(PK; "Entry No.")
        {
            Clustered = true;
        }
    }
}
