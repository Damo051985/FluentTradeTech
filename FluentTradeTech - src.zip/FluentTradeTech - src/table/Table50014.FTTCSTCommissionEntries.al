table 50014 "FTT-CST Commission Entries"
{
    DataClassification = ToBeClassified;
    Caption = 'Commission Ledger Entries';
    fields
    {
        field(1; "Entry No."; Integer)
        {
            DataClassification = ToBeClassified;
            AutoIncrement = true;
        }
        field(2; "Document Type"; enum "Gen. Journal Document Type")
        {
            DataClassification = ToBeClassified;
        }
        field(3; "Document No."; code[50])
        {
            DataClassification = ToBeClassified;
        }
        field(4; "Document Date"; date)
        {
            DataClassification = ToBeClassified;
        }
        field(5; "Sell-to Customer No."; code[20])
        {
            DataClassification = ToBeClassified;
            TableRelation = Customer."No." where(Prospect = const(false));
        }
        field(6; "Sell-to Customer Name"; Text[250])
        {
            DataClassification = ToBeClassified;

        }
        field(7; "Currency Code"; Code[20])
        {
            DataClassification = ToBeClassified;
            TableRelation = Currency.Code;
        }
        field(8; "Salesperson Code"; Code[20])
        {
            DataClassification = ToBeClassified;
            TableRelation = "Salesperson/Purchaser".Code;
        }
        field(9; "Amount (Excl. Vat)"; Decimal)
        {

            AutoFormatExpression = Rec."Currency Code";
            AutoFormatType = 1;
            CalcFormula = sum("Detailed Cust. Ledg. Entry".Amount where("Ledger Entry Amount" = const(true),
                                                                         "Cust. Ledger Entry No." = field("Cust. Ledger Entry No."),
                                                                         "Entry Type" = filter("Initial Entry")));
            Caption = 'Amount (Excl. Vat)';
            Editable = false;
            FieldClass = FlowField;
        }
        field(10; "Amount Paid"; Decimal)
        {
            AutoFormatExpression = Rec."Currency Code";
            AutoFormatType = 1;
            CalcFormula = sum("Detailed Cust. Ledg. Entry".Amount where("Cust. Ledger Entry No." = field("Cust. Ledger Entry No."),
                                                                          "Entry Type" = filter(Application),
                                                                          "Document Type" = filter(Payment)));
            Caption = 'Amount Paid';
            Editable = false;
            FieldClass = FlowField;
        }

        field(11; "Commission Base"; Decimal)
        {
            FieldClass = FlowField;
            CalcFormula = sum("Sales Invoice Line".Amount where("FTT-CST Eligible" = const(true), "Document No." = field("Document No.")));

        }
        field(12; "Commission Amount (LCY)"; Decimal)
        {
            FieldClass = FlowField;
            CalcFormula = sum("Sales Invoice Line"."Commission Base Amount (LCY)" where("FTT-CST Eligible" = const(true), "Document No." = field("Document No.")));
        }
        field(13; "Rem. Commission Amount (LCY)"; Decimal)
        {
            FieldClass = FlowField;
            CalcFormula = sum("FTT-CST Dtldg. Comm. Entries"."Commission Amount (LCY)" where("Customer No." = field("Sell-to Customer No."), "Comm. Ledger Entry No." = field("Entry No.")));
        }
        field(14; "Commission %"; Decimal)
        {
            DataClassification = ToBeClassified;
        }
        field(15; Open; Boolean)
        {
            DataClassification = ToBeClassified;
        }
        field(16; "Cust. Price Group Code"; code[20])
        {
            DataClassification = ToBeClassified;
            Caption = 'Customer Price Group Code';
            TableRelation = "Customer Price Group".Code;
        }

        field(17; "Cust. Ledger Entry No."; Integer)
        {
            DataClassification = ToBeClassified;
            TableRelation = "Cust. Ledger Entry"."Entry No.";
        }
        field(18; "Invoice Settled"; Boolean)
        {
            DataClassification = ToBeClassified;
        }
        field(19; "Commission Agreement No."; Code[50])
        {
            DataClassification = ToBeClassified;
            TableRelation = "FTT-CST Comm. Agrm. Header"."Agreement No.";
        }
        field(20; "Commission Amount"; Decimal)
        {
            FieldClass = FlowField;
            CalcFormula = sum("Sales Invoice Line"."Commission Base Amount" where("FTT-CST Eligible" = const(true), "Document No." = field("Document No.")));
        }
        field(21; "Rem. Commission Amount"; Decimal)
        {
            FieldClass = FlowField;
            CalcFormula = sum("FTT-CST Dtldg. Comm. Entries"."Commission Amount" where("Customer No." = field("Sell-to Customer No."), "Comm. Ledger Entry No." = field("Entry No.")));
        }


    }

    keys
    {
        key(Key1; "Entry No.", "Document No.")
        {
            Clustered = true;

        }
        key(key2; "Document No.", "Sell-to Customer No.")
        {
            IncludedFields = "Salesperson Code";
        }
        key(key3; "Sell-to Customer No.", "Document Date")
        {
            IncludedFields = "Salesperson Code";
        }

    }


    fieldgroups
    {
        // Add changes to field groups here
    }
    procedure ShowDoc(): Boolean
    var
        SalesInvoiceHdr: Record "Sales Invoice Header";
        SalesCrMemoHdr: Record "Sales Cr.Memo Header";
        ServiceInvoiceHeader: Record "Service Invoice Header";
        ServiceCrMemoHeader: Record "Service Cr.Memo Header";
        IssuedFinChargeMemoHeader: Record "Issued Fin. Charge Memo Header";
        IssuedReminderHeader: Record "Issued Reminder Header";
        IsHandled: Boolean;
        IsPageOpened: Boolean;
    begin
        IsHandled := false;

        if IsHandled then
            exit(IsPageOpened);

        case "Document Type" of
            "Document Type"::Invoice:
                begin
                    if SalesInvoiceHdr.Get("Document No.") then begin
                        PAGE.Run(PAGE::"Posted Sales Invoice", SalesInvoiceHdr);
                        exit(true);
                    end;
                    if ServiceInvoiceHeader.Get("Document No.") then begin
                        PAGE.Run(PAGE::"Posted Service Invoice", ServiceInvoiceHeader);
                        exit(true);
                    end;
                end;
            "Document Type"::"Credit Memo":
                begin
                    if SalesCrMemoHdr.Get("Document No.") then begin
                        PAGE.Run(PAGE::"Posted Sales Credit Memo", SalesCrMemoHdr);
                        exit(true);
                    end;
                    if ServiceCrMemoHeader.Get("Document No.") then begin
                        PAGE.Run(PAGE::"Posted Service Credit Memo", ServiceCrMemoHeader);
                        exit(true);
                    end;
                end;
            "Document Type"::"Finance Charge Memo":
                if IssuedFinChargeMemoHeader.Get("Document No.") then begin
                    PAGE.Run(PAGE::"Issued Finance Charge Memo", IssuedFinChargeMemoHeader);
                    exit(true);
                end;
            "Document Type"::Reminder:
                if IssuedReminderHeader.Get("Document No.") then begin
                    PAGE.Run(PAGE::"Issued Reminder", IssuedReminderHeader);
                    exit(true);
                end;
        end;


    end;

    var
        myInt: Integer;

    trigger OnInsert()
    begin

    end;

    trigger OnModify()
    begin

    end;

    trigger OnDelete()
    begin

    end;

    trigger OnRename()
    begin

    end;

}