table 50002 "GMAIL Maintenance Setup"
{
    DataClassification = ToBeClassified;
    Caption = 'GMAIL Maintenance Setup';
    DataCaptionFields = "Page Caption";
    fields
    {
        field(1; "Primary Key"; Guid)
        {
            DataClassification = ToBeClassified;
        }
        field(6; "Page Caption"; Text[250])
        {
            DataClassification = ToBeClassified;
            InitValue = 'Gmail Maintenance Setup';
            Caption = 'Gmail Maintenance Setup';
        }

        field(8; "Authorization URL"; Text[250])
        {
            DataClassification = ToBeClassified;
        }
        field(9; "Token URL"; Text[250])
        {
            DataClassification = ToBeClassified;
        }
        field(10; "Client ID"; Text[250])
        {
            DataClassification = ToBeClassified;
        }
        field(11; "Client Secret ID"; Text[250])
        {
            DataClassification = ToBeClassified;
        }

        field(13; "CallBack URL"; Text[250])
        {
            DataClassification = ToBeClassified;
        }

        field(17; Scopes; Text[1024])
        {
            DataClassification = ToBeClassified;
        }
        field(18; "CRM Email"; Text[1024])
        {
            DataClassification = ToBeClassified;
        }
        field(19; "Add to BCC as Default"; Boolean)
        {
            DataClassification = ToBeClassified;
        }
        field(20; "API Token Key"; Text[250])
        {
            DataClassification = ToBeClassified;
        }
        field(21; "Authorization Code"; Text[250])
        {
            DataClassification = ToBeClassified;
        }
        field(22; "Token Expiration DateTime"; DateTime)
        {
            DataClassification = ToBeClassified;
        }
        field(24; "Refresh Token"; Text[250])
        {
            DataClassification = ToBeClassified;
        }
        field(25; "CRM Template SHID"; Text[250])
        {
            DataClassification = ToBeClassified;
        }
        field(26; "CRM SO Template SHID"; Text[250])
        {
            DataClassification = ToBeClassified;
        }

    }

    keys
    {
        key(Key1; "Primary Key")
        {
            Clustered = true;
        }
    }

    var
        myInt: Integer;

    trigger OnInsert()
    begin

    end;

    trigger OnModify()
    begin

    end;

    trigger OnDelete()
    begin

    end;

    trigger OnRename()
    begin

    end;

}