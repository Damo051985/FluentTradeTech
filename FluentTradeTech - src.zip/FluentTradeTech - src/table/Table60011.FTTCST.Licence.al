table 60011 "FTT-CST Licence Select"
{
    DataClassification = ToBeClassified;

    fields
    {
        field(1; "Filter No."; Integer)
        {
            DataClassification = ToBeClassified;

        }
        field(2; "Item No."; Code[20])
        {
            DataClassification = ToBeClassified;
            Caption = 'Item No.';

        }
        field(3; Description; Text[250])
        {
            Caption = 'Description';

        }
        field(4; "Quantity"; Integer)
        {
            Caption = 'Quantity';
            trigger OnValidate()
            begin

            end;
        }
        field(5; "Unit Price"; Decimal)
        {
            Caption = 'Unit Price';
            trigger OnValidate()
            begin

            end;
        }
        field(6; Level; Integer)
        {
            Caption = 'Level';
            trigger OnValidate()
            begin

            end;
        }
        field(7; Comments; text[250])
        {
            Caption = 'Internal Comments';

        }
        field(8; Optional; Option)
        {
            OptionCaption = 'No,Yes';
            OptionMembers = No,Yes;
        }
        field(9; "Comments Fluent"; text[250])
        {
            Caption = 'Fluent Comments';
        }
        field(10; Redundancy; Option)
        {
            Caption = 'Redundancy';
            OptionCaption = 'No,Yes';
            OptionMembers = No,Yes;

        }
        field(11; DR; Option)
        {
            Caption = 'DR';
            OptionCaption = 'No,Yes';
            OptionMembers = No,Yes;

        }
        field(12; "FTT-CST Location Type"; Enum "FTT-CST Location Type")
        {
            Caption = 'Location Type';
        }
        field(13; Integration; Option) //NRD
        {
            Caption = 'Integration';
            OptionCaption = 'No,Yes';
            OptionMembers = No,Yes;


        }


    }

    keys
    {
        key(Key1; "Filter No.", Level, "Item No.")
        {
            Clustered = true;
        }
    }

    fieldgroups
    {
        // Add changes to field groups here
    }

    var
        myInt: Integer;

    trigger OnInsert()
    begin

    end;

    trigger OnModify()
    begin

    end;

    trigger OnDelete()
    begin

    end;

    trigger OnRename()
    begin

    end;

}