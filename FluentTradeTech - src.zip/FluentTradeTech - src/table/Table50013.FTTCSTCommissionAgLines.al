table 50013 "FTT-CST Comm. Agrm. Lines"
{
    DataClassification = ToBeClassified;
    Caption = 'Commission Agreement Lines';
    fields
    {
        field(1; "Agreement No."; Code[20])
        {
            DataClassification = ToBeClassified;
            TableRelation = "FTT-CST Comm. Agrm. Header"."Agreement No.";
            Editable = false;
        }
        field(2; "Line No."; Integer)
        {
            DataClassification = ToBeClassified;
            Editable = false;
        }
        field(3; "Salesperson Code"; code[20])
        {
            DataClassification = ToBeClassified;
            TableRelation = "Salesperson/Purchaser".Code;
            trigger OnValidate()
            var
                recAgrHeader: Record "FTT-CST Comm. Agrm. Header";
            begin
                if recAgrHeader.Get(rec."Agreement No.") then
                    recAgrHeader.TestField("Salesperson Type", recAgrHeader."Salesperson Type"::Team);
            end;
        }
        field(4; "Customer Type"; Option)
        {
            OptionMembers = "All Customer","Specific Customer";
            OptionCaption = 'All Customer,Specific Customer';
        }
        field(5; "Customer No."; Code[20])
        {
            DataClassification = ToBeClassified;
            TableRelation = Customer."No.";

            trigger OnValidate()
            begin
                if rec."Customer Type" = rec."Customer Type"::"All Customer" then
                    Error('Customer Type should be Specific Customer');
            end;
        }
        field(6; "Item Category Type"; Option)
        {
            OptionMembers = "Child Item Category","Parent Item Category";
            OptionCaption = 'Child Item Category,Parent Item Category';
            trigger OnValidate()
            begin
                rec."Category No." := '';
                rec."Commission %" := 0;
            end;
        }
        field(7; "Category No."; code[20])
        {
            DataClassification = ToBeClassified;
            TableRelation = if ("Item Category Type" = const("Child Item Category")) "Item Category".Code where("Parent Category" = filter(<> ''))
            else
            if ("Item Category Type" = const("Parent Item Category")) "Item Category".Code where("Parent Category" = filter(''));
        }
        field(8; "Commission %"; Decimal)
        {
            DataClassification = ToBeClassified;
            Caption = 'Commission Rate %';
        }
        field(9; "Agreement Period"; Integer)
        {
            DataClassification = ToBeClassified;
        }

    }

    keys
    {
        key(Key1; "Agreement No.", "Line No.")
        {
            Clustered = true;
        }
    }

    fieldgroups
    {
        // Add changes to field groups here
    }

    var
        myInt: Integer;

    trigger OnInsert()
    begin

    end;

    trigger OnModify()
    begin

    end;

    trigger OnDelete()
    begin

    end;

    trigger OnRename()
    begin

    end;

}