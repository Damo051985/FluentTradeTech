table 60013 "Revenue Report"
{
    Caption = 'Revenue Report';
    DataClassification = ToBeClassified;

    fields
    {
        field(10; "Type"; Option)
        {
            Caption = 'Type';
            OptionMembers = " ",Hosted,"NonHosted",Unknown,Total,"Grand Total";
            OptionCaption = '.....,Hosted,Non Hosted,Unknown,Total,Grand Total';
            DataClassification = ToBeClassified;

        }
        field(20; "Salesperson Code"; Code[20])
        {
            Caption = 'Salesperson Code';
            TableRelation = "Salesperson/Purchaser";
            DataClassification = ToBeClassified;
        }
        field(30; "Customer/Prospect"; Text[100])
        {
            Caption = 'Customer/Prospect';
            DataClassification = ToBeClassified;
            TableRelation = Customer.Name;
            ValidateTableRelation = False;
        }
        field(40; "ARR - Previous Contracts"; Decimal)
        {
            Caption = 'ARR - Signed Contracts';
            DataClassification = ToBeClassified;
            DecimalPlaces = 2 : 2;
            Trigger OnValidate()
            var
            Begin
                Rec."ARR Total Revenue" := Rec."ARR - Previous Contracts" + rec."ARR - Additional Products" + Rec."ARR Contract in Progress";
            End;
        }
        field(50; "ARR - Additional Products"; Decimal)
        {
            Caption = 'ARR - Additional Products';
            DataClassification = ToBeClassified;
            DecimalPlaces = 2 : 2;
            Trigger OnValidate()
            var
            Begin
                Rec."ARR Total Revenue" := Rec."ARR - Previous Contracts" + rec."ARR - Additional Products" + Rec."ARR Contract in Progress";
            End;
        }
        field(60; "ARR Contract in Progress"; Decimal)
        {
            Caption = 'ARR Contracts in Progress';
            DataClassification = ToBeClassified;
            DecimalPlaces = 2 : 2;
            Trigger OnValidate()
            var
            Begin
                Rec."ARR Total Revenue" := Rec."ARR - Previous Contracts" + rec."ARR - Additional Products" + Rec."ARR Contract in Progress";
            End;
        }
        field(70; "NRC Contract in Progress"; Decimal)
        {
            Caption = 'NRC Contracts in Progress';
            DataClassification = ToBeClassified;
            DecimalPlaces = 2 : 2;
            Editable = False;
            Trigger OnValidate()
            var
            Begin
                Rec."NRC Total Revenue" := Rec."NRC Contract in Progress";
            End;

        }
        field(80; "ARR Total Revenue"; Decimal)
        {
            Caption = 'ARR Total Revenue';
            DataClassification = ToBeClassified;
            DecimalPlaces = 2 : 2;
        }
        field(90; "NRC Total Revenue"; Decimal)
        {
            Caption = 'NRC Total Revenue';
            DataClassification = ToBeClassified;
            DecimalPlaces = 2 : 2;

        }
        field(100; "Line Type"; Option)
        {
            Caption = 'Line Type';
            OptionMembers = " ",Header,Line,"Over 50 %","Over 85 %","Total 50%","Total 85%","Grand Total";
            DataClassification = ToBeClassified;
        }
        field(110; "New Proj. Stage"; Text[50])
        {
            Caption = 'New Project Stage';
            DataClassification = ToBeClassified;
        }
        field(120; Connectivity; Decimal)
        {
            Caption = 'Connectivity';
            DataClassification = ToBeClassified;
            DecimalPlaces = 2 : 2;
        }
        field(130; Distribution; Decimal)
        {
            Caption = 'Distribution';
            DataClassification = ToBeClassified;
            DecimalPlaces = 2 : 2;
        }
        field(140; "Risk and Others"; Decimal)
        {
            Caption = 'Risk and Others';
            DataClassification = ToBeClassified;
            DecimalPlaces = 2 : 2;
        }
        field(150; "Other YRC"; Decimal)
        {
            Caption = 'Other YRC';
            DataClassification = ToBeClassified;
            DecimalPlaces = 2 : 2;
        }
        field(160; "Document type"; Enum "Sales Document Type")
        {
            Caption = 'Document Type';
            DataClassification = ToBeClassified;
        }
        field(170; "Document No."; Code[250])
        {
            Caption = 'Document No.';
            DataClassification = ToBeClassified;
        }
        field(180; "DocType2"; Enum "Sales Document Type")
        {
            Caption = 'Document Type2';
            DataClassification = ToBeClassified;
        }
        field(190; "DocNo.2"; Code[250])
        {
            Caption = 'Document No.2';
            DataClassification = ToBeClassified;
        }
        field(200; "DocType3"; Enum "Sales Document Type")
        {
            Caption = 'Document Type3';
            DataClassification = ToBeClassified;
        }
        field(210; "DocNo.3"; Code[250])
        {
            Caption = 'Document No.3';
            DataClassification = ToBeClassified;
        }
        field(220; "DocType4"; Enum "Sales Document Type")
        {
            Caption = 'Document Type4';
            DataClassification = ToBeClassified;
        }
        field(230; "DocNo.4"; Code[250])
        {
            Caption = 'Document No.4';
            DataClassification = ToBeClassified;
        }
        field(240; "DocType5"; Enum "Sales Document Type")
        {
            Caption = 'Document Type5';
            DataClassification = ToBeClassified;
        }
        field(250; "DocNo.5"; Code[250])
        {
            Caption = 'Document No.5';
            DataClassification = ToBeClassified;
        }
        field(260; "DocType6"; Enum "Sales Document Type")
        {
            Caption = 'Document Type6';
            DataClassification = ToBeClassified;
        }
        field(270; "DocNo.6"; Code[250])
        {
            Caption = 'Document No.6';
            DataClassification = ToBeClassified;
        }
        field(280; "DocType7"; Enum "Sales Document Type")
        {
            Caption = 'Document Type7';
            DataClassification = ToBeClassified;
        }
        field(290; "DocNo.7"; Code[250])
        {
            Caption = 'Document No.7';
            DataClassification = ToBeClassified;
        }
        field(300; "DocType8"; Enum "Sales Document Type")
        {
            Caption = 'Document Type8';
            DataClassification = ToBeClassified;
        }
        field(310; "DocNo.8"; Code[250])
        {
            Caption = 'Document No.8';
            DataClassification = ToBeClassified;
        }
        field(320; "DocType9"; Enum "Sales Document Type")
        {
            Caption = 'Document Type9';
            DataClassification = ToBeClassified;
        }
        field(330; "DocNo.9"; Code[250])
        {
            Caption = 'Document No.9';
            DataClassification = ToBeClassified;
        }
        field(340; "DocType10"; Enum "Sales Document Type")
        {
            Caption = 'Document Type10';
            DataClassification = ToBeClassified;
        }
        field(350; "DocNo.10"; Code[250])
        {
            Caption = 'Document No.10';
            DataClassification = ToBeClassified;
        }
        field(360; "GT ARR Previous Contracts"; decimal)
        {
            Caption = 'ARR - Signed Contracts';
            FieldClass = FlowField;
            CalcFormula = Sum("Revenue Report"."ARR - Previous Contracts"
            //where("Line Type" = Filter("Over 50 %" | "Over 85 %")));
            where("Line Type" = Filter("Over 50 %" | "Over 85 %"), Type = filter(<> "Total")));
            DecimalPlaces = 2 : 2;
        }
        field(370; "GT ARR Add. Contracts"; decimal)
        {
            Caption = 'ARR - Additional Products';
            FieldClass = FlowField;
            CalcFormula = Sum("Revenue Report"."ARR - Additional Products"
            //where("Line Type" = Filter("Over 50 %" | "Over 85 %")));
            where("Line Type" = Filter("Over 50 %" | "Over 85 %"), Type = filter(<> "Total")));
            DecimalPlaces = 2 : 2;
        }
        field(380; "GT ARR Contract Progress"; decimal)
        {
            Caption = 'ARR Contracts in Progress';
            FieldClass = FlowField;
            CalcFormula = Sum("Revenue Report"."ARR Contract in Progress"
            //where("Line Type" = Filter("Over 50 %" | "Over 85 %")));
            where("Line Type" = Filter("Over 50 %" | "Over 85 %"), Type = filter(<> "Total")));
            DecimalPlaces = 2 : 2;
        }
        field(390; "GT NRC Contract Progress"; decimal)
        {
            Caption = 'NRC Contracts in Progress';
            FieldClass = FlowField;
            CalcFormula = Sum("Revenue Report"."NRC Contract in Progress"
            //where("Line Type" = Filter("Over 50 %" | "Over 85 %")));
            where("Line Type" = Filter("Over 50 %" | "Over 85 %"), Type = filter(<> "Total")));
            DecimalPlaces = 2 : 2;
        }
        field(400; "GT ARR Total Revenue"; decimal)
        {
            Caption = 'ARR Total Revenue';
            FieldClass = FlowField;
            CalcFormula = Sum("Revenue Report"."ARR Total Revenue"
            //where("Line Type" = Filter("Over 50 %" | "Over 85 %")));
            where("Line Type" = Filter("Over 50 %" | "Over 85 %"), Type = filter(<> "Total")));
            DecimalPlaces = 2 : 2;
        }
        field(410; "GT NRC Total Revenue"; decimal)
        {
            Caption = 'NRC Total Revenue';
            FieldClass = FlowField;
            CalcFormula = Sum("Revenue Report"."NRC Total Revenue"
            //where("Line Type" = Filter("Over 50 %" | "Over 85 %")));
            where("Line Type" = Filter("Over 50 %" | "Over 85 %"), Type = filter(<> "Total")));
            DecimalPlaces = 2 : 2;
        }
        field(420; "GT Connectivity"; decimal)
        {
            Caption = 'Connectivity';
            FieldClass = FlowField;
            CalcFormula = Sum("Revenue Report"."Connectivity"
            //where("Line Type" = Filter("Over 50 %" | "Over 85 %")));
            where("Line Type" = Filter("Over 50 %" | "Over 85 %"), Type = filter(<> "Total")));
            DecimalPlaces = 2 : 2;
        }
        field(430; "GT Distribution"; decimal)
        {
            Caption = 'Distribution';
            FieldClass = FlowField;
            CalcFormula = Sum("Revenue Report"."Distribution"
            //where("Line Type" = Filter("Over 50 %" | "Over 85 %")));
            where("Line Type" = Filter("Over 50 %" | "Over 85 %"), Type = filter(<> "Total")));
            DecimalPlaces = 2 : 2;
        }
        field(440; "GT Other YRC"; decimal)
        {
            Caption = 'Other YRC';
            FieldClass = FlowField;
            CalcFormula = Sum("Revenue Report"."Other YRC"
            //where("Line Type" = Filter("Over 50 %" | "Over 85 %")));
            where("Line Type" = Filter("Over 50 %" | "Over 85 %"), Type = filter(<> "Total")));
            DecimalPlaces = 2 : 2;
        }
        field(450; "GT RiskNOthers"; decimal)
        {
            Caption = 'Risk and Others';
            FieldClass = FlowField;
            CalcFormula = Sum("Revenue Report"."Risk and Others"
            where("Line Type" = Filter("Over 50 %" | "Over 85 %"), Type = filter(<> "Total")));
            DecimalPlaces = 2 : 2;
        }
        Field(460; "Internal Comments"; Text[250])
        {
            Caption = 'Internal Comments';
        }

    }
    keys
    {
        key(PK; "Type", "Salesperson Code", "Line Type", "Customer/Prospect")
        {
            Clustered = true;
        }
        key(PK2; "Type", "Salesperson Code", "Line Type")
        {
            SumIndexFields = "ARR - Previous Contracts", "ARR - Additional Products", "ARR Contract in Progress", "NRC Contract in Progress", "ARR Total Revenue", "NRC Total Revenue", Connectivity, Distribution, "Risk and Others", "Other YRC";
        }
    }
    trigger OnInsert()
    var
    Begin

    End;
}
