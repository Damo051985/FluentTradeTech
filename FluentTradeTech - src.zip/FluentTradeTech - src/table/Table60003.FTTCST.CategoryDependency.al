table 60004 "FTT-CST Dependency Filters"
{
    Caption = 'Dependency Filters';
    DataClassification = CustomerContent;

    fields
    {
        field(1; "Filter No."; Integer)
        {
            Caption = 'Filter No.';
            DataClassification = CustomerContent;

        }
        field(2; "FTT-CST Component Option"; Option)
        {
            Caption = 'Compoment Option';
            DataClassification = CustomerContent;
            OptionMembers = Blank,Hosted,NonHosted,Unknown;
            OptionCaption = '. . . . . . .,Hosted,Non Hosted,Unknown';
        }
        field(3; "FTT-CST Location Code"; code[20])
        {
            Caption = 'Region Code';
            DataClassification = CustomerContent;
            TableRelation = "Dimension Value".Code WHERE("Global Dimension No." = CONST(3),
                                                                  "Dimension Value Type" = CONST(Standard),
                                                                  Blocked = CONST(false));
        }
        field(4; "FTT-CST Type of Site"; Option)
        {
            DataClassification = ToBeClassified;
            OptionMembers = Blank,Redundancy,DR,Both,None;
            OptionCaption = '. . . . . . .,Redundancy,DR,Both,None';
            Caption = 'Type of Site';
        }
        field(5; "FTT-CST Licences Filters"; text[1024])
        {
            DataClassification = ToBeClassified;
            Caption = 'Licences Items';
            trigger OnLookup()
            var
                ItemList: page "Item List";
                DependencyItem: Record Item;
                LicencesFilters: text[1024];
            begin
                DependencyItem.SetFilter("Item Category Code", 'LICENSE');
                ItemList.LookupMode(true);
                ItemList.SetTableView(DependencyItem);
                if ItemList.RunModal() = Action::LookupOK then begin
                    "FTT-CST Licences Filters" += ItemList.GetSelectionFilter();
                end;
            end;

        }
        field(6; "FTT-CST Standard Taker Feed"; text[1024])
        {
            DataClassification = ToBeClassified;
            Caption = 'STANDARD TAKER FEED';
            trigger OnLookup()
            var
                ItemList: page "Item List";
                DependencyItem: Record Item;
                LicencesFilters: text[1024];
            begin
                DependencyItem.SetFilter("Item Category Code", 'STANDARD TAKER FEED');
                ItemList.LookupMode(true);
                ItemList.SetTableView(DependencyItem);
                if ItemList.RunModal() = Action::LookupOK then begin
                    "FTT-CST Standard taker feed" += ItemList.GetSelectionFilter();
                end;
            end;

        }
        field(7; "FTT-CST NON Standard Taker"; text[1024])
        {
            DataClassification = ToBeClassified;
            Caption = 'NON STANDART TAKER FEED';
            trigger OnLookup()
            var
                ItemList: page "Item List";
                DependencyItem: Record Item;
                LicencesFilters: text[1024];
            begin
                DependencyItem.SetFilter("Item Category Code", 'NS TAKER FEED');
                ItemList.LookupMode(true);
                ItemList.SetTableView(DependencyItem);
                if ItemList.RunModal() = Action::LookupOK then begin
                    "FTT-CST NON Standard taker" += ItemList.GetSelectionFilter();
                end;
            end;

        }
        field(8; "FTT-CST Standard Maker Feed"; text[1024])
        {
            DataClassification = ToBeClassified;
            Caption = 'STANDARD MAKER FEED';
            trigger OnLookup()
            var
                ItemList: page "Item List";
                DependencyItem: Record Item;
                LicencesFilters: text[1024];
            begin
                DependencyItem.SetFilter("Item Category Code", 'STANDARD MAKER FEED');
                ItemList.LookupMode(true);
                ItemList.SetTableView(DependencyItem);
                if ItemList.RunModal() = Action::LookupOK then begin
                    "FTT-CST Standard maker feed" += ItemList.GetSelectionFilter();
                end;
            end;

        }
        field(9; "FTT-CST NON Standard Maker"; text[1024])
        {
            DataClassification = ToBeClassified;
            Caption = 'NON STANDARD MAKER FEED';
            trigger OnLookup()
            var
                ItemList: page "Item List";
                DependencyItem: Record Item;
                LicencesFilters: text[1024];
            begin
                DependencyItem.SetFilter("Item Category Code", 'NS MAKER FEED');
                ItemList.LookupMode(true);
                ItemList.SetTableView(DependencyItem);
                if ItemList.RunModal() = Action::LookupOK then begin
                    "FTT-CST NON Standard maker" += ItemList.GetSelectionFilter();
                end;
            end;
        }


        field(10; "FTT-CST HARDWARE"; text[1024])
        {
            DataClassification = ToBeClassified;
            Caption = 'HARDWARE';
            trigger OnLookup()
            var
                ItemList: page "Item List";
                DependencyItem: Record Item;
                LicencesFilters: text[1024];
            begin
                DependencyItem.SetFilter("Item Category Code", 'HARDWARE');
                ItemList.LookupMode(true);
                ItemList.SetTableView(DependencyItem);
                if ItemList.RunModal() = Action::LookupOK then begin
                    "FTT-CST HARDWARE" += ItemList.GetSelectionFilter();
                end;
            end;

        }

        field(11; "FTT-CST CPU"; text[1024])
        {
            DataClassification = ToBeClassified;
            Caption = 'CPU';
            trigger OnLookup()
            var
                ItemList: page "Item List";
                DependencyItem: Record Item;
                LicencesFilters: text[1024];
            begin
                DependencyItem.SetFilter("Item Category Code", 'CPU');
                ItemList.LookupMode(true);
                ItemList.SetTableView(DependencyItem);
                if ItemList.RunModal() = Action::LookupOK then begin
                    VALIDATE("FTT-CST CPU", ItemList.GetSelectionFilter());
                end;
            end;

        }
        field(12; "FTT-CST Conectivity"; Option)
        {
            Caption = 'Conectivity';
            DataClassification = CustomerContent;
            OptionMembers = Blank,No,Yes;
            OptionCaption = '. . . . . . ., No,Yes';
        }
        field(13; "FTT-CST DR"; text[1024])
        {
            DataClassification = ToBeClassified;
            Caption = 'DR';
            trigger OnLookup()
            var
                ItemList: page "Item List";
                DependencyItem: Record Item;
                LicencesFilters: text[1024];
            begin
                DependencyItem.SetFilter("Item Category Code", 'DR');
                ItemList.LookupMode(true);
                ItemList.SetTableView(DependencyItem);
                if ItemList.RunModal() = Action::LookupOK then begin
                    VALIDATE("FTT-CST DR", ItemList.GetSelectionFilter());
                end;
            end;

        }
        field(14; "FTT-CST Redundency"; text[1024])
        {
            DataClassification = ToBeClassified;
            Caption = 'Redundency';
            trigger OnLookup()
            var
                ItemList: page "Item List";
                DependencyItem: Record Item;
                LicencesFilters: text[1024];
            begin
                DependencyItem.SetFilter("Item Category Code", 'REDUNDANCY');
                ItemList.LookupMode(true);
                ItemList.SetTableView(DependencyItem);
                if ItemList.RunModal() = Action::LookupOK then begin
                    VALIDATE("FTT-CST Redundency", ItemList.GetSelectionFilter());
                end;
            end;

        }
        field(15; "FTT-CST Integration"; text[1024])
        {
            DataClassification = ToBeClassified;
            Caption = 'Integration';
            trigger OnLookup()
            var
                ItemList: page "Item List";
                DependencyItem: Record Item;
                LicencesFilters: text[1024];
            begin
                DependencyItem.SetFilter("Item Category Code", 'Integration');
                ItemList.LookupMode(true);
                ItemList.SetTableView(DependencyItem);
                if ItemList.RunModal() = Action::LookupOK then begin
                    VALIDATE("FTT-CST Redundency", ItemList.GetSelectionFilter());
                end;
            end;

        }
        field(17; Redundancy; Boolean)
        {

        }
        field(18; DR; Boolean)
        {

        }
        field(19; "FTT-CST Cross Connect"; Boolean)
        {
            Caption = 'Cross Connect';
        }
        field(20; "FTT-CST HARDWARE Qty"; Decimal)
        {
            Caption = 'Hardware Qty';
        }
        field(21; "FTT-CST Component Option2"; Option)
        {
            Caption = 'Compoment Option';
            DataClassification = CustomerContent;
            OptionMembers = Hosted,NonHosted,Unknown;
            OptionCaption = 'Hosted,Non Hosted,Unknown';
        }
        field(22; "FTT-CST Location"; code[20])
        {

        }
        field(23; "Sales Document No."; code[20])
        {

        }
        field(40; "FTT-CST Type of Site2"; Option)
        {
            DataClassification = ToBeClassified;
            OptionMembers = Blank,Primary,PrimaryRed,PrimaryDR,Redundancy,DR,PrimaryRedDR,RedDR,None;
            OptionCaption = '. . . . . . .,Primary,Primary & Redundancy,Primary & Disaster Recovery,Redundancy,Disaster Recovery,Primary & Redundancy & Disaster Recovery,Redundancy & Disaster Recovery,None';
            Caption = 'Type of Site';
        }
        field(41; "FTT-CST DR Description"; text[1024])
        {
            DataClassification = ToBeClassified;
            Caption = 'DR';
        }
        field(42; "FTT-CST Redun Desc."; text[1024])
        {
            DataClassification = ToBeClassified;
            Caption = 'Redunancy';
        }
        field(43; "FTT-CST Integration Desc."; text[1024])
        {
            DataClassification = ToBeClassified;
            Caption = 'Integration';
        }
        field(44; "FTT-CST HARDWARE Desc."; text[1024])
        {
            DataClassification = ToBeClassified;
            Caption = 'HARDWARE';
        }
        field(45; "FTT-CST CPU Desc."; text[1024])
        {
            DataClassification = ToBeClassified;
            Caption = 'CPU';
        }
        field(46; "FTT-CST Integration Dec."; Decimal)
        {

        }
        field(47; "FTT-CST Licences Filters Desc."; text[1024])
        {
            DataClassification = ToBeClassified;
            Caption = 'Licences Items';

        }
        field(48; "FTT-CST Standard Taker Feed Desc."; text[1024])
        {
            DataClassification = ToBeClassified;
            Caption = 'STANDARD TAKER FEED';
        }
        field(49; "FTT-CST NON Standard Taker Desc."; text[1024])
        {
            DataClassification = ToBeClassified;
            Caption = 'NON STANDART TAKER FEED';
        }
        field(50; "FTT-CST Standard Maker Feed Desc."; text[1024])
        {
            DataClassification = ToBeClassified;
            Caption = 'STANDARD MAKER FEED';
        }
        field(51; "FTT-CST NON Standard Maker Desc."; text[1024])
        {
            DataClassification = ToBeClassified;
            Caption = 'NON STANDARD MAKER FEED';
        }
        Field(52; "FTT-CST Sublocation"; Option)
        {
            DataClassification = ToBeClassified;
            OptionMembers = Blank,LD4,LD42,NY2,NY4,NY6,TY3,SG1,None;
            OptionCaption = '. . . . . . .,LD 4,LD 4.2,NY 2,NY 4,NY 6,TY 3,SG 1,None';
            Caption = 'Sublocation';
        }
        field(54; "FTT-CST International Line"; Boolean)
        {
            Caption = 'ADD INTERNATIONAL LINE';
        }
        field(55; "Sell-to Customer No."; code[20])
        {
            Caption = 'Sell-to Customer No.';
        }
        field(56; "Currency Code"; Code[10])
        {
            Caption = 'Currency Code';
            TableRelation = Currency;
        }
        field(57; "Currency Factor"; Decimal)
        {
            Caption = 'Currency Factor';
            DecimalPlaces = 0 : 15;
            Editable = false;
            MinValue = 0;

            trigger OnValidate()
            begin
            end;
        }
        field(58; "Customer Price Group"; Code[10])
        {
            Caption = 'Customer Price Group';
            TableRelation = "Customer Price Group";

            trigger OnValidate()
            begin
            end;
        }
        field(59; "Posting Date"; Date)
        {
            Caption = 'Posting Date';
        }
        field(60; "Document Type"; enum "Sales Document Type")
        {
            DataClassification = ToBeClassified;
            Caption = 'Document Type';
        }
        field(70; "Line Discount %"; Decimal)
        {
            DataClassification = ToBeClassified;
            Caption = 'Line Discount %';
        }
    }

    keys
    {
        key(PK; "Sales Document No.", "Filter No.")
        {
            Clustered = true;
        }
    }
    trigger OnInsert()
    var
        Dependency: record "FTT-CST Dependency Filters";
    begin
        if Dependency.FindSet() then
            "Filter No." := Dependency."Filter No." + 1 else
            Dependency."Filter No." := 1;
    end;
}
