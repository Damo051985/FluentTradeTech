
table 50005 "GMAIL Attachment"
{
    DataClassification = ToBeClassified;

    fields
    {
        field(1; EntryNo; Integer)
        {
            DataClassification = ToBeClassified;
        }
        field(2; "GMAIL Inbox ID"; text[250])
        {
            DataClassification = ToBeClassified;
            TableRelation = "GMAIL Inbound/Outbound"."GMAIL Inbox ID";
        }
        field(3; "Mime Type"; Text[250])
        {
            DataClassification = ToBeClassified;
        }
        field(4; "Date Created"; Date)
        {
            DataClassification = ToBeClassified;
        }
        field(5; "Created By USER"; Code[50])
        {
            DataClassification = ToBeClassified;
        }
        field(6; "File Name"; Text[250])
        {
            DataClassification = ToBeClassified;
        }
        field(9; Data; Media)
        {
            DataClassification = ToBeClassified;
        }
    }

    keys
    {
        key(PK; EntryNo)
        {
            Clustered = true;
        }
    }

}