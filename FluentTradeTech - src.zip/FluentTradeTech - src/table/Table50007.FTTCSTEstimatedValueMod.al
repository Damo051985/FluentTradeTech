table 50007 "FTT-CST Estimated Value Mod"
{
    DataClassification = ToBeClassified;

    fields
    {
        field(1; "Entry No."; Integer)
        {
            DataClassification = ToBeClassified;
            AutoIncrement = true;
        }
        field(2; "Linked No."; Code[50])
        {
            DataClassification = ToBeClassified;
        }
        field(3; "Linked Source Table ID"; Integer)
        {
            DataClassification = ToBeClassified;
        }
        field(4; "FTT-CST Sublocation"; Option)
        {
            DataClassification = ToBeClassified;
            OptionMembers = Blank,LD4,LD42,NY2,NY4,NY6,TY3,SG1,None;
            OptionCaption = '. . . . . . .,LD 4,LD 4.2,NY 2,NY 4,NY 6,TY 3,SG 1, None';
            Caption = 'Sublocation';
        }
        field(5; "FTT-CST Component Option"; Option)
        {
            Caption = 'Location Type';
            DataClassification = ToBeClassified;
            OptionMembers = Blank,Hosted,NonHosted,Unknown;
            OptionCaption = '. . . . . . .,Hosted,Non Hosted,Unknown';
        }
        field(6; "Region Code"; Code[20])
        {
            DataClassification = ToBeClassified;
            TableRelation = "Dimension Value".Code where("Global Dimension No." = const(3),
                                                                  "Dimension Value Type" = const(Standard),
                                                                  Blocked = const(false));

            //>>Dan
            Trigger OnValidate()
            var
                Item: Record Item;
                ItemCategory: Record "Item Category";
                recSalesPricehdr: Record "Price List Header";
                recSalesPRiceLines: Record "Price List Line";
                Contact_l: Record Contact;
                OppurtunityHdr: Record Opportunity;
            Begin
                if not Item.Get(rec."Item No.") then
                    exit;

                "Item No." := Item."No.";
                "Item Category Coede" := item."Item Category Code";
                "FTT-CST Cost Type" := item."FTT-CST Cost Type";

                if item."Unit Price" = 0 then begin
                    if Item."FTT-CST Type of Site" in [Item."FTT-CST Type of Site"::DR, Item."FTT-CST Type of Site"::Redundancy] then begin
                        "DR/Redundancy/Integ PriceCalc%" := Item."FTT-CST Redundancy PriceCalc %";
                        "Unit Price Excl. VAT" := 0;
                        Quantity := 1;
                        "Line Amount Total" := calcTotalofDRRedundacy2(Item."FTT-CST Redundancy PriceCalc %", Rec."Region Code");
                    end;
                    if Item."FTT-CST Integr PriceCalc %" <> 0 then begin
                        "Unit Price Excl. VAT" := 0;
                        Quantity := 1;
                        "DR/Redundancy/Integ PriceCalc%" := Item."FTT-CST Integr PriceCalc %";
                        "Line Amount Total" := calcTotalofIntegration2(Item."FTT-CST Integr PriceCalc %", Rec."Region Code");
                    end;
                end else begin
                    //NRD - Get Unit Price from Sales Price List based on the Currenncy
                    if not OppurtunityHdr.Get("Linked No.") then begin
                        "Unit Price Excl. VAT" := item."Unit Price";
                        "Estimated Value - Currency" := '';
                    end else begin
                        if not Contact_l.get(OppurtunityHdr."Contact No.") then
                            exit;

                        recSalesPricehdr.reset;
                        recSalesPricehdr.SetRange("Currency Code", Contact_l."Currency Code");
                        recSalesPricehdr.SetRange(Status, recSalesPricehdr.Status::Active);
                        if recSalesPricehdr.FindFirst() then begin
                            recSalesPRiceLines.Reset();
                            recSalesPRiceLines.SetRange("Price List Code", recSalesPricehdr.Code);
                            recSalesPRiceLines.SetRange("Product No.", rec."Item No.");
                            if recSalesPRiceLines.FindFirst() then
                                "Unit Price Excl. VAT" := recSalesPRiceLines."Unit Price"
                            else
                                "Unit Price Excl. VAT" := item."Unit Price";
                        end else
                            "Unit Price Excl. VAT" := item."Unit Price";

                        "Estimated Value - Currency" := Contact_l."Currency Code";
                    end;
                end;

            End;
            //<<dan
        }
        field(7; Description; Text[100])
        {
            Caption = 'Description';
            DataClassification = ToBeClassified;


        }
        field(8; "Item No."; Code[20])
        {
            Caption = 'Item No.';
            TableRelation = Item."No.";
            trigger OnValidate()
            var
                Item: Record Item;
                ItemCategory: Record "Item Category";
                recSalesPricehdr: Record "Price List Header";
                recSalesPRiceLines: Record "Price List Line";
                Contact_l: Record Contact;
                OppurtunityHdr: Record Opportunity;
            begin
                if not Item.Get(rec."Item No.") then
                    exit;

                "Item No." := Item."No.";
                "Item Category Coede" := item."Item Category Code";
                "FTT-CST Cost Type" := item."FTT-CST Cost Type";

                if item."Unit Price" = 0 then begin
                    if Item."FTT-CST Type of Site" in [Item."FTT-CST Type of Site"::DR, Item."FTT-CST Type of Site"::Redundancy] then begin
                        "DR/Redundancy/Integ PriceCalc%" := Item."FTT-CST Redundancy PriceCalc %";
                        "Unit Price Excl. VAT" := 0;
                        Quantity := 1;
                        "Line Amount Total" := calcTotalofDRRedundacy(Item."FTT-CST Redundancy PriceCalc %");
                    end;
                    if Item."FTT-CST Integr PriceCalc %" <> 0 then begin
                        "Unit Price Excl. VAT" := 0;
                        Quantity := 1;
                        "DR/Redundancy/Integ PriceCalc%" := Item."FTT-CST Integr PriceCalc %";
                        "Line Amount Total" := calcTotalofIntegration(Item."FTT-CST Integr PriceCalc %");
                    end;
                end else begin
                    //NRD - Get Unit Price from Sales Price List based on the Currenncy
                    if not OppurtunityHdr.Get("Linked No.") then begin
                        "Unit Price Excl. VAT" := item."Unit Price";
                        "Estimated Value - Currency" := '';
                    end else begin
                        if not Contact_l.get(OppurtunityHdr."Contact No.") then
                            exit;

                        recSalesPricehdr.reset;
                        recSalesPricehdr.SetRange("Currency Code", Contact_l."Currency Code");
                        recSalesPricehdr.SetRange(Status, recSalesPricehdr.Status::Active);
                        if recSalesPricehdr.FindFirst() then begin
                            recSalesPRiceLines.Reset();
                            recSalesPRiceLines.SetRange("Price List Code", recSalesPricehdr.Code);
                            recSalesPRiceLines.SetRange("Product No.", rec."Item No.");
                            if recSalesPRiceLines.FindFirst() then
                                "Unit Price Excl. VAT" := recSalesPRiceLines."Unit Price"
                            else
                                "Unit Price Excl. VAT" := item."Unit Price";
                        end else
                            "Unit Price Excl. VAT" := item."Unit Price";

                        "Estimated Value - Currency" := Contact_l."Currency Code";
                    end;
                end;



                if ItemCategory.Get(Item."Item Category Code") then begin
                    if ItemCategory."Parent Category" IN ['TAKER FEED', 'MAKER FEED'] then begin
                        "Parent Item Categ. Code" := 'FEED';
                    end else begin
                        if ItemCategory."Parent Category" <> '' then
                            "Parent Item Categ. Code" := ItemCategory."Parent Category" //NRD
                        else
                            "Parent Item Categ. Code" := Item."Item Category Code"; //NRD
                    end;
                end;
                Description := item.Description;
            end;
        }
        field(9; Quantity; Integer)
        {
            DataClassification = ToBeClassified;
            trigger OnValidate()
            begin
                if "FTT-CST Cost Type" <> "FTT-CST Cost Type"::MRC then
                    "Line Amount Total" := Quantity * "Unit Price Excl. VAT"
                else
                    "Line Amount Total" := (Quantity * "Unit Price Excl. VAT") * 12;
            end;
        }
        field(10; "Unit Price Excl. VAT"; Decimal)
        {
            DataClassification = ToBeClassified;
            Caption = 'Unit Price';
            trigger OnValidate()
            begin
                "Line Amount Total" := Quantity * "Unit Price Excl. VAT";
            end;
        }

        field(12; "Line Amount Total"; Decimal)
        {
            DataClassification = ToBeClassified;
        }
        field(13; "FTT-CST Optional"; Option)
        {
            OptionMembers = No,Yes;
            Caption = 'Optional';
            trigger OnValidate()
            begin
                //Validate("FTT-CST Unit Price", "Unit Price");
                if "FTT-CST Optional" = "FTT-CST Optional"::Yes then begin
                    Validate("Unit Price Excl. VAT", 0.01)
                end;
            end;
        }
        field(14; "FTT-CST Comments"; text[250])
        {
            Caption = 'Internal Comments';
        }
        field(15; "Completed"; Boolean)
        {
            DataClassification = ToBeClassified;
        }
        field(16; "Original Opportunity No."; Code[50])
        {
            DataClassification = ToBeClassified;
        }
        field(17; "DR/Redundancy/Integ PriceCalc%"; Decimal)
        {
            Caption = '%';
            DataClassification = ToBeClassified;
        }
        field(18; "Parent Item Categ. Code"; code[20])
        {
            DataClassification = ToBeClassified;
        }
        field(19; "FTT-CST Cost Type"; Enum "FTT-CST Cost Type")
        {
            DataClassification = ToBeClassified;
            Caption = 'Cost Type';
        }
        field(20; "Item Category Coede"; code[50])
        {
            Caption = 'Item Category';
            DataClassification = ToBeClassified;
            TableRelation = "Item Category".Code;
        }
        field(21; "Cross Connect"; Boolean) //NRD  - 05112024
        {
            DataClassification = ToBeClassified;
        }
        field(30; "Modified"; Boolean) //NRD  - 05112024
        {
            DataClassification = ToBeClassified;
        }
        field(31; "Estimated Value - Currency"; Code[20])
        {
            DataClassification = ToBeClassified;
        }
    }

    keys
    {
        key(Key1; "Entry No.", "Linked No.", "Linked Source Table ID")
        {
            Clustered = true;
            SumIndexFields = "Line Amount Total";
        }
    }

    fieldgroups
    {
        // Add changes to field groups here
    }

    procedure calcTotalofDRRedundacy(PerCentage: Decimal): Decimal
    var
        recEstValue: Record "FTT-CST Estimated Value Mod";
    begin

        recEstValue.SetRange("Linked No.", rec."Linked No.");
        recEstValue.SetRange("Linked Source Table ID", rec."Linked Source Table ID");
        recEstValue.SetFilter("Parent Item Categ. Code", 'FEED|LICENSE');
        if recEstValue.FindSet() then
            recEstValue.CalcSums(recEstValue."Line Amount Total")
        else
            Error('There''s nothing to calculate');
        exit(recEstValue."Line Amount Total" * (PerCentage / 100));

    end;

    procedure calcTotalofIntegration(PerCentage: Decimal): Decimal
    var
        recEstValue: Record "FTT-CST Estimated Value Mod";
    begin
        recEstValue.SetRange("Linked No.", rec."Linked No.");
        recEstValue.SetRange("Linked Source Table ID", rec."Linked Source Table ID");
        recEstValue.SetFilter("Parent Item Categ. Code", 'FEED|LICENSE|REDUNDANCY|DR');
        if recEstValue.FindSet() then
            recEstValue.CalcSums(recEstValue."Line Amount Total")
        else
            Error('There''s nothing to calculate');

        exit(recEstValue."Line Amount Total" * (PerCentage / 100));

    end;

    Procedure updatePerlocation(pRec: Record "FTT-CST Estimated Value Mod")
    var
        recEstValueMod: Record "FTT-CST Estimated Value Mod";

    Begin
        IF TempLoc.IsTemporary THEN
            TempLoc.DELETEALL;

        recEstValueMod.Reset();
        recEstValueMod.SetRange("Linked No.", prec."Linked No.");
        recEstValueMod.SetRange("Linked Source Table ID", prec."Linked Source Table ID");
        IF recEstValueMod.FINDSET then begin
            repeat
                TempLoc.Init();
                TempLoc.Code := recEstValueMod."Region Code";
                IF TempLoc.Insert THEN;
            until recEstValueMod.Next = 0;
        end;

    End;
    //>>Dan
    procedure calcTotalofDRRedundacy2(PerCentage: Decimal; pLoc: Code[20]): Decimal
    var
        recEstValue: Record "FTT-CST Estimated Value Mod";
    begin

        recEstValue.SetRange("Linked No.", rec."Linked No.");
        recEstValue.SetRange("Linked Source Table ID", rec."Linked Source Table ID");
        recEstValue.SetRange("Region Code", pLoc);
        recEstValue.SetFilter("Parent Item Categ. Code", 'FEED|LICENSE');
        if recEstValue.FindSet() then
            recEstValue.CalcSums(recEstValue."Line Amount Total")
        else
            Error('There''s nothing to calculate');
        exit(recEstValue."Line Amount Total" * (PerCentage / 100));

    end;

    procedure calcTotalofIntegration2(PerCentage: Decimal; pLoc: Code[20]): Decimal
    var
        recEstValue: Record "FTT-CST Estimated Value Mod";
    begin
        recEstValue.SetRange("Linked No.", rec."Linked No.");
        recEstValue.SetRange("Region Code", pLoc);
        recEstValue.SetRange("Linked Source Table ID", rec."Linked Source Table ID");
        recEstValue.SetFilter("Parent Item Categ. Code", 'FEED|LICENSE|REDUNDANCY|DR');
        if recEstValue.FindSet() then
            recEstValue.CalcSums(recEstValue."Line Amount Total")
        else
            Error('There''s nothing to calculate');

        exit(recEstValue."Line Amount Total" * (PerCentage / 100));

    end;
    //<<DAn
    var
        myInt: Integer;

    trigger OnInsert()
    begin

    end;

    trigger OnModify()
    begin
        Modified := True;
    end;
    //NRD - 05112024
    trigger OnDelete()
    var
        recCrossConnectTemp: Record "FTT-CST Cross ConnectLnsTemp";
    begin
        recCrossConnectTemp.Reset();
        recCrossConnectTemp.SetRange("Document Type", recCrossConnectTemp."Document Type"::Quote);
        recCrossConnectTemp.SetRange("Document No.", rec."Linked No.");
        recCrossConnectTemp.SetRange("Item No.", rec."Item No.");
        recCrossConnectTemp.SetRange("FTT-CST Location Code", rec."Region Code");
        if recCrossConnectTemp.FindFirst() then
            recCrossConnectTemp.Delete();
    end;
    //NRD
    trigger OnRename()
    begin

    end;

    var
        TempLoc: Record Location temporary;

}