table 50009 "FTT-CST Cross Connect Lines"
{
    DataClassification = ToBeClassified;

    fields
    {
        field(1; "Document Type"; enum "Sales Document Type")
        {
            DataClassification = ToBeClassified;

        }
        field(2; "Document No."; code[50])
        {
            DataClassification = ToBeClassified;
        }
        field(3; "Item No."; Code[20])
        {
            DataClassification = ToBeClassified;
            Caption = 'Item No.';
            TableRelation = Item;

        }
        field(4; Description; Text[250])
        {
            DataClassification = ToBeClassified;
            Caption = 'Description';

        }
        field(5; "Quantity 1"; Integer)
        {
            DataClassification = ToBeClassified;
            Caption = 'SHARED MRC';
        }
        field(6; "Quantity 2"; Integer)
        {
            Caption = 'DEDICATED MRC';
            DataClassification = ToBeClassified;
        }
        field(7; "Quantity 3"; Integer)
        {
            Caption = 'SHARED NRC';
            DataClassification = ToBeClassified;
        }
        field(8; "Quantity 4"; Integer)
        {
            DataClassification = ToBeClassified;
            Caption = 'DEDICATED NRC';
        }
        field(9; "FTT-CST Location Code"; code[20])
        {
            Caption = 'Location Code';
        }
        field(10; "Item Category Code"; Code[20])
        {
            DataClassification = ToBeClassified;
        }


    }

    keys
    {
        key(Key1; "Document Type", "Document No.", "Item No.", "FTT-CST Location Code")
        {
            Clustered = true;
        }
    }

    fieldgroups
    {
        // Add changes to field groups here
    }

    var
        myInt: Integer;

    trigger OnInsert()
    begin

    end;

    // trigger OnModify()
    // var
    //     recSalesLine: Record "Sales Line";
    // begin
    //     if rec."Quantity 1" <> 0 then begin
    //         recSalesLine.Reset();
    //         recSalesLine.SetRange("Document Type", recSalesLine."Document Type"::Order);
    //         recSalesLine.SetRange("Document No.", rec."Document No.");
    //         recSalesLine.SetRange("FTT-CST Location Code", rec."FTT-CST Location Code");
    //         recSalesLine.SetRange(Type, recSalesLine.Type::Item);
    //         recSalesLine.SetRange("No.", '1101');
    //         if recSalesLine.FindFirst() then begin
    //             recSalesLine.Validate(Quantity, (recSalesLine.Quantity - rec."Quantity 1"));
    //             recSalesLine.Modify(true);
    //         end;
    //     end;

    //     if rec."Quantity 2" <> 0 then begin
    //         recSalesLine.Reset();
    //         recSalesLine.SetRange("Document Type", recSalesLine."Document Type"::Order);
    //         recSalesLine.SetRange("Document No.", rec."Document No.");
    //         recSalesLine.SetRange("FTT-CST Location Code", rec."FTT-CST Location Code");
    //         recSalesLine.SetRange(Type, recSalesLine.Type::Item);
    //         recSalesLine.SetRange("No.", '1102');
    //         if recSalesLine.FindFirst() then begin
    //             recSalesLine.Validate(Quantity, (recSalesLine.Quantity - rec."Quantity 2"));
    //             recSalesLine.Modify(true);
    //         end;
    //     end;

    //     if rec."Quantity 3" <> 0 then begin
    //         recSalesLine.Reset();
    //         recSalesLine.SetRange("Document Type", recSalesLine."Document Type"::Order);
    //         recSalesLine.SetRange("Document No.", rec."Document No.");
    //         recSalesLine.SetRange("FTT-CST Location Code", rec."FTT-CST Location Code");
    //         recSalesLine.SetRange(Type, recSalesLine.Type::Item);
    //         recSalesLine.SetRange("No.", '1103');
    //         if recSalesLine.FindFirst() then begin
    //             recSalesLine.Validate(Quantity, (recSalesLine.Quantity - rec."Quantity 3"));
    //             recSalesLine.Modify(true);
    //         end;
    //     end;

    //     if rec."Quantity 4" <> 0 then begin
    //         recSalesLine.Reset();
    //         recSalesLine.SetRange("Document Type", recSalesLine."Document Type"::Order);
    //         recSalesLine.SetRange("Document No.", rec."Document No.");
    //         recSalesLine.SetRange("FTT-CST Location Code", rec."FTT-CST Location Code");
    //         recSalesLine.SetRange(Type, recSalesLine.Type::Item);
    //         recSalesLine.SetRange("No.", '1104');
    //         if recSalesLine.FindFirst() then begin
    //             recSalesLine.Validate(Quantity, (recSalesLine.Quantity - rec."Quantity 4"));
    //             recSalesLine.Modify(true);
    //         end;
    //     end;
    // end;

    trigger OnDelete()
    begin
    end;

    trigger OnRename()
    begin

    end;

}