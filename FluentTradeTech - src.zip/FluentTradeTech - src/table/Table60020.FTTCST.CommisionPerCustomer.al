table 60020 "Commision Per Customer"
{
    Caption = 'Commission Per Customer';
    DataClassification = ToBeClassified;

    fields
    {
        field(10; "Customer Code"; Code[20])
        {
            Caption = 'Customer Code';
            TableRelation = "Customer"."No.";
            DataClassification = ToBeClassified;
            //ValidateTableRelation = False;
        }
        field(20; "Customer Name"; Text[100])
        {
            Caption = 'Customer Name';
            DataClassification = ToBeClassified;
        }
        field(30; "Salesperson Code"; Code[20])
        {
            Caption = 'Salesperson Code';
            TableRelation = "Salesperson/Purchaser".Code;
            DataClassification = ToBeClassified;
            //ValidateTableRelation = False;
        }
        field(40; "Salesperson Name"; Text[100])
        {
            Caption = 'Salesperson Name';
            DataClassification = ToBeClassified;
        }
        field(50; "Invoice Amount Currency"; Decimal)
        {
            Caption = 'Invoice Amount Currency';
            DataClassification = ToBeClassified;
        }
        field(60; "Invoice Amount LCY"; Decimal)
        {
            Caption = 'Invoice Amount LCY';
            DataClassification = ToBeClassified;
        }
        field(70; "Eligible Currency"; Decimal)
        {
            Caption = 'Eligible Currency';
            DataClassification = ToBeClassified;
        }
        field(80; "Eligible LCY"; Decimal)
        {
            Caption = 'Eligible LCY';
            DataClassification = ToBeClassified;
        }
        field(90; "Commision Currency"; Decimal)
        {
            Caption = 'Commission Currency';
            DataClassification = ToBeClassified;
        }
        field(100; "Commision LCY"; Decimal)
        {
            Caption = 'Commission LCY';
            DataClassification = ToBeClassified;
        }
        field(110; Comment; Text[1024])
        {
            Caption = 'Comment';
            DataClassification = ToBeClassified;
        }
        field(120; Type; Option)
        {
            Caption = 'Type';
            OptionMembers = " ",Line,"Grand Total";
            OptionCaption = ' ,Line,Grand Total';
            DataClassification = ToBeClassified;
        }
        field(130; "GTotalFld50"; Decimal)
        {
            Caption = 'Invoice Amount Currency';
            FieldClass = FlowField;
            CalcFormula = Sum("Commision Per Customer"."Invoice Amount Currency");
            //where("Line Type" = Filter("Over 50 %" | "Over 85 %"), Type = filter(<> "Total")));
            DecimalPlaces = 2 : 2;
        }
        field(140; "GTotalFld60"; Decimal)
        {
            Caption = 'Invoice Amount LCY';
            FieldClass = FlowField;
            CalcFormula = Sum("Commision Per Customer"."Invoice Amount LCY");
            DecimalPlaces = 2 : 2;
        }
        field(150; "GTotalFld70"; Decimal)
        {
            Caption = 'Eligible Currency';
            FieldClass = FlowField;
            CalcFormula = Sum("Commision Per Customer"."Eligible Currency");
            DecimalPlaces = 2 : 2;
        }
        field(160; "GTotalFld80"; Decimal)
        {
            Caption = 'Eligible LCY';
            FieldClass = FlowField;
            CalcFormula = Sum("Commision Per Customer"."Eligible LCY");
            DecimalPlaces = 2 : 2;
        }
        field(170; "GTotalFld90"; Decimal)
        {
            Caption = 'Commission Currency';
            FieldClass = FlowField;
            CalcFormula = Sum("Commision Per Customer"."Commision Currency");
            DecimalPlaces = 2 : 2;
        }
        field(180; "GTotalFld100"; Decimal)
        {
            Caption = 'Commission LCY';
            FieldClass = FlowField;
            CalcFormula = Sum("Commision Per Customer"."Commision LCY");
            DecimalPlaces = 2 : 2;
        }
    }
    keys
    {
        key(PK; "Customer Code", "Salesperson Code")
        {
            Clustered = true;
        }
    }
}
