table 60019 "FTTCST Allergies"
{
    Caption = 'Allergies';
    DataCaptionFields = "Employee No.";
    DataClassification = CustomerContent;

    fields
    {
        field(1; "Employee No."; Code[20])
        {
            Caption = 'Employee No.';
            NotBlank = true;
            TableRelation = Employee;
        }
        field(2; "Allergy Code"; Code[10])
        {
            Caption = 'Allergies Code';
            NotBlank = true;

            trigger OnValidate()
            var
                FTTAllergies: Record "FTTCST Allergies";
            begin
                Clear(FTTAllergies);
                IF FTTAllergies.FINDLAST then
                    "Line No." := FTTAllergies."Line No." + 10
                ELSE
                    "Line No." := 10;
            end;
        }
        field(3; "Line No."; Integer)
        {
            Caption = 'Line No.';
            NotBlank = true;
        }
        field(4; Description; Text[100])
        {
            Caption = 'Description';
        }
        field(5; Comment; Text[1024])
        {
            Caption = 'Comment';
        }
    }

    keys
    {
        key(Key1; "Employee No.", "Allergy Code", "Line No.")
        {
            Clustered = true;
        }
    }

    fieldgroups
    {
    }

    trigger Oninsert()
    var

    begin

    end;

    var

}
