table 50012 "FTT-CST Comm. Agrm. Header"
{
    DataClassification = ToBeClassified;
    Caption = 'Commission Agreement';
    fields
    {
        field(1; "Agreement No."; code[50])
        {
            DataClassification = ToBeClassified;

        }
        field(2; "Document Date"; Date)
        {
            DataClassification = ToBeClassified;
        }
        field(3; "Salesperson Type"; Option)
        {
            OptionMembers = "Salesperson","Team";
            OptionCaption = 'Salesperson,Team';
            trigger OnValidate()
            begin
                rec."Supervisor Code" := '';
                rec."Type No." := '';
            end;
        }
        field(4; "Type No."; code[20])
        {
            DataClassification = ToBeClassified;
            TableRelation = if ("Salesperson Type" = const("Salesperson")) "Salesperson/Purchaser"
            else
            if ("Salesperson Type" = const("Team")) Team;
            trigger OnValidate()
            var
                recSalesperson: Record "Salesperson/Purchaser";
                recTeam: Record Team;
            begin
                if rec."Salesperson Type" = rec."Salesperson Type"::Salesperson then begin
                    if recSalesperson.Get("Type No.") then begin
                        rec.Description := recSalesperson.Name;
                        rec."Supervisor Code" := '';
                    end;
                end else begin
                    if recTeam.Get("Type No.") then begin
                        rec.Description := recTeam.Name;
                        rec."Supervisor Code" := recTeam."FTT-CST Supervisor Code";
                    end;
                end;

            end;
        }
        field(5; "Description"; text[250])
        {
            DataClassification = ToBeClassified;
        }
        field(6; "Agr. Starting Date"; Date)
        {
            DataClassification = ToBeClassified;
            trigger OnValidate()
            begin
                rec."Agr. Ending Date" := CalcDate('+1Y', today)
            end;
        }
        field(7; "Agr. Ending Date"; Date)
        {
            DataClassification = ToBeClassified;
        }
        field(8; "Settlement Type"; Option)
        {
            OptionMembers = "Invoice","Partial Payment","Full Payment";
            OptionCaption = 'Invoice,Partial Payment,Full Payment';
        }
        field(9; Status; Option)
        {
            OptionMembers = "Open","De-Activated","Activated";
            OptionCaption = 'Open,De-Activated,Activated';
        }
        field(10; "Supervisor Code"; code[20])
        {
            DataClassification = ToBeClassified;
            TableRelation = "Salesperson/Purchaser".Code;
        }
        field(11; "No Series Code"; Code[20])
        {
            DataClassification = ToBeClassified;
            Editable = false;
        }
        field(12; "Created By"; Code[20])
        {
            DataClassification = ToBeClassified;
        }
        field(13; "Agreement Period"; Integer)
        {
            Caption = 'Agreement Period';
            InitValue = 1;
            MinValue = 1;
        }
        field(14; "PDC Bank Account No."; Code[50])
        {
            DataClassification = ToBeClassified;
            TableRelation = "Bank Account"."No.";

        }
        field(15; "Payment Method Code"; Code[20])
        {
            DataClassification = ToBeClassified;
            TableRelation = "Payment Method";


        }
    }

    keys
    {
        key(Key1; "Agreement No.")
        {
            Clustered = true;
        }
    }

    fieldgroups
    {
        // Add changes to field groups here
    }

    var
        NoSeriesMgt: Codeunit "No. Series";
        AgreementSetup: record "FTT-CST Commission Agr. Setup";

    trigger OnInsert()
    begin
        IF "Agreement No." = '' THEN BEGIN
            TestNoSeries;
            AgreementSetup.Get();

            "Agreement No." := NoSeriesMgt.GetNextNo(AgreementSetup."Comm. Agreement Nos.");
        end;

        "Created By" := USERID;
        "Document Date" := TODAY;
    end;



    trigger OnRename()
    begin

    end;

    local procedure TestNoSeries()
    begin
        if not AgreementSetup.Get() then
            exit;

        AgreementSetup.TestField("Comm. Agreement Nos.")
    end;
}