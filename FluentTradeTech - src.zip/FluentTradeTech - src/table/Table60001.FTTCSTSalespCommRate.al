table 60001 "FTT-CST Salesp. Comm. Rate"
{
    Caption = 'Salesperson Commission Rate';
    DataClassification = CustomerContent;

    fields
    {
        field(1; "Salesperson Code"; Code[20])
        {
            Caption = 'Salesperson Code';
            TableRelation = "Salesperson/Purchaser".Code;
        }
        field(2; "Item Category Code"; Code[20])
        {
            Caption = 'Item Category Code';
            TableRelation = "Item Category".Code;
        }
        field(3; "Agreement Period"; Integer)
        {
            Caption = 'Agreement Period';
            InitValue = 1;
            MinValue = 1;
        }
        field(4; "Commission Rate %"; Decimal)
        {
            Caption = 'Commission Rate %';
            MinValue = 0;
        }
    }
    keys
    {
        key(PK; "Salesperson Code", "Item Category Code", "Agreement Period")
        {
            Clustered = true;
        }
    }
}
