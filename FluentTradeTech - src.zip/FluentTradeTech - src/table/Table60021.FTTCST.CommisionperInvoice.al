table 60021 "Commision per Invoice"
{
    Caption = 'Commission per Invoice';
    DataClassification = CustomerContent;

    fields
    {
        field(3; "Invoice No."; Code[20])
        {
            Caption = 'Invoice No.';
        }
        field(6; "Invoice Status"; Option)
        {
            Caption = 'Invoice Status';
            OptionMembers = " ",Paid,"Unpaid";
            OptionCaption = ' ,Paid,Unpaid';
        }
        field(10; "Customer Code"; Code[20])
        {
            Caption = 'Customer Code';
            TableRelation = "Customer"."No.";
        }
        field(20; "Customer Name"; Text[100])
        {
            Caption = 'Customer Name';
        }
        field(30; "Salesperson Code"; Code[20])
        {
            Caption = 'Salesperson Code';
            TableRelation = "Salesperson/Purchaser".Code;
        }
        field(40; "Salesperson Name"; Text[100])
        {
            Caption = 'Salesperson Name';
        }
        field(50; "Invoice Amount Currency"; Decimal)
        {
            Caption = 'Invoice Amount Currency';
        }
        field(60; "Invoice Amount LCY"; Decimal)
        {
            Caption = 'Invoice Amount LCY';
        }
        field(70; "Eligible Currency"; Decimal)
        {
            Caption = 'Eligible Currency';
        }
        field(80; "Eligible LCY"; Decimal)
        {
            Caption = 'Eligible LCY';
        }
        field(90; "Commision Currency"; Decimal)
        {
            Caption = 'Commission Currency';
        }
        field(100; "Commision LCY"; Decimal)
        {
            Caption = 'Commission LCY';
        }
        field(110; Comment; Text[1024])
        {
            Caption = 'Comment';
        }
        field(120; Type; Option)
        {
            Caption = 'Type';
            OptionMembers = " ",Line,"Grand Total";
            OptionCaption = ' ,Line,Grand Total';
        }
        field(130; "GTotalFld50"; Decimal)
        {
            Caption = 'Invoice Amount Currency';
            FieldClass = FlowField;
            CalcFormula = Sum("Commision Per Invoice"."Invoice Amount Currency");
            DecimalPlaces = 2 : 2;
        }
        field(140; "GTotalFld60"; Decimal)
        {
            Caption = 'Invoice Amount LCY';
            FieldClass = FlowField;
            CalcFormula = Sum("Commision Per Invoice"."Invoice Amount LCY");
            DecimalPlaces = 2 : 2;
        }
        field(150; "GTotalFld70"; Decimal)
        {
            Caption = 'Eligible Currency';
            FieldClass = FlowField;
            CalcFormula = Sum("Commision Per Invoice"."Eligible Currency");
            DecimalPlaces = 2 : 2;
        }
        field(160; "GTotalFld80"; Decimal)
        {
            Caption = 'Eligible LCY';
            FieldClass = FlowField;
            CalcFormula = Sum("Commision Per Invoice"."Eligible LCY");
            DecimalPlaces = 2 : 2;
        }
        field(170; "GTotalFld90"; Decimal)
        {
            Caption = 'Commission Currency';
            FieldClass = FlowField;
            CalcFormula = Sum("Commision Per Invoice"."Commision Currency");
            DecimalPlaces = 2 : 2;
        }
        field(180; "GTotalFld100"; Decimal)
        {
            Caption = 'Commission LCY';
            FieldClass = FlowField;
            CalcFormula = Sum("Commision Per Invoice"."Commision LCY");
            DecimalPlaces = 2 : 2;
        }
    }
    keys
    {
        key(PK; "Invoice No.")
        {
            Clustered = true;
        }
    }
}
