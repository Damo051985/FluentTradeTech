table 50008 "FTT-CST Cross Connect Hdr"
{
    DataClassification = ToBeClassified;

    fields
    {
        field(1; "Document Type"; enum "Sales Document Type")
        {
            DataClassification = ToBeClassified;

        }
        field(2; "Document No."; code[50])
        {
            DataClassification = ToBeClassified;
        }
        field(3; "Customer No."; Code[20])
        {
            DataClassification = ToBeClassified;
            TableRelation = Customer."No.";
            trigger OnValidate()
            var
                recCustomer: Record Customer;
            begin
                if recCustomer.get("Customer No.") then
                    "Customer Name" := recCustomer.Name;
            end;
        }
        field(4; "Customer Name"; Text[500])
        {
            Caption = 'Name';

        }
        field(5; "Cross Connect Status"; Option)
        {
            OptionCaption = 'Open,Line Inserted,Converted';
            OptionMembers = "Open","Line Inserted","Converted";
        }
        field(7; "Total of Shared MRC"; Integer)
        {
            FieldClass = FlowField;
            CalcFormula = sum("FTT-CST Cross Connect Lines"."Quantity 1" where("Document No." = field("Document No."), "Document Type" = field("Document Type")));
            Caption = 'Total of Shared MRC';
        }
        field(8; "Total of Dedicated MRC"; Integer)
        {
            FieldClass = FlowField;
            CalcFormula = sum("FTT-CST Cross Connect Lines"."Quantity 2" where("Document No." = field("Document No."), "Document Type" = field("Document Type")));
            Caption = 'Total of Dedicated MRC';
        }
        field(9; "Total of Shared NRC"; Integer)
        {
            FieldClass = FlowField;
            CalcFormula = sum("FTT-CST Cross Connect Lines"."Quantity 3" where("Document No." = field("Document No."), "Document Type" = field("Document Type")));
        }
        field(10; "Total of Dedicated NRC"; Integer)
        {
            FieldClass = FlowField;
            CalcFormula = sum("FTT-CST Cross Connect Lines"."Quantity 4" where("Document No." = field("Document No."), "Document Type" = field("Document Type")));
        }


    }

    keys
    {
        key(Key1; "Document Type", "Document No.", "Customer No.")
        {
            Clustered = true;
        }
    }

    trigger OnDelete()
    var
        CrossConnectLines: Record "FTT-CST Cross Connect Lines";
    begin
        CrossConnectLines.Reset();
        CrossConnectLines.SetRange("Document Type", rec."Document Type");
        CrossConnectLines.SetRange("Document No.", rec."Document No.");
        if CrossConnectLines.FindSet() then
            CrossConnectLines.DeleteAll();
    end;

}