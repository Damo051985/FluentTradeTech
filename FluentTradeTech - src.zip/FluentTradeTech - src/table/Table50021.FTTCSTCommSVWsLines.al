table 50021 "Commission SV. Worksheet Lines"
{
    DataClassification = ToBeClassified;

    fields
    {
        field(1; "Document No."; code[50])
        {
            DataClassification = ToBeClassified;
            TableRelation = "Commission SV. Worksht. Header"."Document No.";
        }
        field(2; "Line No."; Integer)
        {
            DataClassification = ToBeClassified;
        }

        field(3; "Document Type"; enum "Gen. Journal Document Type")
        {
            DataClassification = ToBeClassified;
        }
        field(4; "Inv, Document No."; code[50])
        {
            DataClassification = ToBeClassified;
        }
        field(5; "Document Date"; date)
        {
            DataClassification = ToBeClassified;
            Caption = 'Posting Date';
        }
        field(7; "Sell-to Customer Name"; Text[250])
        {
            DataClassification = ToBeClassified;
        }
        field(8; "Currency Code"; Code[20])
        {
            DataClassification = ToBeClassified;
            TableRelation = Currency.Code;
        }
        field(9; "Commission Amount"; Decimal)
        {
            DataClassification = ToBeClassified;
        }
        field(10; "Commission Amount (LCY)"; Decimal)
        {
            DataClassification = ToBeClassified;
        }
        field(11; "Supervisor Reward Amount (LCY)"; Decimal)
        {
            DataClassification = ToBeClassified;
        }
        field(12; "Supervisor Reward Amount"; Decimal)
        {
            DataClassification = ToBeClassified;
        }
        field(13; "Rem. Super. Reward Amt (LCY)"; Decimal)
        {
            DataClassification = ToBeClassified;
        }
        field(14; "Supervisor Reward %"; Decimal)
        {
            DataClassification = ToBeClassified;
        }
        field(15; "Application Amount"; Decimal)
        {
            DataClassification = ToBeClassified;
        }
        field(16; "Comm. SV. Entry No."; Integer)
        {
            DataClassification = ToBeClassified;
        }
        field(17; "Rem. Super. Reward Amt"; Decimal)
        {
            DataClassification = ToBeClassified;
        }
        field(18; "Commission Agreement No."; code[50])
        {
            DataClassification = ToBeClassified;
            TableRelation = "FTT-CST Comm. Agrm. Header"."Agreement No.";
        }

    }

    keys
    {
        key(Key1; "Document No.", "Line No.")
        {
            Clustered = true;
        }
    }

    fieldgroups
    {
        // Add changes to field groups here
    }

    var
        myInt: Integer;

    trigger OnInsert()
    begin

    end;

    trigger OnModify()
    begin

    end;

    trigger OnDelete()
    begin

    end;

    trigger OnRename()
    begin

    end;

}