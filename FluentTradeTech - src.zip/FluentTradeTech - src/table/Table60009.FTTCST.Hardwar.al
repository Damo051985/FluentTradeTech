table 60009 "FTT-CST Special Select"
{
    DataClassification = ToBeClassified;

    fields
    {
        field(1; "Filter No."; Integer)
        {
            DataClassification = ToBeClassified;

        }
        field(2; "Item No."; Code[20])
        {
            DataClassification = ToBeClassified;
            Caption = 'Item No.';

        }
        field(3; Description; Text[250])
        {
            Caption = 'Description';

        }
        field(4; "Quantity"; Integer)
        {
            Caption = 'Quantity';
            trigger OnValidate()
            begin

            end;
        }
        field(5; "Unit Price"; Decimal)
        {
            Caption = 'Unit Price';
            trigger OnValidate()
            begin

            end;
        }
        field(6; Level; Integer)
        {
            Caption = 'Level';
            trigger OnValidate()
            begin

            end;
        }
        field(7; Comments; text[250])
        {
            Caption = 'Internal Comment';

        }
        field(8; Optional; Option)
        {
            OptionCaption = 'No,Yes';
            OptionMembers = No,Yes;
        }
        field(9; "Comments Fluent"; text[250])
        {
            Caption = 'Comment Fluent';
        }
        field(10; Redundancy; Option)
        {
            Caption = 'Redundancy';
            OptionCaption = 'No,Yes';
            OptionMembers = No,Yes;

        }
        field(11; DR; Option)
        {
            Caption = 'DR';
            OptionCaption = 'No,Yes';
            OptionMembers = No,Yes;

        }
        field(12; "Recalculation %"; Decimal)
        {
            Caption = '%';
        }
        field(13; "FTT-CST Location Type"; enum "FTT-CST Location Type")
        {
            Caption = 'Location Type';
        }
        field(14; Integration; Boolean)
        {
            Caption = 'Integration';
        }
        Field(52; "FTT-CST Sublocation"; Option)
        {
            DataClassification = ToBeClassified;
            OptionMembers = Blank,LD4,LD42,NY2,NY4,NY6,TY3,SG1,None;
            OptionCaption = '. . . . . . .,LD 4,LD 4.2,NY 2,NY 4,NY 6,TY 3,SG 1,None';
            Caption = 'Sublocation';
        }
        Field(53; "Currency Code"; Code[20])
        {
            Caption = 'Currency Code';
        }
        field(54; "Customer Price Group"; Code[10])
        {
            Caption = 'Customer Price Group';
            TableRelation = "Customer Price Group";

            trigger OnValidate()
            begin
            end;
        }
        field(55; "Posting Date"; date)
        {
            Caption = 'Posting Date';
        }
        field(56; "Integr."; Option) //NRD
        {
            Caption = 'Integration';
            OptionCaption = 'No,Yes';
            OptionMembers = No,Yes;
        }


    }

    keys
    {
        key(Key1; "Filter No.", Level, "Item No.")
        {
            Clustered = true;
        }
    }

    fieldgroups
    {
        // Add changes to field groups here
    }

    var
        myInt: Integer;

    trigger OnInsert()
    var
        PriceListHeader: Record "Price List Header";
        PriceListLine: Record "Price List Line";
        Currency: Record Currency;
        CurrExchRate: Record "Currency Exchange Rate";
    begin
        if (Rec."Customer Price Group" <> '') and (Rec."Currency Code" <> '') then begin
            PriceListLine.SetRange("Source Type", PriceListLine."Source Type"::"Customer Price Group");
            PriceListLine.SetRange("Source No.", Rec."Customer Price Group");
            PriceListLine.SetRange("Currency Code", Rec."Currency Code");
            PriceListLine.SetRange("Starting Date", 0D, Rec."Posting Date");
            PriceListLine.SetRange("Asset Type", PriceListLine."Asset Type"::Item);
            PriceListLine.SetRange("Asset No.", Rec."Item No.");
            if PriceListLine.FindFirst() then
                Rec."Unit Price" := PriceListLine."Unit Price" else begin
                if Rec."Currency Code" <> '' then begin
                    Currency.Get(Rec."Currency Code");
                    //Rec."Unit Price" := CurrExchRate.ExchangeAmount(Rec."Unit Price", Rec."Currency Code", '', WorkDate());
                    Rec."Unit Price" := Round(Rec."Unit Price" / CurrExchRate.ExchangeRate(Today, Rec."Currency Code"), Currency."Unit-Amount Rounding Precision");
                    //Rec.Modify();
                    //Rec.Validate("Unit Price",
                    //CurrExchRate.ExchangeAmtLCYToFCYOnlyFactor(Rec."Unit Price", CurrExchRate.ExchangeRate(Today, Rec."Currency Code")));
                end;
            end;
        end
    end;

    trigger OnModify()
    begin

    end;

    trigger OnDelete()
    begin

    end;

    trigger OnRename()
    begin

    end;

    procedure SetOptionVisible(pVisible: Boolean)
    begin
        OptionVisible := pVisible;
    end;

    var
        OptionVisible: Boolean;

}