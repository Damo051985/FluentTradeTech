table 60016 "Birthday Email Notif. Setup"
{
    Caption = 'Birthday Email Notif. Setup';
    DataClassification = ToBeClassified;
    LookupPageId = "Birthday Email Notif. List";
    fields
    {
        field(10; "User ID"; Code[50])
        {
            Caption = 'Employee ID';
            DataClassification = EndUserIdentifiableInformation;
            NotBlank = true;
            TableRelation = Employee."No.";
            ValidateTableRelation = TRUE;

            trigger OnValidate()
            var
                lEmp: Record Employee;
            begin
                IF lEmp.GET("User ID") then begin
                    "Full Name" := lEmp."First Name" + ' ' + lEmp."Last Name";
                    "Birth Date" := lEmp."Birth Date";
                END;
            end;
        }
        field(20; "Full Name"; Text[250])
        {
            Caption = 'Full Name';
            Editable = False;
        }
        field(30; Designation; Option)
        {
            Caption = 'Designation';
            OptionMembers = " ",Manager,Director,President,HR;
        }
        field(40; Approver; Code[50])
        {
            Caption = 'Approver ID';
            DataClassification = EndUserIdentifiableInformation;
            NotBlank = true;
            TableRelation = Employee."No.";
            ValidateTableRelation = false;

            trigger OnValidate()
            var
                lEmp: Record Employee;
            begin
                IF lEmp.GET("Approver") then
                    "Approver Name" := lEmp."First Name" + ' ' + lEmp."Last Name";
            end;
        }
        field(45; "Approver Name"; Text[250])
        {
            Caption = 'Approver Name';
            DataClassification = EndUserIdentifiableInformation;
            NotBlank = true;
            Editable = False;

            trigger OnValidate()
            var

            begin

            end;
        }
        field(50; "Email Body 1"; Text[250])
        {
            Caption = 'Email Body 1';
        }
        field(60; "Email Body 2"; Text[250])
        {
            Caption = 'Email Body 2';
        }
        field(70; "Email Body 3"; Text[250])
        {
            Caption = 'Email Body 3';
        }
        field(80; "Email Body 4"; Text[250])
        {
            Caption = 'Email Body 4';
        }
        field(90; "Email Body 5"; Text[250])
        {
            Caption = 'Email Body 5';
        }
        field(100; "Email Body 6"; Text[250])
        {
            Caption = 'Email Body 6';
        }
        field(110; "Email Body 7"; Text[250])
        {
            Caption = 'Email Body 7';
        }
        field(120; Subject; Text[250])
        {
            Caption = 'Subject';
        }
        field(130; "Top Greetings"; Text[250])
        {
            Caption = 'Top Greetings';
        }
        field(140; "Bottom Greetings"; Text[250])
        {
            Caption = 'Bottom Greetings';
        }
        field(150; "Emoji 1"; Blob)
        {
            Caption = 'Image 1';
            Subtype = Bitmap;
        }
        field(160; "Emoji 2"; Blob)
        {
            Caption = 'Image 2';
            Subtype = Bitmap;
        }
        field(170; "Picture Length"; Integer)
        {
            Caption = 'Picture Length';
        }
        field(180; Comment; Text[250])
        {
            Caption = 'Comment';
        }
        field(190; "Birth Date"; Date)
        {
            Caption = 'Notification Date';
            Editable = False;
        }
        field(200; "Date Period"; DateFormula)
        {
            Caption = 'Date Period';
            trigger OnValidate()
            var
                lEmp: Record Employee;
                lExp: Text[30];
                DayInt, MonthInt, YearInt : Integer;
                InputDate, InputDate2 : date;
            Begin
                IF lEmp.GET("User ID") THEN begin
                    lEmp.TestField("Birth Date");
                    DayInt := DATE2DMY(lEmp."Birth Date", 1);
                    MonthInt := DATE2DMY(lEmp."Birth Date", 2);
                    YearInt := DATE2DMY(TODAY, 3);
                    InputDate := DMY2Date(DayInt, MonthInt, YearInt);
                    lExp := '<-' + FORMAT("Date Period") + '>';
                    "notification Date" := CalcDate(lExp, InputDate)
                end;
            End;
        }
        field(220; "notification Date"; Date)
        {
            Caption = 'Notification Date';
            Editable = False;
        }
        field(230; "Greeting From"; Text[50])
        {
            Caption = 'Greetings From';
            Editable = true;
        }
        field(240; "Mailing Group"; Code[30])
        {
            Caption = 'Mailing Group';
            Editable = true;
            TableRelation = "Email Mailing Group Code"."Mailing Group Code";
        }
    }
    keys
    {
        key(PK; "User ID")
        {
            Clustered = true;
        }
    }
    Trigger OnInsert()
    var
    Begin
        "Email Body 1" := Label1;
        "Email Body 2" := Label2;
        "Email Body 3" := Label3;
        "Email Body 4" := Label4;
        "Top Greetings" := LabelTop;
        "Bottom Greetings" := LabelBot;
        Subject := LabelSub;
        EVALUATE("Date Period", '<0D>');
        Validate("Date Period");
    End;

    var
        Label1: Label 'On behalf of the entire team at Fluent Trade Technologies Inc., we would like to take a moment to wish you a very happy birthday!';
        Label2: Label 'We hope this special day brings you joy, laughter, and a well-deserved celebration.';
        Label3: Label 'Your hard work, dedication, and positive spirit are truly appreciated, and we’re grateful to have you as part of our team.';
        Label4: Label 'Enjoy your day to the fullest – here’s to another wonderful year ahead!';
        LabelTop: Label 'Dear';
        LabelBot: Label 'Warmest Wishes,';
        LabelSub: Label 'Happy Birthday';
}
