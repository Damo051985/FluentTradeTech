table 60005 "FTT-CST Dependancy Item"
{
    Caption = 'Standard Item Sales Code';
    DataClassification = CustomerContent;

    fields
    {
        field(1; "No."; Code[20])
        {
            Caption = 'Item No.';
            DataClassification = CustomerContent;
            TableRelation = Item."No.";
        }
        field(2; "Code"; Code[10])
        {
            Caption = 'Code';
            DataClassification = CustomerContent;
            TableRelation = "Standard Sales Code".Code;

            trigger OnValidate()
            begin
                GetDataStandardSalesCode();
            end;
        }
        field(3; Description; Text[100])
        {
            Caption = 'Description';
            DataClassification = CustomerContent;

            Editable = false;
        }
        field(10; Redundancy; Option)
        {
            Caption = 'Redundancy';
            OptionCaption = 'No,Yes';
            OptionMembers = No,Yes;

        }
        field(11; DR; Option)
        {
            Caption = 'DR';
            OptionCaption = 'No,Yes';
            OptionMembers = No,Yes;

        }
        field(18; "Unit Price"; Decimal)
        {
            Caption = 'Unit Price';
            DataClassification = CustomerContent;

            //Editable = false; //Temporary Disabled / NRD
        }
        field(60003; "FTT-CST RED/DR PriceCalc %"; Decimal)
        {
            Caption = 'DR\Redundancy %';
            DataClassification = CustomerContent;

            Editable = false;
        }
        field(60020; "Filter No."; Integer)
        {

        }
        field(60021; "FTT-CST DR"; boolean)
        {
            Caption = 'DR';
        }
        field(60022; "FTT-CST Redundency"; boolean)
        {
            Caption = 'Redundency';
        }
        field(60023; "FTT-CST Integration"; boolean)
        {
            Caption = 'Redundency';
        }
        field(60024; "FTT-CST FEED"; boolean)
        {
            Caption = 'Redundency';
        }
        field(60025; "FTT-CST Quantity"; Decimal)
        {
            Caption = 'Quantity';
        }
        Field(60026; "FTT-CST Cross Connect"; boolean)
        {
            Caption = 'Cross Connect';
        }
        field(60027; "Item Category Code"; code[20])
        {

        }
        field(60028; "Location Code"; code[20])
        {
            Caption = 'Location Code';
        }
        field(60029; Level; Integer)
        {
            caption = 'Level';
        }
        field(60030; "FTT-CST Comments"; text[250])
        {
            Caption = 'Internal Comments';
        }

        field(60031; Optional; Option)
        {
            Caption = 'Optional';
            OptionCaption = 'No,Yes';
            OptionMembers = No,Yes;

        }
        field(60032; "FTT-CST Use for Discount"; Boolean)
        {
            Caption = 'Use for discount';
        }
        field(60033; "FTT-CST Parent Category Code"; code[20])
        {
            Caption = 'Parent Category Code';
        }
        field(60035; "Sales Document No."; Code[20])
        {

        }
        field(60036; "FTT-CST Comments Fluent"; text[250])
        {
            Caption = 'Fluent Comments';
        }
        field(60037; "FTT-CST Location Type"; Enum "FTT-CST Location Type")
        {
            Caption = 'Location Type';
        }
        field(60038; "FTT-CST Use for DR"; boolean)
        {
            Caption = 'Use DR';
        }
        field(60039; "FTT-CST Sublocation"; Option)
        {
            DataClassification = ToBeClassified;
            OptionMembers = Blank,LD4,LD42,NY2,NY4,NY6,TY3,SG1,ML1,CP1,None;
            OptionCaption = '. . . . . . .,LD 4,LD 4.2,NY 2,NY 4,NY 6,TY 3,SG 1, None';
            Caption = 'Sublocation';
        }
        field(60040; "FTT-CST Component Option"; Option)
        {
            Caption = 'Location Type';
            DataClassification = CustomerContent;
            OptionMembers = Blank,Hosted,NonHosted,Unknown;
            OptionCaption = '. . . . . . .,Hosted,Non Hosted,Unknown';
        }
        field(60041; "FTT-CST Use for Red"; boolean)
        {
            Caption = 'Use Redundency';
        }
        field(60042; "Currency Code"; Code[10])
        {
            Caption = 'Currency Code';
            TableRelation = Currency;
        }
        field(60043; "Integr."; Option) //NRD
        {
            Caption = 'Integration';
            OptionCaption = 'No,Yes';
            OptionMembers = No,Yes;
        }
        Field(60010; "Line Discount %"; Decimal)
        {
            Caption = 'Line Discount %';
            DataClassification = CustomerContent;
        }

    }
    keys
    {
        key(PK; "Location Code", "Filter No.", "No.", "Sales Document No.")
        {
            Clustered = true;
        }
        key(Key2; Level)
        {

        }
    }

    local procedure GetDataStandardSalesCode()
    var
        StandardSalesCode: Record "Standard Sales Code";
    begin
        StandardSalesCode.Get(Rec.Code);
        Rec.Description := StandardSalesCode.Description;
        //Rec."Currency Code" := StandardSalesCode."Currency Code";
    end;
}