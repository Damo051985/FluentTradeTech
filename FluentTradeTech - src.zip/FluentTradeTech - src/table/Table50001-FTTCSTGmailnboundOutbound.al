
table 50001 "GMAIL Inbound/Outbound"
{
    DataClassification = ToBeClassified;
    DataCaptionFields = Subject;

    fields
    {
        field(1; EntryNo; Integer)
        {
            DataClassification = ToBeClassified;
        }
        field(2; "GMAIL Inbox ID"; text[250])
        {
            DataClassification = ToBeClassified;
        }
        field(3; "Sent From"; text[250])
        {
            DataClassification = ToBeClassified;
        }
        field(4; "Sent To"; text[1024])
        {
            DataClassification = ToBeClassified;
        }
        field(5; "Message Content"; Blob)
        {
            DataClassification = ToBeClassified;
        }
        field(6; "Recipients"; Text[1024])
        {
            DataClassification = ToBeClassified;
        }
        field(7; "Date Received"; Date)
        {
            DataClassification = ToBeClassified;
        }
        field(8; "Subject"; Text[1024])
        {
            DataClassification = ToBeClassified;
        }
        field(9; "Marked As Unread"; Boolean)
        {
            DataClassification = ToBeClassified;
        }
        field(10; "Email ID"; Text[250])
        {
            DataClassification = ToBeClassified;
        }
        field(11; "Created by User"; Code[50])
        {
            DataClassification = ToBeClassified;
        }
        field(12; "Date created"; Date)
        {
            DataClassification = ToBeClassified;
        }
        field(13; "Email Type"; Option)
        {
            OptionMembers = "Inbox","Sent";
            OptionCaption = 'Inbox,Sent';
        }
        field(15; "Thread ID"; Text[250])
        {
            DataClassification = ToBeClassified;
        }
        field(16; "BCC"; Text[1024])
        {
            DataClassification = ToBeClassified;
        }
        field(17; "Estimated Sales Value (LCY)"; Decimal)
        {
            FieldClass = FlowField;
            CalcFormula = sum("FTT-CST Estimated Value Mod"."Line Amount Total" where("Linked No." = field("GMAIL Inbox ID"), "Linked Source Table ID" = const(50001)));
        }
        field(20; "FTT-CST Contact"; Text[250])
        {
            DataClassification = ToBeClassified;
            Caption = 'Contact';
        }

    }

    keys
    {
        key(PK1; EntryNo)
        {
            Clustered = true;

        }

    }

    fieldgroups
    {

    }

    var
        myInt: Integer;

    trigger OnInsert()
    var
        GMAILIntegCdu: Codeunit "Gmail Integration";
    begin
        Clear(GMAILIntegCdu);
        GMAILIntegCdu.GetdetailMessage(rec."GMAIL Inbox ID");
    end;

    trigger OnDelete()
    var
        EmailReation: Record "GMAIL Email Relation";
        receGMailEmailAttachment: Record "GMAIL Attachment";
        recGMAILDeletedLogs: Record "GMAIL Deleted Logs";
    begin

        recGMAILDeletedLogs.Reset();
        recGMAILDeletedLogs.Init();
        recGMAILDeletedLogs."GMAIL Inbox ID" := rec."GMAIL Inbox ID";
        recGMAILDeletedLogs.Insert();

        EmailReation.Reset();
        EmailReation.SetFilter("GMAIL Inbox ID", '%1', rec."GMAIL Inbox ID");
        if EmailReation.FindSet() then
            EmailReation.DeleteAll();

        receGMailEmailAttachment.Reset();
        receGMailEmailAttachment.SetFilter("GMAIL Inbox ID", rec."GMAIL Inbox ID");
        if receGMailEmailAttachment.FindSet() then
            receGMailEmailAttachment.DeleteAll();
    end;

    trigger OnRename()
    begin

    end;

}