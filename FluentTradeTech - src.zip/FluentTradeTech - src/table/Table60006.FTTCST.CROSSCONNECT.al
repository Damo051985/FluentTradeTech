table 60006 "FTT-CST Cross Connect"
{
    DataClassification = ToBeClassified;

    fields
    {
        field(1; "Filter No."; Integer)
        {
            DataClassification = ToBeClassified;

        }
        field(2; "Item No."; Code[20])
        {
            DataClassification = ToBeClassified;
            Caption = 'Item No.';
            TableRelation = Item;

        }
        field(3; Description; Text[250])
        {
            Caption = 'Description';

        }
        field(4; "Quantity 1"; Integer)
        {
            Caption = 'SHARED MRC';
            trigger OnValidate()
            begin
                //if "Quantity 1" <> 0 then //NRD - Temp Disabled
                Validate("Quantity 3", "Quantity 1");
            end;
        }
        field(5; "Quantity 2"; Integer)
        {
            Caption = 'DEDICATED MRC';
            trigger OnValidate()
            begin
                // if "Quantity 4" <> 0 then //NRD - Temp Disabled
                Validate("Quantity 4", "Quantity 2");
            end;
        }
        field(6; "Quantity 3"; Integer)
        {
            Caption = 'SHARED NRC';
        }
        field(7; "Quantity 4"; Integer)
        {
            Caption = 'DEDICATED NRC';
        }
        field(8; "Item Category Code"; Code[20]) //NRD
        {
            DataClassification = ToBeClassified;
        }



    }

    keys
    {
        key(Key1; "Filter No.", "Item No.")
        {
            Clustered = true;
        }
    }

    fieldgroups
    {
        // Add changes to field groups here
    }

    var
        myInt: Integer;

    trigger OnInsert()
    begin

    end;

    trigger OnModify()
    begin

    end;

    trigger OnDelete()
    begin

    end;

    trigger OnRename()
    begin

    end;

}