table 50010 "FTT-CST Cross ConnectLnsTemp"
{
    DataClassification = ToBeClassified;

    fields
    {
        field(1; "Document Type"; enum "Sales Document Type")
        {
            DataClassification = ToBeClassified;

        }
        field(2; "Document No."; code[50])
        {
            DataClassification = ToBeClassified;
        }
        field(3; "Item No."; Code[20])
        {
            DataClassification = ToBeClassified;
            Caption = 'Item No.';
            TableRelation = Item;

        }
        field(4; Description; Text[250])
        {
            DataClassification = ToBeClassified;
            Caption = 'Description';

        }
        field(5; "Quantity 1"; Integer)
        {
            DataClassification = ToBeClassified;
            Caption = 'SHARED MRC';
        }
        field(6; "Quantity 2"; Integer)
        {
            Caption = 'DEDICATED MRC';
            DataClassification = ToBeClassified;
        }
        field(7; "Quantity 3"; Integer)
        {
            Caption = 'SHARED NRC';
            DataClassification = ToBeClassified;
        }
        field(8; "Quantity 4"; Integer)
        {
            DataClassification = ToBeClassified;
            Caption = 'DEDICATED NRC';
        }
        field(9; "FTT-CST Location Code"; code[20])
        {
            Caption = 'Location Code';
        }
        field(10; "Item Category Code"; Code[20])
        {
            DataClassification = ToBeClassified;
        }
        field(11; calculated; Boolean) //NRD - 05112024
        {
            DataClassification = ToBeClassified;
        }

    }

    keys
    {
        key(Key1; "Document Type", "Document No.", "Item No.", "FTT-CST Location Code")
        {
            Clustered = true;
        }
    }

    fieldgroups
    {
        // Add changes to field groups here
    }

    var
        myInt: Integer;

    trigger OnInsert()
    begin

    end;

    trigger OnDelete()
    begin
    end;

    trigger OnRename()
    begin

    end;

}