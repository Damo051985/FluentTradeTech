page 60005 "FTT-CST Commision Filter"
{
    // ApplicationArea = All;
    // Caption = 'Commission Entries';
    // DeleteAllowed = false;
    // InsertAllowed = false;
    // PageType = ListPlus;
    // RefreshOnActivate = true;
    // UsageCategory = Lists;

    layout
    {
        area(Content)
        {
            group(General)
            {
                ShowCaption = false;
                field("FTT-CST Salesp. Benef. Filter"; "FTT-CST Salesp. Benef. Filter")
                {
                    ApplicationArea = All;
                    Caption = 'Salesperson Beneficiary Filter';
                    TableRelation = "Salesperson/Purchaser".Code;
                    ToolTip = 'Specifies the salesperson beneficiary code that will be used to filter the amounts in the window.';

                    trigger OnValidate()
                    var
                        UserSetup: record "User Setup"; //NRD.-
                        ERROR001_l: Label 'Not allowed to generate other salesperson commission. \ This field should be your salesperson code %1 not %2! ';
                    begin
                        //NRD+ User can be able to see the commission where they are the salesperson.
                        if UserSetup.Get(UserId) then
                            if UserSetup."Salespers./Purch. Code" <> '' then
                                if UserSetup."Salespers./Purch. Code" <> "FTT-CST Salesp. Benef. Filter" then
                                    Error(ERROR001_l, UserSetup."Salespers./Purch. Code", "FTT-CST Salesp. Benef. Filter");
                        //NRD-

                        "FTT-CST Total Amount (LCY)" := CurrPage.CommissionEntries.Page.SetFilters("FTT-CST Salesp. Benef. Filter", "FTT-CST Date Filter");
                        CurrPage.Update();
                    end;
                }
                field("FTT-CST Date Filter"; "FTT-CST Date Filter")
                {
                    ApplicationArea = All;
                    Caption = 'Date Filter';
                    ToolTip = 'Specifies the dates that will be used to filter the amounts in the window.';

                    trigger OnValidate()
                    begin
                        "FTT-CST Total Amount (LCY)" := CurrPage.CommissionEntries.Page.SetFilters("FTT-CST Salesp. Benef. Filter", "FTT-CST Date Filter");
                        CurrPage.Update();
                    end;
                }
            }
            part(CommissionEntries; "FTT-CST Commission Entries")
            {
                ApplicationArea = All;
            }
            group(Control24)
            {
                ShowCaption = false;
                group("Total Amount")
                {
                    Caption = 'Total Amount';
                    field("FTT-CST Total Amount (LCY)"; "FTT-CST Total Amount (LCY)")
                    {
                        ApplicationArea = All;
                        Caption = 'Total Amount (LCY)';
                        Editable = false;
                        ToolTip = 'Specifies the total for filtered entries.';
                    }
                }
            }
        }
    }

    trigger OnOpenPage()
    begin
        if SalespersonPurchaserCodeGlobal <> '' then
            "FTT-CST Salesp. Benef. Filter" := SalespersonPurchaserCodeGlobal;

        "FTT-CST Date Filter" := Format(CalcDate('-CM', WorkDate())) + '..' + Format(CalcDate('CM', WorkDate()));
        "FTT-CST Total Amount (LCY)" := CurrPage.CommissionEntries.Page.SetFilters("FTT-CST Salesp. Benef. Filter", "FTT-CST Date Filter");
    end;

    internal procedure SetFilters(SalespersonPurchaserCode: Code[20])
    begin
        SalespersonPurchaserCodeGlobal := SalespersonPurchaserCode;
    end;

    var
        "FTT-CST Salesp. Benef. Filter": Code[20];
        SalespersonPurchaserCodeGlobal: Code[20];
        "FTT-CST Total Amount (LCY)": Decimal;
        "FTT-CST Date Filter": Text;
}
