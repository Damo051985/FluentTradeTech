page 60015 "FTT-CST Item List"
{
    PageType = Worksheet;
    ApplicationArea = All;
    SourceTable = "FTT-CST Special Select";
    Caption = 'Items';

    layout
    {
        area(Content)
        {
            repeater(GroupName)
            {
                field(Name; Rec."Item No.")
                {
                    ApplicationArea = All;
                    Width = 4;
                }
                field("Integr."; Rec."Integr.") //NRD
                {
                    ApplicationArea = all;
                    Caption = 'Integration';
                    Width = 6;
                    Visible = IntegVisible;
                }
                field(Redundancy; Rec.Redundancy)
                {
                    Caption = 'Redundancy';
                    Width = 6;
                    Visible = RedVisible;
                }
                field(DR; Rec.DR)
                {
                    Caption = 'DR';
                    Width = 6;
                    Visible = DRVisible;
                }
                field("FTT-CST Sublocation"; Rec."FTT-CST Sublocation")
                {
                    ApplicationArea = all;
                    Visible = SublocationVisible;
                }
                field(Description; Rec.Description)
                {
                    ApplicationArea = All;
                    Width = 20;

                }
                field("FTT-CST Quanity"; Rec."Quantity")
                {
                    Width = 6;
                }
                field("Unit Price"; Rec."Unit Price")
                {
                    Visible = PriceVisible;
                    trigger OnValidate()
                    begin
                        if rec.Integration then
                            if Rec."Recalculation %" > 0 then error('You can not change Price for Integration Item - %1', rec.Description);
                    end;

                }
                field("Recalculation %"; Rec."Recalculation %")
                {
                    Visible = PercentVisible;
                    trigger OnValidate()
                    begin
                        if rec.Integration then
                            if Rec."Unit Price" > 0 then error('You can not change Recalculation % for Integration Item - %1', rec.Description);
                    end;
                }

                field(Optional; Rec.Optional)
                {
                    ApplicationArea = all;
                    Width = 6;
                }
                field("Fluent Comments"; Rec."Comments Fluent")
                {
                    ApplicationArea = all;
                    Caption = 'Fluent Comments';
                }
                field(Comments; Rec.Comments)
                {
                    ApplicationArea = all;
                    Caption = 'Internal Comments';
                }
                field("Item Group Code"; ShowItemGroupCode(Rec."Item No."))
                {
                    Editable = false;
                    Visible = ItemGrouVisible;

                }
            }
        }
    }

    actions
    {
        area(Processing)
        {
            action(ActionName)
            {
                ApplicationArea = All;

                trigger OnAction();
                begin

                end;
            }
        }
    }
    //NRD
    local procedure ShowItemGroupCode(pitemCode: code[20]): Code[20]
    var
        defaultdim: Record "Default Dimension";
    begin
        if not defaultdim.Get(27, pitemCode, 'ITEM GROUP') then
            exit('');

        exit(defaultdim."Dimension Value Code");
    end;

    procedure MakeitemGroupVisible(pItemGroupVisible: Boolean) //NRD
    begin
        ItemGrouVisible := pItemGroupVisible;
    end;
    //+
    procedure GetSelectionFilter(): Text
    var
        Item: Record "FTT-CST Special Select";
        SelectionFilterManagement: Codeunit SelectionFilterManagement;
    begin
        CurrPage.SetSelectionFilter(Item);
        exit(GetSelectionFilterForItem(Item));
    end;

    procedure GetSelectionFilterForItem(var Item: Record "FTT-CST Special Select"): Text
    var
        RecRef: RecordRef;
    begin
        RecRef.GetTable(Item);
        exit(GetSelectionFilter(RecRef, Item.FieldNo("Item No.")));
    end;

    procedure GetSelectionFilter(var TempRecRef: RecordRef; SelectionFieldID: Integer): Text
    var
        RecRef: RecordRef;
        FieldRef: FieldRef;
        FirstRecRef: Text;
        LastRecRef: Text;
        SelectionFilter: Text;
        SavePos: Text;
        TempRecRefCount: Integer;
        More: Boolean;
    begin
        if TempRecRef.IsTemporary then begin
            RecRef := TempRecRef.Duplicate();
            RecRef.Reset();
        end else
            RecRef.Open(TempRecRef.Number, false, TempRecRef.CurrentCompany);

        TempRecRefCount := TempRecRef.Count();
        if TempRecRefCount > 0 then begin
            TempRecRef.Ascending(true);
            TempRecRef.Find('-');
            while TempRecRefCount > 0 do begin
                TempRecRefCount := TempRecRefCount - 1;
                RecRef.SetPosition(TempRecRef.GetPosition());
                RecRef.Find();
                FieldRef := RecRef.Field(SelectionFieldID);
                FirstRecRef := Format(FieldRef.Value);
                LastRecRef := FirstRecRef;
                More := TempRecRefCount > 0;
                while More do
                    if RecRef.Next() = 0 then
                        More := false
                    else begin
                        SavePos := TempRecRef.GetPosition();
                        TempRecRef.SetPosition(RecRef.GetPosition());
                        if not TempRecRef.Find() then begin
                            More := false;
                            TempRecRef.SetPosition(SavePos);
                        end else begin
                            FieldRef := RecRef.Field(SelectionFieldID);
                            LastRecRef := Format(FieldRef.Value);
                            TempRecRefCount := TempRecRefCount - 1;
                            if TempRecRefCount = 0 then
                                More := false;
                        end;
                    end;
                if SelectionFilter <> '' then
                    SelectionFilter := SelectionFilter + '|';
                if FirstRecRef = LastRecRef then
                    SelectionFilter := SelectionFilter + AddQuotes(FirstRecRef)
                else
                    SelectionFilter := SelectionFilter + AddQuotes(FirstRecRef) + '..' + AddQuotes(LastRecRef);
                if TempRecRefCount > 0 then
                    TempRecRef.Next();
            end;
            exit(SelectionFilter);
        end;
    end;

    procedure AddQuotes(inString: Text): Text
    begin
        inString := ReplaceString(inString, '''', '''''');
        if DelChr(inString, '=', ' &|()*@<>=.!?') = inString then
            exit(inString);
        exit('''' + inString + '''');
    end;

    procedure ReplaceString(String: Text; FindWhat: Text; ReplaceWith: Text) NewString: Text
    begin
        while STRPOS(String, FindWhat) > 0 do begin
            NewString := NewString + DELSTR(String, STRPOS(String, FindWhat)) + ReplaceWith;
            String := COPYSTR(String, STRPOS(String, FindWhat) + STRLEN(FindWhat));
        end;
        NewString := NewString + String;
    end;

    trigger OnAfterGetRecord()
    begin
        //Rec."Quantity" := 0;
    end;

    procedure MakePriceVisible(pPriceVisible: Boolean)
    begin
        PriceVisible := pPriceVisible;
    end;

    procedure MakeRedDRVisible(pVisible: Boolean)
    begin
        DRVisible := pVisible;
        RedVisible := pVisible;
        SublocationVisible := not pVisible;
    end;

    procedure MakePercentageVisible(pVisible: Boolean)
    begin
        PercentVisible := pVisible;
    end;

    procedure MakeIntegVisible(pVisible: Boolean) //NRD
    begin
        IntegVisible := pVisible;
    end;

    procedure MakeSublocationVisible(pVisible: Boolean)
    begin
        SublocationVisible := pVisible;
    end;

    var
        PriceVisible: Boolean;
        DRVisible: Boolean;
        RedVisible: Boolean;
        PercentVisible: Boolean;
        SublocationVisible: Boolean;
        IntegVisible: Boolean; //NRD
        ItemGrouVisible: Boolean;

}