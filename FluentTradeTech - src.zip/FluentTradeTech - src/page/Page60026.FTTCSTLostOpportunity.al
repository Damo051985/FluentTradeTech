page 60026 LostOpportunity
{
    Caption = 'Lost Opportunity';
    PageType = Worksheet;
    SourceTable = LostOpportunityTable;
    ApplicationArea = Basic, Suite, Planning;
    Editable = true;
    RefreshOnActivate = true;
    UsageCategory = Tasks;
    DelayedInsert = true;
    SourceTableView = where("Line Type" = filter(line));
    LinksAllowed = false;
    SaveValues = true;

    layout
    {
        area(Content)
        {
            repeater(control1)
            {
                field(Prospect; Rec.Prospect)
                {
                    ToolTip = 'Specifies the value of the Prospect field.', Comment = '%';
                }
                field(Name; Rec.Name)
                {
                    ToolTip = 'Specifies the value of the Name field.', Comment = '%';
                }
                field(Description; Rec.Description)
                {
                    ToolTip = 'Specifies the value of the Description field.', Comment = '%';
                }
                field("Lost to"; Rec."Lost to")
                {
                    ToolTip = 'Specifies the value of the Lost to field.', Comment = '%';
                }
                field(Salesperson; Rec.Salesperson)
                {
                    ToolTip = 'Specifies the value of the Salesperson field.', Comment = '%';
                }
                field("Salesperson Name"; Rec."Salesperson Name")
                {
                    ToolTip = 'Specifies the value of the Salesperson Name field.', Comment = '%';
                }
                field("Current Sales Cycle Stage"; Rec."Current Sales Cycle Stage")
                {
                    ToolTip = 'Specifies the value of the Current Sales Cycle Stage field.', Comment = '%';
                }
                field("Closing Date"; Rec."Closing Date")
                {
                    ToolTip = 'Specifies the value of the Closing Date field.', Comment = '%';
                }
                field("Total Revenue"; Rec."Total Revenue")
                {
                    ToolTip = 'Specifies the value of the Total Revenue field.', Comment = '%';
                }
            }
        }
    }
    actions
    {
        area(navigation)
        {
            group(Process)
            {
                action("Run Report")
                {
                    Caption = 'Lost Opportunity Report';
                    ApplicationArea = all;
                    Visible = False;

                    trigger OnAction()
                    var
                        OppLost: Report "Opportunity Lost Report";
                    begin
                        OppLost.RUN;
                    end;
                }

                action("UpdateLost")
                {
                    Caption = 'Update Lost Opportunity Report';
                    ApplicationArea = all;
                    Visible = False;
                    trigger OnAction()
                    var
                        lLostOpp: Codeunit LostOpportunity;
                    begin
                        Clear(lLostOpp);
                        lLostOpp.LostTotalRevenue();
                        Message('Done Updating');
                    end;
                }
            }
        }
    }
    trigger OnInsertRecord(BelowxRec: Boolean): Boolean
    var
    Begin
        Rec."Line Type" := Rec."Line Type"::Line;
    End;
}
