page 60047 "Commision New Sales"
{
    ApplicationArea = All;
    Caption = 'Commission New Sales ';
    PageType = Card;
    UsageCategory = Lists;
    SourceTable = "Commision New Sales";
    Editable = False;
    RefreshOnActivate = true;
    Permissions = TableData "Sales Invoice Header" = rm;

    layout
    {
        area(Content)
        {
            group(General)
            {
                Caption = 'General';

                field("Invoice No."; Rec."Invoice No.")
                {
                    ToolTip = 'Specifies the value of the Invoice No. field.';
                    Visible = False;
                }
            }
            part("CommNewSalSub"; "Comm. New Sales Subform")
            {
                ApplicationArea = Basic, Suite;
            }
            part("CommNewSalGrand"; "Comm. New Sales Grand Total")
            {
                ApplicationArea = Basic, Suite;
            }
        }
    }
    actions
    {
        area(processing)
        {
            action(UpdateCommNewSales)
            {
                ApplicationArea = All;
                Caption = 'Update Commission New Sales';
                Visible = True;
                trigger OnAction()
                var
                    lCommRep: Codeunit "Commission Reports";
                begin
                    lCommRep.InsertCustomerPerAgreementPeriod();
                end;
            }
            action(DeleteLines)
            {
                ApplicationArea = All;
                Caption = 'Delete Lines';
                Visible = False;
                trigger OnAction()
                var
                    lCommNewSales: Record "Commision New Sales";
                    lSIH: Record "Sales Invoice Header";
                begin
                    IF lCommNewSales.FINDSET then
                        lCommNewSales.DELETEALL;

                    IF lSIH.FINDSET then
                        lSIH.ModifyAll("Inserted in Report 3", FALSE);
                end;
            }
        }
    }
    Trigger OnOpenPage()
    var
        lCommRep: Codeunit "Commission Reports";
    Begin
        lCommRep.InsertCustomerPerAgreementPeriod();
    End;

    var
        gVis: Boolean;
        UserSet: Record "User Setup";
}
