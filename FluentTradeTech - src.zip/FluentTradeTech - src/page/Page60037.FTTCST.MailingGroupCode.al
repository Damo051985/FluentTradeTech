page 60037 "Mailing Group Code"
{
    ApplicationArea = All;
    Caption = 'Mailing Group List';
    PageType = List;
    SourceTable = "Email Mailing Group Code";
    UsageCategory = Lists;
    CardPageId = "Mailing Group Card";

    layout
    {
        area(Content)
        {
            repeater(General)
            {
                field("Mailing Group Code"; Rec."Mailing Group Code")
                {
                    ToolTip = 'Specifies the value of the Mailing Group Code field.';
                }
                field(Description; Rec.Description)
                {
                    ToolTip = 'Specifies the value of the Description field.';
                }
            }
        }
    }
}
