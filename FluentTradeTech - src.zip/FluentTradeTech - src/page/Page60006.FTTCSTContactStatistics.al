page 60006 "FTT-CST Contact Statistics"
{
    ApplicationArea = All;
    Caption = 'Recurring Item Sales Lines';
    PageType = CardPart;
    SourceTable = Contact;
    UsageCategory = None;

    layout
    {
        area(Content)
        {

            //field("FTT-CST No. of Opportunities"; Rec."FTT-CST No. of Opportunities")
            //{
            //    ToolTip = 'Open Opportunities';
            //                Caption = 'Opportunities';
            field("No. of Opportunities"; Rec."No. of Opportunities")
            {
                ApplicationArea = RelationshipMgmt;
                ToolTip = 'Specifies the number of open opportunities involving the contact. The field is not editable.';
            }
            field("Estimated Value (LCY)"; Rec."Estimated Value (LCY)")
            {
                ApplicationArea = RelationshipMgmt;
                ToolTip = 'Specifies the total estimated value of all the opportunities involving the contact. The field is not editable.';
                Visible = false;
            }
            field("Calcd. Current Value (LCY)"; Rec."Calcd. Current Value (LCY)")
            {
                ApplicationArea = RelationshipMgmt;
                ToolTip = 'Specifies the total calculated current value of all the opportunities involving the contact. The field is not editable.';
                Visible = false;
            }
        }
    }
}


