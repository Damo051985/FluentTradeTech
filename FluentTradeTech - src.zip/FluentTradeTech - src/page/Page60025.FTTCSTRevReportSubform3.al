page 60025 FTTCSTRevReportSubform3
{
    ApplicationArea = All;
    Caption = 'Grand Total';
    PageType = CardPart;
    SourceTable = "Revenue Report";
    SourceTableView = where("Line Type" = filter("Grand Total"));
    DeleteAllowed = False;
    InsertAllowed = False;
    ModifyAllowed = False;
    Editable = FALSE;
    layout
    {
        area(Content)
        {
            repeater(General)
            {
                field("Type"; Rec."Type")
                {
                    ToolTip = 'Specifies the value of the Type field.';
                    StyleExpr = gStyle;
                }
                field("Salesperson Code"; Rec."Salesperson Code")
                {
                    ToolTip = 'Specifies the value of the Salesperson Code field.';
                    StyleExpr = gStyle;
                }
                field("Customer/Prospect"; Rec."Customer/Prospect")
                {
                    ToolTip = 'Specifies the value of the Customer/Prospect field.';
                    StyleExpr = gStyle;
                }
                field("GT ARR Previous Contracts"; Rec."GT ARR Previous Contracts")
                {
                    ToolTip = 'Specifies the value of the Grand Total ARR Previous Contracts field.';
                    StyleExpr = gStyle;
                }
                field("GT ARR Add. Contracts"; Rec."GT ARR Add. Contracts")
                {
                    ToolTip = 'Specifies the value of the Grand Total ARR Additional Products field.';
                    StyleExpr = gStyle;
                }
                field("GT ARR Contract Progress"; Rec."GT ARR Contract Progress")
                {
                    ToolTip = 'Specifies the value of the Grand Total ARR Contracts Progress field.';
                    StyleExpr = gStyle;
                }
                field("GT NRC Contract Progress"; Rec."GT NRC Contract Progress")
                {
                    ToolTip = 'Specifies the value of the Grand Total NRC Contract Progress field.';
                    StyleExpr = gStyle;
                }
                field("GT Total Contract Progress"; Rec."GT ARR Total Revenue")
                {
                    ToolTip = 'Specifies the value of the Grand Total ARR Total Revenue field.';
                    StyleExpr = gStyle;
                }
                field("GT NRC Total Revenue"; Rec."GT NRC Total Revenue")
                {
                    ToolTip = 'Specifies the value of the Grand Total NRC Total Revenue field.';
                    StyleExpr = gStyle;
                }
                field("GT Connectivity"; Rec."GT Connectivity")
                {
                    ToolTip = 'Specifies the value of the Grand Total Connectivity field.';
                    StyleExpr = gStyle;
                }
                field("GT Distribution"; Rec."GT Distribution")
                {
                    ToolTip = 'Specifies the value of the Grand Total Distribution field.';
                    StyleExpr = gStyle;
                }
                field("GT RiskNOther"; Rec."GT RiskNOthers")
                {
                    ToolTip = 'Specifies the value of the Grand Total Risk and Others field.';
                    StyleExpr = gStyle;
                }
                field("GT Other YRC"; Rec."GT Other YRC")
                {
                    ToolTip = 'Specifies the value of the Grand Total Other YRC field.';
                    StyleExpr = gStyle;
                }
            }
        }
    }
    trigger OnAfterGetRecord()
    var
    Begin
        gStyle := 'StrongAccent'
    End;

    trigger OnOpenPage()
    var
        lRev: Record "Revenue Report";
        CustSubs: Codeunit FTTCSTCustomSubcriber;
    Begin
        Clear(CustSubs);
        CustSubs.GetTotals();
        lRev.INIT;
        lRev."Line Type" := lRev."Line Type"::"Grand Total";
        lRev."Customer/Prospect" := '';
        IF lRev.Insert THEN;
    End;

    var
        gStyle: Text[30];
}
