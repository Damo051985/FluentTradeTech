page 50042 "Commission SV Subform"
{
    PageType = ListPart;
    SourceTable = "Commission SV. Worksheet Lines";
    AutoSplitKey = true;
    Caption = 'Lines';
    RefreshOnActivate = true;
    InsertAllowed = false;
    layout
    {
        area(Content)
        {
            repeater(GroupName)
            {
                field("Document Type"; Rec."Document Type")
                {
                    ApplicationArea = all;
                    Editable = false;
                }
                field("Inv, Document No."; Rec."Inv, Document No.")
                {
                    ApplicationArea = all;
                    Editable = false;
                    Caption = 'Document No.';
                }
                field("Document Date"; Rec."Document Date")
                {
                    ApplicationArea = all;
                    Editable = false;
                }
                field("Sell-to Customer Name"; Rec."Sell-to Customer Name")
                {
                    ApplicationArea = all;
                    Editable = false;
                }
                field("Currency Code"; Rec."Currency Code")
                {
                    ApplicationArea = all;
                    Editable = false;
                }
                field("Supervisor Reward %"; Rec."Supervisor Reward %")
                {
                    ApplicationArea = all;
                    Editable = false;
                    Visible = false;
                }
                field("Commission Amount (LCY)"; Rec."Commission Amount (LCY)")
                {
                    ApplicationArea = all;
                    Editable = false;
                }
                field("Commission Amount"; Rec."Commission Amount")
                {
                    ApplicationArea = all;
                    Editable = false;
                }
                field("Supervisor Reward Amount (LCY)"; Rec."Supervisor Reward Amount (LCY)")
                {
                    ApplicationArea = all;
                    Editable = false;
                }
                field("Supervisor Reward Amount"; Rec."Supervisor Reward Amount")
                {
                    ApplicationArea = all;
                }
                field("Rem. Super. Reward Amt"; Rec."Rem. Super. Reward Amt")
                {
                    ApplicationArea = all;
                }
                field("Application Amount"; Rec."Application Amount")
                {
                    ApplicationArea = all;
                    Style = Unfavorable;
                    trigger OnValidate()
                    var
                        RecCommWshHeader: Record "Commission Worksheet Header";
                    begin
                        if rec."Application Amount" > rec."Rem. Super. Reward Amt" then
                            Error('Application Amount should not be greater than to Remaining Supervisor Reward Amount');

                        RecCommWshHeader.Reset();
                        RecCommWshHeader.SetRange("Document No.", rec."Document No.");
                        RecCommWshHeader.CalcFields("Total Application Amount");
                        CurrPage.Update(false);
                    end;
                }

            }
        }
    }
}


