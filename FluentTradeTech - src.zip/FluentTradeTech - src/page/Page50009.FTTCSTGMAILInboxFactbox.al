page 50009 "GMAIL Inbox factbox"
{

    PageType = ListPart;
    SourceTable = "GMAIL Email Relation";
    SourceTableView = WHERE("Email Type" = filter('Inbox'));
    DeleteAllowed = false;
    InsertAllowed = false;
    ModifyAllowed = false;
    layout
    {
        area(Content)
        {
            repeater(Group)
            {
                field(Subject; Rec.Subject)
                {
                    ApplicationArea = All;
                    trigger OnDrillDown()
                    var
                        recGmailInboundOutbound: Record "GMAIL Inbound/Outbound";
                        recSentEmail: Record "Sent Email";
                    begin
                        if rec."Email Type" = rec."Email Type"::Inbox then begin
                            if not recGmailInboundOutbound.Get(rec."Inbox Entry No.") then
                                exit;
                            OpenReceived(recGmailInboundOutbound);
                        end;
                    end;
                }
                field("Date Received"; Rec."Date Received")
                {
                    ApplicationArea = all;
                }
                field("Sent From"; Rec."Sent From")
                {
                    ApplicationArea = all;
                }
                field("Sent To"; Rec."Sent To")
                {
                    ApplicationArea = all;
                }


            }
        }

    }

    procedure OpenReceived(ReceivedEmail: Record "Gmail Inbound/Outbound")
    var
        EmailViewer: Page "Email Inbox Viewer";
    begin
        EmailViewer.SetRecord(ReceivedEmail);
        EmailViewer.Run();
    end;

    trigger OnOpenPage()
    begin
        Rec.SetCurrentKey("Thread ID");
        Rec.Ascending(false);

    end;

}