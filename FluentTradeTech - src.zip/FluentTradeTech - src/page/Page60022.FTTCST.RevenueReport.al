page 60022 "Revenue Report"
{
    //ApplicationArea = Basic, Suite, Assembly;
    ApplicationArea = All;
    Caption = 'Revenue in contract sizes report';
    PageType = Card;
    SourceTable = "Revenue Report";
    UsageCategory = Lists;
    Editable = true;
    RefreshOnActivate = true;
    SourceTableView = where("Line Type" = filter(Header));

    layout
    {
        area(Content)
        {
            group(General)
            {
                Caption = 'General';

                field("Type"; Rec."Type")
                {
                    ToolTip = 'Specifies the value of the Type field.', Comment = '%';
                    Visible = False;
                }
                field("Salesperson Code"; Rec."Salesperson Code")
                {
                    ToolTip = 'Specifies the value of the Salesperson Code field.', Comment = '%';
                    Visible = false;
                }
                field("Customer/Prospect"; Rec."Customer/Prospect")
                {
                    ToolTip = 'Specifies the value of the Customer/Prospect field.', Comment = '%';
                    Visible = false;
                }
            }
            part("Over 85%"; "Revenue Report Subform2")
            {
                ApplicationArea = Basic, Suite;
            }
            part("Total 85%"; "Total85Percent")
            {
                ApplicationArea = Basic, Suite;
            }
            part("Over 50%"; "Revenue Report Subform")
            {
                ApplicationArea = Basic, Suite;
            }
            part("Total 50%"; "Total50Percent")
            {
                ApplicationArea = Basic, Suite;
            }
            part("Grand Total"; FTTCSTRevReportSubform3)
            {
                ApplicationArea = Basic, Suite;
            }

        }
    }
    actions
    {
        area(navigation)
        {
            group(Process)
            {
                action("Utility")
                {
                    Caption = 'Update Item Unit of measure.';
                    ApplicationArea = all;
                    Visible = gVis;
                    trigger OnAction()
                    var
                        lRev, lRev2 : Record "Revenue Report";
                        lItem: Record Item;
                    begin
                        Clear(lItem);
                        lItem.Setfilter("Base Unit of Measure", '<>%1', 'PCS');
                        IF lItem.FINDSET then begin
                            lItem.MODIFYALL("Base Unit of Measure", 'PCS');
                            lItem.MODIFYALL("Sales Unit of Measure", 'PCS');
                            Message('Done updating PCS in Unit of measure.');
                        End;
                    end;
                }
                action("Run Report")
                {
                    Caption = 'Run Report';
                    ApplicationArea = all;
                    Visible = gVis;
                    trigger OnAction()
                    var
                        OppLost: Report "Opportunity Lost Report";
                        sndYrDisc: decimal;
                        CurrExcrate2: Record "Currency Exchange Rate";
                        lCurr: Record Currency;
                    begin
                        /*
                        IF lCurr.FINDSET THEN BEGIN
                            Repeat
                                Clear(CurrExcrate2);
                                CurrExcrate2.SetRange("Currency Code", lCurr.Code);
                                IF CurrExcrate2.FINDLAST THEN begin
                                    CurrExcrate2."Relational Adjmt Exch Rate Amt" := 1;
                                    CurrExcrate2."Relational Exch. Rate Amount" := 1;
                                    CurrExcrate2."FTTCST Updated to Rate" := False;
                                    CurrExcrate2.Modify;
                                end;
                            Until lCurr.Next = 0;
                            Message('Done');
                        END;
                        */
                    end;
                }

                action("UpdateRev")
                {
                    Caption = 'Update Revenue';
                    ApplicationArea = all;
                    Visible = True;
                    trigger OnAction()
                    var
                        CustSubs: Codeunit FTTCSTCustomSubcriber;
                    begin
                        Clear(CustSubs);
                        CustSubs.GETSOPrimaryHosted85percentPrimRen;
                        CustSubs.GETSOPrimaryHosted50percentPrimRen;
                        CustSubs.GETSOPrimaryHosted85percentPrimRen2;
                        CustSubs.GetTotals();
                        Message('Done Updating.');
                    end;
                }
            }
        }
    }
    trigger OnOpenPage()
    var
    Begin
        gVis := False;
        IF UserId = 'DO' then
            gVis := TRUE;
    End;

    var
        RevRep: Record "Revenue Report";
        gVis: Boolean;
}
