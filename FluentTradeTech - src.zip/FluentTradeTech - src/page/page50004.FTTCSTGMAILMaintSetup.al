page 50004 "GMAIL Maintenance Setup"
{
    PageType = Card;
    ApplicationArea = All;
    UsageCategory = Administration;
    SourceTable = 50002;
    RefreshOnActivate = true;
    Caption = 'GMAIL Integration Setup';

    layout
    {

        area(Content)
        {
            group(General)
            {
                field("Add to BCC as Default"; Rec."Add to BCC as Default")
                {
                    ApplicationArea = all;
                    Caption = 'Add to CC as Default';

                }
                field("CRM Email"; Rec."CRM Email")
                {
                    ApplicationArea = all;
                    ShowMandatory = true;
                }
                group(SalesQuote)
                {
                    Caption = 'SALES QUOTE Template';

                    field("CRM Template SHID"; Rec."CRM Template SHID")
                    {
                        ApplicationArea = all;
                        Caption = 'SQ Template SHID';
                        ExtendedDatatype = Masked;
                    }
                }
                group(SalesOrder)
                {
                    Caption = 'SALES ORDER Template';

                    field("CRM SO Template SHID"; Rec."CRM SO Template SHID")
                    {
                        ApplicationArea = all;
                        Caption = 'SO Template SHID';
                        ExtendedDatatype = Masked;
                    }
                }

            }

            group("Oauth 2.0 Configuration")
            {
                field("Authorization URL"; rec."Authorization URL")
                {
                    ApplicationArea = all;
                    ShowMandatory = true;
                }
                field("Token URL"; rec."Token URL")
                {
                    ApplicationArea = all;
                    ShowMandatory = true;
                }
                field("CallBack URL"; rec."CallBack URL")
                {
                    ApplicationArea = all;
                    ShowMandatory = true;
                }
                field("Client ID"; rec."Client ID")
                {
                    ApplicationArea = all;
                    ShowMandatory = true;
                }
                field("Client Secret ID"; rec."Client Secret ID")
                {
                    ApplicationArea = all;
                    ShowMandatory = true;
                }

                field(Scopes; rec.Scopes)
                {
                    ApplicationArea = all;
                    ShowMandatory = true;
                }
            }
            group("Token Details")
            {
                field("Authorization Code"; Rec."Authorization Code")
                {
                    ApplicationArea = all;
                    Enabled = false;
                }
                field("API Token Key"; Rec."API Token Key")
                {
                    ApplicationArea = all;
                    Enabled = false;
                }
                field("Token Expiration Date/Time"; rec."Token Expiration DateTime")
                {
                    ApplicationArea = all;
                    Enabled = false;
                    Caption = 'Token Expiration Date/Time';
                }
                field("Refresh Token"; Rec."Refresh Token")
                {
                    ApplicationArea = all;
                    Enabled = false;
                }


            }
        }

    }


    actions
    {
        area(Processing)
        {
            action("Generate Oauth2.0 Token")
            {
                ApplicationArea = All;
                Caption = 'Generate Oauth2.0 Token';
                Promoted = true;
                PromotedCategory = Process;
                PromotedIsBig = true;
                image = LaunchWeb;
                trigger OnAction()
                begin
                    rec.TestField("Authorization URL");
                    rec.TestField("Token URL");
                    rec.TestField("Client ID");
                    rec.TestField("Client Secret ID");
                    rec.TestField("CallBack URL");
                    rec.TestField(Scopes);


                    if rec."Refresh Token" <> '' then
                        Error('Refresh token has been configured already! \ Token should be automatically updated every an hour.');

                    if (CurrentDateTime > rec."Token Expiration DateTime") then
                        page.Run(50000);

                end;
            }
            action(DeletedLogs)
            {
                ApplicationArea = All;
                Caption = 'Delete GMAIL Logs';
                Image = DeleteRow;
                Visible = false;
                trigger OnAction()
                var
                    recGmailDeletedLogs: Record "GMAIL Deleted Logs";
                    recGMAILEmailRelation: Record "GMAIL Email Relation";
                begin
                    if not Confirm('Do you want to clear the GMAIL Deleted Logs and Email Relation?', false) then
                        exit;

                    recGmailDeletedLogs.DeleteAll();
                    recGMAILEmailRelation.DeleteAll();
                    Commit();
                    Message('Deleted Succesfully!');
                end;
            }

        }
    }

    trigger OnOpenPage()
    var
        UserSetup: Record "User Setup";
    begin
        if UserSetup.Get(UserId) then
            if not UserSetup."GMAIL Admin Access" then
                Error('Account %1 doesn''t have GMAIL Admin access!', UserId);
    end;

    procedure UpdateTokenDetails()
    var
        TokenValue: Text[1024];
        RefreshTokenValue: Text[1024];
        AuthCode: Text[1024];
        ExpireInTxt: Text[1024];
        TxtToInteExp: Integer;
        ConverToDateTime: DateTime;
        GMAILMGTSetup: Record "GMAIL Maintenance Setup";
    begin
        IsolatedStorage.Get('OAUTH-TOKEN', TokenValue);
        IsolatedStorage.Get('OAUTH-CODE', AuthCode);
        IsolatedStorage.Get('OAUTH-EXP', ExpireInTxt);
        IsolatedStorage.Get('OAUTH-REF', RefreshTokenValue);

        if GMAILMGTSetup.Get() then begin
            GMAILMGTSetup."API Token Key" := TokenValue;
            GMAILMGTSetup."Authorization Code" := AuthCode;
            GMAILMGTSetup."Refresh Token" := RefreshTokenValue;
            Evaluate(TxtToInteExp, ExpireInTxt + '000');
            ConverToDateTime := (CurrentDateTime + (TxtToInteExp));
            GMAILMGTSetup."Token Expiration DateTime" := ConverToDateTime;
            GMAILMGTSetup.Modify();
            Commit();
            CurrPage.Update();
        end;

    end;


    var
        ERROR001: Label 'Token must be expired!';
        ERROR002: Label 'GMAIL Integration Setup does not exist!';

}