page 60008 "FTT-CST Dialog"
{
    Caption = 'Percentage for calculation';
    PageType = StandardDialog;
    SourceTable = "Integer";
    SourceTableView = where(number = filter(1));

    layout
    {
        area(content)
        {
            field(MyInputText; MyInputText)
            {
                Caption = 'Manual percentage';
                ApplicationArea = all;
                MinValue = 0;
            }
        }
    }
    var

        MyInputText: Decimal;

    procedure GetValue(var PriceCalculationPerc: Decimal)
    begin
        PriceCalculationPerc := MyInputText;
    end;

    procedure SetValue(var PriceCalculationPerc: Decimal)
    begin
        MyInputText := PriceCalculationPerc;
    end;

    procedure SetValue2(var PriceCalculationPerc: Decimal; ItemNo: code[20])
    var
        Item: record Item;
    begin
        MyInputText := PriceCalculationPerc;
        DialogCaption := 'Percentage for calculation - ' + Item.Description;
    end;

    procedure SetValue3(var PriceCalculationPerc: text; ItemNo: code[20])
    var
        Item: record Item;
    begin
        //MyInputText := PriceCalculationPerc;
        DialogCaption := 'Percentage for calculation - ' + Item.Description;
    end;

    var
        DialogCaption: Text;



}