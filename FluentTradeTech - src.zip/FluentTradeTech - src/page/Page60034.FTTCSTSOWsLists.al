page 60034 "SOWs Lists"
{
    Caption = 'SOW Documents';
    DelayedInsert = true;
    Editable = true;
    PageType = List;
    SourceTable = "Document Attachment";
    SourceTableView = SORTING(ID, "Table ID");

    layout
    {
        area(content)
        {
            repeater(Group)
            {
                field(Name; rec."File Name")
                {
                    ApplicationArea = All;
                    Editable = false;
                    ToolTip = 'Specifies the filename of the attachment.';

                    trigger OnDrillDown()
                    var
                        Selection: Integer;
                    begin
                        if Rec."Document Reference ID".HasValue() then
                            rec.Export(true)
                        else
                            if not IsOfficeAddin or not EmailHasAttachments then
                                InitiateUploadFile()
                            else begin
                                Selection := StrMenu(MenuOptionsTxt, 1, SelectInstructionTxt);
                                case
                                    Selection of
                                    1:
                                        InitiateAttachFromEmail();
                                    2:
                                        InitiateUploadFile();
                                end;
                            end;

                    end;
                }
                field("FTT-CST Document Type"; Rec."FTT-CST Document Type")
                {
                    ApplicationArea = All;
                    Editable = false;
                    ToolTip = 'Specifies the file type.';
                }
                field("FTT-CST Customer Name"; Rec."FTT-CST Customer Name")
                {
                    ApplicationArea = All;
                    Editable = false;
                    ToolTip = 'Specifies the customer name.';
                    Visible = False;
                }
                field("FTT-CST Contact Name"; Rec."FTT-CST Contact Name")
                {
                    ApplicationArea = All;
                    Editable = false;
                    ToolTip = 'Specifies the contact name.';
                }
                field("ExpiratStarting Date"; Rec."FTT-CST Starting Date")
                {
                    ApplicationArea = All;
                    //ToolTip = 'Specifies the date when the document was attached.';
                }
                field("Expiration Date"; Rec."FTT-CST Expiration Date")
                {
                    ApplicationArea = All;
                    //ToolTip = 'Specifies the date when the document was attached.';
                }
                field("Notification Date"; Rec."FTT-CST Notification Date")
                {
                    ApplicationArea = All;

                }
                field("Notification Period"; Rec."FTT-CST Notification Period")
                {
                    ApplicationArea = All;

                }
                //>>Dan 082224 Copied from page 60004
                field("Employee"; Rec."FTT-CST Employee")
                {
                    ApplicationArea = All;
                    Visible = False;
                }
                field("FTT-CST Google Drive Link"; Rec."FTT-CST Google Drive Link")
                {
                    ApplicationArea = all;

                    trigger OnLookup(var Text: Text): Boolean
                    var
                        pagHyperLink: Page "HyperLink Show";
                    begin

                        if rec."FTT-CST Google Drive Link" = '' then
                            Error('No Google Drive Link found!');

                        pagHyperLink.SetURL(rec."FTT-CST Google Drive Link");
                        pagHyperLink.Run();
                    end;
                    //<<Dan 082224
                }
            }
        }
    }

    actions
    {
        area(navigation)
        {
            group(Process)
            {
                action("Open CLE via Filter Page")

                {
                    Caption = 'Open SOW via Filter Page';
                    ApplicationArea = All;
                    Promoted = true;
                    PromotedCategory = Process;
                    PromotedIsBig = true;

                    trigger OnAction()
                    var
                        varFilterPageBuilder: FilterPageBuilder;
                        DocumentAttachment: Record "Document Attachment";
                    begin
                        varFilterPageBuilder.AddRecord('Document Attachment Table', DocumentAttachment);
                        varFilterPageBuilder.Addfield('Document Attachment Table', DocumentAttachment."FTT-SCT Record Type");
                        varFilterPageBuilder.Addfield('Document Attachment Table', DocumentAttachment."FTT-CST Customer No.");
                        varFilterPageBuilder.PageCaption := 'SOW Filter Page';
                        if varFilterPageBuilder.RunModal() then begin
                            DocumentAttachment.SetView(varFilterPageBuilder.GetView('Document Attachment Table'));
                            Page.Run(Page::"FTT-CST SOW Attachment", DocumentAttachment);
                        end;
                    end;
                }
            }
        }
    }


    trigger OnOpenPage()
    var
        varFilterPageBuilder: FilterPageBuilder;
        DocumentAttachment: Record "Document Attachment";
    begin
        UpdateSOW(Rec);
        Rec.FilterGroup(2);
        rec.SetRange("FTT-CST SOW Document", TRUE);
        Rec.FilterGroup(0);
    end;

    trigger OnInit()
    begin
        FlowFieldsEditable := true;
        IsOfficeAddin := OfficeMgmt.IsAvailable();

        //if IsOfficeAddin then
        //    EmailHasAttachments := OfficeHostMgmt.EmailHasAttachments()
        //else
        EmailHasAttachments := false;
    end;

    local procedure InitiateUploadFile()
    var
        DocumentAttachment: Record "Document Attachment";
        TempBlob: Codeunit "Temp Blob";
        FileName: Text;
    begin
        ImportWithFilter(TempBlob, FileName);
        if FileName <> '' then
            DocumentAttachment.SaveAttachment(FromRecRef, FileName, TempBlob);
        CurrPage.Update(true);
    end;

    local procedure ImportWithFilter(var TempBlob: Codeunit "Temp Blob"; var FileName: Text)
    var
        FileManagement: Codeunit "File Management";
        IsHandled: Boolean;
    begin
        IsHandled := false;
        OnBeforeImportWithFilter(TempBlob, FileName, IsHandled, FromRecRef);
        if IsHandled then
            exit;

        FileName := FileManagement.BLOBImportWithFilter(
            TempBlob, ImportTxt, FileName, StrSubstNo(FileDialogTxt, FilterTxt), FilterTxt);
    end;

    local procedure InitiateAttachFromEmail()
    begin
        OfficeMgmt.InitiateSendToAttachments(FromRecRef);
        CurrPage.Update(true);
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterOpenForRecRef(var DocumentAttachment: Record "Document Attachment"; var RecRef: RecordRef; var FlowFieldsEditable: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeImportWithFilter(var TempBlob: Codeunit "Temp Blob"; var FileName: Text; var IsHandled: Boolean; RecRef: RecordRef)
    begin
    end;

    procedure UpdateSOW(SOWRecord: record "Document Attachment")
    var
        SalesHeader: record 36;
        Contact: Record 5050;

    begin
        if SOWRecord.FindSet() then
            repeat
                if SOWRecord."Table ID" = 36 then begin
                    if SalesHeader.get(SOWRecord."Document Type", SOWRecord."No.") then begin
                        SOWRecord."FTT-CST Customer No." := SalesHeader."Sell-to Customer No.";
                        SOWRecord."FTT-CST Table Name" := 'CUSTOMER';
                        SOWRecord."FTT-SCT Record Type" := SOWRecord."FTT-SCT Record Type"::Customer;
                        SOWRecord."FTT-CST Customer Name" := SalesHeader."Sell-to Customer Name";
                        //>>dan 082924
                        SOWRecord."FTT-CST Starting Date" := salesHeader."FTT-CST Agr. Starting Date";
                        SOWRecord."FTT-CST Expiration Date" := salesHeader."FTT-CST Agr. Ending Date";
                        IF FORMAT(SOWRecord."FTT-CST Notification Period") <> '' THEN
                            SOWRecord."FTT-CST Notification Date" := CALCDATE(SOWRecord."FTT-CST Notification Period", SOWRecord."FTT-CST Expiration Date");
                        //<<dan 082924
                        SOWRecord.modify;
                    end;
                    if SOWRecord."Table ID" = 5050 then begin
                        //if SalesHeader.get(SOWRecord."Document Type", SOWRecord."No.") then begin
                        SOWRecord."FTT-CST Customer No." := SOWRecord."No.";
                        SOWRecord."FTT-CST Table Name" := 'CONTACT';
                        SOWRecord."FTT-SCT Record Type" := SOWRecord."FTT-SCT Record Type"::Contact;
                        if Contact.get(SalesHeader."Sell-to Contact No.") then
                            SOWRecord."FTT-CST Customer Name" := Contact.Name;
                        SOWRecord.modify;
                        //end;
                    end;
                end;

            until SOWRecord.next = 0;
    end;

    var
        FromRecRef: RecordRef;
        OfficeMgmt: Codeunit "Office Management";
        OfficeHostMgmt: Codeunit "Office Host Management";
        SalesDocumentFlow: Boolean;
        FileExtensionLbl: Label '.%1', Locked = true;
        FileDialogTxt: Label 'Attachments (%1)|%1', Comment = '%1=file types, such as *.txt or *.docx';
        FilterTxt: Label '*.jpg;*.jpeg;*.bmp;*.png;*.gif;*.tiff;*.tif;*.pdf;*.docx;*.doc;*.xlsx;*.xls;*.pptx;*.ppt;*.msg;*.xml;*.*', Locked = true;
        ImportTxt: Label 'Attach a document.';
        SelectFileTxt: Label 'Attach File(s)...';
        PurchaseDocumentFlow: Boolean;
        ShareOptionsVisible: Boolean;
        ShareEditOptionVisible: Boolean;
        DownloadEnabled: Boolean;
        FlowToPurchTxt: Label 'Flow to Purch. Trx';
        FlowToSalesTxt: Label 'Flow to Sales Trx';
        FlowFieldsEditable: Boolean;
        EmailHasAttachments: Boolean;
        IsOfficeAddin: Boolean;
        IsMultiSelect: Boolean;
        MenuOptionsTxt: Label 'Attach from email,Upload file', Comment = 'Comma seperated phrases must be translated seperately.';
        SelectInstructionTxt: Label 'Choose the files to attach.';
}
