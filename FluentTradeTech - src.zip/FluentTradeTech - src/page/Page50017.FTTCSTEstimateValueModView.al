page 50017 "FTT-CST Est. Value Mod View"
{
    PageType = List;
    ApplicationArea = All;
    SourceTable = "FTT-CST Estimated Value Mod";
    PopulateAllFields = true;
    InsertAllowed = false;
    DeleteAllowed = false;
    ModifyAllowed = false;
    layout
    {
        area(Content)
        {
            repeater(EstValueRep)
            {
                field("Item No."; Rec."Item No.")
                {
                    ApplicationArea = all;
                }
                field(Description; Rec.Description)
                {
                    ApplicationArea = all;
                    Enabled = false;
                }
                field("Item Category Coede"; Rec."Item Category Coede")
                {
                    ApplicationArea = all;
                }
                field("Region Code"; Rec."Region Code")
                {
                    ApplicationArea = All;
                }
                field("FTT-CST Sublocation"; Rec."FTT-CST Sublocation")
                {
                    ApplicationArea = all;
                }
                field("FTT-CST Component Option"; Rec."FTT-CST Component Option")
                {
                    ApplicationArea = all;
                }
                field("FTT-CST Optional"; Rec."FTT-CST Optional")
                {
                    ApplicationArea = all;
                    Visible = false;
                }
                field(Quantity; Rec.Quantity)
                {
                    ApplicationArea = all;
                }
                field("Estimated Value - Currency"; Rec."Estimated Value - Currency")
                {
                    ApplicationArea = all;
                    Enabled = false;
                }
                field("Unit Price Excl. VAT"; Rec."Unit Price Excl. VAT")
                {
                    ApplicationArea = all;
                }
                field("DR/Redundancy/Integ PriceCalc%"; Rec."DR/Redundancy/Integ PriceCalc%")
                {
                    Caption = '%';
                    ApplicationArea = all;
                }
                field("Line Amount Total"; Rec."Line Amount Total")
                {
                    ApplicationArea = all;
                    Enabled = false;
                }
                field("FTT-CST Comments"; Rec."FTT-CST Comments")
                {
                    ApplicationArea = all;
                }
            }
        }
    }


    var
        myInt: Integer;
}