page 60030 LostOpportunity2Subform
{
    ApplicationArea = Basic, Suite;
    Caption = 'General';
    PageType = ListPart;
    SourceTable = LostOpportunityTable;
    SourceTableView = where("Line Type" = filter("Line"));
    Editable = False;

    layout
    {
        area(Content)
        {
            repeater(General)
            {

                field("Customer/Prospect"; Rec.Prospect)
                {
                    ToolTip = 'Specifies the value of the Customer/Prospect field.';
                    //StyleExpr = gStyle;
                    Editable = True;
                    Caption = 'Prospect';
                }
                field("Name"; Rec.Name)
                {
                    ToolTip = 'Name of the Prospect';
                    //StyleExpr = gStyle;
                    Editable = True;
                    Caption = 'Name';
                }
                field("Description"; Rec.Description)
                {
                    //StyleExpr = gStyle;
                    Editable = True;
                    Caption = 'Description';
                }
                field("LostTo"; Rec."Lost to")
                {
                    //StyleExpr = gStyle;
                    Editable = True;
                    Caption = 'Lost to';
                }
                field("SalesPerson"; Rec."Salesperson")
                {
                    //StyleExpr = gStyle;
                    Editable = True;
                    Caption = 'Salesperson';
                }
                field("SalesPername"; Rec."Salesperson Name")
                {
                    //StyleExpr = gStyle;
                    Editable = True;
                    Caption = 'Salesperson Name';
                }
                field("CurrSalesCyStg"; Rec."Current Sales Cycle Stage")
                {
                    //StyleExpr = gStyle;
                    Editable = True;
                    Caption = 'Current Sales Cycle Stage';
                }
                field("DlosingDate"; Rec."Closing Date")
                {
                    //StyleExpr = gStyle;
                    Editable = True;
                    Caption = 'Closing Date';
                }
                field("RevenueTotal"; Rec."Total Revenue")
                {
                    StyleExpr = 'Strong';
                    Editable = True;
                    Caption = 'Total Revenue';
                    trigger OnDrillDown()
                    var
                        lOppCard: Page "Opportunity Card";
                        lOpp: Record Opportunity;
                        lOppEntList: Page "Opportunity Entry List";
                        lOppEnt: Record "Opportunity Entry";
                    Begin
                        IF (Rec."Doc. No." = '') or (Rec."Total Revenue" = 0) THEN
                            Exit;

                        Clear(lOppEntList);
                        Clear(lOppEnt);
                        lOppEnt.SETFILTER("Opportunity No.", Rec."Doc. No.");
                        IF lOppEnt.FINDSET then BEGIN
                            lOppEntList.SetTableView(lOppEnt);
                            lOppEntList.RUN;
                        End;
                    End;
                }
                field("Docno"; Rec."Doc. No.")
                {
                    //StyleExpr = gStyle;
                    Editable = True;
                    Caption = 'Doc no';
                    Visible = gVis;
                }
            }
        }
    }
    Local Procedure initializedFields()
    var
    Begin
    End;

    Trigger OnOpenPage()
    var
        lSL: Record "Sales Line";
        lRev: Record "Revenue Report";
    Begin
        gVIS := False;
        IF UserId = 'DO' then
            gVis := TRUE;
    End;

    trigger OnAfterGetRecord()
    var
    Begin

    End;

    Trigger OnAfterGetCurrRecord()
    var
        lSL: Record "Sales Line";
    Begin

    End;

    trigger OnInsertRecord(BelowxRec: Boolean): Boolean
    var
    Begin

    End;

    Trigger OnDeleteRecord(): Boolean
    var
    Begin

    End;

    var
        CustSubs: Codeunit FTTCSTCustomSubcriber;
        EditTF: Boolean;
        gStyle: Text[30];
        gVis: Boolean;
}
