page 60014 "FTT-CST Cross Connect"
{
    PageType = Worksheet;
    ApplicationArea = All;
    //UsageCategory = Lists;
    Editable = true;
    InsertAllowed = true;
    SourceTable = "FTT-CST Cross Connect";
    Caption = 'Cross Connect';

    layout
    {
        area(Content)
        {
            repeater(GroupName)
            {
                field(Name; Rec."Item No.")
                {
                    ApplicationArea = All;

                    trigger OnValidate()
                    var
                        Item: record Item;
                        SalesReceivablesSetup: record "Sales & Receivables Setup";
                    begin
                        SalesReceivablesSetup.Get();
                        if Item.GET(Rec."Item No.") then begin
                            rec.Description := Item.Description;
                            if (item."Item Category Code" = SalesReceivablesSetup."FTT-CST STANDARD TAKER FEED") or
                            (item."Item Category Code" = SalesReceivablesSetup."FTT-CST STANDARD MAKER FEED") then begin
                                rec."Quantity 1" := 1;
                                rec."Quantity 3" := 1;
                            end;
                            if (item."Item Category Code" = SalesReceivablesSetup."FTT-CST NS MAKER FEED") or
                            (item."Item Category Code" = SalesReceivablesSetup."FTT-CST NS TAKER FEED") then begin
                                rec."Quantity 2" := 2;
                                rec."Quantity 4" := 2;
                            end;
                        end;
                    end;

                }
                field(Description; Rec.Description)
                {
                    ApplicationArea = All;


                }
                field("Quantity 1"; Rec."Quantity 1")
                {
                    ApplicationArea = All;
                    trigger OnValidate()
                    begin
                        if CheckSharedCC(Rec."Item No.") then
                            Error('Shared Cross Connect not allowed for this Item - %1', rec.Description);
                    end;
                }
                field("Quantity 2"; Rec."Quantity 2")
                {
                    ApplicationArea = All;
                }
                field("Quantity 3"; Rec."Quantity 3")
                {
                    trigger OnValidate()
                    begin
                        if CheckSharedCC(Rec."Item No.") then
                            Error('Shared Cross Connect not allowed for this Item - %1', rec.Description);
                    end;
                }
                field("Quantity 4"; Rec."Quantity 4")
                {

                }
            }
        }
        area(Factboxes)
        {

        }
    }


    procedure CheckSharedCC(var ItemNo: code[20]): Boolean;
    var
        Item: record Item;
    begin
        if Item.Get(ItemNo) then;
        if Item."FTT-CST Shared CC NOT Allowed" then exit(true) else exit(false);
    end;

    trigger OnInsertRecord(BelowxRec: Boolean): Boolean
    var
        Item: record Item;
        SalesReceivablesSetup: record "Sales & Receivables Setup";
    begin
        SalesReceivablesSetup.Get();
        if Item.GET(Rec."Item No.") then begin
            rec.Description := Item.Description;
            if (item."Item Category Code" = SalesReceivablesSetup."FTT-CST STANDARD TAKER FEED") or
            (item."Item Category Code" = SalesReceivablesSetup."FTT-CST STANDARD MAKER FEED") then begin
                rec."Quantity 1" := 1;
                rec."Quantity 3" := 1;
            end;
            if (item."Item Category Code" = SalesReceivablesSetup."FTT-CST NS MAKER FEED") or
            (item."Item Category Code" = SalesReceivablesSetup."FTT-CST NS TAKER FEED") then begin
                rec."Quantity 2" := 2;
                rec."Quantity 4" := 2;
            end;
        end;
    end;

}