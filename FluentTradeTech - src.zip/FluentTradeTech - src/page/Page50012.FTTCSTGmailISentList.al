page 50012 "GMAIL Sent Emails"
{
    PageType = List;
    Caption = 'GMAIL Sent Emails';
    ApplicationArea = all;
    //UsageCategory = Lists;
    SourceTable = "Gmail Inbound/Outbound";
    Permissions = tabledata "Gmail Inbound/Outbound" = rimd;
    RefreshOnActivate = true;
    InsertAllowed = false;
    SourceTableView = where("Email Type" = const(Sent));
    layout
    {
        area(Content)
        {
            repeater(SentEmails)
            {

                field("Thread ID"; Rec."Thread ID")
                {
                    Visible = false;
                }

                field(Desc; Rec.Subject)
                {

                    ToolTip = 'Specifies a subject of the email that was received.';
                    Editable = false;
                    trigger OnDrillDown()
                    begin
                        Open(Rec);
                    end;
                }


                field(DateTimeSent; Rec."Date Received")
                {
                    Caption = 'Sent';

                    ToolTip = 'Specifies the date and time the email was received.';
                    Editable = false;
                }

                field(SentFrom; rec."Sent From")
                {

                    Caption = 'Sent From';
                    ToolTip = 'Specifies the email address that this email was sent from.';
                    Editable = false;
                }
                field(SentTo; rec."Sent To")
                {

                    Caption = 'Sent To';
                    ToolTip = 'Specifies the email address that this email was sent to.';
                    Editable = false;

                }

            }
        }

    }
    actions
    {
        area(Navigation)
        {
            action(EmailRelation)
            {
                ApplicationArea = All;
                Caption = 'Email Relation';
                ToolTip = 'Specify the Email where it belongs.';
                Image = BusinessRelation;
                Promoted = true;
                PromotedCategory = Process;
                PromotedOnly = true;

                trigger OnAction()
                var
                    pagGmailInboxRelation: page "GMAIL Email Sent Relation";
                    recGmailInbox: Record "GMAIL Email Relation";
                begin
                    Clear(pagGmailInboxRelation);
                    recGmailInbox.Reset();
                    recGmailInbox.SetRange("Email Type", recGmailInbox."Email Type"::Sent);
                    recGmailInbox.SetFilter("Inbox Entry No.", '%1', rec.EntryNo);
                    recGmailInbox.SetRange("Thread ID", rec."Thread ID");
                    recGmailInbox.SetRange("GMAIL Inbox ID", rec."GMAIL Inbox ID");

                    pagGmailInboxRelation.SetTableView(recGmailInbox);
                    pagGmailInboxRelation.Run();

                end;
            }


        }
        area(Processing)
        {
            action(SyncronizeEmail)
            {
                ApplicationArea = All;
                Caption = 'Synchronize Gmail';
                Promoted = true;
                PromotedIsBig = true;
                PromotedOnly = true;
                PromotedCategory = Process;
                Image = UpdateXML;
                Visible = false;
                trigger OnAction()
                var
                    GmailIntegCdu: codeunit "Gmail Integration";
                    recUserSetup: Record "User Setup";
                begin
                    if not recUserSetup.Get(UserId) then
                        exit;

                    // if (CurrentDateTime > recUserSetup."Token Expiration DateTime") then
                    //     Error(ERROR001);

                    if not Confirm('Do you want to proceed on the GMAIL Synchronization?') then
                        exit;

                    //  if GuiAllowed then
                    //GmailIntegCdu.ShowGMAILList(recUserSetup."E-Mail", recUserSetup."API Token Key", 2, false);

                    CurrPage.Update(false);
                    Message('GMAIL Outbound has been succesfully updated!');
                end;

            }


        }
    }

    trigger OnOpenPage()
    var
        UserSetup: Record "User Setup";
    begin
        if UserSetup.Get(UserId) then
            if not UserSetup."GMAIL Admin Access" then
                Error('Account %1 doesn''t have GMAIL Admin access!', UserId);

        // rec.FilterGroup(2);
        // rec.SetRange(Rec."Created by User", UserId);
        // rec.FilterGroup(0);


        Rec.SetCurrentKey("Date Received");
        Rec.Ascending(false);

    end;


    procedure Open(ReceivedEmail: Record "Gmail Inbound/Outbound")
    var
        EmailViewer: Page "Email Inbox Viewer";
    begin
        EmailViewer.SetRecord(ReceivedEmail);
        EmailViewer.Run();
    end;



    var

        ERROR001: Label 'Token has been expired already!';
}