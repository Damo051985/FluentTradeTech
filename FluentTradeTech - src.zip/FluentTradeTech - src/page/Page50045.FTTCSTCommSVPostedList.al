page 50045 "Comm. Worksht. SV Posted List"
{
    PageType = List;
    ApplicationArea = All;
    UsageCategory = Lists;
    SourceTable = "Commission SV. Worksht. Header";
    Editable = false;
    CardPageId = "Comm. Worksheet SV. Rev. Card";
    Caption = 'Commission Supervisor Posted List';
    DeleteAllowed = false;
    layout
    {
        area(Content)
        {
            repeater(General)
            {
                field("Document No."; rec."Document No.")
                {
                    ApplicationArea = All;
                    Caption = 'Commission Supervisor No.';

                }
                field("Vendor Name (SalesPerson)"; Rec."Vendor Name (SalesPerson)")
                {
                    ApplicationArea = All;
                    Caption = 'Vendor Name (Supervisor)';

                }

                field("Commission Agreement No."; Rec."Commission Agreement No.")
                {
                    ApplicationArea = all;
                }
                field("Total SV. Reward Amount"; Rec."Total SV. Reward Amount")
                {
                    ApplicationArea = all;
                }
                field("Total SV. Reward Amount (LCY)"; Rec."Total SV. Reward Amount (LCY)")
                {
                    ApplicationArea = all;
                    Caption = 'Total Supervisor Reward Amount (LCY)';
                }
                field("Invoice Date From"; Rec."Invoice Date From")
                {
                    ApplicationArea = All;

                }
                field("Invoice Date To"; Rec."Invoice Date To")
                {
                    ApplicationArea = All;

                }
                field("Creation Date"; rec."Creation Date")
                {
                    ApplicationArea = All;
                }
                field(Status; rec.Status)
                {
                    ApplicationArea = All;
                }
            }
        }
        area(Factboxes)
        {

        }

    }

    trigger OnOpenPage()
    begin
        rec.FilterGroup(2);
        rec.SetFilter(Rec.Status, '%1', Rec.Status::"Payment Posted");
        rec.FilterGroup(0);
    end;
}