page 50011 "GMAIL Attachement List"
{
    PageType = List;
    ApplicationArea = All;
    UsageCategory = Lists;
    SourceTable = "GMAIL Attachment";
    Caption = 'GMAIL Attachment List';
    RefreshOnActivate = true;
    layout
    {
        area(Content)
        {
            repeater(GroupName)
            {
                field(EntryNo; Rec.EntryNo)
                {
                    ApplicationArea = all;
                }

                field(Subject; GetSubject(rec."GMAIL Inbox ID"))
                {
                    ApplicationArea = all;
                }
                field("File Name"; Rec."File Name")
                {
                    ApplicationArea = All;
                    trigger OnDrillDown()
                    var
                        TenantMedia: Record "Tenant Media";
                        InStreamPic: InStream;
                        FileName: Text;
                        recEmailAttachement: Record "GMAIL Attachment";
                    begin
                        recEmailAttachement.Reset();
                        recEmailAttachement.SetRange(EntryNo, rec.EntryNo);
                        if recEmailAttachement.FindFirst() then
                            if not recEmailAttachement.data.HasValue then
                                exit;

                        if TenantMedia.Get(recEmailAttachement.data.MediaId) then begin
                            TenantMedia.CalcFields(Content);
                            if TenantMedia.Content.HasValue then begin
                                FileName := rec."File Name";
                                TenantMedia.Content.CreateInStream(InStreamPic);
                                DownloadFromStream(InStreamPic, '', '', '', FileName);
                            end;
                        end;
                    end;

                }

                field("Mime Type"; Rec."Mime Type")
                {
                    ApplicationArea = all;
                }
                field("Date/Time Created"; Rec."Date Created")
                {
                    ApplicationArea = all;
                }
                field("Created By USER"; Rec."Created By USER")
                {
                    ApplicationArea = all;
                }
            }
        }
    }

    actions
    {
        // area(Processing)
        // {
        //     action(ActionName)
        //     {
        //         ApplicationArea = All;

        //         trigger OnAction()
        //         begin

        //         end;
        //     }
        // }
    }

    trigger OnInsertRecord(BelowxRec: Boolean): Boolean
    var
        recGMAILATTACLAST: Record "GMAIL Attachment";
    begin
        recGMAILATTACLAST.Reset();
        if recGMAILATTACLAST.FindLast() then
            rec.EntryNo := recGMAILATTACLAST.EntryNo + 1
        else
            rec.EntryNo := 1;


    end;

    trigger OnOpenPage()
    var
        UserSetup: Record "User Setup";
    begin
        if UserSetup.Get(UserId) then
            if not UserSetup."GMAIL Admin Access" then
                Error('Account %1 doesn''t have GMAIL Admin access!', UserId);
        // rec.FilterGroup(2);
        // rec.SetRange(Rec."Created by User", UserId);
        // rec.FilterGroup(0);


        Rec.SetCurrentKey("Date Created");
        Rec.Ascending(false);

    end;

    procedure GetSubject(pGmailInboxID: text[250]): text
    var
        recGmaiInbound: Record "GMAIL Inbound/Outbound";
    begin
        recGmaiInbound.Reset();
        recGmaiInbound.SetRange("GMAIL Inbox ID", pGmailInboxID);
        if recGmaiInbound.FindFirst() then
            exit(recGmaiInbound.Subject);

        exit('');

    end;

    var
        myInt: Integer;
}