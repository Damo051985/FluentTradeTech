page 60038 "FTT CST Mailing Group"
{
    ApplicationArea = All;
    Caption = 'Mailing Group';
    PageType = ListPart;
    SourceTable = "Email Mailing Group";

    layout
    {
        area(Content)
        {
            Repeater(General)
            {
                Caption = 'General';

                field("Mailing Group Code"; Rec."Mailing Group Code")
                {
                    ToolTip = 'Specifies the value of the Mailing Group Code field.';
                    Visible = False;
                }
                field(Description; Rec.Description)
                {
                    ToolTip = 'Specifies the value of the Description field.';
                    Visible = False;
                }
                field("User ID"; Rec."User ID")
                {
                    ToolTip = 'Specifies the value of the User ID field.';
                }
                field("User Name"; Rec."User Name")
                {
                    ToolTip = 'Specifies the value of the User Name field.';
                }
                field(Email; Rec.Email)
                {
                    ToolTip = 'Specifies the value of the Email field.';
                }
                field(Active; Rec.Active)
                {
                    ToolTip = 'Specifies the value of the Active field.';
                }
                field(SenDBy; Rec."Send By")
                {
                    ToolTip = 'Specifies the value of the Send by field.';
                }
                field(Comment; Rec.Comment)
                {
                    ToolTip = 'Specifies the value of the Comment field.';
                }
            }
        }
    }
}
