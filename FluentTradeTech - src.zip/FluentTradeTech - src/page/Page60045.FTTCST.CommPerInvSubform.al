page 60045 "Comm. Per Inv. Subform"
{
    ApplicationArea = All;
    Caption = 'Line Details';
    PageType = ListPart;
    SourceTable = "Commision per Invoice";
    //SourceTableView = sorting("Invoice No.") order(descending) where("Type" = filter(Line));
    SourceTableView = where("Type" = filter(Line));

    layout
    {
        area(Content)
        {
            repeater(General)
            {
                field("Invoice No."; Rec."Invoice No.")
                {
                    ToolTip = 'Specifies the value of the Invoice No. field.', Comment = '%';
                }
                field("Invoice Status"; Rec."Invoice Status")
                {
                    ToolTip = 'Specifies the value of the Invoice Status field.', Comment = '%';
                }
                field("Customer Code"; Rec."Customer Code")
                {
                    ToolTip = 'Specifies the value of the Customer Code field.', Comment = '%';
                }
                field("Customer Name"; Rec."Customer Name")
                {
                    ToolTip = 'Specifies the value of the Customer Name field.', Comment = '%';
                }
                field("Salesperson Code"; Rec."Salesperson Code")
                {
                    ToolTip = 'Specifies the value of the Salesperson Code field.', Comment = '%';
                }
                field("Salesperson Name"; Rec."Salesperson Name")
                {
                    ToolTip = 'Specifies the value of the Salesperson Name field.', Comment = '%';
                }
                field("Invoice Amount Currency"; Rec."Invoice Amount Currency")
                {
                    ToolTip = 'Specifies the value of the Invoice Amount Currency field.', Comment = '%';
                }
                field("Invoice Amount LCY"; Rec."Invoice Amount LCY")
                {
                    ToolTip = 'Specifies the value of the Invoice Amount LCY field.', Comment = '%';
                }
                field("Eligible Currency"; Rec."Eligible Currency")
                {
                    ToolTip = 'Specifies the value of the Eligible Currency field.', Comment = '%';
                }
                field("Eligible LCY"; Rec."Eligible LCY")
                {
                    ToolTip = 'Specifies the value of the Eligible LCY field.', Comment = '%';
                }
                field("Commision Currency"; Rec."Commision Currency")
                {
                    ToolTip = 'Specifies the value of the Commision Currency field.', Comment = '%';
                }
                field("Commision LCY"; Rec."Commision LCY")
                {
                    ToolTip = 'Specifies the value of the Commision LCY field.', Comment = '%';
                }
            }
        }
    }
}
