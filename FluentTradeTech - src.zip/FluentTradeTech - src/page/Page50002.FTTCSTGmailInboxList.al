page 50002 "GMAIL Received Emails"
{
    PageType = List;
    Caption = 'Emails';
    ApplicationArea = all;
    UsageCategory = Lists;
    SourceTable = "Gmail Inbound/Outbound";
    Permissions = tabledata "Gmail Inbound/Outbound" = rimd;
    RefreshOnActivate = true;
    InsertAllowed = false;
    SourceTableView = where("Email Type" = const(Inbox));
    layout
    {
        area(Content)
        {
            repeater(ReceivedEmails)
            {

                field("Thread ID"; Rec."Thread ID")
                {
                    Visible = false;
                }

                field(Desc; Rec.Subject)
                {

                    ToolTip = 'Specifies a subject of the email that was received.';
                    Editable = false;
                    trigger OnDrillDown()
                    begin
                        Open(Rec);
                    end;
                }
                field(ContactName; gContName)
                {
                    Caption = 'Contact';

                    //ToolTip = 'Specifies the date and time the email was received.';
                    Editable = false;
                }

                field(DateTimeSent; Rec."Date Received")
                {
                    Caption = 'Received';

                    ToolTip = 'Specifies the date and time the email was received.';
                    Editable = false;
                }

                field(SentFrom; rec."Sent From")
                {

                    Caption = 'Sent From';
                    ToolTip = 'Specifies the email address that this email was sent from.';
                    Editable = false;
                }
                field(SentTo; rec."Sent To")
                {

                    Caption = 'Sent To';
                    ToolTip = 'Specifies the email address that this email was sent to.';
                    Editable = false;

                }
                field("Estimated Sales Value (LCY)"; Rec."Estimated Sales Value (LCY)")
                {
                    Caption = 'Estimated Sales Value';
                    ToolTip = 'Specifies the total of Estimated Sales Value';
                }

            }
        }

    }
    actions
    {
        area(Navigation)
        {
            action(EmailRelation)
            {
                ApplicationArea = All;
                Caption = 'Email Relation';
                ToolTip = 'Specify the Email where it belongs.';
                Image = BusinessRelation;
                Promoted = true;
                PromotedCategory = Process;
                PromotedOnly = true;

                trigger OnAction()
                var
                    pagGmailInboxRelation: page "GMAIL Email Inbox Relation";
                    recGmailInbox: Record "GMAIL Email Relation";
                begin
                    Clear(pagGmailInboxRelation);
                    recGmailInbox.Reset();
                    recGmailInbox.SetRange("Email Type", recGmailInbox."Email Type"::Inbox);
                    recGmailInbox.SetFilter("Inbox Entry No.", '%1', rec.EntryNo);
                    recGmailInbox.SetRange("Thread ID", rec."Thread ID");
                    recGmailInbox.SetRange("GMAIL Inbox ID", rec."GMAIL Inbox ID");

                    pagGmailInboxRelation.SetTableView(recGmailInbox);
                    pagGmailInboxRelation.Run();

                end;
            }
            action(OpenEstValue)
            {
                ApplicationArea = All;
                Caption = 'Open Estimated Sales Value (LCY)';
                Image = ViewJob;
                PromotedCategory = Process;
                Promoted = true;
                PromotedIsBig = true;
                RunPageMode = view;
                trigger OnAction()
                var
                    pagEstValue: page "FTT-CST Est. Value Mod View";
                    recEstValie: Record "FTT-CST Estimated Value Mod";
                begin
                    Clear(pagEstValue);
                    recEstValie.Reset();
                    recEstValie.SetRange("Linked No.", rec."GMAIL Inbox ID");
                    if recEstValie.FindSet() then
                        pagEstValue.SetTableView(recEstValie)
                    else
                        pagEstValue.SetTableView(recEstValie);

                    pagEstValue.Run();
                end;

            }
            action(DeleteOldLines)
            {
                ApplicationArea = All;
                Caption = 'Delete Old Lines';
                Image = ViewJob;
                PromotedCategory = Process;
                Promoted = true;
                PromotedIsBig = true;
                RunPageMode = view;
                Visible = False;
                trigger OnAction()
                var
                    recEstValie: Record "FTT-CST Estimated Value Mod";
                begin
                    Clear(recEstValie);
                    recEstValie.SetRange("Linked No.", rec."GMAIL Inbox ID");
                    recEstValie.SetRange("Linked Source Table ID", 50001);
                    recEstValie.SetRange("Original Opportunity No.", '');
                    IF recEstValie.FINDSET then begin
                        IF Confirm('Are you sure do you want to delete Gmail Inbox ID %1', True, recEstValie."Linked No.") THEN BEGIN
                            recEstValie.DELETEALL;
                            Message('Done');
                        END;
                    end;
                end;

            }

        }
        area(Processing)
        {
            action(CreateOppofromEmail)
            {
                ApplicationArea = All;
                Caption = 'Create Opport. From Email';
                Promoted = true;
                PromotedIsBig = true;
                PromotedOnly = true;
                PromotedCategory = Process;
                Image = CreateJobSalesInvoice;

                trigger OnAction()
                var
                    reprocessCreatefromEmail: Report "Create Opport. from Email";
                    recGmailInbound: Record "GMAIL Inbound/Outbound";
                    recEmailRElation: Record "GMAIL Email Relation";
                begin
                    Clear(reprocessCreatefromEmail);

                    if not Confirm('Do you want to create an Opportunity from this email?') then
                        exit;

                    recGmailInbound.Reset();
                    recGmailInbound.SetRange(EntryNo, rec.EntryNo);
                    if recGmailInbound.FindFirst() then begin

                        recEmailRElation.Reset();
                        recEmailRElation.SetRange("GMAIL Inbox ID", recGmailInbound."GMAIL Inbox ID");
                        recEmailRElation.SetRange("Linked Document Type", recEmailRElation."Linked Document Type"::Contact);
                        if recEmailRElation.FindFirst() then
                            reprocessCreatefromEmail.SetDefaultContact(recEmailRElation."Linked Document No.");

                        reprocessCreatefromEmail.SetTableView(recGmailInbound);
                        reprocessCreatefromEmail.Run();
                    end;

                end;
            }

        }
    }
    Trigger OnAfterGetRecord()
    var
        recGmailInbox: Record "GMAIL Email Relation";
        lCont: Record Contact;
    Begin
        gContName := '';
        recGmailInbox.Reset();
        recGmailInbox.SetRange("Email Type", recGmailInbox."Email Type"::Inbox);
        recGmailInbox.SetFilter("Inbox Entry No.", '%1', rec.EntryNo);
        recGmailInbox.SetRange("Thread ID", rec."Thread ID");
        recGmailInbox.SetRange("GMAIL Inbox ID", rec."GMAIL Inbox ID");
        IF RecGmailInbox.FINDSET THEN begin
            repeat
                IF lCont.GET(recGmailInbox."Linked Document No.") then
                    gContName := lCont.Name;
            until (recGmailInbox.Next = 0) OR (gContName <> '')
        end;
    End;

    trigger OnOpenPage()
    var
        UserSetup: Record "User Setup";
        lUserSetup: Record "User Setup";
    begin
        if UserSetup.Get(UserId) then
            if not UserSetup."GMAIL Admin Access" then
                Error('Account %1 doesn''t have GMAIL Admin access!', UserId);

        // rec.FilterGroup(2);
        // rec.SetRange(Rec."Created by User", UserId);
        // rec.FilterGroup(0);

        Rec.SetCurrentKey("Date Received");
        Rec.Ascending(false);

    end;


    procedure Open(ReceivedEmail: Record "Gmail Inbound/Outbound")
    var
        EmailViewer: Page "Email Inbox Viewer";
    begin
        EmailViewer.SetRecord(ReceivedEmail);
        EmailViewer.Run();
    end;



    var

        ERROR001: Label 'Token has been expired already!';
        gVis: Boolean;
        gContName: Text[250];
}