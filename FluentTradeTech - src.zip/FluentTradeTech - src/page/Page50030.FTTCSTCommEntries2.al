page 50030 "FTT-CST Commission Entries2"
{
    Caption = 'Commission Ledger Entries';
    DataCaptionFields = "Sell-to Customer No.";
    DeleteAllowed = false;
    InsertAllowed = false;
    Editable = false;
    PageType = List;
    Permissions = TableData "Cust. Ledger Entry" = r, tabledata "Sales Invoice Line" = rm;
    SourceTable = "FTT-CST Commission Entries";
    SourceTableView = sorting("Entry No.", "Document No.") order(descending);
    UsageCategory = History;
    ApplicationArea = All;
    layout
    {
        area(Content)
        {
            repeater(General)
            {
                ShowCaption = false;
                field("Entry No."; Rec."Entry No.")
                {
                    ApplicationArea = All;

                }
                field("Document Type"; Rec."Document Type")
                {
                    ApplicationArea = all;
                }
                field("Document No."; Rec."Document No.")
                {
                    ApplicationArea = all;
                }
                field("Document Date"; Rec."Document Date")
                {
                    ApplicationArea = all;
                    Caption = 'Posting Date';
                }

                field("Sell-to Customer No."; Rec."Sell-to Customer No.")
                {
                    ApplicationArea = all;
                }
                field("Sell-to Customer Name"; Rec."Sell-to Customer Name")
                {
                    ApplicationArea = all;
                }
                field("Currency Code"; Rec."Currency Code")
                {
                    ApplicationArea = all;
                }
                field("Salesperson Code"; Rec."Salesperson Code")
                {
                    ApplicationArea = all;
                }
                field("Amount (Excl. Vat)"; Rec."Amount (Excl. Vat)")
                {
                    ApplicationArea = all;
                }
                field("Amount Paid"; Rec."Amount Paid")
                {
                    ApplicationArea = all;
                }
                field("Commission Base"; Rec."Commission Base")
                {
                    ApplicationArea = all;
                }
                field("Commission Amount"; Rec."Commission Amount")
                {
                    ApplicationArea = all;
                }
                field("Rem. Commission Amount"; Rec."Rem. Commission Amount")
                {
                    ApplicationArea = all;
                }
                field("Commission Amount (LCY)"; Rec."Commission Amount (LCY)")
                {
                    ApplicationArea = all;
                }
                field("Rem. Commission Amount (LCY)"; Rec."Rem. Commission Amount (LCY)")
                {
                    ApplicationArea = all;
                }
                field(Open; Rec.Open)
                {
                    ApplicationArea = all;
                }
            }
        }
    }

    actions
    {
        area(navigation)
        {
            group("Ent&ry")
            {
                action(Customer)
                {
                    ApplicationArea = Basic, Suite;
                    Caption = 'Customer';
                    Image = Customer;
                    RunObject = Page "Customer Card";
                    RunPageLink = "No." = field("Sell-to Customer No.");
                    ShortCutKey = 'Shift+F7';
                    ToolTip = 'View or edit detailed information about the customer.';
                }

                action("Detailed Comm. &Ledger Entries")
                {
                    ApplicationArea = Basic, Suite;
                    Caption = 'Detailed Commission &Ledger Entries';
                    Image = View;
                    RunObject = Page "FTT-CST Dtldg. Comm. Entries";
                    RunPageLink = "Comm. Ledger Entry No." = field("Entry No."),
                                  "Customer No." = field("Sell-to Customer No.");
                    RunPageView = sorting("Comm. Ledger Entry No.", "Posting Date");
                    Scope = Repeater;
                    ShortCutKey = 'Ctrl+F7';
                    ToolTip = 'View a summary of the all posted entries and adjustments related to a specific customer ledger entry.';
                }
            }
        }
        area(processing)
        {
            action("&Navigate")
            {
                ApplicationArea = Basic, Suite;
                Caption = 'Find entries...';
                Image = Navigate;
                Scope = Repeater;
                ShortCutKey = 'Ctrl+Alt+Q';
                ToolTip = 'Find entries and documents that exist for the document number and posting date on the selected document. (Formerly this action was named Navigate.)';

                trigger OnAction()
                begin
                    Navigate.SetDoc(Rec."Document Date", Rec."Document No.");
                    Navigate.Run();
                end;
            }
            action("Show Document")
            {
                ApplicationArea = Basic, Suite;
                Caption = 'Show Document';
                Image = Document;
                ShortCutKey = 'Return';
                ToolTip = 'Show details for the posted payment, invoice, or credit memo.';

                trigger OnAction()
                begin
                    Rec.ShowDoc();
                end;
            }
            // action("Re-Calculate the Ledger Entries")
            // {
            //     ApplicationArea = All;
            //     Image = Recalculate;

            //     trigger OnAction()
            //     var
            //         recCommLedgerEntries: Record "FTT-CST Commission Entries";
            //     begin
            //         recCommLedgerEntries.Reset();
            //         recCommLedgerEntries.SetRange("Entry No.", rec."Entry No.");
            //         if recCommLedgerEntries.FindFirst() then begin
            //             recCommLedgerEntries.Open := true;
            //             recCommLedgerEntries.Modify();
            //         end

            //     end;
            // }

        }
        area(Promoted)
        {
            group(Category_Process)
            {
                Caption = 'Process', Comment = 'Generated from the PromotedActionCategories property index 1.';

                group(Category_Category4)
                {
                    Caption = 'Line', Comment = 'Generated from the PromotedActionCategories property index 3.';
                    ShowAs = SplitButton;

                    actionref("Show Document_Promoted"; "Show Document")
                    {
                    }

                }

                actionref("&Navigate_Promoted"; "&Navigate")
                {
                }

            }
            group(Category_Category5)
            {
                Caption = 'Entry', Comment = 'Generated from the PromotedActionCategories property index 4.';
                separator(Navigate_Separator)
                {
                }

                actionref(Customer_Promoted; Customer)
                {
                }
            }
            group(Category_Category6)
            {
                Caption = 'Navigate', Comment = 'Generated from the PromotedActionCategories property index 5.';
            }
            group(Category_Report)
            {
                Caption = 'Report', Comment = 'Generated from the PromotedActionCategories property index 2.';
            }
        }
    }

    trigger OnOpenPage()
    var
        UserSetup: Record "User Setup";
    begin
        if not UserSetup.Get(UserId) then
            exit;

        if not UserSetup."Commission Full Access" then begin
            UserSetup.TestField("Salespers./Purch. Code");
            rec.FilterGroup(2);
            rec.SetRange(Rec."Salesperson Code", UserSetup."Salespers./Purch. Code");
            rec.FilterGroup(0);
        end else begin
            rec.Reset();
            rec.SetCurrentKey("Entry No.", "Document No.");
            rec.Ascending(false);
        end;
    end;

    var
        Navigate: Page Navigate;
}