page 50036 "Commission WS Subform"
{
    PageType = ListPart;
    SourceTable = "Commission Worksheet Lines";
    AutoSplitKey = true;
    Caption = 'Lines';
    RefreshOnActivate = true;
    // DeleteAllowed = false;
    InsertAllowed = false;
    layout
    {
        area(Content)
        {
            repeater(GroupName)
            {
                field("Document Type"; Rec."Document Type")
                {
                    ApplicationArea = all;
                    Editable = false;
                }
                field("Inv, Document No."; Rec."Inv, Document No.")
                {
                    ApplicationArea = all;
                    Editable = false;
                    Caption = 'Document No.';
                }
                field("Document Date"; Rec."Document Date")
                {
                    ApplicationArea = all;
                    Editable = false;
                }
                field("Sell-to Customer Name"; Rec."Sell-to Customer Name")
                {
                    ApplicationArea = all;
                    Editable = false;
                }
                field("Currency Code"; Rec."Currency Code")
                {
                    ApplicationArea = all;
                    Editable = false;
                }
                field("Commission Agreement No."; Rec."Commission Agreement No.")
                {
                    ApplicationArea = all;
                    Editable = false;
                }

                field("Commission %"; Rec."Commission %")
                {
                    ApplicationArea = all;
                    Editable = false;
                    Visible = false;
                }
                field("Commission Base"; Rec."Commission Base")
                {
                    ApplicationArea = all;
                    Editable = false;
                }
                field("Commission Amount (LCY)"; Rec."Commission Amount (LCY)")
                {
                    ApplicationArea = all;
                    Editable = false;
                    Visible = false;
                }
                field("Commission Amount"; Rec."Commission Amount")
                {
                    ApplicationArea = all;
                    Editable = false;
                }
                field("Rem. Commission Amount"; Rec."Rem. Commission Amount")
                {
                    ApplicationArea = all;
                    Caption = 'Rem. Commission Amount';
                    Editable = false;
                }
                field("Application Amount"; Rec."Application Amount")
                {
                    ApplicationArea = all;
                    Style = Unfavorable;
                    trigger OnValidate()
                    var
                        RecCommWshHeader: Record "Commission Worksheet Header";
                    begin
                        if rec."Application Amount" > rec."Rem. Commission Amount" then
                            Error('Application Amount should not be greater than to Remaining Commission Amount');

                        RecCommWshHeader.Reset();
                        RecCommWshHeader.SetRange("Document No.", rec."Document No.");
                        RecCommWshHeader.CalcFields("Total Application Amount");
                        CurrPage.Update(false);
                    end;
                }

            }
        }
    }
}


