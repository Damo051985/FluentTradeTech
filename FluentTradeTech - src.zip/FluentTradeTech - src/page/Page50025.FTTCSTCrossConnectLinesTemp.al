page 50025 "FTT-CST Cross ConnectLinesTemp"
{
    Caption = 'Cross Connect Lines';
    PageType = Worksheet;
    Editable = true;
    ApplicationArea = All;
    SourceTable = "FTT-CST Cross ConnectLnsTemp";

    //RefreshOnActivate = true;
    //DeleteAllowed = false;
    //InsertAllowed = false;

    layout
    {
        area(Content)
        {
            repeater(Group)
            {
                field("FTT-CST Location Code"; Rec."FTT-CST Location Code")
                {
                    ApplicationArea = all;
                }
                field("Item No."; Rec."Item No.")
                {
                    ApplicationArea = All;

                }
                field(Description; Rec.Description)
                {
                    ApplicationArea = all;
                }
                field("Quantity 1"; Rec."Quantity 1")
                {
                    ApplicationArea = all;
                }
                field("Quantity 2"; Rec."Quantity 2")
                {
                    ApplicationArea = all;
                }
                field("Quantity 3"; Rec."Quantity 3")
                {
                    ApplicationArea = all;
                }
                field("Quantity 4"; Rec."Quantity 4")
                {
                    ApplicationArea = all;
                }
            }
        }
    }

    var
        myInt: Integer;
}