page 50037 "Comm. Worksheet Reversed List"
{
    PageType = List;
    ApplicationArea = All;
    UsageCategory = Lists;
    SourceTable = "Commission Worksheet Header";
    Editable = false;
    CardPageId = "Comm. Worksheet Rev. Card";
    Caption = 'Commission Worksheet Reversed List';
    DeleteAllowed = false;
    layout
    {
        area(Content)
        {
            repeater(General)
            {
                field("Document No."; rec."Document No.")
                {
                    ApplicationArea = All;
                    Caption = 'Comm. Worksheet No.';

                }
                field("Vendor Name (SalesPerson)"; Rec."Vendor Name (SalesPerson)")
                {
                    ApplicationArea = All;

                }
                field("Commission Agreement No."; Rec."Commission Agreement No.")
                {
                    ApplicationArea = all;
                }
                field("Total Commission Amount"; Rec."Total Commission Amount")
                {
                    ApplicationArea = all;
                }
                field("Total Commission Amount (LCY)"; Rec."Total Commission Amount (LCY)")
                {
                    ApplicationArea = all;
                }
                field("Invoice Date From"; Rec."Invoice Date From")
                {
                    ApplicationArea = All;

                }
                field("Invoice Date To"; Rec."Invoice Date To")
                {
                    ApplicationArea = All;

                }
                field("Creation Date"; rec."Creation Date")
                {
                    ApplicationArea = All;
                }
                field(Status; rec.Status)
                {
                    ApplicationArea = All;
                }
            }
        }
        area(Factboxes)
        {

        }

    }

    trigger OnOpenPage()
    begin
        rec.FilterGroup(2);
        rec.SetFilter(Rec.Status, '%1|%2', Rec.Status::"Payable Reversed", rec.Status::"Payment Reversed");
        rec.FilterGroup(0);
    end;
}