page 60039 "Mailing Group Card"
{
    ApplicationArea = All;
    Caption = 'Mailing Group Card';
    PageType = Card;
    SourceTable = "Email Mailing Group Code";

    layout
    {
        area(Content)
        {
            group(General)
            {
                Caption = 'General';

                field("Mailing Group Code"; Rec."Mailing Group Code")
                {
                    ToolTip = 'Specifies the value of the Mailing Group Code field.';
                    //Editable = False;
                }
            }
            part("Mailing Group List"; "FTT CST Mailing Group")
            {
                ApplicationArea = Basic, Suite;
                SubPageLink = "Mailing Group Code" = field("Mailing Group Code");
                UpdatePropagation = Both;
            }
        }
    }
}
