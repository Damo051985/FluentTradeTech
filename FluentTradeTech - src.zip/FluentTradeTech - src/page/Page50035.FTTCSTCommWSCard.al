page 50035 "Comm. Worksheet Card"
{
    PageType = Card;
    SourceTable = "Commission Worksheet Header";
    Caption = 'Commission Worksheet Card';
    RefreshOnActivate = true;
    Permissions = tabledata "Cust. Ledger Entry" = rimd,
    tabledata "Detailed Cust. Ledg. Entry" = rimd,
    tabledata "Sales Invoice Header" = rimd,
    tabledata "Sales Invoice Line" = rimd;
    DeleteAllowed = true;
    PromotedActionCategories = 'New,Process,Report,Payables/Payment Creation,Function';
    layout
    {
        area(Content)
        {
            group(General)
            {
                field("Document No."; Rec."Document No.")
                {
                    ApplicationArea = All;
                    Editable = false;
                    Caption = 'Comm. Worksheet No.';
                }
                field("Commission Agreement No."; Rec."Commission Agreement No.")
                {
                    ApplicationArea = all;
                    Editable = false;

                }
                field("Agreement Period"; Rec."Agreement Period")
                {
                    ApplicationArea = all;
                    Editable = false;
                    Visible = false;
                }
                field("Commission %"; Rec."Commission %")
                {
                    ApplicationArea = all;
                    Visible = false;
                    Editable = false;
                }
                field("Invoice Date From"; rec."Invoice Date From")
                {
                    ApplicationArea = All;
                    Editable = rec.Status = rec.Status::Open;
                    Caption = 'Invoice Date Filter From';
                }
                field("Invoice Date To"; rec."Invoice Date To")
                {
                    ApplicationArea = All;
                    Editable = rec.Status = rec.Status::Open;
                    Caption = 'Invoice Date Filter To';
                }

                field(Status; Rec.Status)
                {
                    ApplicationArea = All;
                    Editable = false;
                }
                field("Assigned User ID"; Rec."Assigned User ID")
                {
                    ApplicationArea = all;
                    Editable = false;
                }
                field("Creation Date"; rec."Creation Date")
                {
                    ApplicationArea = All;
                    Editable = false;

                }
            }

            group("Payables and Payment Details")
            {
                field("Vendor No.  (SalesPerson)"; rec."Vendor No.  (SalesPerson)")
                {
                    ApplicationArea = All;
                    Editable = false;
                    ShowMandatory = true;

                }
                field("Vendor Name (SalesPerson)"; rec."Vendor Name (SalesPerson)")
                {
                    ApplicationArea = All;
                    Editable = false;

                }
                field(CommPINo; rec."Comm. PI No.")
                {
                    ApplicationArea = All;
                    Editable = false;
                    Caption = 'Comm. Purchase Invoice No.';

                    trigger OnDrillDown()
                    var
                        PurchInv: Page "Purchase Invoice";
                        PostedPurchInv: page "Posted Purchase Invoice";
                        PurchHeader: Record "Purchase Header";
                        PurchInvHeader: Record "Purch. Inv. Header";
                    begin
                        PurchHeader.Reset();
                        PurchHeader.SetRange("Document Type", PurchHeader."Document Type"::Invoice);
                        PurchHeader.SetRange("No.", Rec."Comm. PI No.");
                        if PurchHeader.FindFirst() then begin
                            PurchInv.SetRecord(PurchHeader);
                            PurchInv.Run();
                        end else begin
                            PurchInvHeader.Reset();
                            PurchInvHeader.SetRange(PurchInvHeader."Pre-Assigned No.", rec."Comm. PI No.");
                            if PurchInvHeader.FindFirst() then begin
                                PostedPurchInv.SetRecord(PurchInvHeader);
                                PostedPurchInv.Run();
                            end;
                        end;
                    end;
                }
                field("Comm. Payable Doc. No."; rec."Comm. Payable Doc. No.")
                {
                    ApplicationArea = All;
                    Editable = false;
                    //FieldPropertyName = FieldPropertyValue;
                    Caption = 'Commission APV No.';
                    trigger OnDrillDown()
                    var
                        PostedPurchInv: Page "Posted Purchase Invoice";
                        PurchInvHeader: Record "Purch. Inv. Header";
                    begin
                        PurchInvHeader.Reset();
                        PurchInvHeader.SetRange("No.", Rec."Comm. Payable Doc. No.");
                        if PurchInvHeader.FindFirst() then begin
                            PostedPurchInv.SetRecord(PurchInvHeader);
                            PostedPurchInv.Run();
                        end;
                    end;
                }
                field("Payable Reversal No."; Rec."Payable Reversal No.")
                {
                    ApplicationArea = All;
                    Editable = false;
                }
                field("Comm. Payment Doc. No."; rec."Comm. Payment Doc. No.")
                {
                    ApplicationArea = All;
                    Editable = false;
                    Caption = 'Commission Payment No.';
                    trigger OnDrillDown()
                    var
                        PaymentJournal: Page "Payment Journal";
                        GenJnlLine: Record "Gen. Journal Line";
                    begin
                        GenJnlLine.Reset();
                        GenJnlLine.SetRange("Document Type", GenJnlLine."Document Type"::Payment);
                        GenJnlLine.SetRange(GenJnlLine."Document No.", Rec."Comm. Payment Doc. No.");
                        if GenJnlLine.FindFirst() then begin
                            PaymentJournal.SetRecord(GenJnlLine);
                            PaymentJournal.Run();
                        end;
                    end;
                }
                field("Payable Due Date"; Rec."Payable Due Date")
                {
                    ApplicationArea = all;
                    Enabled = false;
                }
                field("Settlement Type"; Rec."Settlement Type")
                {
                    ApplicationArea = all;
                    Enabled = false;
                }
                field("Payment Method Code"; Rec."Payment Method Code")
                {
                    ApplicationArea = all;
                    Enabled = false;
                }
                field("PDC Bank Account No."; Rec."PDC Bank Account No.")
                {
                    ApplicationArea = all;
                    Caption = 'Bank Account No.';
                    Enabled = false;


                }
            }
            part(CommWSSLines; "Commission WS Subform")
            {
                ApplicationArea = All;
                SubPageLink = "Document No." = field("Document No.");
                Editable = rec.Status = rec.Status::Calculated;
                Caption = 'Commission WS Lines';
                UpdatePropagation = Both;

            }

            group("Commission Details")
            {

                field("Total Commission Base"; Rec."Total Commission Base")
                {
                    ApplicationArea = All;
                    Editable = false;
                    Caption = 'Total Commission Base';
                    Style = Unfavorable;
                }
                field("Total Application Amount"; Rec."Total Application Amount")
                {
                    ApplicationArea = All;
                    Editable = false;

                }
                field("Total Commission Amount"; Rec."Total Commission Amount")
                {
                    ApplicationArea = all;
                    Editable = false;
                }
                field("Total Commission Amount (LCY)"; Rec."Total Commission Amount (LCY)")
                {
                    ApplicationArea = All;
                    Editable = false;
                    Style = Favorable;

                }

            }


        }
    }

    actions
    {
        area(Processing)
        {

            group(Function)
            {

                action(Calculate)
                {
                    ApplicationArea = All;
                    Caption = 'Calculate Commission';
                    Image = Calculate;
                    Promoted = true;
                    PromotedCategory = Process;
                    PromotedIsBig = true;

                    trigger OnAction()
                    var
                        rptCommCalculation: Report "Commission Worksheet Calc";
                    begin

                        //rec.TestField(rec."Scheme Code");
                        Rec.TestField(rec."Document No.");
                        Rec.TestField(rec.Status, rec.Status::Open);
                        if Confirm('Proceed to Commission Calculation?', false) then begin
                            Commit();
                            rptCommCalculation.SetCommWorksheet(Rec);
                            rptCommCalculation.Run();
                            CurrPage.Update(true);
                        end;
                    end;
                }
                action(ClearCalc)
                {
                    ApplicationArea = All;
                    Caption = 'Clear Commission';
                    Image = ClearLog;
                    Promoted = true;
                    PromotedCategory = Process;
                    PromotedIsBig = true;

                    trigger OnAction()
                    var
                        CommWSSalesInvLine: Record "Commission Worksheet Lines";
                        SalesInvHeader: Record "Sales Invoice Header";
                    begin

                        Rec.TestField(rec.Status, rec.Status::Calculated);
                        if Confirm('Proceed to Commission Clearing?', false) then begin
                            CommWSSalesInvLine.Reset();
                            CommWSSalesInvLine.SetRange("Document No.", Rec."Document No.");
                            if CommWSSalesInvLine.FindSet() then
                                repeat
                                    SalesInvHeader.Reset();
                                    SalesInvHeader.SetRange("No.", CommWSSalesInvLine."Inv, Document No.");
                                    if SalesInvHeader.FindFirst() then begin
                                        SalesInvHeader."Commission Computed" := false;
                                        SalesInvHeader.Modify();

                                    end;
                                until CommWSSalesInvLine.Next() = 0;

                            CommWSSalesInvLine.Reset();
                            CommWSSalesInvLine.SetRange("Document No.", Rec."Document No.");
                            if CommWSSalesInvLine.FindSet() then
                                CommWSSalesInvLine.DeleteAll();

                            Rec."Agreement Period" := 0;
                            Rec."Settlement Type" := Rec."Settlement Type"::"Full Payment";
                            rec."Vendor No.  (SalesPerson)" := '';
                            rec."Vendor Name (SalesPerson)" := '';
                            rec."Commission Agreement No." := '';
                            rec."Commission %" := 0;
                            rec."Invoice Date From" := 0D;
                            rec."Payment Method Code" := '';
                            rec."PDC Bank Account No." := '';
                            rec."Invoice Date To" := 0D;
                            Rec.Status := Rec.Status::Open;
                            Rec.Modify();

                            Message('Commission has been cleared already!');

                        end;
                    end;
                }
                group(Release)
                {
                    action(Release2)
                    {
                        ApplicationArea = All;
                        Caption = 'Re&lease';
                        Image = ReleaseDoc;
                        Promoted = true;
                        PromotedCategory = Category5;
                        PromotedOnly = true;
                        PromotedIsBig = true;
                        ToolTip = 'Release the document to the next stage of processing. You must reopen the document before you can make changes to it.';

                        trigger OnAction()
                        begin

                            rec.TestField(Status, rec.Status::Calculated);
                            rec.Status := Rec.Status::Released;
                            Rec.Modify();
                            CurrPage.Update(false);
                        end;
                    }
                    action(Reopen)
                    {
                        ApplicationArea = All;
                        Caption = 'Re&open';
                        Enabled = rec.Status <> rec.Status::Open;
                        Image = ReOpen;
                        Promoted = true;
                        PromotedCategory = Category5;
                        PromotedOnly = true;
                        PromotedIsBig = true;
                        ToolTip = 'Reopen the document to change it after it has been approved. Approved documents have the Released status and must be opened before they can be changed';

                        trigger OnAction()
                        var
                            ReleasePurchDoc: Codeunit "Release Purchase Document";
                        begin
                            rec.TestField(Status, rec.Status::Released);
                            rec.Status := Rec.Status::Calculated;
                            Rec.Modify();
                            CurrPage.Update(false);
                        end;

                    }
                }

            }
            group("Payable and Payment Creation")
            {

                action(CreatePI)
                {
                    ApplicationArea = All;
                    Caption = 'Create Payable'; // create PI
                    Promoted = true;
                    PromotedIsBig = true;
                    PromotedCategory = Category4;
                    image = NewPurchaseInvoice;
                    trigger OnAction()
                    var
                        CommMgnt: Codeunit "FTT-CST Commission Mgt.";
                    begin
                        Rec.TestField(Status, Rec.Status::Released);

                        if Confirm('Proceed with Payable Creation?', false) then begin
                            rec.CalcFields("Total Application Amount");
                            CommMgnt.CreatePurchasheInvoice(rec."Total Application Amount", Rec);
                        end;

                    end;
                }
                action(CreatePayment)
                {
                    ApplicationArea = All;
                    Caption = 'Create Payment'; //create payment
                    Promoted = true;
                    PromotedIsBig = true;
                    PromotedCategory = Category4;
                    Image = "Invoicing-Payment";
                    Visible = true;
                    trigger OnAction()
                    var
                        CommMgnt: Codeunit "FTT-CST Commission Mgt.";
                        CommSetup: Record "FTT-CST Commission Agr. Setup";
                        Selected: Integer;
                        PurchCrmMemo: Record "Purch. Cr. Memo Hdr.";
                    begin
                        if not CommSetup.Get() then
                            exit;

                        Rec.TestField(Status, Rec.Status::"Payable Posted");
                        if not CheckPayableisReversed() then begin
                            if Confirm('Proceed with Payment Creation?', false) then begin
                                CommMgnt.CreatePayment(Rec);
                                if CommSetup."Create & Post Payment" then
                                    Message('Commission Payment has been posted succesfully.');
                            end;
                        end else begin

                            PurchCrmMemo.Reset();
                            PurchCrmMemo.SetRange("Comm. Document No.", Rec."Document No.");
                            if PurchCrmMemo.FindFirst() then begin
                                Rec."Payable Reversal No." := PurchCrmMemo."No.";
                                Rec.Status := Rec.Status::"Payable Reversed";
                                Rec.Modify();
                                RemoveTagInvoices;
                            end;
                            Commit();
                            Error('Payable has been reversed already.');
                        end;
                    end;
                }

            }
            action(CheckReversal)
            {
                ApplicationArea = All;
                Caption = 'Check Reversal';
                Image = CheckJournal;
                Promoted = true;
                PromotedIsBig = true;
                PromotedCategory = Process;
                trigger OnAction()
                var
                    VendorLedgerEntry: Record "Vendor Ledger Entry";
                    PurchCrmMemo: Record "Purch. Cr. Memo Hdr.";
                begin
                    if rec.Status = rec.Status::"Payment Posted" then begin
                        VendorLedgerEntry.Reset();
                        VendorLedgerEntry.SetRange("Document Type", VendorLedgerEntry."Document Type"::Payment);
                        VendorLedgerEntry.SetRange("Document No.", rec."Comm. Payment Doc. No.");
                        if VendorLedgerEntry.FindFirst() then begin
                            if VendorLedgerEntry.Reversed then begin
                                Rec.Status := Rec.Status::"Payment Reversed";
                                Rec.Modify();
                                Commit();
                                ReversedtheLine;
                                RemoveTagInvoices;
                                //Message('Payment is already reversed.');
                                Message('Succesfully tagged this worksheet %1 as reversed!', rec."Document No.");
                            end else
                                Error('Payment No. %1 must be reversed.', Rec."Comm. Payment Doc. No.");
                        end;
                        if CheckPayableisReversed() then begin
                            PurchCrmMemo.Reset();
                            PurchCrmMemo.SetRange("Comm. Document No.", Rec."Document No.");
                            if PurchCrmMemo.FindFirst() then begin
                                Rec."Payable Reversal No." := PurchCrmMemo."No.";
                                Rec.Status := Rec.Status::"Payable Reversed";
                                Rec.Modify();
                                Commit();
                                ReversedtheLine;
                                RemoveTagInvoices;
                                Message('Succesfully tagged this worksheet %1 as reversed!', rec."Document No.");
                            end;

                        end else begin
                            Error('Payable No. %1 must be reversed/cancelled before Commission Worksheet reversal.', rec."Comm. Payable Doc. No.");
                        end;
                    end else
                        if Rec.Status = Rec.Status::"Payable Posted" then begin
                            if CheckPayableisReversed() then begin
                                PurchCrmMemo.Reset();
                                PurchCrmMemo.SetRange("Comm. Document No.", Rec."Document No.");
                                if PurchCrmMemo.FindFirst() then begin
                                    Rec."Payable Reversal No." := PurchCrmMemo."No.";
                                    Rec.Status := Rec.Status::"Payable Reversed";
                                    Rec.Modify();
                                    Commit();
                                    ReversedtheLine;
                                    RemoveTagInvoices;
                                    Message('Succesfully tagged this worksheet %1 as reversed!', rec."Document No.");
                                end;


                            end else begin
                                Error('Payable No. %1 must be reversed/cancelled before Commission Worksheet reversal.', rec."Comm. Payable Doc. No.");
                            end;
                        end else begin
                            Message('Status must be Payable Posted or Payment Posted to check reversal.');
                        end;
                end;
            }

        }
    }

    var
        myinteger: integer;


    local procedure ReversedtheLine()
    var
        recCommSalesInvLine: Record "Commission Worksheet Lines";
    begin
        recCommSalesInvLine.Reset();
        recCommSalesInvLine.SetRange("Document No.", rec."Document No.");
        if recCommSalesInvLine.FindFirst() then
            repeat
                recCommSalesInvLine."Application Amount" := recCommSalesInvLine."Application Amount" * -1;
                recCommSalesInvLine.Modify();
            until recCommSalesInvLine.Next() = 0;

    end;

    local procedure RemoveTagInvoices()
    var
        CommAppliesToDoc: Record "Commission Worksheet Lines";
        SalesInvHeader: Record "Sales Invoice Header";
    begin
        CommAppliesToDoc.Reset();
        CommAppliesToDoc.SetRange(CommAppliesToDoc."Document No.", Rec."Document No.");
        if CommAppliesToDoc.FindSet() then
            repeat

                SalesInvHeader.Reset();
                SalesInvHeader.SetRange("No.", CommAppliesToDoc."Inv, Document No.");
                if SalesInvHeader.FindFirst() then begin
                    SalesInvHeader."Commission Computed" := false;
                    SalesInvHeader.Modify();
                    //CommAppliesToDoc.Delete();
                end;
            until CommAppliesToDoc.Next() = 0;
    end;

    local procedure CheckPayableisReversed(): Boolean
    var
        PurchInvHEader: Record "Purch. Inv. Header";
    begin
        PurchInvHEader.Reset();
        PurchInvHEader.SetRange("No.", Rec."Comm. Payable Doc. No.");
        if PurchInvHEader.FindFirst() then begin
            PurchInvHEader.CalcFields(Cancelled);
            exit(PurchInvHEader.Cancelled);
        end;
    end;

    trigger OnDeleteRecord(): Boolean
    begin
        Rec.TestField(Status, Rec.Status::Open);
    end;

}