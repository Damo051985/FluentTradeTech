page 50010 "GMAIL Sent factbox"
{

    PageType = ListPart;
    SourceTable = "GMAIL Email Relation";
    SourceTableView = WHERE("Email Type" = filter('Sent'));
    Permissions = tabledata "Sent Email" = r;
    layout
    {
        area(Content)
        {
            repeater(Group)
            {
                field(Subject; Rec.Subject)
                {
                    ApplicationArea = All;
                    trigger OnDrillDown()
                    var
                        recGmailInboundOutbound: Record "Gmail Inbound/Outbound";
                        recSentEmail: Record "Sent Email";
                    begin
                        if rec."Email Type" = rec."Email Type"::Sent then begin
                            if rec."Email Type" = rec."Email Type"::Sent then begin
                                if not recGmailInboundOutbound.Get(rec."Inbox Entry No.") then
                                    exit;
                                OpenReceived(recGmailInboundOutbound);
                            end;
                        end;

                    end;

                }
                field("Date Sent"; Rec."Date Sent")
                {
                    ApplicationArea = all;
                }
                field("Sent From"; Rec."Sent From")
                {
                    ApplicationArea = all;
                }
                field("Sent To"; Rec."Sent To")
                {
                    ApplicationArea = all;
                }


            }
        }

    }

    actions
    {
        area(Processing)
        {
            group(Gmail)
            {
                action(GMAILSent)
                {
                    ApplicationArea = All;
                    Caption = 'Gmail Sent Email';
                    Image = Email;
                    RunObject = page "GMAIL Sent Emails";
                }
            }
        }

    }


    trigger OnOpenPage()
    begin
        Rec.SetCurrentKey("Thread ID");
        Rec.Ascending(false);

    end;

    procedure OpenReceived(ReceivedEmail: Record "Gmail Inbound/Outbound")
    var
        EmailViewer: Page "Email Inbox Viewer";
    begin
        EmailViewer.SetRecord(ReceivedEmail);
        EmailViewer.Run();
    end;
}