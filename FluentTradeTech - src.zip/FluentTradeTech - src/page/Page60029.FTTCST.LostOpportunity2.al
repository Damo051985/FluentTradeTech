page 60029 LostOpportunity2
{
    ApplicationArea = Basic, Suite, Assembly;
    Caption = 'Lost Opportunity Report';
    PageType = Card;
    SourceTable = "LostOpportunityTable";
    UsageCategory = Lists;
    Editable = true;
    RefreshOnActivate = true;
    SourceTableView = where("Line Type" = filter(Header));

    layout
    {
        area(Content)
        {
            group(General)
            {
                Caption = 'General';
            }
            part("LostOppo2"; "LostOpportunity2Subform")
            {
                ApplicationArea = Basic, Suite;
            }
            part("LostOppo3"; "LostOppoSubform3")
            {
                ApplicationArea = Basic, Suite;
            }
        }
    }
    actions
    {
        area(navigation)
        {
            action("UpdateLost")
            {
                Caption = 'Update Lost Opportunity Report';
                ApplicationArea = all;
                Visible = True;
                trigger OnAction()
                var
                    lLostOpp: Codeunit LostOpportunity;
                begin
                    Clear(lLostOpp);
                    lLostOpp.LostTotalRevenue();
                    Message('Done Updating');
                end;
            }
        }
    }
    trigger OnOpenPage()
    var
        lLostOpp: Codeunit LostOpportunity;
        lLostOppTable: Record LostOpportunityTable;
    Begin
        gVis := False;
        IF UserId = 'DO' then
            gVis := TRUE;

        Clear(lLostOpp);
        lLostOpp.LostTotalRevenue();
    End;

    var
        RevRep: Record "Revenue Report";
        gVis: Boolean;
}
