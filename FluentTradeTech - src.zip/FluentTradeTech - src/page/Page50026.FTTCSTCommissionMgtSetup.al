page 50026 "Commission Agreement Setup"
{
    PageType = Card;
    ApplicationArea = All;
    UsageCategory = Administration;
    SourceTable = "FTT-CST Commission Agr. Setup";
    RefreshOnActivate = true;
    Caption = 'Commission Agreement Setup';

    layout
    {

        area(Content)
        {
            group(General)
            {
                field("PI Create/Post"; Rec."PI Create/Post")
                {
                    ApplicationArea = all;

                }
                field("Create & Post Payment"; Rec."Create & Post Payment")
                {
                    ApplicationArea = all;
                }
                field("Credit Memo Adjustment"; Rec."Credit Memo Adjustment")
                {
                    ApplicationArea = all;
                }

            }

            group("Number Series")
            {
                field("Comm. Agreement Nos."; Rec."Comm. Agreement Nos.")
                {
                    ApplicationArea = all;
                    ShowMandatory = true;
                }
                field("Comm. WS Nos."; Rec."Comm. WS Nos.")
                {
                    ApplicationArea = all;
                    ShowMandatory = true;
                }
                field("Comm. SV Nos."; Rec."Comm. SV Nos.")
                {
                    ApplicationArea = all;
                    ShowMandatory = true;
                }

            }
            group("Claimed")
            {
                field("Payable G/L Account No."; Rec."Payable G/L Account No.")
                {
                    ApplicationArea = all;
                    ShowMandatory = true;
                }
                field("Default Currency Code"; Rec."Default Currency Code")
                {
                    ApplicationArea = all;
                    ShowMandatory = true;
                }

                group("Sales Person")
                {
                    field("Claimed Journal Batch"; Rec."Claimed Journal Batch")
                    {
                        ApplicationArea = all;
                        ShowMandatory = true;
                    }
                    field("Claimed Jornal Template"; Rec."Claimed Jornal Template")
                    {
                        ApplicationArea = all;
                        ShowMandatory = true;
                    }
                }
                group("Supervisor")
                {
                    field("Claimed SV Journal Batch"; Rec."Claimed SV Journal Batch")
                    {
                        ApplicationArea = all;
                        ShowMandatory = true;
                    }
                    field("Claimed SV Jornal Template"; Rec."Claimed SV Jornal Template")
                    {
                        ApplicationArea = all;
                        ShowMandatory = true;
                    }
                }



            }
        }
    }

    actions
    {
        area(Processing)
        {
            action(DeleteLedgerEntries)
            {
                Visible = false;
                Caption = 'Delete Ledger';
                ApplicationArea = all;
                trigger OnAction()
                var
                    commLedgerEntries: Record "FTT-CST Commission Entries";
                    commdtleldgerentries: Record "FTT-CST Dtldg. Comm. Entries";
                begin
                    commLedgerEntries.DeleteAll();
                    commdtleldgerentries.DeleteAll();
                    Message('done');
                end;
            }
        }
    }

    trigger OnOpenPage()
    var
        UserSetup: Record "User Setup";
    begin
        if not UserSetup.Get(UserId) then
            exit;

        UserSetup.TestField("Commission Full Access", true);

    end;
}