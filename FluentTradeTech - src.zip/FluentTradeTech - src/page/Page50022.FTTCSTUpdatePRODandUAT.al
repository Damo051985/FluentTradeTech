page 50022 "FTT-CST UpdatePRODandUAT"
{
    ApplicationArea = All;
    Caption = 'Update Date For PROD/UAT';
    PageType = StandardDialog;

    layout
    {
        area(Content)
        {
            field("Selected"; Option2)
            {
                ApplicationArea = All;
                Caption = 'Option';
            }

            field("FTT-CST Inv. Starting Date"; StartingDate)
            {
                ApplicationArea = All;
                Caption = 'Date';
            }
        }
    }

    trigger OnQueryClosePage(CloseAction: Action): Boolean
    begin
        if CloseAction = Action::OK then begin
            if StartingDate = 0D then
                Error(StartingDateEmptyErr);
        end;
    end;

    procedure GetDate2(): Date
    begin
        exit(StartingDate);
    end;

    procedure GetOption(): Integer
    begin
        exit(Option2);
    end;

    var
        Option2: Option Prod,UAT;
        StartingDate: Date;
        StartingDateEmptyErr: Label 'Date can not be empty';
}
