page 60013 "FTT-CST Dependency Item"

{
    AdditionalSearchTerms = 'product,finished good,component,raw material,assembly item';
    ApplicationArea = Basic, Suite, Assembly, Service;
    Caption = 'Dependancy Item';
    PageType = ListPart;
    SourceTable = "FTT-CST Dependancy Item";
    SourceTableView = sorting("Location Code", Level) order(ascending);
    UsageCategory = Lists;
    DeleteAllowed = true;
    DelayedInsert = true;
    Editable = true;


    AboutTitle = 'About items';
    AboutText = '**Items** represent the products and services you buy and sell. For each item, you can manage the default sales and purchase prices used when creating documents, as well as track inventory numbers. With [Item Templates](?page=1383 "Opens the Item Templates") you can quickly create new items having common details defined by the template.';

    layout
    {
        area(content)
        {
            repeater(Control1)
            {
                Caption = 'Item';
                field(Level; Rec.Level)
                {
                    ApplicationArea = all;
                    Visible = false;
                }
                field("Location Code"; Rec."Location Code")
                {
                    ApplicationArea = all;

                }
                field("FTT_CST Sublocation"; Rec."FTT-CST Sublocation")
                {
                    ApplicationArea = all;
                }

                field("No."; Rec."No.")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies a number to identify the item. You can use ranges of item numbers to logically group products or to imply information about them. Or use simple numbers and item categories to group items.';
                }
                field(Description; Rec.Description)
                {
                    ApplicationArea = All;
                    Editable = false;
                    ToolTip = 'Specifies a default text to describe the item on related documents such as orders or invoices. You can translate the descriptions so that they show up in the language of the customer or vendor.';
                }
                field("Integr."; Rec."Integr.") //NRD
                {
                    ApplicationArea = all;
                }
                field(Redundancy; Rec.Redundancy)
                {
                    ApplicationArea = all;
                }
                field(DR; Rec.DR)
                {
                    ApplicationArea = all;
                }
                field("FTT-CST Quantity"; Rec."FTT-CST Quantity")
                {
                    ApplicationArea = Invoicing, Basic, Suite;
                    ToolTip = 'Specifies the Quantity for the item';
                }
                field("Unit Price"; Rec."Unit Price")
                {
                    ApplicationArea = Invoicing, Basic, Suite;
                    ToolTip = 'Specifies the price for one unit of the item, in LCY.';
                }
                field("DR\Redundancy %"; Rec."FTT-CST RED/DR PriceCalc %")
                {
                    ApplicationArea = Invoicing, Basic, Suite;
                    ToolTip = 'Specifies the DR\Redundancy % for the item, in %';
                    Caption = '%';
                }
                field(Optional; Rec.Optional)
                {

                }
                field("FTT-CST Comments Fluent"; Rec."FTT-CST Comments Fluent")
                {

                }
                field(Comments; Rec."FTT-CST Comments")
                {

                }
                field("Item Group Code"; ShowItemGroupCode(Rec."No."))
                {
                    Editable = false;
                }
            }
        }
    }
    //NRD
    local procedure ShowItemGroupCode(pitemCode: code[20]): Code[20]
    var
        defaultdim: Record "Default Dimension";
    begin
        if not defaultdim.Get(27, pitemCode, 'ITEM GROUP') then
            exit('');

        exit(defaultdim."Dimension Value Code");
    end;
    //+
    procedure SetFilters2(Filter: text[1024]; EntryNo: Integer; LocationCode: code[20]; Level: Integer)
    var
        RecItem: record Item;
        DependancyItem: Record "FTT-CST Dependancy Item";
        ItemModify: Record Item;
        SalesReceivablesSetup: record "Sales & Receivables Setup";
        PageDialog: page "FTT-CST Dialog";
        PriceCalcPerc: Decimal;
    begin
        RecItem.SetFilter("No.", Filter);
        SalesReceivablesSetup.get();
        if RecItem.FindSet() then
            repeat
                DependancyItem.Init();
                DependancyItem.TransferFields(RecItem);
                DependancyItem."Filter No." := EntryNo;
                DependancyItem.Level := Level;
                DependancyItem."Location Code" := LocationCode;
                DependancyItem."FTT-CST Quantity" := RecItem."FTT-CST Quantity";
                if strpos(Format(RecItem."Item Category Code"), 'FEED') > 0 then
                    DependancyItem."FTT-CST FEED" := true;
                DependancyItem.Insert;
                Commit();
                if RecItem."FTT-CST Redundancy PriceCalc %" <> 0 then begin
                    ItemModify.Get(RecItem."No.");
                    Clear(PageDialog);
                    PageDialog.SetValue2(ItemModify."FTT-CST Red. Backup PCalc %", ItemModify."No.");

                    if PageDialog.RunModal() = Action::OK then begin

                        PageDialog.GetValue(PriceCalcPerc);

                        DependancyItem.Get(LocationCode, EntryNo, RecItem."No.");
                        DependancyItem."FTT-CST RED/DR PriceCalc %" := PriceCalcPerc;

                        if RecItem."Item Category Code" = SalesReceivablesSetup."FTT-CST Redundancy Category" then
                            DependancyItem."FTT-CST Redundency" := true;
                        if RecItem."Item Category Code" = SalesReceivablesSetup."FTT-CST DR Category" then
                            DependancyItem."FTT-CST DR" := true;
                        if RecItem."Item Category Code" = SalesReceivablesSetup."FTT-CST Integration Category" then
                            DependancyItem."FTT-CST Integration" := true;

                        ItemModify."FTT-CST Redundancy PriceCalc %" := PriceCalcPerc;
                        ItemModify.Modify();
                        DependancyItem.Modify();
                    end;
                end;
                if RecItem."FTT-CST Integr PriceCalc %" <> 0 then begin
                    ItemModify.Get(RecItem."No.");
                    Clear(PageDialog);
                    PageDialog.SetValue2(ItemModify."FTT-CST Backup Integr. Calc %", ItemModify."No.");
                    if PageDialog.RunModal() = Action::OK then begin
                        PageDialog.GetValue(PriceCalcPerc);
                        DependancyItem.Get(LocationCode, EntryNo, RecItem."No.");
                        DependancyItem."FTT-CST RED/DR PriceCalc %" := PriceCalcPerc;
                        ItemModify."FTT-CST Integr PriceCalc %" := PriceCalcPerc;
                        ItemModify.Modify();
                        DependancyItem.Modify();
                    end;
                end;
            until RecItem.next = 0;
    end;

    procedure SetFilters(Filter: text[1024]; EntryNo: Integer; LocationCode: code[20]; Level: Integer; SalesNo: code[20])
    var
        RecItem: record Item;
        DependancyItem: Record "FTT-CST Dependancy Item";
        ItemModify: Record Item;
        SalesReceivablesSetup: record "Sales & Receivables Setup";
        PageDialog: page "FTT-CST Dialog";
        PriceCalcPerc: Decimal;
    begin
        RecItem.SetFilter("No.", Filter);
        SalesReceivablesSetup.get();
        if RecItem.FindSet() then
            repeat
                DependancyItem.Init();
                DependancyItem.TransferFields(RecItem);
                DependancyItem."Filter No." := EntryNo;
                DependancyItem."FTT-CST Comments Fluent" := RecItem."FTT-CST Comments Fluent";
                DependancyItem.Level := Level;
                case Level of
                    6:
                        begin
                            DependancyItem."FTT-CST Parent Category Code" := 'REDUNDENCY';
                            DependancyItem."FTT-CST Use for Discount" := true;
                        end;
                    7:
                        begin
                            DependancyItem."FTT-CST Parent Category Code" := 'DR';
                            DependancyItem."FTT-CST Use for Discount" := true;
                        end;
                    8:
                        DependancyItem."FTT-CST Parent Category Code" := 'HARDWARE';
                    9:
                        DependancyItem."FTT-CST Parent Category Code" := 'HARDWARE';
                    10:
                        DependancyItem."FTT-CST Parent Category Code" := 'HOSTING';
                    11:
                        DependancyItem."FTT-CST Parent Category Code" := 'INTEGRATION';

                end;

                DependancyItem."Location Code" := LocationCode;
                DependancyItem."FTT-CST Quantity" := RecItem."FTT-CST Quantity";
                if strpos(Format(RecItem."Item Category Code"), 'FEED') > 0 then
                    DependancyItem."FTT-CST FEED" := true;
                DependancyItem.Insert;
                Commit();
                if RecItem."FTT-CST Redundancy PriceCalc %" <> 0 then begin
                    ItemModify.Get(RecItem."No.");
                    Clear(PageDialog);
                    PageDialog.SetValue2(ItemModify."FTT-CST Red. Backup PCalc %", ItemModify."No.");

                    if PageDialog.RunModal() = Action::OK then begin

                        PageDialog.GetValue(PriceCalcPerc);

                        DependancyItem.Get(LocationCode, EntryNo, RecItem."No.");
                        DependancyItem."FTT-CST RED/DR PriceCalc %" := PriceCalcPerc;

                        if RecItem."Item Category Code" = SalesReceivablesSetup."FTT-CST Redundancy Category" then
                            DependancyItem."FTT-CST Redundency" := true;
                        if RecItem."Item Category Code" = SalesReceivablesSetup."FTT-CST DR Category" then
                            DependancyItem."FTT-CST DR" := true;
                        if RecItem."Item Category Code" = SalesReceivablesSetup."FTT-CST Integration Category" then
                            DependancyItem."FTT-CST Integration" := true;

                        ItemModify."FTT-CST Redundancy PriceCalc %" := PriceCalcPerc;
                        ItemModify.Modify();
                        DependancyItem.Modify();
                    end;
                end;

                if RecItem."FTT-CST Integr PriceCalc %" <> 0 then begin
                    ItemModify.Get(RecItem."No.");
                    Clear(PageDialog);
                    PageDialog.SetValue2(ItemModify."FTT-CST Backup Integr. Calc %", ItemModify."No.");
                    if PageDialog.RunModal() = Action::OK then begin
                        PageDialog.GetValue(PriceCalcPerc);
                        DependancyItem.Get(LocationCode, EntryNo, RecItem."No.");
                        DependancyItem."FTT-CST RED/DR PriceCalc %" := PriceCalcPerc;
                        ItemModify."FTT-CST Integr PriceCalc %" := PriceCalcPerc;
                        ItemModify.Modify();
                        DependancyItem.Modify();
                    end;
                end;

            until RecItem.next = 0;
    end;



}