page 50038 "Comm. Worksheet Rev. Card"
{
    PageType = Card;
    SourceTable = "Commission Worksheet Header";
    Caption = 'Comm. Worksheet Reversed Card';
    RefreshOnActivate = true;
    Permissions = tabledata "Cust. Ledger Entry" = rimd,
    tabledata "Detailed Cust. Ledg. Entry" = rimd,
    tabledata "Sales Invoice Header" = rimd,
    tabledata "Sales Invoice Line" = rimd;
    DeleteAllowed = false;

    layout
    {
        area(Content)
        {
            group(General)
            {
                field("Document No."; Rec."Document No.")
                {
                    ApplicationArea = All;
                    Editable = false;
                    Caption = 'Comm. Worksheet No.';
                }
                field("Commission Agreement No."; Rec."Commission Agreement No.")
                {
                    ApplicationArea = all;
                    Editable = false;
                }
                field("Agreement Period"; Rec."Agreement Period")
                {
                    ApplicationArea = all;
                    Editable = false;
                }
                field("Commission %"; Rec."Commission %")
                {
                    ApplicationArea = all;
                    Editable = false;
                    Visible = false;
                }
                field("Invoice Date From"; rec."Invoice Date From")
                {
                    ApplicationArea = All;
                    Editable = rec.Status = rec.Status::Open;
                    Caption = 'Invoice Date Filter From';
                }
                field("Invoice Date To"; rec."Invoice Date To")
                {
                    ApplicationArea = All;
                    Editable = rec.Status = rec.Status::Open;
                    Caption = 'Invoice Date Filter To';
                }

                field(Status; Rec.Status)
                {
                    ApplicationArea = All;
                    Editable = false;
                }
                field("Assigned User ID"; Rec."Assigned User ID")
                {
                    ApplicationArea = all;
                    Editable = false;
                }
                field("Creation Date"; rec."Creation Date")
                {
                    ApplicationArea = All;
                    Editable = false;

                }
            }

            group("Payables and Payment Details")
            {
                field("Vendor No.  (SalesPerson)"; rec."Vendor No.  (SalesPerson)")
                {
                    ApplicationArea = All;
                    Editable = false;
                    ShowMandatory = true;

                }
                field("Vendor Name (SalesPerson)"; rec."Vendor Name (SalesPerson)")
                {
                    ApplicationArea = All;
                    Editable = false;

                }
                field(CommPINo; rec."Comm. PI No.")
                {
                    ApplicationArea = All;
                    Editable = false;
                    Caption = 'Comm. Purchase Invoice No.';

                    trigger OnDrillDown()
                    var
                        PurchInv: Page "Purchase Invoice";
                        PostedPurchInv: page "Posted Purchase Invoice";
                        PurchHeader: Record "Purchase Header";
                        PurchInvHeader: Record "Purch. Inv. Header";
                    begin
                        PurchHeader.Reset();
                        PurchHeader.SetRange("Document Type", PurchHeader."Document Type"::Invoice);
                        PurchHeader.SetRange("No.", Rec."Comm. PI No.");
                        if PurchHeader.FindFirst() then begin
                            PurchInv.SetRecord(PurchHeader);
                            PurchInv.Run();
                        end else begin
                            PurchInvHeader.Reset();
                            PurchInvHeader.SetRange(PurchInvHeader."Pre-Assigned No.", rec."Comm. PI No.");
                            if PurchInvHeader.FindFirst() then begin
                                PostedPurchInv.SetRecord(PurchInvHeader);
                                PostedPurchInv.Run();
                            end;
                        end;
                    end;
                }
                field("Comm. Payable Doc. No."; rec."Comm. Payable Doc. No.")
                {
                    ApplicationArea = All;
                    Editable = false;
                    //FieldPropertyName = FieldPropertyValue;
                    Caption = 'Commission APV No.';
                    trigger OnDrillDown()
                    var
                        PostedPurchInv: Page "Posted Purchase Invoice";
                        PurchInvHeader: Record "Purch. Inv. Header";
                    begin
                        PurchInvHeader.Reset();
                        PurchInvHeader.SetRange("No.", Rec."Comm. Payable Doc. No.");
                        if PurchInvHeader.FindFirst() then begin
                            PostedPurchInv.SetRecord(PurchInvHeader);
                            PostedPurchInv.Run();
                        end;
                    end;
                }
                field("Payable Reversal No."; Rec."Payable Reversal No.")
                {
                    ApplicationArea = All;
                    Editable = false;
                }
                field("Comm. Payment Doc. No."; rec."Comm. Payment Doc. No.")
                {
                    ApplicationArea = All;
                    Editable = false;
                    Caption = 'Commission Payment No.';
                    trigger OnDrillDown()
                    var
                        PaymentJournal: Page "Payment Journal";
                        GenJnlLine: Record "Gen. Journal Line";
                    begin
                        GenJnlLine.Reset();
                        GenJnlLine.SetRange("Document Type", GenJnlLine."Document Type"::Payment);
                        GenJnlLine.SetRange(GenJnlLine."Document No.", Rec."Comm. Payment Doc. No.");
                        if GenJnlLine.FindFirst() then begin
                            PaymentJournal.SetRecord(GenJnlLine);
                            PaymentJournal.Run();
                        end;
                    end;
                }
                field("Payable Due Date"; Rec."Payable Due Date")
                {
                    ApplicationArea = all;
                    Enabled = false;
                }
                field("Settlement Type"; Rec."Settlement Type")
                {
                    ApplicationArea = all;
                    Enabled = false;
                }
                field("Payment Method Code"; Rec."Payment Method Code")
                {
                    ApplicationArea = all;
                    Enabled = false;
                }
                field("PDC Bank Account No."; Rec."PDC Bank Account No.")
                {
                    ApplicationArea = all;
                    Caption = 'Bank Account No.';
                    Enabled = false;


                }
            }
            part(CommWSSLines; "Commission WS Subform")
            {
                ApplicationArea = All;
                SubPageLink = "Document No." = field("Document No.");
                Editable = rec.Status = rec.Status::Calculated;
                Caption = 'Commission WS Lines';
                UpdatePropagation = Both;

            }

            group("Commission Details")
            {

                field("Total Commission Base"; Rec."Total Commission Base")
                {
                    ApplicationArea = All;
                    Editable = false;
                    Caption = 'Total Commission Base';
                    Style = Unfavorable;
                }
                field("Total Application Amount"; Rec."Total Application Amount")
                {
                    ApplicationArea = All;
                    Editable = false;

                }
                field("Total Commission Amount"; Rec."Total Commission Amount")
                {
                    ApplicationArea = all;
                    Editable = false;
                }

                field("Total Commission Amount (LCY)"; Rec."Total Commission Amount (LCY)")
                {
                    ApplicationArea = All;
                    Editable = false;
                    Style = Favorable;

                }

            }


        }
    }


}