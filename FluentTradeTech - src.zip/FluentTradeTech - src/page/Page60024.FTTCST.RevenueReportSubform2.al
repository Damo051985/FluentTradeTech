page 60024 "Revenue Report Subform2"
{
    ApplicationArea = Basic, Suite;
    Caption = 'Over 85%';
    PageType = ListPart;
    SourceTable = "Revenue Report";
    SourceTableView = where("Line Type" = filter("Over 85 %"), Type = filter(<> "Total"));
    Editable = True;

    layout
    {
        area(Content)
        {
            repeater(General)
            {
                field("Type"; Rec."Type")
                {
                    ToolTip = 'Specifies the value of the Type field.';
                    Editable = EditTF;
                    StyleExpr = gStyle;
                }
                field("Salesperson Code"; Rec."Salesperson Code")
                {
                    ToolTip = 'Specifies the value of the Salesperson Code field.';
                    Editable = EditTF;
                    StyleExpr = gStyle;
                }
                field("Customer/Prospect"; Rec."Customer/Prospect")
                {
                    ToolTip = 'Specifies the value of the Customer/Prospect field.';
                    Editable = EditTF;
                    StyleExpr = gStyle;
                }
                field("ARR - Previous Contracts"; Rec."ARR - Previous Contracts")
                {
                    ToolTip = 'Specifies the value of the ARR - Previous Contracts field.';
                    StyleExpr = gStyle;
                    Editable = False;
                    DecimalPlaces = 2 : 2;
                    trigger OnDrillDown()
                    var
                        lSH: Record "Sales Header";
                        lSL: Record "Sales Line";
                        lSL2: Record "Sales Line";
                        lSLp: Page "Sales Lines";
                    Begin
                        IF (Rec."Document No." = '') OR (Rec."ARR - Previous Contracts" = 0) then
                            Exit;
                        CLEAR(lSL);
                        lSL.SetRange("Document Type", Rec."Document type");
                        lSL.Setfilter("Document No.", Rec."Document No.");
                        lSL.SetRange("FTT-CST Optional", lSL."FTT-CST Optional"::No);
                        lSL.SETFILTER("FTT-CST Cost Type", '<>%1', lSL."FTT-CST Cost Type"::NRC);
                        IF lSL.FindSet() THEN BEGIN
                            Clear(lSLp);
                            lSLp.SetTableView(lSL);
                            lSLp.RUN;
                        END;
                    End;
                }

                field("ARR - Additional Products"; Rec."ARR - Additional Products")
                {
                    ToolTip = 'Specifies the value of the ARR - Additional Products field.';
                    StyleExpr = gStyle;
                    Editable = False;
                    DecimalPlaces = 2 : 2;
                    trigger OnDrillDown()
                    var
                        lSH: Record "Sales Header";
                        lSL: Record "Sales Line";
                        lSL2: Record "Sales Line";
                        lSLp: Page "Sales Lines";
                    Begin
                        IF (Rec."DocNo.2" = '') OR (Rec."ARR - Additional Products" = 0) then
                            Exit;
                        CLEAR(lSL);
                        lSL.SetRange("Document Type", Rec."DocType2");
                        lSL.Setfilter("Document No.", Rec."DocNo.2");
                        lSL.SetRange("FTT-CST Optional", lSL."FTT-CST Optional"::No);
                        lSL.SETFILTER("FTT-CST Cost Type", '<>%1', lSL."FTT-CST Cost Type"::NRC);
                        IF lSL.FindSet() THEN BEGIN
                            Clear(lSLp);
                            lSLp.SetTableView(lSL);
                            lSLp.RUN;
                        END;
                    End;
                }
                field("ARR Contract in Progress"; Rec."ARR Contract in Progress")
                {
                    ToolTip = 'Specifies the value of the ARR Contract in Progress field.';
                    StyleExpr = gStyle;
                    Editable = False;
                    DecimalPlaces = 2 : 2;
                    trigger OnDrillDown()
                    var
                        lSH: Record "Sales Header";
                        lSL: Record "Sales Line";
                        lSL2: Record "Sales Line";
                        lSLp: Page "Sales Lines";
                        lopp: Record Opportunity;
                        lOppPg: Page "Opportunity Card";
                        lOppEntList: Page "Opportunity Entry List";
                        lOppEnt: Record "Opportunity Entry";
                    Begin
                        CLEAR(lSL);
                        IF (Rec."DocNo.3" = '') OR (Rec."ARR Contract in Progress" = 0) then
                            Exit;
                        lSL.SetRange("Document Type", Rec."DocType3");
                        lSL.Setfilter("Document No.", Rec."DocNo.3");
                        lSL.SetRange("FTT-CST Optional", lSL."FTT-CST Optional"::No);
                        lSL.SETFILTER("FTT-CST Cost Type", '<>%1', lSL."FTT-CST Cost Type"::NRC);
                        IF lSL.FindSet() THEN BEGIN
                            Clear(lSLp);
                            lSLp.SetTableView(lSL);
                            lSLp.RUN;
                        END else begin
                            Clear(lOppEntList);
                            Clear(lOppEnt);
                            lOppEnt.SETFILTER("Opportunity No.", Rec."DocNo.3");
                            IF lOppEnt.FINDSET then BEGIN
                                lOppEntList.SetTableView(lOppEnt);
                                lOppEntList.RUN;
                            End;
                        end;
                    End;
                }
                field("NRC Contract in Progress"; Rec."NRC Contract in Progress")
                {
                    ToolTip = 'Specifies the value of the NRC Contract in Progress field.';
                    StyleExpr = gStyle;
                    Editable = False;
                    DecimalPlaces = 2 : 2;
                    trigger OnDrillDown()
                    var
                        lSH: Record "Sales Header";
                        lSL: Record "Sales Line";
                        lSL2: Record "Sales Line";
                        lSLp: Page "Sales Lines";
                        lopp: Record Opportunity;
                        lOppPg: Page "Opportunity Card";
                        lOppEntList: Page "Opportunity Entry List";
                        lOppEnt: Record "Opportunity Entry";
                    Begin
                        CLEAR(lSL);
                        Clear(lSLp);
                        IF (Rec."DocNo.4" = '') OR (Rec."NRC Contract in Progress" = 0) then
                            Exit;
                        lSL.SetRange("Document Type", Rec."DocType4");
                        lSL.Setfilter("Document No.", Rec."DocNo.4");
                        lSL.SetRange("FTT-CST Optional", lSL."FTT-CST Optional"::No);
                        lSL.SETFILTER("FTT-CST Cost Type", '%1', lSL."FTT-CST Cost Type"::NRC);
                        IF lSL.FindSet() THEN BEGIN
                            Clear(lSLp);
                            lSLp.SetTableView(lSL);
                            lSLp.RUN;
                        END else begin
                            Clear(lOppEntList);
                            Clear(lOppEnt);
                            lOppEnt.SETFILTER("Opportunity No.", Rec."DocNo.3");
                            IF lOppEnt.FINDSET then BEGIN
                                lOppEntList.SetTableView(lOppEnt);
                                lOppEntList.RUN;
                            End;
                        end;
                    End;
                }
                field("ARR Total Revenue"; Rec."ARR Total Revenue")
                {
                    ToolTip = 'Specifies the value of the ARR Total Revenue field.';
                    StyleExpr = 'Strong';
                    Editable = False;
                    DecimalPlaces = 2 : 2;
                }
                field("NRC Total Revenue"; Rec."NRC Total Revenue")
                {
                    ToolTip = 'Specifies the value of the NRC Total Revenue field.';
                    StyleExpr = 'Strong';
                    Editable = False;
                    DecimalPlaces = 2 : 2;
                }
                field(Connectivity; Rec.Connectivity)
                {
                    ToolTip = 'Specifies the value of the Connectivity field.';
                    StyleExpr = gStyle;
                    Editable = False;
                    DecimalPlaces = 2 : 2;
                }
                field(Distribution; Rec.Distribution)
                {
                    ToolTip = 'Specifies the value of the Distribution field.';
                    StyleExpr = gStyle;
                    Editable = False;
                    DecimalPlaces = 2 : 2;
                }
                field("Risk and Others"; Rec."Risk and Others")
                {
                    ToolTip = 'Specifies the value of the Risk and Others field.';
                    StyleExpr = gStyle;
                    Editable = False;
                    DecimalPlaces = 2 : 2;
                }
                field("Other YRC"; Rec."Other YRC")
                {
                    ToolTip = 'Specifies the value of the Other YRC field.';
                    StyleExpr = gStyle;
                    Editable = False;
                    DecimalPlaces = 2 : 2;
                }

                field("Line Type"; Rec."Line Type")
                {
                    ToolTip = 'Specifies the value of the Line Type field.';
                    Visible = False;
                    Editable = False;
                    StyleExpr = gStyle;
                }
                field("New Proj. Stage"; Rec."New Proj. Stage")
                {
                    ToolTip = 'Specifies the value of the New Project Stage field.';
                    Visible = False;
                    Editable = False;
                    StyleExpr = gStyle;
                }
                field("internal Comments"; Rec."Internal Comments")
                {
                    ToolTip = 'Specifies the value of the Internal Comments field.';
                    StyleExpr = gStyle;
                }
            }
        }
    }
    Trigger OnOpenPage()
    var
        lrev: Record "Revenue Report";
    Begin
        Clear(CustSubs);
        CustSubs.GETSOPrimaryHosted85percentPrimRen;
        CustSubs.GETSOPrimaryHosted85percentPrimRen2;
        lRev."Customer/Prospect" := 'Total for Over 85 %';
        lRev.Type := lRev.Type::Total;
        lRev."Line Type" := lRev."Line Type"::"Over 85 %";
        IF lRev.Insert THEN;
    End;

    Trigger OnAfterGetCurrRecord()
    var
        lSL: Record "Sales Line";
    Begin
        IF (Rec.Type = Rec.Type::"Grand Total") or (Rec.Type = Rec.Type::"Total") then
            EditTF := False
        Else
            EditTF := True;
    End;

    trigger OnInsertRecord(BelowxRec: Boolean): Boolean
    var
    Begin
        IF (Rec.Type = Rec.Type::"Grand Total") or (Rec.Type = Rec.Type::"Total") THEN
            Error('Not allowed to insert Total!');
    End;

    trigger OnAfterGetRecord()
    var
    Begin
        IF Rec.Type = Rec.Type::Total then
            gStyle := 'Strong'
        Else
            gStyle := 'Standard';
    End;

    Trigger OnDeleteRecord(): Boolean
    var
    Begin
        IF (Rec.Type = Rec.Type::"Grand Total") or (Rec.Type = Rec.Type::"Total") THEN
            Error('Not allowed to delete Total!');
    End;

    var
        CustSubs: Codeunit FTTCSTCustomSubcriber;
        EditTF: Boolean;
        gStyle: Text[30];
}
