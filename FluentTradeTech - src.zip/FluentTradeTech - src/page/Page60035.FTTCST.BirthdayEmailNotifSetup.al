page 60035 "Birthday Email Notif. List"
{
    ApplicationArea = Basic, Suite;
    Caption = 'Birthday Email Notification List';
    PageType = List;
    SourceTable = "Birthday Email Notif. Setup";
    UsageCategory = Lists;
    Editable = False;
    CardPageId = "Bday Email Notif. Setup";
    ModifyAllowed = False;

    layout
    {
        area(Content)
        {
            repeater(General)
            {
                field("User ID"; Rec."User ID")
                {
                    ToolTip = 'Specifies the value of the User ID field.';
                    ApplicationArea = Basic, Suite;
                    LookupPageID = "User Lookup";
                }
                field("Full Name"; Rec."Full Name")
                {
                    ToolTip = 'Specifies the value of the Full Name field.';
                    ApplicationArea = Basic, Suite;
                }
                field(Designation; Rec.Designation)
                {
                    ToolTip = 'Specifies the value of the Designation field.';
                    ApplicationArea = Basic, Suite;
                }
                field(Approver; Rec.Approver)
                {
                    ToolTip = 'Specifies the value of the Approver field.';
                    ApplicationArea = Basic, Suite;
                    LookupPageID = "User Lookup";
                }
                field(ApproverName; Rec."Approver Name")
                {
                    ToolTip = 'Specifies the value of the Approver Name field.';
                }
                field(Subject; Rec.Subject)
                {
                    ToolTip = 'Specifies the value of the Subject field.';
                    ApplicationArea = Basic, Suite;
                }
                field("Top Greetings"; Rec."Top Greetings")
                {
                    ToolTip = 'Specifies the value of the Top Greetings field.';
                    ApplicationArea = Basic, Suite;
                }
                field("Bottom Greetings"; Rec."Bottom Greetings")
                {
                    ToolTip = 'Specifies the value of the Bottom Greetings field.';
                    ApplicationArea = Basic, Suite;
                }
                field("Greetings From"; Rec."Greeting From")
                {
                    ToolTip = 'Specifies the value of the Greetings From field.';
                    ApplicationArea = Basic, Suite;
                }
                field("Email Body 1"; Rec."Email Body 1")
                {
                    ToolTip = 'Specifies the value of the Email Body 1 field.';
                    ApplicationArea = Basic, Suite;
                }
                field("Email Body 2"; Rec."Email Body 2")
                {
                    ToolTip = 'Specifies the value of the Email Body 2 field.';
                    ApplicationArea = Basic, Suite;
                }
                field("Email Body 3"; Rec."Email Body 3")
                {
                    ToolTip = 'Specifies the value of the Email Body 3 field.';
                    ApplicationArea = Basic, Suite;
                }
                field("Email Body 4"; Rec."Email Body 4")
                {
                    ToolTip = 'Specifies the value of the Email Body 4 field.';
                    ApplicationArea = Basic, Suite;
                }
                field("Email Body 5"; Rec."Email Body 5")
                {
                    ToolTip = 'Specifies the value of the Email Body 5 field.';
                    ApplicationArea = Basic, Suite;
                    Visible = False;
                }
                field("Email Body 6"; Rec."Email Body 6")
                {
                    ToolTip = 'Specifies the value of the Email Body 6 field.';
                    ApplicationArea = Basic, Suite;
                    Visible = False;
                }
                field("Email Body 7"; Rec."Email Body 7")
                {
                    ToolTip = 'Specifies the value of the Email Body 7 field.';
                    ApplicationArea = Basic, Suite;
                    Visible = False;
                }
                field("Emoji 1"; Rec."Emoji 1")
                {
                    Caption = 'Image 1';
                    ToolTip = 'Specifies the value of the Emoji 1 field.';
                    ApplicationArea = Basic, Suite;
                    Visible = False;
                    Trigger OnValidate()
                    var
                    Begin
                        CurrPage.SAVERECORD;
                    End;
                }
                field("Emoji 2"; Rec."Emoji 2")
                {
                    Caption = 'Image 2';
                    ToolTip = 'Specifies the value of the Emoji 2 field.';
                    ApplicationArea = Basic, Suite;
                    Visible = False;
                    Trigger OnValidate()
                    var
                    Begin
                        CurrPage.SAVERECORD;
                    End;
                }
                field("Picture Length"; Rec."Picture Length")
                {
                    ToolTip = 'Specifies the value of the Picture Length field.';
                    ApplicationArea = Basic, Suite;
                    Visible = False;
                }
                field("Date Period"; Rec."Date Period")
                {
                    ToolTip = 'Specifies the value of the Date Period field.';
                }
                field("notif Date"; Rec."notification Date")
                {
                    ToolTip = 'Specifies the value of the Notification Date field.';
                }
                field(Comment; Rec.Comment)
                {
                    ToolTip = 'Specifies the value of the Comment field.';
                    ApplicationArea = Basic, Suite;
                }
            }
        }
    }
    actions
    {
        area(processing)
        {
            action(DeletePicture1)
            {
                ApplicationArea = All;
                Caption = 'Delete image 1';
                Visible = False;
                trigger OnAction()
                begin
                    IF Confirm('The image 1 will be delete, Do you wish to continue?') THEn begin
                        Clear(rec."Emoji 1");
                        Rec.Modify;
                    end;
                end;
            }
            action(DeletePicture2)
            {
                ApplicationArea = All;
                Caption = 'Delete image 2';
                Visible = False;
                trigger OnAction()
                begin
                    IF Confirm('The image 2 will be delete, Do you wish to continue?') THEn begin
                        Clear(rec."Emoji 2");
                        Rec.Modify;
                    end;
                end;
            }
            action("TestBdayNotif")
            {
                Caption = 'Test Bday Notification';
                ApplicationArea = all;
                Visible = False;
                trigger OnAction()
                var
                    lBdayEmailNotif: Codeunit "Birthday Email Notification";
                Begin
                    Clear(lBdayEmailNotif);
                    lBdayEmailNotif.BirthdayNotification();
                End;
            }
        }
    }

    var

}
