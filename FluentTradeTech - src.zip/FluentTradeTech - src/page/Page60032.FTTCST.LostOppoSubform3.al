page 60032 LostOppoSubform3
{
    ApplicationArea = Basic, Suite;
    Caption = 'Grand Total';
    PageType = ListPart;
    SourceTable = LostOpportunityTable;
    SourceTableView = where("Line Type" = filter(Total));
    Editable = TRUE;
    DeleteAllowed = False;
    InsertAllowed = False;
    ModifyAllowed = False;
    //RefreshOnActivate = true;
    layout
    {
        area(Content)
        {
            repeater(General)
            {
                field(Prospect; Rec.Prospect)
                {
                    ToolTip = 'Specifies the value of the Customer/Prospect field.';
                }
                field(Name; Rec.Name)
                {
                    ToolTip = 'Name of the Prospect';
                }
                field(Description; Rec.Description)
                {
                    ToolTip = 'Specifies the value of the Description field.', Comment = '%';
                }
                field("Lost to"; Rec."Lost to")
                {
                    ToolTip = 'Specifies the value of the Lost to field.', Comment = '%';
                }
                field(Salesperson; Rec.Salesperson)
                {
                    ToolTip = 'Specifies the value of the Salesperson field.', Comment = '%';
                }
                field("Salesperson Name"; Rec."Salesperson Name")
                {
                    ToolTip = 'Specifies the value of the Salesperson Name field.', Comment = '%';
                }
                field("Current Sales Cycle Stage"; Rec."Current Sales Cycle Stage")
                {
                    ToolTip = 'Specifies the value of the Current Sales Cycle Stage field.', Comment = '%';
                }
                field("Closing Date"; Rec."Closing Date")
                {
                    ToolTip = 'Specifies the value of the Closing Date field.', Comment = '%';
                }
                field("Total Revenue"; Rec."Grand Total")
                {
                    ToolTip = 'Specifies the value of the Total Revenue field.';
                    StyleExpr = 'StrongAccent';
                }
            }
        }
    }
    trigger OnOpenPage()
    var
        lLostOpp: Record LostOpportunityTable;
    Begin

        lLostOpp.INIT;
        lLostOpp.Description := '...';
        lLostOpp."Line Type" := lLostOpp."Line Type"::Header;
        IF lLostOpp.INSERT THEN;

        Clear(lLostOpp);
        lLostOpp.INIT;
        lLostOpp.Prospect := '...';
        lLostOpp."Line Type" := lLostOpp."Line Type"::Total;
        IF lLostOpp.INSERT THEN;
    End;
}
