page 50006 "GMAIL Email Inbox Relation"
{
    PageType = List;
    ApplicationArea = All;
    SourceTable = "GMAIL Email Relation";
    SourceTableView = where("Email Type" = const(Inbox));
    Caption = 'GMAIL Inbox Relation';
    PopulateAllFields = true;
    layout
    {
        area(Content)
        {
            repeater(ReceivedEmails)
            {
                field("Email Type"; rec."Email Type")
                {
                    ApplicationArea = All;
                    Visible = false;
                }

                field("Linked Document Type"; Rec."Linked Document Type")
                {
                    ApplicationArea = all;
                    ShowMandatory = true;
                }
                field("Linked Document No."; Rec."Linked Document No.")
                {
                    ApplicationArea = all;
                    ShowMandatory = true;
                    trigger OnValidate()
                    begin
                        CurrPage.SaveRecord();

                        if rec."Linked Document Type" = rec."Linked Document Type"::Customer then
                            CreateRelatedContact(rec)
                        else if rec."Linked Document Type" = rec."Linked Document Type"::Contact then
                            CreateRelatedCustomer(rec)
                        else
                            CreateEstValueFromOppo(rec);
                    end;

                }
                field(Description; Rec.Description)
                {
                    Caption = 'Name / Description';
                    ApplicationArea = all;
                }
            }
        }
    }


    actions
    {
        area(Processing)
        {

        }
    }

    trigger OnOpenPage()
    begin
        rec.SetCurrentKey("Email Type", "Inbox Entry No.", EntryNo, "GMAIL Inbox ID");

        rec.FilterGroup(2);
        Rec.Setfilter("Linked Document Type", '<>%1', Rec."Linked Document Type"::Customer);
        rec.FilterGroup(0);
    end;

    trigger OnInit()
    var
        myInt: Integer;
    begin
        rec.SetCurrentKey("Email Type", "Inbox Entry No.", EntryNo, "GMAIL Inbox ID")
    end;

    trigger OnInsertRecord(BelowxRec: Boolean): Boolean
    var
        recGmailRelation: Record "GMAIL Email Relation";
        recLastGmailRelation: Record "GMAIL Email Relation";
        recCustomer: Record Customer;
        recContact: Record Contact;
    begin
        if (rec."Linked Document Type" = rec."Linked Document Type"::Customer) OR (rec."Linked Document Type" = rec."Linked Document Type"::Contact) then begin
            recLastGmailRelation.Reset();
            if recLastGmailRelation.FindLast() then
                rec.EntryNo := recLastGmailRelation.EntryNo + 1
            else
                rec.EntryNo := 1;

            // recGmailRelation.Reset();
            // recGmailRelation.SetRange("Inbox Entry No.", rec."Inbox Entry No.");
            // recGmailRelation.SetRange("Email Type", rec."Email Type");
            // recGmailRelation.SetRange("Linked Document Type", rec."Linked Document Type");
            // if recGmailRelation.FindFirst() then
            //     Error(ERROR001, rec."Linked Document Type");

            Commit();


        end else begin
            recLastGmailRelation.Reset();
            if recLastGmailRelation.FindLast() then
                rec.EntryNo := recLastGmailRelation.EntryNo + 1
            else
                rec.EntryNo := 1;

            // recGmailRelation.Reset();
            // recGmailRelation.SetRange("Inbox Entry No.", rec."Inbox Entry No.");
            // recGmailRelation.SetRange("Email Type", rec."Email Type");
            // recGmailRelation.SetRange("Linked Document Type", rec."Linked Document Type");
            // if recGmailRelation.FindFirst() then
            //     Error(ERROR001, rec."Linked Document Type");
        end;


    end;

    local procedure CreateRelatedCustomer(var pGmailRelation: Record "GMAIL Email Relation")
    var
        ContactRelation: Record "Contact Business Relation";
        recLastGmailRelation: Record "GMAIL Email Relation";
    begin
        ContactRelation.Reset();
        ContactRelation.SetRange("Link to Table", ContactRelation."Link to Table"::Customer);
        ContactRelation.SetRange("Contact No.", pGmailRelation."Linked Document No.");
        if ContactRelation.FindFirst() then begin

            recLastGmailRelation.Reset();
            if recLastGmailRelation.FindLast() then
                rec.EntryNo := recLastGmailRelation.EntryNo + 1
            else
                rec.EntryNo := 1;

            pGmailRelation."Linked Document Type" := pGmailRelation."Linked Document Type"::Customer;
            pGmailRelation.Validate("Linked Document No.", ContactRelation."No.");
            pGmailRelation.Insert();

            CurrPage.Update(false);
        end;

    end;

    local procedure CreateRelatedContact(var pGmailRelation: Record "GMAIL Email Relation")
    var
        ContactRelation: Record "Contact Business Relation";
        recLastGmailRelation: Record "GMAIL Email Relation";
    begin

        ContactRelation.Reset();
        ContactRelation.SetRange("Link to Table", ContactRelation."Link to Table"::Customer);
        ContactRelation.SetRange("No.", pGmailRelation."Linked Document No.");
        if ContactRelation.FindFirst() then begin

            recLastGmailRelation.Reset();
            if recLastGmailRelation.FindLast() then
                rec.EntryNo := recLastGmailRelation.EntryNo + 1
            else
                rec.EntryNo := 1;

            pGmailRelation."Linked Document Type" := pGmailRelation."Linked Document Type"::Contact;
            pGmailRelation.Validate("Linked Document No.", ContactRelation."Contact No.");
            pGmailRelation.Insert();
            Commit();
            CurrPage.Update(false);
        end;

    end;

    local procedure CreateEstValueFromOppo(pGmailRelation: Record "GMAIL Email Relation")
    var
        reclEstValue: Record "FTT-CST Estimated Value Mod";
        reclEstValue2: Record "FTT-CST Estimated Value Mod";
        reclEstValue3: Record "FTT-CST Estimated Value Mod";
    begin
        reclEstValue.Reset();
        reclEstValue.SetRange("Linked No.", pGmailRelation."Linked Document No.");
        if reclEstValue.FindSet() then
            repeat
                reclEstValue2.Init();
                reclEstValue3.Reset();
                if reclEstValue3.FindLast() then
                    reclEstValue2."Entry No." := reclEstValue3."Entry No." + 1;

                reclEstValue2."Linked No." := pGmailRelation."GMAIL Inbox ID";
                reclEstValue2."Linked Source Table ID" := 50001;
                reclEstValue2."Original Opportunity No." := reclEstValue."Linked No.";
                reclEstValue2."Region Code" := reclEstValue."Region Code";
                reclEstValue2."FTT-CST Comments" := reclEstValue."FTT-CST Comments";
                reclEstValue2."FTT-CST Component Option" := reclEstValue."FTT-CST Component Option";
                reclEstValue2."FTT-CST Sublocation" := reclEstValue."FTT-CST Sublocation";
                reclEstValue2."FTT-CST Optional" := reclEstValue."FTT-CST Optional";
                reclEstValue2."Item Category Coede" := reclEstValue."Item Category Coede";
                reclEstValue2."Item No." := reclEstValue."Item No.";
                reclEstValue2.Description := reclEstValue.Description;
                reclEstValue2."Line Amount Total" := reclEstValue."Line Amount Total";
                reclEstValue2.Quantity := reclEstValue.Quantity;
                reclEstValue2."Unit Price Excl. VAT" := reclEstValue."Unit Price Excl. VAT";
                reclEstValue2.Insert(true);
            until reclEstValue.Next() = 0;
    end;

    var
        G_EntryNO: Integer;

        ERROR001: Label 'Duplicate Related Document Type %1 is not allowed!';

}