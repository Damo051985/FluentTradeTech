page 60040 "FTT Allergies"
{
    AutoSplitKey = true;
    Caption = 'Allergies';
    DataCaptionFields = "Employee No.";
    PageType = List;
    SourceTable = "FTTCST Allergies";

    layout
    {
        area(content)
        {
            repeater(Control1)
            {
                ShowCaption = false;
                field("Confidential Code"; Rec."Allergy Code")
                {
                    ApplicationArea = BasicHR;
                    ToolTip = 'Specifies a code to define the type of confidential information.';
                }
                Field(LineNo; Rec."Line No.")
                {
                    ApplicationArea = BasicHR;
                    //Editable = False;
                    Visible = False;
                }
                field(Description; Rec.Description)
                {
                    ApplicationArea = BasicHR;
                    ToolTip = 'Specifies a description of the confidential information.';
                }
                field(Comment; Rec.Comment)
                {
                    ApplicationArea = Comments;
                    ToolTip = 'Specifies if a comment is associated with the entry.';
                }
            }
        }
    }

}
