page 60016 "FTT-CST Dependancy Filter"
{
    ApplicationArea = All;
    Caption = 'Item Category Hierarchy and Dependencies';
    DeleteAllowed = true;
    InsertAllowed = true;
    Editable = true;
    PageType = Document;
    RefreshOnActivate = true;
    SourceTable = "FTT-CST Dependency Filters";

    layout
    {
        area(Content)
        {
            group(General)
            {
                group(Grou1)
                {
                    field("FTT-CST Component Option"; Rec."FTT-CST Component Option")
                    {
                        ApplicationArea = All;
                        Caption = 'Components option';
                        trigger OnValidate()
                        begin

                        end;
                    }
                    field("FTT-CST Location Code"; Rec."FTT-CST Location Code")
                    {
                        ApplicationArea = All;
                        Caption = 'Location';
                        trigger OnValidate()
                        begin

                        end;
                    }
                    group(TypeofSite)
                    {
                        Caption = 'TYPE OF SITE';

                        field(Primary2; PrimaryVisible)
                        {
                            Caption = 'Primary';
                            trigger OnValidate()
                            var
                                DepItems: Record "FTT-CST Dependancy Item";

                            begin
                                Commit();
                                CurrPage.Update(true);
                                DepItems.SetRange("Filter No.", Rec."Filter No.");
                                DepItems.DeleteAll();

                                Rec."FTT-CST CPU" := '';
                                Rec."FTT-CST HARDWARE" := '';
                                Rec."FTT-CST Licences Filters" := '';
                                Rec."FTT-CST NON Standard maker" := '';
                                Rec."FTT-CST Standard maker feed" := '';
                                Rec."FTT-CST Standard taker feed" := '';
                                Rec."FTT-CST NON Standard taker" := '';
                                Rec.Modify();
                            end;
                        }
                        field(Redundancy2; RedundencyVisible)
                        {
                            caption = 'Redundancy';
                            trigger OnValidate()
                            var
                                DepItems: Record "FTT-CST Dependancy Item";
                            begin
                                if not RedundencyVisible then
                                    rec."FTT-CST Redundency" := '';
                                CurrPage.Update(true);
                                DepItems.SetRange("Filter No.", Rec."Filter No.");
                                DepItems.SetRange("FTT-CST Redundency", TRUE);
                                DepItems.DeleteAll();
                                Commit();
                                CurrPage.Update();
                            end;
                        }
                        field(DR2; DRVisible)
                        {
                            caption = 'DR';
                            trigger OnValidate()
                            var
                                DepItems: Record "FTT-CST Dependancy Item";
                            begin
                                if not DRVisible then
                                    rec."FTT-CST DR" := '';
                                CurrPage.Update(true);
                                DepItems.SetRange("Filter No.", Rec."Filter No.");
                                DepItems.SetRange("FTT-CST DR", TRUE);
                                DepItems.DeleteAll();
                                Commit();
                                CurrPage.Update();
                                Commit();
                                CurrPage.Update();
                            end;
                        }

                        field("FTT-CST Conectivity"; ConectivityVisible)
                        {
                            ApplicationArea = All;
                            Caption = 'Connectivity';
                            ToolTip = 'Specifies the Conectivity that will be used to filter.';

                            trigger OnValidate()
                            begin
                                if not ConectivityVisible then
                                    Rec."FTT-CST Cross Connect" := false;
                            end;
                        }
                    }


                    group(Primary)
                    {
                        visible = PrimaryVisible;
                        Caption = '';
                        field("FTT-CST Licences Filters"; Rec."FTT-CST Licences Filters")
                        {
                            ApplicationArea = All;
                            Caption = 'Licenses';
                            trigger OnLookup(var Text: Text): Boolean;
                            var
                                ItemList: page "Item List";
                                DependencyItem: Record Item;
                                LicencesFilters: text[1024];
                            begin
                                DependencyItem.SetFilter("Item Category Code", 'LICENSE');
                                ItemList.LookupMode(true);
                                ItemList.SetTableView(DependencyItem);
                                if ItemList.RunModal() = Action::LookupOK then begin
                                    DependancyFilter := ItemList.GetSelectionFilter();
                                    Rec.VALIDATE("FTT-CST Licences Filters", ItemList.GetSelectionFilter());
                                    CurrPage.SelectedDepItems.Page.SetFilters(DependancyFilter, Rec."Filter No.", LocationCode, 1, Rec."Sales Document No.");
                                    CurrPage.Update();
                                end;
                            end;
                        }



                        field("FTT-CST Standard taker feed"; Rec."FTT-CST Standard taker feed")
                        {

                            ApplicationArea = All;
                            Caption = 'STANDARD TAKER FEED';
                            trigger OnLookup(var Text: Text): Boolean;
                            var
                                ItemList: page "Item List";
                                DependencyItem: Record Item;
                                LicencesFilters: text[1024];
                            begin
                                DependencyItem.SetFilter("Item Category Code", 'STANDARD TAKER FEED');
                                ItemList.LookupMode(true);
                                ItemList.SetTableView(DependencyItem);
                                if ItemList.RunModal() = Action::LookupOK then begin
                                    //if DependancyFilter <> '' then
                                    //    DependancyFilter := DependancyFilter + '|' + ItemList.GetSelectionFilter() else
                                    DependancyFilter := ItemList.GetSelectionFilter();
                                    Rec.VALIDATE("FTT-CST Standard taker feed", ItemList.GetSelectionFilter());
                                    Rec.Modify();

                                    if DependancyFilter <> '' then
                                        //CurrPage.SelectedDepItems.Page.SetFilters(DependancyFilter, Rec."Filter No.");
                                    CurrPage.Update();
                                end;
                            end;
                        }
                        field("FTT-CST NON Standard taker feed"; Rec."FTT-CST NON Standard taker")
                        {

                            ApplicationArea = All;
                            Caption = 'NS TAKER FEED';
                            trigger OnLookup(var Text: Text): Boolean;
                            var
                                ItemList: page "Item List";
                                DependencyItem: Record Item;
                                LicencesFilters: text[1024];
                            begin
                                DependencyItem.SetFilter("Item Category Code", 'NS TAKER FEED');
                                ItemList.LookupMode(true);
                                ItemList.SetTableView(DependencyItem);
                                if ItemList.RunModal() = Action::LookupOK then begin
                                    //if DependancyFilter <> '' then
                                    //    DependancyFilter := DependancyFilter + '|' + ItemList.GetSelectionFilter() else
                                    DependancyFilter := ItemList.GetSelectionFilter();
                                    Rec.VALIDATE("FTT-CST NON Standard taker", ItemList.GetSelectionFilter());

                                    if DependancyFilter <> '' then
                                        //CurrPage.SelectedDepItems.Page.SetFilters(DependancyFilter, Rec."Filter No.");
                                    CurrPage.Update();
                                end;
                            end;
                        }
                        field("FTT-CST Standard maker feed"; Rec."FTT-CST Standard maker feed")
                        {
                            ApplicationArea = All;
                            Caption = 'STANDARD MAKER FEED';

                            trigger OnLookup(var Text: Text): Boolean;
                            var
                                ItemList: page "Item List";
                                DependencyItem: Record Item;
                                LicencesFilters: text[1024];
                            begin
                                DependencyItem.SetFilter("Item Category Code", 'STANDARD MAKER FEED');
                                ItemList.LookupMode(true);
                                ItemList.SetTableView(DependencyItem);
                                if ItemList.RunModal() = Action::LookupOK then begin
                                    //if DependancyFilter <> '' then
                                    //    DependancyFilter := DependancyFilter + '|' + ItemList.GetSelectionFilter() else
                                    DependancyFilter := ItemList.GetSelectionFilter();
                                    Rec.VALIDATE("FTT-CST Standard maker feed", ItemList.GetSelectionFilter());


                                    //CurrPage.SelectedDepItems.Page.SetFilters(DependancyFilter, Rec."Filter No.");
                                    CurrPage.Update();
                                end;
                            end;
                        }
                        field("FTT-CST NON Standard maker feed"; Rec."FTT-CST NON Standard maker")
                        {
                            ApplicationArea = All;
                            Caption = 'NS MAKER FEED';

                            trigger OnLookup(var Text: Text): Boolean;
                            var
                                ItemList: page "Item List";
                                DependencyItem: Record Item;
                                LicencesFilters: text[1024];
                            begin
                                DependencyItem.SetFilter("Item Category Code", 'NS MAKER FEED');
                                ItemList.LookupMode(true);
                                ItemList.SetTableView(DependencyItem);
                                if ItemList.RunModal() = Action::LookupOK then begin
                                    DependancyFilter := ItemList.GetSelectionFilter();
                                    Rec.VALIDATE("FTT-CST NON Standard maker", ItemList.GetSelectionFilter());


                                    //CurrPage.SelectedDepItems.Page.SetFilters(DependancyFilter, Rec."Filter No.");
                                    CurrPage.Update();
                                end
                            end;
                        }

                        field("FTT-CST HARDWARE"; Rec."FTT-CST HARDWARE")
                        {
                            ApplicationArea = All;
                            Caption = 'HARDWARE';
                            trigger OnLookup(var Text: Text): Boolean;
                            var
                                ItemList: page "FTT-CST Item List";
                                DependencyItem: Record Item;
                                LicencesFilters: text[1024];
                                HardwareFilters: text[1024];
                                SetUpLines: text[1024];
                                SpecailSelect: record "FTT-CST Special Select";
                                SalesReceivables: Record "Sales & Receivables Setup";
                                DependencyItem2: Record "FTT-CST Dependancy Item";
                                pQty: Decimal;
                            begin
                                SalesReceivables.GET();

                                DependencyItem.SetFilter("Item Category Code", 'HARDWARE');
                                SpecailSelect.SetRange("Filter No.", Rec."Filter No.");
                                SpecailSelect.DeleteAll();

                                if DependencyItem.FindSet() then
                                    repeat
                                        SpecailSelect.Init;
                                        SpecailSelect."Item No." := DependencyItem."No.";
                                        SpecailSelect."Filter No." := Rec."Filter No.";
                                        SpecailSelect.Description := DependencyItem.Description;
                                        SpecailSelect."Unit Price" := DependencyItem."Unit Price";
                                        SpecailSelect.Insert();
                                    until DependencyItem.Next = 0;
                                Commit();
                                SpecailSelect.SetRange("Filter No.", Rec."Filter No.");

                                ItemList.LookupMode(true);
                                ItemList.SetTableView(SpecailSelect);
                                if ItemList.RunModal() = Action::LookupOK then begin
                                    AddHardwareConnect(HardwareFilters);
                                    Rec."FTT-CST HARDWARE" := HardwareFilters;
                                    Rec.Modify();
                                    Commit;
                                    if Confirm('Do you want to add "Servers set up" proportionally?') then begin
                                        clear(ItemList);

                                        pQty := 0;
                                        DependencyItem2.SetRange("Filter No.", Rec."Filter No.");
                                        DependencyItem2.SetFilter("Item Category Code", 'HARDWARE');
                                        if DependencyItem2.FindSet() then
                                            repeat
                                                pQty := pQty + DependencyItem2."FTT-CST Quantity";
                                            until DependencyItem2.next = 0;

                                        DependencyItem.SetFilter("Item Category Code", SalesReceivables."FTT-CST Servers Set Up");
                                        SpecailSelect.SetRange("Filter No.", Rec."Filter No.");
                                        SpecailSelect.DeleteAll();

                                        if DependencyItem.FindSet() then
                                            repeat
                                                SpecailSelect.Init;
                                                SpecailSelect.Level := 8;
                                                SpecailSelect."Item No." := DependencyItem."No.";
                                                SpecailSelect."Filter No." := Rec."Filter No.";
                                                SpecailSelect.Description := DependencyItem.Description;
                                                SpecailSelect."Unit Price" := DependencyItem."Unit Price";
                                                SpecailSelect.Quantity := pQty;
                                                SpecailSelect.Insert();
                                            until DependencyItem.Next = 0;
                                        Commit();
                                        SpecailSelect.SetRange("Filter No.", Rec."Filter No.");

                                        ItemList.LookupMode(true);
                                        ItemList.SetTableView(SpecailSelect);

                                        if ItemList.RunModal() = Action::LookupOK then begin
                                            AddSetUpLine(SetUpLines);
                                        end;

                                    end;
                                    CurrPage.Update();
                                end;

                            end;
                        }
                        field("FTT-CST CPU"; Rec."FTT-CST CPU")
                        {
                            ApplicationArea = All;
                            Caption = 'Hosting and management';

                            trigger OnValidate()
                            var
                                DependencyItem2: record "FTT-CST Dependancy Item";
                                pQty: Decimal;
                            begin
                                /*DependencyItem2.SetRange("Filter No.", Rec."Filter No.");
                                DependencyItem2.SetFilter("Item Category Code", 'HARDWARE');
                                if DependencyItem2.FindSet() then
                                    repeat
                                        pQty := pQty + DependencyItem2."FTT-CST Quantity";
                                    until DependencyItem2.next = 0;
                                */
                                CurrPage.SelectedItems.Page.SetFilters(Rec."FTT-CST CPU");
                                CurrPage.Update();
                            end;


                            trigger OnLookup(var Text: Text): Boolean;
                            var
                                ItemList: page "FTT-CST Item List";
                                DependencyItem: Record "FTT-CST Special Select";
                                DependencyItem2: Record "FTT-CST Dependancy Item";
                                Item: record Item;
                                LicencesFilters: text[1024];
                                SalesReceivablesSetup: Record "Sales & Receivables Setup";
                                SpecailSelect: Record "FTT-CST Special Select";
                                FTTCSTCPU: text[1024];
                                pQty: Decimal;
                            begin
                                pQty := 0;
                                DependencyItem2.SetRange("Filter No.", Rec."Filter No.");
                                DependencyItem2.SetFilter("Item Category Code", 'HARDWARE');
                                if DependencyItem2.FindSet() then
                                    repeat
                                        pQty := pQty + DependencyItem2."FTT-CST Quantity";
                                    until DependencyItem2.next = 0;

                                SalesReceivablesSetup.Get();
                                SalesReceivablesSetup.TestField("FTT-CST Hosting and management");
                                Item.SetRange("Item Category Code", SalesReceivablesSetup."FTT-CST Hosting and management");
                                SpecailSelect.SetRange("Filter No.", Rec."Filter No.");
                                SpecailSelect.DeleteAll();

                                if Item.FindSet() then
                                    repeat
                                        SpecailSelect.Init;
                                        SpecailSelect."Item No." := Item."No.";
                                        //SpecailSelect.Level := 8;
                                        SpecailSelect."Filter No." := Rec."Filter No.";
                                        SpecailSelect.Description := Item.Description;
                                        SpecailSelect."Unit Price" := Item."Unit Price";
                                        SpecailSelect.Quantity := pQty;
                                        SpecailSelect.Insert();
                                    until Item.Next = 0;

                                Commit();
                                SpecailSelect.SetRange("Filter No.", Rec."Filter No.");
                                ItemList.LookupMode(true);
                                ItemList.SetTableView(SpecailSelect);
                                if ItemList.RunModal() = Action::LookupOK then begin
                                    AddHostingLIne(FTTCSTCPU);
                                    Rec."FTT-CST CPU" := FTTCSTCPU;
                                    Rec.Modify;
                                end;
                            end;
                        }
                    }
                }
                group(DR)
                {
                    Caption = '';
                    Visible = DRVisible;
                    field("FTT-CST DR"; Rec."FTT-CST DR")
                    {
                        ApplicationArea = All;
                        Caption = 'DR';
                        trigger OnValidate()
                        begin
                            CurrPage.SelectedItems.Page.SetFilters(Rec."FTT-CST DR");
                            CurrPage.Update();
                        end;


                        trigger OnLookup(var Text: Text): Boolean;
                        var
                            ItemList: page "Item List";
                            DependencyItem: Record Item;
                            LicencesFilters: text[1024];
                        begin
                            DependencyItem.SetFilter("Item Category Code", 'DR');
                            ItemList.LookupMode(true);
                            ItemList.SetTableView(DependencyItem);
                            if ItemList.RunModal() = Action::LookupOK then begin
                                DependancyFilter := ItemList.GetSelectionFilter();
                                Rec.VALIDATE("FTT-CST DR", ItemList.GetSelectionFilter());
                                //CurrPage.SelectedDepItems.Page.SetFilters(DependancyFilter, Rec."Filter No.");
                                CurrPage.Update();
                            end;
                        end;
                    }
                }
                group(Redundency)
                {
                    Visible = RedundencyVisible;
                    Caption = '';
                    field("FTT-CST Redandency"; Rec."FTT-CST Redundency")
                    {
                        ApplicationArea = All;
                        Caption = 'REDUNDANCY';
                        trigger OnValidate()
                        begin
                            CurrPage.SelectedItems.Page.SetFilters(Rec."FTT-CST DR");
                            CurrPage.Update();
                        end;


                        trigger OnLookup(var Text: Text): Boolean;
                        var
                            ItemList: page "Item List";
                            DependencyItem: Record Item;
                            LicencesFilters: text[1024];
                        begin
                            DependencyItem.SetFilter("Item Category Code", 'REDUNDANCY');
                            ItemList.LookupMode(true);
                            ItemList.SetTableView(DependencyItem);
                            if ItemList.RunModal() = Action::LookupOK then begin
                                DependancyFilter := ItemList.GetSelectionFilter();
                                Rec.VALIDATE("FTT-CST Redundency", ItemList.GetSelectionFilter());
                                //CurrPage.SelectedDepItems.Page.SetFilters(DependancyFilter, Rec."Filter No.");
                                CurrPage.Update();
                            end;
                        end;
                    }
                }
                field("FTT-CST Integration"; Rec."FTT-CST Integration")
                {
                    ApplicationArea = All;
                    Caption = 'Integration';
                    trigger OnValidate()
                    var
                        DepItems: record "FTT-CST Dependancy Item";
                    begin
                        CurrPage.SelectedItems.Page.SetFilters(Rec."FTT-CST Integration");
                        CurrPage.Update();
                        CurrPage.Update(true);
                        DepItems.SetRange("Filter No.", Rec."Filter No.");
                        DepItems.SetRange("FTT-CST Integration", TRUE);
                        DepItems.DeleteAll();
                        Commit();
                    end;


                    trigger OnLookup(var Text: Text): Boolean;
                    var
                        ItemList: page "Item List";
                        DependencyItem: Record Item;
                        LicencesFilters: text[1024];
                    begin
                        DependencyItem.SetFilter("Item Category Code", 'INSTALLATION');
                        ItemList.LookupMode(true);
                        ItemList.SetTableView(DependencyItem);
                        if ItemList.RunModal() = Action::LookupOK then begin
                            DependancyFilter := ItemList.GetSelectionFilter();
                            Rec.VALIDATE("FTT-CST Integration", ItemList.GetSelectionFilter());
                            //CurrPage.SelectedDepItems.Page.SetFilters(DependancyFilter, Rec."Filter No.");
                            CurrPage.Update();
                        end;
                    end;
                }
                group("CROSS СONNECT")
                {
                    Visible = ConectivityVisible;
                    field("Cross Connect"; Rec."FTT-CST Cross Connect")
                    {
                        caption = 'Add CROSS CONNECT';
                        ApplicationArea = all;
                        trigger OnValidate()
                        var
                            CrossConnect: Page "FTT-CST Cross Connect";
                            recCrossConnect: record "FTT-CST Cross Connect";
                            DependencyItems: record "FTT-CST Dependancy Item";
                        begin
                            recCrossConnect.SetRange("Filter No.", rec."Filter No.");
                            recCrossConnect.DeleteAll();

                            DependencyItems.SetRange("Filter No.", Rec."Filter No.");
                            DependencyItems.SetRange("FTT-CST Cross Connect", true);
                            if DependencyItems.FindSet() then
                                DependencyItems.DeleteAll();
                            Commit();

                            DependencyItems.RESET;
                            if Rec."FTT-CST Cross Connect" then begin
                                DependencyItems.SetRange("Filter No.", Rec."Filter No.");
                                DependencyItems.SetRange("FTT-CST FEED", true);
                                if DependencyItems.FindSet() then
                                    repeat
                                        recCrossConnect.Init();
                                        recCrossConnect."Filter No." := DependencyItems."Filter No.";
                                        recCrossConnect."Item No." := DependencyItems."No.";
                                        recCrossConnect.Description := DependencyItems.Description;
                                        if СheckIFFeedTypeIsNS(DependencyItems."No.") then begin
                                            recCrossConnect."Quantity 2" := 2;
                                            recCrossConnect."Quantity 4" := 2;
                                        end else begin
                                            recCrossConnect."Quantity 1" := 1;
                                            recCrossConnect."Quantity 3" := 1;
                                        end;
                                        recCrossConnect.Insert();
                                    until DependencyItems.next = 0;
                                Commit();
                                recCrossConnect.SetRange("Filter No.", Rec."Filter No.");
                                CrossConnect.LookupMode(true);
                                CrossConnect.SetTableView(recCrossConnect);
                                if CrossConnect.RunModal() = Action::LookupOK then begin
                                    AddCrossConnect();
                                end;
                            end;
                        end;
                    }
                }
            }


            part(SelectedItems; "Item List")
            {
                Visible = false;
            }
            part(SelectedDepItems; "FTT-CST Dependency Item")
            {
                ApplicationArea = Basic, Suite;
                Editable = true;
                Enabled = true;
                SubPageLink = "Filter No." = FIELD("Filter No."), "Sales Document No." = Field("Sales Document No."); //NRD - Add Sales Document No.
                UpdatePropagation = Both;
            }

        }
    }
    actions
    {
        area(navigation)
        {
            group(Process)
            {
                action("CROSS CONNECT2")
                {
                    Caption = 'Add CROSS CONNECT';
                    ApplicationArea = all;
                    trigger OnAction()
                    begin
                        Message('Add CROSS CONNECT');
                    end;
                }


            }
        }
    }
    trigger OnOpenPage()
    var
        DependancyItem: Record "FTT-CST Dependancy Item";
    begin
        DependancyFilter := '';
        Rec."FTT-CST Cross Connect" := false;
        if Rec.FindLast() then begin
            Rec."FTT-CST CPU" := '';
            Rec."FTT-CST HARDWARE" := '';
            Rec."FTT-CST Licences Filters" := '';
            Rec."FTT-CST NON Standard maker" := '';
            Rec."FTT-CST Standard maker feed" := '';
            rec."FTT-CST Standard taker feed" := '';
            rec."FTT-CST NON Standard taker" := '';
            Rec."FTT-CST DR" := '';
            rec."FTT-CST Redundency" := '';
            rec."FTT-CST Integration" := '';
            rec."FTT-CST Location Code" := '';
            Rec."FTT-CST Cross Connect" := false;
            Rec.Modify()
        end else begin
            Rec.Init();
            Rec."Filter No." := 1;
            Rec."FTT-CST Cross Connect" := false;
            Rec.Insert;
        end;
        if DependancyFilter = '' then begin
            //CurrPage.SelectedDepItems.Page.SetFilters('0', Rec."Filter No.");
            CurrPage.Update();
        end;
        DependancyItem.SetRange("Filter No.", Rec."Filter No.");
        DependancyItem.DeleteAll();
    end;



    internal procedure SetFilters(SalespersonPurchaserCode: Code[20])
    begin
        SalespersonPurchaserCodeGlobal := SalespersonPurchaserCode;
    end;

    procedure AddCrossConnect()
    var
        CrossConnect: record "FTT-CST Cross Connect";
        DepItems: record "FTT-CST Dependancy Item";
        Item: Record Item;
        SalesReceivablesSetup: Record "Sales & Receivables Setup";
        Qty1: Decimal;
        Qty2: Decimal;
        Qty3: Decimal;
        Qty4: Decimal;
    begin
        SalesReceivablesSetup.Get();
        Qty1 := 0;
        Qty2 := 0;
        Qty3 := 0;
        Qty4 := 0;

        CrossConnect.SetRange("Filter No.", rec."Filter No.");
        if CrossConnect.FindSet() then
            repeat
                Qty1 := Qty1 + CrossConnect."Quantity 1";
                Qty2 := Qty2 + CrossConnect."Quantity 2";
                Qty3 := Qty3 + CrossConnect."Quantity 3";
                Qty4 := Qty4 + CrossConnect."Quantity 4";
            until CrossConnect.next = 0;
        Item.Reset;
        item.SetRange("Item Category Code", SalesReceivablesSetup."FTT-CST Shared MRC CC Category");
        if Item.FindFirst() and (Qty1 > 0) then begin
            Message('FTT-CST Shared MRC CC Category');
            DepItems.Init();
            DepItems."Filter No." := Rec."Filter No.";
            DepItems."No." := Item."No.";
            DepItems."FTT-CST Quantity" := Qty1;
            DepItems.Description := Item.Description;
            DepItems."Unit Price" := Item."Unit Price";
            DepItems."FTT-CST Cross Connect" := True;
            DepItems."FTT-CST Parent Category Code" := 'LICENSE';
            DepItems.Level := 12;
            DepItems.Insert();
        end;
        Item.Reset;
        Item.SetRange("Item Category Code", SalesReceivablesSetup."FTT-CST Shared NRC CC Category");
        if Item.FindFirst() and (Qty3 > 0) then begin
            Message('FTT-CST Shared NRC CC Category');
            DepItems.Init();
            DepItems."Filter No." := Rec."Filter No.";
            DepItems."No." := Item."No.";
            DepItems."FTT-CST Quantity" := Qty3;
            DepItems.Description := Item.Description;
            DepItems."Unit Price" := Item."Unit Price";
            DepItems."FTT-CST Cross Connect" := True;
            DepItems."FTT-CST Parent Category Code" := 'LICENSE';
            DepItems.Level := 12;
            DepItems.Insert();
        end;

        Item.Reset;
        Item.SetRange("Item Category Code", SalesReceivablesSetup."FTT-CST Ded. MRC CC Category");
        if item.FindFirst() and (Qty2 > 0) then begin
            Message('FTT-CST Ded. MRC CC Category');
            DepItems.Init();
            DepItems."Filter No." := Rec."Filter No.";
            DepItems."No." := Item."No.";
            DepItems."FTT-CST Quantity" := Qty2;
            DepItems.Description := Item.Description;
            DepItems."Unit Price" := Item."Unit Price";
            DepItems."FTT-CST Cross Connect" := True;
            DepItems."FTT-CST Parent Category Code" := 'LICENSE';
            DepItems.Level := 12;
            DepItems.Insert();
        end;

        Item.Reset;
        Item.SetRange("Item Category Code", SalesReceivablesSetup."FTT-CST Ded. NRC CC Category");
        if Item.FindFirst() and (Qty4 > 0) then begin
            Message('FTT-CST Ded. NRC CC Category');
            DepItems.Init();
            DepItems."Filter No." := Rec."Filter No.";
            DepItems."No." := Item."No.";
            DepItems."FTT-CST Quantity" := Qty4;
            DepItems.Description := Item.Description;
            DepItems."Unit Price" := Item."Unit Price";
            DepItems."FTT-CST Cross Connect" := True;
            DepItems."FTT-CST Parent Category Code" := 'LICENSE';
            DepItems.Level := 12;
            DepItems.Insert();
        end;
    end;

    procedure AddHardwareConnect(var pFilter: text[1024])
    var
        DepItems: record "FTT-CST Dependancy Item";
        Item: Record Item;
        SalesReceivablesSetup: Record "Sales & Receivables Setup";
        SpecialSelect: record "FTT-CST Special Select";
    begin
        pFilter := '';
        SalesReceivablesSetup.Get();
        SpecialSelect.SetRange("Filter No.", Rec."Filter No.");
        if SpecialSelect.FindSet() then
            repeat
                if SpecialSelect.Quantity > 0 then begin
                    DepItems.Init();
                    DepItems."Filter No." := Rec."Filter No.";
                    DepItems."No." := SpecialSelect."Item No.";
                    DepItems."FTT-CST Quantity" := SpecialSelect.Quantity;
                    DepItems.Description := SpecialSelect.Description;
                    DepItems."Unit Price" := SpecialSelect."Unit Price";
                    DepItems."Item Category Code" := 'HARDWARE';
                    DepItems."FTT-CST Parent Category Code" := 'HARDWARE';
                    DepItems.Level := 8;
                    DepItems.Insert();
                    if pFilter = '' then
                        pFilter := SpecialSelect."Item No." else
                        pFilter := pFilter + '|' + SpecialSelect."Item No.";
                end;
            until SpecialSelect.next = 0;
    end;

    procedure AddHostingLine(var pFilter: text[1024])
    var
        DepItems: record "FTT-CST Dependancy Item";
        Item: Record Item;
        SalesReceivablesSetup: Record "Sales & Receivables Setup";
        SpecialSelect: record "FTT-CST Special Select";
    begin
        pFilter := '';
        SalesReceivablesSetup.Get();
        SpecialSelect.SetRange("Filter No.", Rec."Filter No.");
        if SpecialSelect.FindSet() then
            repeat
                if SpecialSelect.Quantity > 0 then begin
                    DepItems.Init();
                    DepItems."Filter No." := Rec."Filter No.";
                    DepItems."No." := SpecialSelect."Item No.";
                    DepItems."FTT-CST Quantity" := SpecialSelect.Quantity;
                    DepItems.Description := SpecialSelect.Description;
                    DepItems."Unit Price" := SpecialSelect."Unit Price";
                    DepItems."FTT-CST Parent Category Code" := 'HOSTING';
                    DepItems.Level := 10;
                    DepItems.Insert();
                    if pFilter = '' then
                        pFilter := SpecialSelect."Item No." else
                        pFilter := pFilter + '|' + SpecialSelect."Item No.";
                end;
            until SpecialSelect.next = 0;
    end;

    procedure AddSetUpLine(var pFilter: text[1024])
    var
        DepItems: record "FTT-CST Dependancy Item";
        Item: Record Item;
        SalesReceivablesSetup: Record "Sales & Receivables Setup";
        SpecialSelect: record "FTT-CST Special Select";
    begin
        pFilter := '';
        SalesReceivablesSetup.Get();
        SpecialSelect.SetRange("Filter No.", Rec."Filter No.");
        if SpecialSelect.FindSet() then
            repeat
                if SpecialSelect.Quantity > 0 then begin
                    DepItems.Init();
                    DepItems."Filter No." := Rec."Filter No.";
                    DepItems."No." := SpecialSelect."Item No.";
                    DepItems."FTT-CST Quantity" := SpecialSelect.Quantity;
                    DepItems.Description := SpecialSelect.Description;
                    DepItems."Unit Price" := SpecialSelect."Unit Price";
                    DepItems."Item Category Code" := 'SERVERS SET UP'; //NRD
                    DepItems."FTT-CST Parent Category Code" := 'HARDWARE';
                    DepItems.level := 9;
                    DepItems.Insert();
                    if pFilter = '' then
                        pFilter := SpecialSelect."Item No." else
                        pFilter := pFilter + '|' + SpecialSelect."Item No.";
                end;
            until SpecialSelect.next = 0;
    end;

    procedure СheckIFFeedTypeIsNS(ItemNo: code[20]): Boolean;
    var
        Item: record Item;
        SalesReceivables: Record "Sales & Receivables Setup";
    begin
        if Item.Get(ItemNo) then;
        if (Item."Item Category Code" = 'NS MAKER FEED') or (Item."Item Category Code" = 'NS TAKER FEED') then
            exit(true) else
            exit(false);
    end;

    var
        "FTT-CST Salesp. Benef. Filter": Code[20];
        SalespersonPurchaserCodeGlobal: Code[20];
        "FTT-CST Total Amount (LCY)": Decimal;
        "FTT-CST Date Filter": Text;
        DependancyFilter: Text[1024];
        [InDataSet]
        PrimaryVisible: Boolean;
        [InDataSet]
        DRVisible: Boolean;
        [InDataSet]
        RedundencyVisible: Boolean;
        [InDataSet]
        CrossConnect: boolean;
        [InDataSet]
        ConectivityVisible: Boolean;
        LondonLocation: Boolean;
        LocationCode: code[20];
}