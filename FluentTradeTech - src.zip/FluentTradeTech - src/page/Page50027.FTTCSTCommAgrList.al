page 50027 "FTT-CST Comm. Agreement List"
{
    Caption = 'Commission Agreement List';
    PageType = List;
    UsageCategory = Lists;
    ApplicationArea = All;
    SourceTable = "FTT-CST Comm. Agrm. Header";
    CardPageId = "FTT-CST Comm. Agreement Card";
    layout
    {
        area(Content)
        {
            repeater(Group)
            {
                field("Agreement No."; Rec."Agreement No.")
                {
                    ApplicationArea = All;
                }
                field("Document Date"; Rec."Document Date")
                {
                    ApplicationArea = All;
                }
                field("Salesperson Type"; Rec."Salesperson Type")
                {
                    ApplicationArea = all;
                    Caption = 'Type';
                }
                field(Description; Rec.Description)
                {
                    ApplicationArea = all;
                }
                field("Agr. Starting Date"; Rec."Agr. Starting Date")
                {
                    ApplicationArea = all;
                    Caption = 'Starting Date';
                }
                field("Agr. Ending Date"; Rec."Agr. Ending Date")
                {
                    ApplicationArea = all;
                    Caption = 'Ending Date';
                }
                field(Status; Rec.Status)
                {
                    ApplicationArea = all;
                }

            }
        }
        area(Factboxes)
        {

        }
    }

    actions
    {
        // area(Processing)
        // {
        //     action(ActionName)
        //     {
        //         ApplicationArea = All;

        //         trigger OnAction();
        //         begin

        //         end;
        //     }
        // }
    }

    trigger OnOpenPage()
    var
        UserSetup: Record "User Setup";
    begin
        if not UserSetup.Get(UserId) then
            exit;

        UserSetup.TestField("Commission Full Access", true);

    end;
}