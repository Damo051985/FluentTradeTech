page 60003 "FTT-CST Salesp. Comm. Rates"
{
    ApplicationArea = All;
    Caption = 'Salesperson Commission Rates';
    DelayedInsert = true;
    PageType = List;
    SourceTable = "FTT-CST Salesp. Comm. Rate";
    UsageCategory = Lists;

    layout
    {
        area(Content)
        {
            repeater(General)
            {
                field("Salesperson Code"; Rec."Salesperson Code")
                {
                    ToolTip = 'Specifies a salesperson code for the Salespeople/Purchasers table.';
                }
                field("Item Category Code"; Rec."Item Category Code")
                {
                    ToolTip = 'Specifies an item category code of the salesperson commission rate.';
                }
                field("Agreement Period"; Rec."Agreement Period")
                {
                    ToolTip = 'Specifies agreement period for the salesperson commission rate.';
                }
                field("Commission Rate %"; Rec."Commission Rate %")
                {
                    ToolTip = 'Specifies the percentage to use to calculate the salesperson commission.';
                }
            }
        }
    }
    //Nimrod+
    trigger OnOpenPage()
    var
        UserSETUP: Record "User Setup";
    begin
        if not UserSETUP.Get(UserId) then
            exit;

        if UserSETUP."Salespers./Purch. Code" <> '' then begin
            rec.FilterGroup(2);
            rec.SetRange(Rec."Salesperson Code", UserSETUP."Salespers./Purch. Code");
            rec.FilterGroup(0);
        end;

    end;
    //-
}
