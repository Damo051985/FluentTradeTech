page 60042 "Comm. Per Customer Subform"
{
    ApplicationArea = All;
    Caption = 'Line Details';
    PageType = ListPart;
    SourceTable = "Commision Per Customer";
    SourceTableView = where("Type" = filter(Line));
    Editable = False;

    layout
    {
        area(Content)
        {
            repeater(General)
            {
                field("Customer Code"; Rec."Customer Code")
                {
                    ToolTip = 'Specifies the value of the Customer Code field.';
                }
                field("Customer Name"; Rec."Customer Name")
                {
                    ToolTip = 'Specifies the value of the Customer Name field.';
                }
                field("Salesperson Code"; Rec."Salesperson Code")
                {
                    ToolTip = 'Specifies the value of the Salesperson Code field.';
                }
                field("Salesperson Name"; Rec."Salesperson Name")
                {
                    ToolTip = 'Specifies the value of the Salesperson Name field.';
                }
                field("Invoice Amount Currency"; Rec."Invoice Amount Currency")
                {
                    ToolTip = 'Specifies the value of the Invoice Amount Currency field.';
                }
                field("Invoice Amount LCY"; Rec."Invoice Amount LCY")
                {
                    ToolTip = 'Specifies the value of the Invoice Amount LCY field.';
                }
                field("Eligible Currency"; Rec."Eligible Currency")
                {
                    ToolTip = 'Specifies the value of the Eligible Currency field.';
                }
                field("Eligible LCY"; Rec."Eligible LCY")
                {
                    ToolTip = 'Specifies the value of the Eligible LCY field.';
                }
                field("Commision Currency"; Rec."Commision Currency")
                {
                    ToolTip = 'Specifies the value of the Commision Currency field.';
                }
                field("Commision LCY"; Rec."Commision LCY")
                {
                    ToolTip = 'Specifies the value of the Commision LCY field.';
                }
            }
        }
    }
    Trigger OnOpenPage()
    var
    Begin
        IF USERID = 'DO' then
            gVis := true
        ELSE
            gVis := FALSE;
    End;

    var
        gVis: Boolean;
        UserSet: Record "User Setup";
}
