page 60000 "FTT-CST Stn. Item Sales Codes"
{
    ApplicationArea = All;
    Caption = 'Recurring Item Sales Lines';
    PageType = List;
    SourceTable = "FTT-CST Stn. Item Sales Code";
    UsageCategory = None;

    layout
    {
        area(Content)
        {
            repeater(General)
            {
                field("Code"; Rec."Code")
                {
                    ToolTip = 'Specifies a standard sales code from the Standard Sales Code.';
                }
                field(Description; Rec.Description)
                {
                    ToolTip = 'Specifies a description of the Standard Sales Code.';
                }
                field("Insert Rec. Lines On Pr. List"; Rec."Insert Rec. Lines On Pr. List")
                {
                    ToolTip = 'Specifies how you want to use Standard Sales Codes on Sales Price Lists.';
                }
                field("Insert Rec. Lines On Quotes"; Rec."Insert Rec. Lines On Quotes")
                {
                    ToolTip = 'Specifies how you want to use Standard Sales Codes on Sales quotes.';
                }
                field("Insert Rec. Lines On Orders"; Rec."Insert Rec. Lines On Orders")
                {
                    ToolTip = 'Specifies how you want to use Standard Sales Codes on Sales Orders.';
                }
                field("Insert Rec. Lines On Invoices"; Rec."Insert Rec. Lines On Invoices")
                {
                    ToolTip = 'Specifies how you want to use Standard Sales Codes on Sales Invoices.';
                }
                field("Insert Rec. Lines On Cr. Memos"; Rec."Insert Rec. Lines On Cr. Memos")
                {
                    ToolTip = 'Specifies how you want to use Standard Sales Codes on Sales Credit Memos.';
                }
            }
        }
    }

    procedure GetSelected(var StnItemSalesCode: Record "FTT-CST Stn. Item Sales Code")
    begin
        CurrPage.SetSelectionFilter(StnItemSalesCode);
    end;
}
