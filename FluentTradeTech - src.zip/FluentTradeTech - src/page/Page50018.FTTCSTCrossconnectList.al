page 50018 "FTT-CST Cross Connect List"
{
    PageType = List;
    ApplicationArea = All;
    UsageCategory = Lists;
    SourceTable = "FTT-CST Cross Connect Hdr";
    InsertAllowed = false;
    DeleteAllowed = false;
    ModifyAllowed = false;
    CardPageId = "FTT-CST Cross Connect Card";
    Caption = 'Cross Connect List';
    layout
    {
        area(Content)
        {
            repeater(CrossConnectList)
            {
                field("Document Type"; Rec."Document Type")
                {
                    ApplicationArea = all;
                }
                field("Document No."; Rec."Document No.")
                {
                    ApplicationArea = all;
                }
                field("Customer No."; Rec."Customer No.")
                {
                    ApplicationArea = all;
                }
                field("Customer Name"; Rec."Customer Name")
                {
                    ApplicationArea = all;
                }
                field("Cross Connect Status"; Rec."Cross Connect Status")
                {
                    ApplicationArea = all;
                }
            }
        }
    }



    var
        myInt: Integer;
}