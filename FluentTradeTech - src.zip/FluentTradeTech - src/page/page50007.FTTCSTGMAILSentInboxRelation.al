page 50007 "GMAIL Email Sent Relation"
{
    PageType = List;
    ApplicationArea = All;
    SourceTable = "GMAIL Email Relation";
    SourceTableView = where("Email Type" = const(Sent));
    Caption = 'GMAIL Sent Relation';
    PopulateAllFields = true;

    layout
    {
        area(Content)
        {
            repeater(ReceivedEmails)
            {
                field("Email Type"; rec."Email Type")
                {
                    ApplicationArea = All;
                    Visible = false;
                }

                field("Linked Document Type"; Rec."Linked Document Type")
                {
                    ApplicationArea = all;
                    ShowMandatory = true;
                }
                field("Linked Document No."; Rec."Linked Document No.")
                {
                    ApplicationArea = all;
                    ShowMandatory = true;
                }
                field(Description; Rec.Description)
                {
                    Caption = 'Name / Description';
                    ApplicationArea = all;
                }
            }
        }
    }

    actions
    {
        area(Processing)
        {
            //     action(ActionName)
            //     {
            //         ApplicationArea = All;

            //         trigger OnAction()
            //         begin

            //         end;
            //     }
        }
    }

    trigger OnOpenPage()
    begin
        rec.SetCurrentKey("Email Type", "Inbox Entry No.", EntryNo, "GMAIL Inbox ID")
    end;

    trigger OnInit()
    var
        myInt: Integer;
    begin
        rec.SetCurrentKey("Email Type", "Inbox Entry No.", EntryNo, "GMAIL Inbox ID")
    end;

    trigger OnInsertRecord(BelowxRec: Boolean): Boolean
    var
        recLastGmailRelation: Record "GMAIL Email Relation";
        recGmailRelation: Record "GMAIL Email Relation";
    begin
        recLastGmailRelation.Reset();
        if recLastGmailRelation.FindLast() then
            rec.EntryNo := recLastGmailRelation.EntryNo + 1
        else
            rec.EntryNo := 1;

        recGmailRelation.Reset();
        recGmailRelation.SetRange("Inbox Entry No.", rec."Inbox Entry No.");
        recGmailRelation.SetRange("Email Type", rec."Email Type");
        recGmailRelation.SetRange("Linked Document Type", rec."Linked Document Type");
        if recGmailRelation.FindFirst() then
            Error(ERROR001, rec."Linked Document Type");
    end;

    var
        G_EntryNO: Integer;
        ERROR001: Label 'Duplicate Related Document Type %1 is not allowed!';
}