page 60007 "FTT-CST Customer Statistics"
{
    ApplicationArea = All;
    Caption = 'Recurring Item Sales Lines';
    PageType = CardPart;
    SourceTable = Customer;
    UsageCategory = None;

    layout
    {
        area(Content)
        {

            field("No. of Opportunities"; NoofOpportunities)
            {
                ApplicationArea = RelationshipMgmt;
                ToolTip = 'Specifies the number of open opportunities involving the contact. The field is not editable.';
                trigger OnDrillDown()
                var
                    OppotrunityEntry: Record "Opportunity Entry";
                    OpportunityEntries: Page "Opportunity Entries";
                    CompanyName: code[20];
                begin
                    //Evaluate(CompanyName, CopyStr(Rec.Name, 1, 20));
                    OppotrunityEntry.SetRange("FTT-CST Company Name", Rec.Name);
                    OppotrunityEntry.SetRange(Active, true);
                    if OppotrunityEntry.FindSet() then begin
                        OpportunityEntries.SetTableView(OppotrunityEntry);
                        OpportunityEntries.RunModal()
                    end;
                end;
            }
        }
    }
    trigger OnAfterGetRecord()
    var
        Oppotrunity: Record "Opportunity Entry";
        CompanyName: code[20];

    begin
        UpdateOpportunity();
        Oppotrunity.SetRange("FTT-CST Company Name", Rec.Name);
        Oppotrunity.SetRange(Active, true);

        NoofOpportunities := Oppotrunity.Count();
    end;

    procedure UpdateOpportunity()
    var
        Opportunity: record "Opportunity Entry";
        Contact: Record Contact;
    begin
        if Opportunity.FindSet() then
            repeat
                if Contact.get(Opportunity."Contact Company No.") then begin
                    Opportunity."FTT-CST Company Name" := Contact."Company Name";
                    Opportunity.Modify();
                end;
            until Opportunity.next = 0;
    end;

    var
        [InDataSet]
        NoofOpportunities: Integer;
}
