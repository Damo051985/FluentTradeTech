page 50032 "FTT-CST Supervisor Entry"
{
    Caption = 'Supervisor Ledger Entries';
    DataCaptionFields = "Sell-to Customer No.";
    DeleteAllowed = false;
    InsertAllowed = false;
    Editable = false;
    PageType = List;
    Permissions = TableData "Cust. Ledger Entry" = r, tabledata "Sales Invoice Line" = rm;
    SourceTable = "FTT-CST SV Ledger Entry";
    SourceTableView = sorting("Sell-to Customer No.", "Document Date") order(descending);
    UsageCategory = History;
    ApplicationArea = All;
    layout
    {
        area(Content)
        {
            repeater(General)
            {
                ShowCaption = false;
                field("Entry No."; Rec."Entry No.")
                {
                    ApplicationArea = All;
                }
                field("Document Type"; Rec."Document Type")
                {
                    ApplicationArea = all;
                }
                field("Document No."; Rec."Document No.")
                {
                    ApplicationArea = all;
                }
                field("Document Date"; Rec."Document Date")
                {
                    ApplicationArea = all;
                    Caption = 'Posting Date';
                }
                field("Sell-to Customer No."; Rec."Sell-to Customer No.")
                {
                    ApplicationArea = all;
                }
                field("Sell-to Customer Name"; Rec."Sell-to Customer Name")
                {
                    ApplicationArea = all;
                }
                field("Currency Code"; Rec."Currency Code")
                {
                    ApplicationArea = all;
                }
                field("Salesperson Code"; Rec."Salesperson Code")
                {
                    ApplicationArea = all;
                }
                field("Supervisor Code"; Rec."Supervisor Code")
                {
                    ApplicationArea = all;
                }
                field("Commission Amount (LCY)"; Rec."Commission Amount (LCY)")
                {
                    ApplicationArea = all;
                }
                field("Commission Amount"; Rec."Commission Amount")
                {
                    ApplicationArea = all;
                }
                field("Supervisor Reward Amount"; Rec."Supervisor Reward Amount")
                {
                    ApplicationArea = all;
                }
                field("Rem. Super. Reward Amt"; Rec."Rem. Super. Reward Amt")
                {
                    ApplicationArea = all;
                }
                field("Supervisor Reward Amount (LCY)"; Rec."Supervisor Reward Amount (LCY)")
                {
                    ApplicationArea = all;
                }
                field("Rem. Super. Reward Amt (LCY)"; Rec."Rem. Super. Reward Amt (LCY)")
                {
                    ApplicationArea = all;
                }
                field("Invoice Settled"; Rec."Invoice Settled")
                {
                    ApplicationArea = all;
                    Width = 8;
                }
                field(Open; Rec.Open)
                {
                    ApplicationArea = all;
                }
            }
        }
    }

    actions
    {
        area(navigation)
        {
            group("Ent&ry")
            {
                action(Customer)
                {
                    ApplicationArea = Basic, Suite;
                    Caption = 'Customer';
                    Image = Customer;
                    RunObject = Page "Customer Card";
                    RunPageLink = "No." = field("Sell-to Customer No.");
                    ShortCutKey = 'Shift+F7';
                    ToolTip = 'View or edit detailed information about the customer.';
                }

                action("Detailed Comm. &Ledger Entries")
                {
                    ApplicationArea = Basic, Suite;
                    Caption = 'Detailed Supervisor &Ledger Entries';
                    Image = View;
                    RunObject = Page "FTT-CST Dtldg. Super. Entries";
                    RunPageLink = "Supv. Ledger Entry No." = field("Entry No."),
                                  "Customer No." = field("Sell-to Customer No.");
                    RunPageView = sorting("Supv. Ledger Entry No.", "Posting Date");
                    Scope = Repeater;
                    ShortCutKey = 'Ctrl+F7';
                    ToolTip = 'View a summary of the all posted entries and adjustments related to a specific customer ledger entry.';
                }
            }
        }
        area(processing)
        {
            action("&Navigate")
            {
                ApplicationArea = Basic, Suite;
                Caption = 'Find entries...';
                Image = Navigate;
                Scope = Repeater;
                ShortCutKey = 'Ctrl+Alt+Q';
                ToolTip = 'Find entries and documents that exist for the document number and posting date on the selected document. (Formerly this action was named Navigate.)';

                trigger OnAction()
                begin
                    Navigate.SetDoc(Rec."Document Date", Rec."Document No.");
                    Navigate.Run();
                end;
            }
            action("Show Document")
            {
                ApplicationArea = Basic, Suite;
                Caption = 'Show Document';
                Image = Document;
                ShortCutKey = 'Return';
                ToolTip = 'Show details for the posted payment, invoice, or credit memo.';

                trigger OnAction()
                begin
                    Rec.ShowDoc();
                end;
            }

        }
        area(Promoted)
        {
            group(Category_Process)
            {
                Caption = 'Process', Comment = 'Generated from the PromotedActionCategories property index 1.';

                group(Category_Category4)
                {
                    Caption = 'Line', Comment = 'Generated from the PromotedActionCategories property index 3.';
                    ShowAs = SplitButton;

                    actionref("Show Document_Promoted"; "Show Document")
                    {
                    }

                }

                actionref("&Navigate_Promoted"; "&Navigate")
                {
                }

            }
            group(Category_Category5)
            {
                Caption = 'Entry', Comment = 'Generated from the PromotedActionCategories property index 4.';
                separator(Navigate_Separator)
                {
                }

                actionref(Customer_Promoted; Customer)
                {
                }
            }
            group(Category_Category6)
            {
                Caption = 'Navigate', Comment = 'Generated from the PromotedActionCategories property index 5.';
            }
            group(Category_Report)
            {
                Caption = 'Report', Comment = 'Generated from the PromotedActionCategories property index 2.';
            }
        }
    }


    trigger OnOpenPage()
    var
        UserSetup: Record "User Setup";
    begin
        if not UserSetup.Get(UserId) then
            exit;

        if not UserSetup."Commission Full Access" then begin
            UserSetup.TestField("Salespers./Purch. Code");
            rec.FilterGroup(2);
            rec.SetRange(Rec."Supervisor Code", UserSetup."Salespers./Purch. Code");
            rec.FilterGroup(0);
        end else begin
            rec.Reset();
            rec.SetCurrentKey("Entry No.", "Document No.");
            rec.Ascending(false);
        end;
    end;

    // trigger OnOpenPage()
    // var
    //     recCommAgrlist: Record "FTT-CST Comm. Agrm. Header";

    // begin
    //     recCommAgrlist.Reset();
    //     recCommAgrlist.SetRange(recCommAgrlist."Salesperson Type",recCommAgrlist."Salesperson Type"::Team);
    //     recCommAgrlist.SetRange();
    // end;
    var
        Navigate: Page Navigate;
}