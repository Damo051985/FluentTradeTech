page 60041 "Commision Per Customer"
{
    ApplicationArea = All;
    Caption = 'Commission Per Customer';
    PageType = Card;
    UsageCategory = Lists;
    SourceTable = "Commision Per Customer";
    Editable = False;
    RefreshOnActivate = true;
    Permissions = TableData "Sales Invoice Header" = rm;

    layout
    {
        area(Content)
        {
            group(General)
            {
                Caption = 'General';

                field("Customer Code"; Rec."Customer Code")
                {
                    ToolTip = 'Specifies the value of the Customer Code field.';
                    Visible = False;
                }
                field("Salesperson Code"; Rec."Salesperson Code")
                {
                    ToolTip = 'Specifies the value of the Salesperson Code field.';
                    Visible = False;
                }
            }

            part("CommPerCustSub"; "Comm. Per Customer Subform")
            {
                ApplicationArea = Basic, Suite;
            }
            part("CommPerCustGrand"; "Comm. Per Cust. Grand Total")
            {
                ApplicationArea = Basic, Suite;
            }

        }
    }
    actions
    {
        area(processing)
        {
            action(UpdateCommPerCust)
            {
                ApplicationArea = All;
                Caption = 'Update Commission per customer';
                Visible = True;
                trigger OnAction()
                var
                    lCommRep: Codeunit "Commission Reports";
                begin
                    lCommRep.InsertCustomer();
                end;
            }
            action(DeleteLines)
            {
                ApplicationArea = All;
                Caption = 'Delete Lines';
                Visible = False;
                trigger OnAction()
                var
                    lCommPerCust: Record "Commision Per Customer";
                    lSIH: Record "Sales Invoice Header";
                begin
                    IF lCommPerCust.FINDSET then
                        lCommPerCust.DELETEALL;

                    IF lSIH.FINDSET then
                        lSIH.ModifyAll("Inserted in Report", FALSE);
                end;
            }
            action(UpdateContact)
            {
                ApplicationArea = All;
                Caption = 'Update Currency';
                Visible = gVis;
                trigger OnAction()
                var
                    Contact: Record Contact;
                    Oppo: Record Opportunity;
                begin
                    Clear(Oppo);
                    Oppo.SETRANGE("FTT-CST Currency", '');
                    IF Oppo.FINDSET THEN
                        repeat
                            IF Contact.get(Oppo."Contact No.") THEN begin
                                Oppo."FTT-CST Currency" := Contact."Currency Code";
                                Oppo.Modify;
                            end;
                        Until Oppo.Next = 0;
                    Message('Done');
                end;
            }
        }
    }
    Trigger OnOpenPage()
    var
        lCommRep: Codeunit "Commission Reports";
    Begin
        lCommRep.InsertCustomer();
        IF UserId = 'DO' then
            gVis := true
        ELSE
            gVis := FALSE;
    End;

    var
        gVis: Boolean;
        UserSet: Record "User Setup";
}
