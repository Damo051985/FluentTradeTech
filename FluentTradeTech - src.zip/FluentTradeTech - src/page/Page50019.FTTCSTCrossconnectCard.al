page 50019 "FTT-CST Cross Connect Card"
{
    PageType = Card;
    ApplicationArea = All;
    SourceTable = "FTT-CST Cross Connect Hdr";
    //DeleteAllowed = false;
    InsertAllowed = false;
    ModifyAllowed = false;
    Caption = 'Cross Connect Card';
    layout
    {
        area(Content)
        {
            group(General)
            {
                field("Document Type"; Rec."Document Type")
                {
                    ApplicationArea = All;

                }
                field("Document No."; Rec."Document No.")
                {
                    ApplicationArea = all;
                }
                field("Customer No."; Rec."Customer No.")
                {
                    ApplicationArea = all;
                }
                field("Customer Name"; Rec."Customer Name")
                {
                    ApplicationArea = all;
                }
                field("Cross Connect Status"; Rec."Cross Connect Status")
                {
                    ApplicationArea = all;
                }
            }
            group(Lines)
            {
                part(CrossConnectLines; "FTT-CST Cross Connect Lines")
                {
                    ApplicationArea = all;
                    Editable = false;
                    Caption = 'Cross Connect Lines';
                    SubPageLink = "Document No." = field("Document No."), "Document Type" = field("Document Type");
                }
            }
            group(Total)
            {
                field("Total of Dedicated MRC"; Rec."Total of Dedicated MRC")
                {
                    ApplicationArea = all;
                    Editable = false;
                }
                field("Total of Shared MRC"; Rec."Total of Shared MRC")
                {
                    ApplicationArea = all;
                    Editable = false;

                }
                field("Total of Dedicated NRC"; Rec."Total of Dedicated NRC")
                {
                    ApplicationArea = all;
                    Editable = false;
                }
                field("Total of Shared NRC"; Rec."Total of Shared NRC")
                {
                    ApplicationArea = all;
                    Editable = false;
                }
            }
        }
    }

    trigger OnOpenPage()
    var
        myInt: Integer;
    begin
        rec.SetRange("Document Type");
        rec.SetRange("Document No.");
        rec.CalcFields("Total of Dedicated MRC", Rec."Total of Dedicated NRC", rec."Total of Shared MRC", rec."Total of Shared NRC");
    end;

    var
        myInt: Integer;
}