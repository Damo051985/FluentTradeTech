page 60019 "FTT-CST Item List V2"
{
    PageType = Worksheet;
    ApplicationArea = All;
    SourceTable = "FTT-CST Special Select";
    Caption = 'Items';

    layout
    {
        area(Content)
        {
            repeater(GroupName)
            {
                field(Name; Rec."Item No.")
                {
                    ApplicationArea = All;

                }
                field(Description; Rec.Description)
                {
                    ApplicationArea = All;

                }
                field("FTT-CST Quanity"; Rec."Quantity")
                {
                    ApplicationArea = All;
                    trigger OnValidate()
                    begin
                    end;
                }
                field("Unit Price"; Rec."Unit Price")
                {
                    ApplicationArea = All;
                }
                field("Comments Fluent"; Rec."Comments Fluent")
                {
                    Caption = 'Fluent Comment';
                }
                field(Comments; Rec.Comments)
                {
                    ApplicationArea = All;
                }

            }
        }
    }

    actions
    {
        area(Processing)
        {
            action(ActionName)
            {
                ApplicationArea = All;

                trigger OnAction();
                begin

                end;
            }
        }
    }
    procedure GetSelectionFilter(): Text
    var
        Item: Record Item;
        SelectionFilterManagement: Codeunit SelectionFilterManagement;
    begin
        CurrPage.SetSelectionFilter(Item);
        exit(SelectionFilterManagement.GetSelectionFilterForItem(Item));
    end;

    trigger OnAfterGetRecord()
    begin
        //Rec."Quantity" := 0;
    end;

}