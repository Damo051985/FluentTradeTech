page 60027 Total50Percent
{
    ApplicationArea = All;
    Caption = 'Total Over 50%';
    PageType = CardPart;
    SourceTable = "Revenue Report";
    SourceTableView = where("Line Type" = filter("Over 50 %"), Type = filter("Total"));
    DeleteAllowed = False;
    InsertAllowed = False;
    ModifyAllowed = False;
    Editable = FALSE;
    layout
    {
        area(Content)
        {
            repeater(General)
            {
                field("Type"; Rec."Type")
                {
                    ToolTip = 'Specifies the value of the Type field.';
                    StyleExpr = gStyle;
                }
                field("Salesperson Code"; Rec."Salesperson Code")
                {
                    ToolTip = 'Specifies the value of the Salesperson Code field.';
                    StyleExpr = gStyle;
                }
                field("Customer/Prospect"; Rec."Customer/Prospect")
                {
                    ToolTip = 'Specifies the value of the Customer/Prospect field.';
                    StyleExpr = gStyle;
                }
                field("GT ARR Previous Contracts"; Rec."ARR - Previous Contracts")
                {
                    ToolTip = 'Specifies the value of the Grand Total ARR Previous Contracts field.';
                    StyleExpr = gStyle;
                }
                field("GT ARR Add. Contracts"; Rec."ARR - Additional Products")
                {
                    ToolTip = 'Specifies the value of the Grand Total ARR Additional Products field.';
                    StyleExpr = gStyle;
                }
                field("GT ARR Contract Progress"; Rec."ARR Contract in Progress")
                {
                    ToolTip = 'Specifies the value of the Grand Total ARR Contracts Progress field.';
                    StyleExpr = gStyle;
                }
                field("GT NRC Contract Progress"; Rec."NRC Contract in Progress")
                {
                    ToolTip = 'Specifies the value of the Grand Total NRC Contract Progress field.';
                    StyleExpr = gStyle;
                }
                field("GT Total Contract Progress"; Rec."ARR Total Revenue")
                {
                    ToolTip = 'Specifies the value of the Grand Total ARR Total Revenue field.';
                    StyleExpr = gStyle;
                }
                field("GT NRC Total Revenue"; Rec."NRC Total Revenue")
                {
                    ToolTip = 'Specifies the value of the Grand Total NRC Total Revenue field.';
                    StyleExpr = gStyle;
                }
                field("GT Connectivity"; Rec."Connectivity")
                {
                    ToolTip = 'Specifies the value of the Grand Total Connectivity field.';
                    StyleExpr = gStyle;
                }
                field("GT Distribution"; Rec."Distribution")
                {
                    ToolTip = 'Specifies the value of the Grand Total Distribution field.';
                    StyleExpr = gStyle;
                }
                field("GT RiskNOther"; Rec."Risk and Others")
                {
                    ToolTip = 'Specifies the value of the Grand Total Risk and Others field.';
                    StyleExpr = gStyle;
                }
                field("GT Other YRC"; Rec."Other YRC")
                {
                    ToolTip = 'Specifies the value of the Grand Total Other YRC field.';
                    StyleExpr = gStyle;
                }
            }
        }
    }
    trigger OnAfterGetRecord()
    var
    Begin
        gStyle := 'Strong';
    End;

    trigger OnOpenPage()
    var

    Begin

    End;

    var
        gStyle: Text[30];
}
