page 50015 "FTT-CST Estimated Value Mod"
{
    PageType = List;
    ApplicationArea = All;
    SourceTable = "FTT-CST Estimated Value Mod";
    PopulateAllFields = true;
    layout
    {
        area(Content)
        {
            repeater(EstValueRep)
            {
                field("Item No."; Rec."Item No.")
                {
                    ApplicationArea = all;
                }
                field(Description; Rec.Description)
                {
                    ApplicationArea = all;
                    Enabled = false;
                }
                field("Item Category Coede"; Rec."Item Category Coede")
                {
                    ApplicationArea = all;
                }
                field("Region Code"; Rec."Region Code")
                {
                    ApplicationArea = All;
                }
                field("FTT-CST Sublocation"; Rec."FTT-CST Sublocation")
                {
                    ApplicationArea = all;
                }
                field("FTT-CST Component Option"; Rec."FTT-CST Component Option")
                {
                    ApplicationArea = all;
                }
                field("FTT-CST Optional"; Rec."FTT-CST Optional")
                {
                    ApplicationArea = all;
                    Visible = false;
                }
                field(Quantity; Rec.Quantity)
                {
                    ApplicationArea = all;
                }
                field("Estimated Value - Currency"; Rec."Estimated Value - Currency")
                {
                    ApplicationArea = all;
                    Enabled = false;
                }
                field("Unit Price Excl. VAT"; Rec."Unit Price Excl. VAT")
                {
                    ApplicationArea = all;
                }
                field("DR/Redundancy/Integ PriceCalc%"; Rec."DR/Redundancy/Integ PriceCalc%")
                {
                    Caption = '%';
                    ApplicationArea = all;
                }
                field("Line Amount Total"; Rec."Line Amount Total")
                {
                    ApplicationArea = all;
                    Enabled = false;
                }
                field("FTT-CST Comments"; Rec."FTT-CST Comments")
                {
                    ApplicationArea = all;
                }
            }
        }
    }

    actions
    {
        area(Processing)
        {
            action(UpdateRecalLines)
            {
                ApplicationArea = All;
                Image = Recalculate;
                Promoted = true;
                PromotedCategory = Process;
                Caption = 'Update';
                ToolTip = 'this trigger to recalculate all the DR/Redundancy/Integration in the Lines';
                trigger OnAction()
                var
                    recEstValueMod: Record "FTT-CST Estimated Value Mod";
                begin

                    if not Confirm('Do you want to re-calculate the lines?', false) then
                        exit;
                    updatePerlocationPage(rec);
                    IF (TempLoc.FINDSET) then
                        Repeat
                            //UpdateRedundancy
                            recEstValueMod.Reset();
                            recEstValueMod.SetRange("Linked No.", rec."Linked No.");
                            recEstValueMod.SetRange("Linked Source Table ID", rec."Linked Source Table ID");
                            recEstValueMod.SetRange("Region Code", TempLoc.Code); //Dan
                            recEstValueMod.SetRange("Parent Item Categ. Code", 'REDUNDANCY');
                            recEstValueMod.SetFilter("DR/Redundancy/Integ PriceCalc%", '<>0');
                            if recEstValueMod.FindFirst() then begin
                                //recEstValueMod."Line Amount Total" := recEstValueMod.calcTotalofDRRedundacy(recEstValueMod."DR/Redundancy/Integ PriceCalc%");
                                recEstValueMod."Line Amount Total" := recEstValueMod.calcTotalofDRRedundacy2(recEstValueMod."DR/Redundancy/Integ PriceCalc%", TempLoc.Code); //Dan
                                recEstValueMod.Modify();
                            end;

                            //UpdateDR
                            recEstValueMod.Reset();
                            recEstValueMod.SetRange("Linked No.", rec."Linked No.");
                            recEstValueMod.SetRange("Linked Source Table ID", rec."Linked Source Table ID");
                            recEstValueMod.SetRange("Region Code", TempLoc.Code); //Dan
                            recEstValueMod.SetRange("Parent Item Categ. Code", 'DR');
                            recEstValueMod.SetFilter("DR/Redundancy/Integ PriceCalc%", '<>0');
                            if recEstValueMod.FindFirst() then begin
                                //recEstValueMod."Line Amount Total" := recEstValueMod.calcTotalofDRRedundacy(recEstValueMod."DR/Redundancy/Integ PriceCalc%");
                                recEstValueMod."Line Amount Total" := recEstValueMod.calcTotalofDRRedundacy2(recEstValueMod."DR/Redundancy/Integ PriceCalc%", TempLoc.Code); //Dan
                                recEstValueMod.Modify();
                            end;

                            //UpdateIntegration
                            recEstValueMod.Reset();
                            recEstValueMod.SetRange("Linked No.", rec."Linked No.");
                            recEstValueMod.SetRange("Linked Source Table ID", rec."Linked Source Table ID");
                            recEstValueMod.SetRange("Region Code", TempLoc.Code); //Dan
                            recEstValueMod.SetRange("Parent Item Categ. Code", 'INSTALLATION');
                            recEstValueMod.SetFilter("DR/Redundancy/Integ PriceCalc%", '<>0');
                            if recEstValueMod.FindFirst() then begin
                                //recEstValueMod."Line Amount Total" := recEstValueMod.calcTotalofIntegration(recEstValueMod."DR/Redundancy/Integ PriceCalc%");
                                recEstValueMod."Line Amount Total" := recEstValueMod.calcTotalofIntegration2(recEstValueMod."DR/Redundancy/Integ PriceCalc%", TempLoc.Code); //Dan
                                recEstValueMod.Modify();
                            end;
                        until TempLoc.next = 0;
                    Message('Lines are succesfully recalculated!');
                end;
            }
            //Nimrod- 05112024
            action("Add Cross Connect")
            {
                ApplicationArea = All;
                Image = LinkAccount;
                Promoted = true;
                PromotedCategory = Process;
                Caption = 'Add Cross Connect';

                trigger OnAction()
                var
                    recCrosConnectionTemp: Record "FTT-CST Cross ConnectLnsTemp";
                    recCrosConnectionTemp2: Record "FTT-CST Cross ConnectLnsTemp";
                    recCrosConnectionTemp3: Record "FTT-CST Cross ConnectLnsTemp";
                    recEstValueMod: Record "FTT-CST Estimated Value Mod";
                    recEstValueMod2: Record "FTT-CST Estimated Value Mod";
                    pagCrossConnect: Page "FTT-CST Cross ConnectLinesTemp";
                    SharedNRCQty: Decimal;
                    SharedMRCQty: Decimal;
                    DedicatedNRDQty: Decimal;
                    DedicatedMRCQty: Decimal;
                    Item: Record Item;
                begin

                    recCrosConnectionTemp.Reset();
                    recCrosConnectionTemp.SetRange("Document Type", recCrosConnectionTemp."Document Type"::Quote);
                    recCrosConnectionTemp.SetRange("Document No.", rec."Linked No.");
                    if not recCrosConnectionTemp.FindSet() then begin

                        recCrosConnectionTemp.DeleteAll();
                        recEstValueMod.Reset();
                        recEstValueMod.SetRange("Linked Source Table ID", 5092);
                        recEstValueMod.SetRange("Linked No.", rec."Linked No.");
                        recEstValueMod.SetFilter("Parent Item Categ. Code", '%1', 'FEED');
                        if recEstValueMod.FindSet() then
                            repeat
                                recCrosConnectionTemp.Init();
                                recCrosConnectionTemp."Document Type" := recCrosConnectionTemp."Document Type"::Quote;
                                recCrosConnectionTemp."Document No." := rec."Linked No.";
                                recCrosConnectionTemp."Item No." := recEstValueMod."Item No.";
                                recCrosConnectionTemp."FTT-CST Location Code" := recEstValueMod."Region Code";
                                recCrosConnectionTemp."Item Category Code" := recEstValueMod."Item Category Coede";
                                recCrosConnectionTemp.Description := recEstValueMod.Description;
                                recCrosConnectionTemp.Insert();
                            until recEstValueMod.Next() = 0;
                        Commit();

                        recCrosConnectionTemp3.Reset();
                        recCrosConnectionTemp3.SetRange("Document Type", recCrosConnectionTemp3."Document Type"::Quote);
                        recCrosConnectionTemp3.SetRange("Document No.", recEstValueMod."Linked No.");
                        if recCrosConnectionTemp3.FindSet() then
                            recCrosConnectionTemp3.ModifyAll(calculated, false);
                        Commit();

                        recCrosConnectionTemp.Reset();
                        recCrosConnectionTemp.SetRange("Document Type", recCrosConnectionTemp."Document Type"::Quote);
                        recCrosConnectionTemp.SetRange("Document No.", recEstValueMod."Linked No.");
                        recCrosConnectionTemp3.FindSet();

                        pagCrossConnect.LookupMode(true);
                        pagCrossConnect.SetTableView(recCrosConnectionTemp);
                        if pagCrossConnect.RunModal() = Action::LookupOK then begin
                            pagCrossConnect.GetRecord(recCrosConnectionTemp);

                            if recCrosConnectionTemp.FindSet() then
                                repeat
                                    SharedMRCQty := 0;
                                    DedicatedMRCQty := 0;
                                    SharedNRCQty := 0;
                                    DedicatedNRDQty := 0;

                                    recCrosConnectionTemp2.Reset();
                                    recCrosConnectionTemp2.SetRange("Document Type", recCrosConnectionTemp2."Document Type"::Quote);
                                    recCrosConnectionTemp2.SetRange("Document No.", rec."Linked No.");
                                    recCrosConnectionTemp2.SetRange("FTT-CST Location Code", recCrosConnectionTemp."FTT-CST Location Code");
                                    recCrosConnectionTemp2.SetRange(calculated, false);
                                    if recCrosConnectionTemp2.FindSet() then begin
                                        repeat
                                            SharedMRCQty += recCrosConnectionTemp2."Quantity 1";
                                            DedicatedMRCQty += recCrosConnectionTemp2."Quantity 2";
                                            SharedNRCQty += recCrosConnectionTemp2."Quantity 3";
                                            DedicatedNRDQty += recCrosConnectionTemp2."Quantity 4";

                                            recCrosConnectionTemp2.calculated := true;
                                            recCrosConnectionTemp2.Modify();
                                            Commit();
                                        until recCrosConnectionTemp2.Next() = 0;

                                        if SharedMRCQty <> 0 then begin //SharedMRC
                                            if Item.Get('1101') then
                                                CreateDocumentLine('1101', SharedMRCQty, recCrosConnectionTemp."FTT-CST Location Code");
                                        end;

                                        if SharedNRCQty <> 0 then begin //SharedNRC
                                            if Item.Get('1103') then
                                                CreateDocumentLine('1103', SharedNRCQty, recCrosConnectionTemp."FTT-CST Location Code");
                                        end;

                                        if DedicatedMRCQty <> 0 then begin //DedicatedMRC
                                            if Item.Get('1102') then
                                                CreateDocumentLine('1102', DedicatedMRCQty, recCrosConnectionTemp."FTT-CST Location Code");
                                        end;

                                        if DedicatedNRDQty <> 0 then begin //DedicatedNRC
                                            if Item.Get('1104') then
                                                CreateDocumentLine('1104', DedicatedNRDQty, recCrosConnectionTemp."FTT-CST Location Code");
                                        end;
                                    end;

                                until recCrosConnectionTemp.Next() = 0;
                        end;
                    end else begin

                        recEstValueMod.Reset();
                        recEstValueMod.SetRange("Linked Source Table ID", 5092);
                        recEstValueMod.SetRange("Linked No.", recCrosConnectionTemp."Document No.");
                        recEstValueMod.SetFilter("Parent Item Categ. Code", '%1', 'FEED');
                        if recEstValueMod.FindSet() then
                            repeat
                                recCrosConnectionTemp.Reset();
                                recCrosConnectionTemp.SetRange("Document Type", recCrosConnectionTemp."Document Type"::Quote);
                                recCrosConnectionTemp.SetRange("Document No.", recEstValueMod."Linked No.");
                                recCrosConnectionTemp.SetRange("Item No.", recEstValueMod."Item No.");
                                recCrosConnectionTemp.SetRange("FTT-CST Location Code", recEstValueMod."Region Code");
                                if not recCrosConnectionTemp.FindFirst() then begin
                                    recCrosConnectionTemp.Init();
                                    recCrosConnectionTemp."Document Type" := recCrosConnectionTemp."Document Type"::Quote;
                                    recCrosConnectionTemp."Document No." := rec."Linked No.";
                                    recCrosConnectionTemp."Item No." := recEstValueMod."Item No.";
                                    recCrosConnectionTemp."FTT-CST Location Code" := recEstValueMod."Region Code";
                                    recCrosConnectionTemp."Item Category Code" := recEstValueMod."Item Category Coede";
                                    recCrosConnectionTemp.Description := recEstValueMod.Description;
                                    recCrosConnectionTemp.Insert();
                                end;
                            until recEstValueMod.Next() = 0;
                        Commit();

                        recCrosConnectionTemp3.Reset();
                        recCrosConnectionTemp3.SetRange("Document Type", recCrosConnectionTemp3."Document Type"::Quote);
                        recCrosConnectionTemp3.SetRange("Document No.", recEstValueMod."Linked No.");
                        if recCrosConnectionTemp3.FindSet() then
                            recCrosConnectionTemp3.ModifyAll(calculated, false);
                        Commit();

                        recCrosConnectionTemp.Reset();
                        recCrosConnectionTemp.SetRange("Document Type", recCrosConnectionTemp."Document Type"::Quote);
                        recCrosConnectionTemp.SetRange("Document No.", recEstValueMod."Linked No.");
                        recCrosConnectionTemp3.FindSet();


                        pagCrossConnect.LookupMode(true);
                        pagCrossConnect.SetTableView(recCrosConnectionTemp);
                        if pagCrossConnect.RunModal() = Action::LookupOK then begin
                            pagCrossConnect.GetRecord(recCrosConnectionTemp);
                            if recCrosConnectionTemp.FindSet() then
                                repeat
                                    SharedMRCQty := 0;
                                    DedicatedMRCQty := 0;
                                    SharedNRCQty := 0;
                                    DedicatedNRDQty := 0;

                                    recCrosConnectionTemp2.Reset();
                                    recCrosConnectionTemp2.SetRange("Document Type", recCrosConnectionTemp2."Document Type"::Quote);
                                    recCrosConnectionTemp2.SetRange("Document No.", rec."Linked No.");
                                    recCrosConnectionTemp2.SetRange("FTT-CST Location Code", recCrosConnectionTemp."FTT-CST Location Code");
                                    recCrosConnectionTemp2.SetRange(calculated, false);
                                    if recCrosConnectionTemp2.FindSet() then begin
                                        repeat
                                            SharedMRCQty += recCrosConnectionTemp2."Quantity 1";
                                            DedicatedMRCQty += recCrosConnectionTemp2."Quantity 2";
                                            SharedNRCQty += recCrosConnectionTemp2."Quantity 3";
                                            DedicatedNRDQty += recCrosConnectionTemp2."Quantity 4";

                                            recCrosConnectionTemp2.calculated := true;
                                            recCrosConnectionTemp2.Modify();
                                            Commit();
                                        until recCrosConnectionTemp2.Next() = 0;

                                        if SharedMRCQty <> 0 then begin //SharedMRC
                                            recEstValueMod2.Reset();
                                            recEstValueMod2.SetRange("Linked Source Table ID", 5092);
                                            recEstValueMod2.SetRange("Linked No.", rec."Linked No.");
                                            recEstValueMod2.SetRange("Region Code", recCrosConnectionTemp."FTT-CST Location Code");
                                            recEstValueMod2.SetRange("Item No.", '1101');
                                            if recEstValueMod2.FindFirst() then
                                                recEstValueMod2.Delete();
                                            Commit();
                                            if Item.Get('1101') then
                                                CreateDocumentLine('1101', SharedMRCQty, recCrosConnectionTemp."FTT-CST Location Code");
                                        end;

                                        if SharedNRCQty <> 0 then begin //SharedNRC
                                            recEstValueMod2.Reset();
                                            recEstValueMod2.SetRange("Linked Source Table ID", 5092);
                                            recEstValueMod2.SetRange("Linked No.", rec."Linked No.");
                                            recEstValueMod2.SetRange("Region Code", recCrosConnectionTemp."FTT-CST Location Code");
                                            recEstValueMod2.SetRange("Item No.", '1103');
                                            if recEstValueMod2.FindFirst() then
                                                recEstValueMod2.Delete();
                                            Commit();
                                            if Item.Get('1103') then
                                                CreateDocumentLine('1103', SharedNRCQty, recCrosConnectionTemp."FTT-CST Location Code");
                                        end;

                                        if DedicatedMRCQty <> 0 then begin //DedicatedMRC
                                            recEstValueMod2.Reset();
                                            recEstValueMod2.SetRange("Linked Source Table ID", 5092);
                                            recEstValueMod2.SetRange("Linked No.", rec."Linked No.");
                                            recEstValueMod2.SetRange("Region Code", recCrosConnectionTemp."FTT-CST Location Code");
                                            recEstValueMod2.SetRange("Item No.", '1102');
                                            if recEstValueMod2.FindFirst() then
                                                recEstValueMod2.Delete();
                                            Commit();
                                            if Item.Get('1102') then
                                                CreateDocumentLine('1102', DedicatedMRCQty, recCrosConnectionTemp."FTT-CST Location Code");
                                        end;

                                        if DedicatedNRDQty <> 0 then begin //DedicatedNRC
                                            recEstValueMod2.Reset();
                                            recEstValueMod2.SetRange("Linked Source Table ID", 5092);
                                            recEstValueMod2.SetRange("Linked No.", rec."Linked No.");
                                            recEstValueMod2.SetRange("Region Code", recCrosConnectionTemp."FTT-CST Location Code");
                                            recEstValueMod2.SetRange("Item No.", '1104');
                                            if recEstValueMod2.FindFirst() then
                                                recEstValueMod2.Delete();
                                            Commit();
                                            if Item.Get('1104') then
                                                CreateDocumentLine('1104', DedicatedNRDQty, recCrosConnectionTemp."FTT-CST Location Code");
                                        end;
                                    end;

                                until recCrosConnectionTemp.Next() = 0;
                        end;
                    end;
                end;

            }
        }
    }

    trigger OnQueryClosePage(CloseAction: Action): Boolean
    begin
        if CloseAction = Action::OK then begin
            GetTotalAmt();
        end;
    end;

    trigger OnInsertRecord(BelowxRec: Boolean): Boolean
    var
        myInt: Integer;
    begin
        if (rec."Parent Item Categ. Code" = 'CROSS CONNECTS') and (rec."Cross Connect" = false) AND (Rec."Item Category Coede" <> 'INTERNATIONAL LINE') then
            Error('Unable to Insert Cross Connect manually. \ Kindly click the Add Cross Connect Button!');

    end;

    Procedure updatePerlocationPage(pRec: Record "FTT-CST Estimated Value Mod")
    var
        recEstValueMod: Record "FTT-CST Estimated Value Mod";

    Begin
        IF TempLoc.IsTemporary THEN
            TempLoc.DELETEALL;

        recEstValueMod.Reset();
        recEstValueMod.SetRange("Linked No.", prec."Linked No.");
        recEstValueMod.SetRange("Linked Source Table ID", prec."Linked Source Table ID");
        IF recEstValueMod.FINDSET then begin
            repeat
                TempLoc.Init();
                TempLoc.Code := recEstValueMod."Region Code";
                IF TempLoc.Insert THEN;
            until recEstValueMod.Next = 0;
        end;

    End;

    procedure GetTotalAmt(): Decimal
    begin
        //rec.SetRange("Entry No.", rec."Entry No.");
        rec.SetRange("Linked No.", rec."Linked No.");
        rec.SetRange("Linked Source Table ID", rec."Linked Source Table ID");
        rec.CalcSums("Line Amount Total");
        exit(rec."Line Amount Total");
    end;

    //NRD
    local procedure CreateDocumentLine(ItemNo: Code[20]; Qty: Decimal; RegionCode: code[50])
    var
        recEstValueMode: Record "FTT-CST Estimated Value Mod";
        recEstValueMode2: Record "FTT-CST Estimated Value Mod";
    begin
        recEstValueMode2.Reset();
        recEstValueMode2.SetRange("Linked Source Table ID", 5092);
        recEstValueMode2.SetRange("Linked No.", rec."Linked No.");
        recEstValueMode2.SetRange("Region Code", RegionCode);
        if recEstValueMode2.FindFirst() then;

        recEstValueMode.Init();
        recEstValueMode."Entry No." := 0;
        recEstValueMode."Linked Source Table ID" := 5092;
        recEstValueMode."Linked No." := Rec."Linked No.";
        recEstValueMode.Validate("Item No.", ItemNo);
        recEstValueMode."Cross Connect" := true;
        recEstValueMode.validate(Quantity, Qty);
        recEstValueMode."Region Code" := recEstValueMode2."Region Code";
        recEstValueMode."FTT-CST Component Option" := recEstValueMode2."FTT-CST Component Option";
        recEstValueMode."FTT-CST Sublocation" := recEstValueMode2."FTT-CST Sublocation";
        recEstValueMode.Insert();


    end;


    var
        myInt: Integer;
        TempLoc: Record Location temporary;
}