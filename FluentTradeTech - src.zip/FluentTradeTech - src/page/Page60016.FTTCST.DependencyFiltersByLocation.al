page 60017 "FTT-CST Dep Filter by Location"
{
    ApplicationArea = All;
    Caption = 'Item Category Hierarchy and Dependencies';
    DeleteAllowed = true;
    InsertAllowed = true;
    Editable = true;
    PageType = Document;
    RefreshOnActivate = true;
    SourceTable = "FTT-CST Dependency Filters";

    layout
    {
        area(Content)
        {
            group(General)
            {
                ShowCaption = false;
                group(Locations)
                {
                    Caption = 'LOCATIONS';
                    field(LondonLocation; LondonLocation)
                    {
                        Caption = 'LONDON';
                        ApplicationArea = all;
                        trigger OnValidate()
                        begin
                            if LondonLocation then begin
                                Rec."FTT-CST Location Code" := 'LONDON';
                                Rec.Modify();
                            end;

                            if LondonLocation then begin
                                NewYorkLocation := false;
                                SINGAPORELocation := false;
                                TokyoLocation := false;
                                MALAYSIALocation := false;
                                COPENHAGENLocation := false;
                                CHICAGOLocation := false;

                                LocationCode := 'LONDON';
                                if PrevLocationCode = '' then
                                    PrevLocationCode := 'LONDON';
                                CompLocVisible := true;
                                PrimaryVisible := false;
                                ConVisible := false;
                                IntegrationVisible := false;
                                ConectivityVisible := false;
                            end;
                            if (COPENHAGENLocation = false) and (SINGAPORELocation = false) and (NewYorkLocation = false) and
                            (TokyoLocation = false) and (LondonLocation = false) and (MALAYSIALocation = false) and (CHICAGOLocation = false)
                                 then
                                LocTypeVisible := false else
                                LocTypeVisible := true;
                            if not MakeBackupDependencyFilters(Rec, true) then begin
                                ResetSelectedFilters2();
                                ResetSelectedFilters();
                            end;
                            CurrPage.Update();
                        end;

                    }
                    field(NewYorkLocation; NewYorkLocation)
                    {
                        Caption = 'NEW YORK';
                        trigger OnValidate()
                        begin
                            if NewYorkLocation then begin
                                Rec."FTT-CST Location Code" := 'NEW YORK';
                                Rec.Modify();

                                LondonLocation := false;
                                SINGAPORELocation := false;
                                TokyoLocation := false;
                                LocationCode := 'NEW YORK';
                                if PrevLocationCode = '' then
                                    PrevLocationCode := 'NEW YORK';
                                MALAYSIALocation := false;
                                COPENHAGENLocation := false;
                                CHICAGOLocation := false;


                                CompLocVisible := true;
                                PrimaryVisible := false;
                                ConVisible := false;
                                IntegrationVisible := false;
                                ConectivityVisible := false;
                            end;
                            if (COPENHAGENLocation = false) and (SINGAPORELocation = false) and (NewYorkLocation = false) and
                               (TokyoLocation = false) and (LondonLocation = false) and (MALAYSIALocation = false) and (CHICAGOLocation = false)
                            then
                                LocTypeVisible := false else
                                LocTypeVisible := true;
                            IF NOT MakeBackupDependencyFilters(Rec, true) THEN BEGIN
                                ResetSelectedFilters2();
                                ResetSelectedFilters();
                            END;
                            CurrPage.Update();
                        end;

                    }
                    field(TOKYOLocation; TokyoLocation)
                    {
                        Caption = 'TOKYO';
                        trigger OnValidate()
                        begin
                            if TokyoLocation then begin
                                if TokyoLocation then begin
                                    Rec."FTT-CST Location Code" := 'TOKYO';
                                    Rec.Modify();
                                end;
                                NewYorkLocation := false;
                                LondonLocation := false;
                                SINGAPORELocation := false;
                                LocationCode := 'TOKYO';
                                if PrevLocationCode = '' then
                                    PrevLocationCode := 'TOKYO';
                                MALAYSIALocation := false;
                                COPENHAGENLocation := false;
                                CHICAGOLocation := false;

                                CompLocVisible := true;
                                PrimaryVisible := false;
                                ConVisible := false;
                                IntegrationVisible := false;
                                ConectivityVisible := false;
                            end;
                            if (COPENHAGENLocation = false) and (SINGAPORELocation = false) and (NewYorkLocation = false) and
                            (TokyoLocation = false) and (LondonLocation = false) and (MALAYSIALocation = false) and (CHICAGOLocation = false)
                                 then
                                LocTypeVisible := false else
                                LocTypeVisible := true;
                            IF NOT MakeBackupDependencyFilters(Rec, true) THEN BEGIN
                                ResetSelectedFilters2();
                                ResetSelectedFilters();
                            END;
                        end;

                    }
                    field(SINGAPORELocation; SINGAPORELocation)
                    {
                        Caption = 'SINGAPORE';
                        trigger OnValidate()
                        begin
                            if SINGAPORELocation then begin
                                Rec."FTT-CST Location Code" := 'SINGAPORE';
                                Rec.Modify();
                                NewYorkLocation := false;
                                LondonLocation := false;
                                TokyoLocation := false;
                                COPENHAGENLocation := false;
                                MALAYSIALocation := false;
                                CHICAGOLocation := false;

                                LocationCode := 'SINGAPORE';
                                CompLocVisible := true;
                                PrimaryVisible := false;
                                ConVisible := false;
                                IntegrationVisible := false;
                                ConectivityVisible := false;
                            end;
                            if (COPENHAGENLocation = false) and (SINGAPORELocation = false) and (NewYorkLocation = false) and
(TokyoLocation = false) and (LondonLocation = false) and (MALAYSIALocation = false) and (CHICAGOLocation = false)
     then
                                LocTypeVisible := false else
                                LocTypeVisible := true;
                            IF NOT MakeBackupDependencyFilters(Rec, true) THEN BEGIN
                                ResetSelectedFilters2();
                                ResetSelectedFilters();
                            END;
                        end;

                    }
                    // COPENHAGEN, MALAYSIA
                    field(COPENHAGENLocation; COPENHAGENLocation)
                    {
                        Caption = 'COPENHAGEN';
                        trigger OnValidate()
                        begin
                            if COPENHAGENLocation then begin
                                Rec."FTT-CST Location Code" := 'COPENHAGEN';
                                Rec.Modify();
                                NewYorkLocation := false;
                                LondonLocation := false;
                                TokyoLocation := false;
                                MALAYSIALocation := false;
                                CHICAGOLocation := false;

                                LocationCode := 'COPENHAGEN';
                                SINGAPORELocation := false;
                                CompLocVisible := true;
                                PrimaryVisible := false;
                                ConVisible := false;
                                IntegrationVisible := false;
                                ConectivityVisible := false;
                            end;
                            if (COPENHAGENLocation = false) and (SINGAPORELocation = false) and (NewYorkLocation = false) and
(TokyoLocation = false) and (LondonLocation = false) and (MALAYSIALocation = false) and (CHICAGOLocation = false)
     then
                                LocTypeVisible := false else
                                LocTypeVisible := true;
                            IF NOT MakeBackupDependencyFilters(Rec, true) THEN BEGIN
                                ResetSelectedFilters2();
                                ResetSelectedFilters();
                            END;
                        end;

                    }
                    field(MALAYSIALocation; MALAYSIALocation)
                    {
                        Caption = 'MALAYSIA';
                        trigger OnValidate()
                        begin
                            if MALAYSIALocation then begin
                                Rec."FTT-CST Location Code" := 'MALAYSIA';
                                Rec.Modify();
                                NewYorkLocation := false;
                                LondonLocation := false;
                                TokyoLocation := false;
                                COPENHAGENLocation := false;
                                SINGAPORELocation := false;
                                CHICAGOLocation := false;

                                LocationCode := 'MALAYSIA';
                                CompLocVisible := true;
                                PrimaryVisible := false;
                                ConVisible := false;
                                IntegrationVisible := false;
                                ConectivityVisible := false;
                            end;
                            if (COPENHAGENLocation = false) and (SINGAPORELocation = false) and (NewYorkLocation = false) and
                            (TokyoLocation = false) and (LondonLocation = false) and (MALAYSIALocation = false)
                                 then
                                LocTypeVisible := false else
                                LocTypeVisible := true;
                            IF NOT MakeBackupDependencyFilters(Rec, true) THEN BEGIN
                                ResetSelectedFilters2();
                                ResetSelectedFilters();
                            END;
                        end;

                    }
                    field(CHICAGOLocation; CHICAGOLocation)
                    {
                        Caption = 'CHICAGO';
                        trigger OnValidate()
                        begin
                            if CHICAGOLocation then begin
                                Rec."FTT-CST Location Code" := 'CHICAGO';
                                Rec.Modify();
                                NewYorkLocation := false;
                                LondonLocation := false;
                                TokyoLocation := false;
                                COPENHAGENLocation := false;
                                SINGAPORELocation := false;
                                MALAYSIALocation := false;

                                LocationCode := 'CHICAGO';
                                CompLocVisible := true;
                                PrimaryVisible := false;
                                ConVisible := false;
                                IntegrationVisible := false;
                                ConectivityVisible := false;
                            end;
                            if (COPENHAGENLocation = false) and (SINGAPORELocation = false) and (NewYorkLocation = false) and
                            (TokyoLocation = false) and (LondonLocation = false) and (MALAYSIALocation = false) and (CHICAGOLocation = false)
                                 then
                                LocTypeVisible := false else
                                LocTypeVisible := true;
                            IF NOT MakeBackupDependencyFilters(Rec, true) THEN BEGIN
                                ResetSelectedFilters2();
                                ResetSelectedFilters();
                            END;
                        end;

                    }
                }

                group(Grou1)
                {
                    ShowCaption = false;
                    Visible = LocTypeVisible;
                    field("FTT-CST Component Option"; Rec."FTT-CST Component Option")
                    {
                        ApplicationArea = All;
                        Caption = 'LOCATION TYPE';
                        trigger OnValidate()
                        begin
                            if rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::NonHosted then begin
                                //AddCrossConnectVisible := true;
                                HardwareVisible := false;

                            end else
                                AddCrossConnectVisible := false;

                            if rec."FTT-CST Component Option" <> rec."FTT-CST Component Option"::Blank then begin
                                TypeSiteVisible := true;
                            end else
                                TypeSiteVisible := false;

                            if (COPENHAGENLocation = false) and (SINGAPORELocation = false) and (NewYorkLocation = false) and
                                (TokyoLocation = false) and (LondonLocation = false) and (MALAYSIALocation = false)
                                then
                                CompLocVisible := false else
                                CompLocVisible := true;
                            if rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Blank then begin
                                HMVisible := false;
                                IntegrationVisible := false;
                                ConVisible := false;
                                TypeSiteVisible := false;
                                DRVisible := false;
                                RedundencyVisible := false;
                                HardwareVisible := false;
                                ResetSelectedFilters();
                            end;
                            if rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Blank then begin
                                TypeSiteVisible := true;
                                HMVisible := false;
                                ConVisible := false;
                                IntegrationVisible := false;
                                HMVisible := false;
                                IntegrationVisible := false;
                                ConVisible := false;
                                TypeSiteVisible := false;
                                DRVisible := false;
                                RedundencyVisible := false;
                                HardwareVisible := false;
                            end;
                            if (xRec."FTT-CST Component Option" <> rec."FTT-CST Component Option") and
                            (xRec."FTT-CST Component Option" <> xrec."FTT-CST Component Option"::Blank) then begin
                                TypeSiteVisible := true;
                                HMVisible := false;
                                ConVisible := false;
                                IntegrationVisible := false;
                                HMVisible := false;
                                IntegrationVisible := false;
                                DRVisible := false;
                                RedundencyVisible := false;
                                HardwareVisible := false;
                                PrimaryVisible := false;
                                ConfirmDocumentVisible := false;
                                AddCrossConnectVisible := false;
                                ResetSelectedFilters();
                                if rec."FTT-CST Component Option" <> rec."FTT-CST Component Option"::Blank then
                                    TypeSiteVisible := true;
                            end;
                            CurrPage.Update();
                        end;
                    }
                    group(TypeofSiteGroup)
                    {
                        Visible = TypeSiteVisible;
                        ShowCaption = false;
                        field("FTT-CST Type of Site"; Rec."FTT-CST Type of Site")
                        {
                            ApplicationArea = All;
                            Caption = 'TYPE OF SITE';

                            trigger OnValidate()
                            begin
                                if (rec."FTT-CST Type of Site" = rec."FTT-CST Type of Site"::Both) or (rec."FTT-CST Type of Site" = rec."FTT-CST Type of Site"::DR) then begin
                                    DRVisible := true;
                                    HardwareVisible := false;
                                end else
                                    DRVisible := false;

                                if (rec."FTT-CST Type of Site" = rec."FTT-CST Type of Site"::Both) or (rec."FTT-CST Type of Site" = rec."FTT-CST Type of Site"::Redundancy) then begin
                                    RedundencyVisible := true;
                                    HardwareVisible := false;
                                end else
                                    RedundencyVisible := false;

                                if Rec."FTT-CST Type of Site" = rec."FTT-CST Type of Site"::None then begin
                                    HardwareVisible := true;
                                end;

                                if (Rec."FTT-CST Type of Site" = rec."FTT-CST Type of Site"::Both) and (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::NonHosted) then begin
                                    HardwareVisible := false;
                                    RedundencyVisible := true;
                                    DRVisible := true;
                                    ConfirmDocumentVisible := false;
                                    PrimaryVisible := false;
                                    HardwareVisible := false;
                                    AddCrossConnectVisible := false;
                                    ConVisible := false;
                                    HMVisible := false;
                                end;

                                if rec."FTT-CST Type of Site" = rec."FTT-CST Type of Site"::Blank then begin
                                    HardwareVisible := false;
                                    HMVisible := false;
                                    RedundencyVisible := false;
                                    DRVisible := false;
                                    PrimaryVisible := false;
                                    IntegrationVisible := false;
                                    ConVisible := false;
                                end;
                                if rec."FTT-CST Type of Site" = rec."FTT-CST Type of Site"::None then begin
                                    if rec."FTT-CST Component Option" <> rec."FTT-CST Component Option"::NonHosted then begin
                                        HardwareVisible := true;
                                        DRVisible := false;
                                        RedundencyVisible := false;
                                    end else begin
                                        ConVisible := true;
                                        HardwareVisible := false;
                                        PrimaryVisible := false;
                                        AddCrossConnectVisible := false;
                                        ConfirmDocumentVisible := false;
                                        rec."FTT-CST Redundency" := '';
                                        rec."FTT-CST DR" := '';
                                    end;
                                end;
                                MakeBackupDependencyFilters(Rec, false);
                                CurrPage.Update();
                            end;
                        }
                    }
                    group(DR)
                    {
                        Caption = '';
                        Visible = DRVisible;
                        field("FTT-CST DR"; Rec."FTT-CST DR")
                        {
                            ApplicationArea = All;
                            Caption = 'DR';
                            Editable = true;
                            trigger OnValidate()
                            begin
                                CurrPage.SelectedItems.Page.SetFilters(Rec."FTT-CST DR");
                            end;


                            trigger OnLookup(var Text: Text): Boolean;
                            var
                                ItemList: page "Item List";
                                DependencyItem: Record Item;
                                LicencesFilters: text[1024];
                            begin
                                DependencyItem.SetFilter("Item Category Code", 'DR');
                                ItemList.LookupMode(true);
                                ItemList.SetTableView(DependencyItem);
                                if ItemList.RunModal() = Action::LookupOK then begin
                                    DependancyFilter := ItemList.GetSelectionFilter();
                                    Rec.VALIDATE("FTT-CST DR", ItemList.GetSelectionFilter());
                                    CurrPage.SelectedDepItems.Page.SetFilters(DependancyFilter, Rec."Filter No.", LocationCode, 7, Rec."Sales Document No.");

                                    if (rec."FTT-CST Type of Site" = rec."FTT-CST Type of Site"::DR) and (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Hosted) then begin
                                        if Rec."FTT-CST DR" <> '' then
                                            HardwareVisible := true else begin
                                            HardwareVisible := false;
                                        end;
                                    end;

                                    if (rec."FTT-CST Type of Site" = rec."FTT-CST Type of Site"::Both) and (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Hosted) then begin
                                        if (Rec."FTT-CST DR" <> '') and (rec."FTT-CST Redundency" <> '') then
                                            HardwareVisible := true else begin
                                            HardwareVisible := false;
                                        end;
                                    end;

                                    if (rec."FTT-CST Type of Site" = rec."FTT-CST Type of Site"::DR) and (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::NonHosted) then begin
                                        if Rec."FTT-CST DR" <> '' then
                                            ConVisible := true else begin
                                            ConVisible := false;
                                        end;
                                    end;

                                    if (rec."FTT-CST Type of Site" = rec."FTT-CST Type of Site"::Both) and (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::NonHosted) then begin
                                        if (Rec."FTT-CST DR" <> '') and (rec."FTT-CST Redundency" <> '') then
                                            ConVisible := true else begin
                                            ConVisible := false;
                                        end;
                                    end;

                                    CurrPage.Update();
                                    MakeBackupDependencyFilters(Rec, false)
                                end;
                            end;
                        }
                    }
                    group(Redundency)
                    {
                        Visible = RedundencyVisible;
                        Caption = '';
                        Editable = true;
                        field("FTT-CST Redandency"; Rec."FTT-CST Redundency")
                        {
                            ApplicationArea = All;
                            Caption = 'REDUNDANCY';
                            trigger OnValidate()
                            begin
                                CurrPage.SelectedItems.Page.SetFilters(Rec."FTT-CST DR");
                                CurrPage.Update();
                            end;


                            trigger OnLookup(var Text: Text): Boolean;
                            var
                                ItemList: page "Item List";
                                DependencyItem: Record Item;
                                LicencesFilters: text[1024];
                            begin
                                DependencyItem.SetFilter("Item Category Code", 'REDUNDANCY');
                                ItemList.LookupMode(true);
                                ItemList.SetTableView(DependencyItem);
                                if ItemList.RunModal() = Action::LookupOK then begin
                                    DependancyFilter := ItemList.GetSelectionFilter();
                                    Rec.VALIDATE("FTT-CST Redundency", ItemList.GetSelectionFilter());
                                    CurrPage.SelectedDepItems.Page.SetFilters(DependancyFilter, Rec."Filter No.", LocationCode, 6, Rec."Sales Document No.");

                                    if rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Hosted then begin
                                        if (rec."FTT-CST Type of Site" = rec."FTT-CST Type of Site"::Redundancy) and (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Hosted) then begin
                                            if Rec."FTT-CST Redundency" <> '' then
                                                HardwareVisible := true else begin
                                                HardwareVisible := false;
                                            end;

                                        end;
                                        if (rec."FTT-CST Type of Site" = rec."FTT-CST Type of Site"::Both) and (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Hosted) then begin
                                            if (Rec."FTT-CST DR" <> '') and (rec."FTT-CST Redundency" <> '') then
                                                HardwareVisible := true else begin
                                                HardwareVisible := false;
                                            end;
                                        end;
                                        if (rec."FTT-CST Type of Site" = rec."FTT-CST Type of Site"::Both) and (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Hosted) then begin
                                            if (Rec."FTT-CST DR" <> '') or (rec."FTT-CST Redundency" <> '') then
                                                ConVisible := false;
                                        end;
                                    end;

                                    if rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::NonHosted then begin
                                        if (rec."FTT-CST Type of Site" = rec."FTT-CST Type of Site"::Both) and (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::NonHosted) then begin
                                            if (Rec."FTT-CST DR" <> '') and (rec."FTT-CST Redundency" <> '') then
                                                ConVisible := true;
                                        end;
                                        if (rec."FTT-CST Type of Site" = rec."FTT-CST Type of Site"::Redundancy) and (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::NonHosted) then begin
                                            if (rec."FTT-CST Redundency" <> '') then
                                                ConVisible := true;
                                        end;
                                        if (rec."FTT-CST Type of Site" = rec."FTT-CST Type of Site"::DR) and (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::NonHosted) then begin
                                            if (Rec."FTT-CST DR" <> '') then
                                                ConVisible := true;
                                        end;
                                    end;

                                    CurrPage.Update();
                                end;
                                MakeBackupDependencyFilters(Rec, false);
                            end;
                        }
                    }
                    group(HardwareGroup)

                    {
                        ShowCaption = false;
                        Visible = HardwareVisible;
                        field("FTT-CST HARDWARE"; Rec."FTT-CST HARDWARE")
                        {
                            ApplicationArea = All;
                            Caption = 'HARDWARE';
                            Editable = true;
                            trigger OnLookup(var Text: Text): Boolean;
                            var
                                ItemList: page "FTT-CST Item List V2";
                                DependencyItem: Record Item;
                                LicencesFilters: text[1024];
                                HardwareFilters: text[1024];
                                SetUpLines: text[1024];
                                SpecailSelect: record "FTT-CST Special Select";
                                SalesReceivables: Record "Sales & Receivables Setup";
                                DependencyItem2: Record "FTT-CST Dependancy Item";
                                pQty: Decimal;
                            begin
                                SalesReceivables.GET();

                                DependencyItem.SetFilter("Item Category Code", 'HARDWARE');
                                SpecailSelect.SetRange("Filter No.", Rec."Filter No.");
                                SpecailSelect.DeleteAll();

                                if DependencyItem.FindSet() then
                                    repeat
                                        SpecailSelect.Init;
                                        SpecailSelect."Item No." := DependencyItem."No.";
                                        SpecailSelect."Filter No." := Rec."Filter No.";
                                        SpecailSelect.Description := DependencyItem.Description;
                                        SpecailSelect."Comments Fluent" := DependencyItem."FTT-CST Comments Fluent";
                                        SpecailSelect."Unit Price" := DependencyItem."Unit Price";
                                        SpecailSelect.Insert();
                                    until DependencyItem.Next = 0;
                                Commit();
                                SpecailSelect.SetRange("Filter No.", Rec."Filter No.");

                                ItemList.LookupMode(true);
                                ItemList.SetTableView(SpecailSelect);
                                if ItemList.RunModal() = Action::LookupOK then begin
                                    AddHardwareConnect(HardwareFilters);
                                    Rec."FTT-CST HARDWARE" := HardwareFilters;
                                    Rec.Modify();
                                    Commit;
                                    if Confirm('Do you want to add "Servers set up" proportionally?') then begin
                                        clear(ItemList);

                                        pQty := 0;
                                        DependencyItem2.SetRange("Filter No.", Rec."Filter No.");
                                        DependencyItem2.SetFilter("Item Category Code", 'HARDWARE');
                                        if DependencyItem2.FindSet() then
                                            repeat
                                                pQty := pQty + DependencyItem2."FTT-CST Quantity";
                                            until DependencyItem2.next = 0;

                                        DependencyItem.SetFilter("Item Category Code", SalesReceivables."FTT-CST Servers Set Up");
                                        SpecailSelect.SetRange("Filter No.", Rec."Filter No.");
                                        SpecailSelect.DeleteAll();

                                        if DependencyItem.FindSet() then
                                            repeat
                                                SpecailSelect.Init;
                                                SpecailSelect."Item No." := DependencyItem."No.";
                                                SpecailSelect."Filter No." := Rec."Filter No.";
                                                SpecailSelect.Description := DependencyItem.Description;
                                                SpecailSelect."Comments Fluent" := DependencyItem."FTT-CST Comments Fluent";
                                                SpecailSelect."Unit Price" := DependencyItem."Unit Price";
                                                SpecailSelect.Quantity := pQty;
                                                SpecailSelect.Insert();
                                            until DependencyItem.Next = 0;
                                        Commit();
                                        SpecailSelect.SetRange("Filter No.", Rec."Filter No.");

                                        ItemList.LookupMode(true);
                                        ItemList.SetTableView(SpecailSelect);

                                        if ItemList.RunModal() = Action::LookupOK then begin
                                            AddSetUpLine(SetUpLines);
                                        end;

                                    end;
                                    if Rec."FTT-CST HARDWARE" <> '' then begin
                                        if rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Hosted then begin
                                            HMVisible := true;
                                            IntegrationVisible := false;
                                        end;
                                        if Rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::NonHosted then begin
                                            HMVisible := false;
                                            IntegrationVisible := true;
                                        end;
                                    end else begin
                                        HMVisible := false;
                                        IntegrationVisible := true;
                                    end;
                                    CurrPage.Update();
                                end;
                                MakeBackupDependencyFilters(Rec, false)
                            end;
                        }
                    }
                    group(HMGroup)
                    {
                        ShowCaption = false;
                        Visible = HMVisible;
                        field("FTT-CST CPU"; Rec."FTT-CST CPU")
                        {
                            ApplicationArea = All;
                            Caption = 'HOSTING AND MANAGEMENT';
                            Editable = true;

                            trigger OnValidate()
                            var
                                DependencyItem2: record "FTT-CST Dependancy Item";
                                pQty: Decimal;
                            begin
                                CurrPage.SelectedItems.Page.SetFilters(Rec."FTT-CST CPU");
                                CurrPage.Update();
                            end;


                            trigger OnLookup(var Text: Text): Boolean;
                            var
                                ItemList: page "FTT-CST Item List V2";
                                DependencyItem: Record "FTT-CST Special Select";
                                DependencyItem2: Record "FTT-CST Dependancy Item";
                                Item: record Item;
                                LicencesFilters: text[1024];
                                SalesReceivablesSetup: Record "Sales & Receivables Setup";
                                SpecailSelect: Record "FTT-CST Special Select";
                                FTTCSTCPU: text[1024];
                                pQty: Decimal;
                            begin
                                pQty := 0;
                                DependencyItem2.SetRange("Filter No.", Rec."Filter No.");
                                DependencyItem2.SetFilter("Item Category Code", 'HARDWARE');
                                if DependencyItem2.FindSet() then
                                    repeat
                                        pQty := pQty + DependencyItem2."FTT-CST Quantity";
                                    until DependencyItem2.next = 0;

                                SalesReceivablesSetup.Get();
                                SalesReceivablesSetup.TestField("FTT-CST Hosting and management");
                                Item.SetRange("Item Category Code", SalesReceivablesSetup."FTT-CST Hosting and management");
                                SpecailSelect.SetRange("Filter No.", Rec."Filter No.");
                                SpecailSelect.DeleteAll();

                                if Item.FindSet() then
                                    repeat
                                        SpecailSelect.Init;
                                        SpecailSelect."Item No." := Item."No.";
                                        SpecailSelect."Filter No." := Rec."Filter No.";
                                        SpecailSelect.Description := Item.Description;
                                        SpecailSelect."Comments Fluent" := Item."FTT-CST Comments Fluent";
                                        SpecailSelect."Unit Price" := Item."Unit Price";
                                        SpecailSelect.Quantity := pQty;
                                        SpecailSelect.Insert();
                                    until Item.Next = 0;

                                Commit();
                                SpecailSelect.SetRange("Filter No.", Rec."Filter No.");
                                ItemList.LookupMode(true);
                                ItemList.SetTableView(SpecailSelect);
                                if ItemList.RunModal() = Action::LookupOK then begin
                                    AddHostingLIne(FTTCSTCPU);
                                    Rec."FTT-CST CPU" := FTTCSTCPU;
                                    Rec.Modify;
                                end;
                                ConVisible := true;
                                MakeBackupDependencyFilters(Rec, false)
                            end;
                        }
                    }
                    group(ConGrou)
                    {
                        ShowCaption = false;
                        Visible = ConVisible;
                        Editable = true;
                        field("FTT-CST Conectivity"; rec."FTT-CST Conectivity")
                        {
                            ApplicationArea = All;
                            Caption = 'CONNECTIVITY';
                            ToolTip = 'Specifies the Conectivity that will be used to filter.';

                            trigger OnValidate()
                            begin
                                if rec."FTT-CST Conectivity" = Rec."FTT-CST Conectivity"::Yes then begin
                                    ConectivityVisible := true;
                                    AddCrossConnectVisible := true;
                                    ConfirmDocumentVisible := True;
                                    PrimaryVisible := true;
                                end else begin
                                    ConectivityVisible := false;
                                    AddCrossConnectVisible := false;
                                    PrimaryVisible := true;
                                    ConfirmDocumentVisible := True;
                                end;
                                if Rec."FTT-CST Conectivity" = Rec."FTT-CST Conectivity"::Blank then begin
                                    PrimaryVisible := false;
                                    CompLocVisible := false;
                                end;
                                MakeBackupDependencyFilters(Rec, false);
                                CurrPage.Update();
                            end;
                        }
                    }
                    group(Primary)
                    {
                        visible = PrimaryVisible;
                        Caption = '';
                        field("FTT-CST Licences Filters"; Rec."FTT-CST Licences Filters")
                        {
                            ApplicationArea = All;
                            Caption = 'LICENSES';
                            Editable = true;
                            trigger OnLookup(var Text: Text): Boolean;
                            var
                                ItemList: page "Item List";
                                FTTItemList: page "FTT-CST License List";
                                DependencyItem: Record Item;
                                Item: record Item;
                                LicencesFilters: text[1024];
                                SpecailSelect: Record "FTT-CST Licence Select";

                            begin
                                /*DependencyItem.SetFilter("Item Category Code", 'LICENSE');
                                ItemList.LookupMode(true);
                                ItemList.SetTableView(DependencyItem);
                                if ItemList.RunModal() = Action::LookupOK then begin
                                    DependancyFilter := ItemList.GetSelectionFilter();
                                    Rec.VALIDATE("FTT-CST Licences Filters", ItemList.GetSelectionFilter());
                                    CurrPage.SelectedDepItems.Page.SetFilters(DependancyFilter, Rec."Filter No.", LocationCode, 1);
                                    CurrPage.Update();
                                end;
                                */
                                Item.SetFilter("Item Category Code", 'LICENSE');
                                SpecailSelect.SetRange("Filter No.", Rec."Filter No.");
                                SpecailSelect.DeleteAll();

                                if Item.FindSet() then
                                    repeat
                                        SpecailSelect.Init;
                                        SpecailSelect."Item No." := Item."No.";
                                        SpecailSelect."Filter No." := Rec."Filter No.";
                                        SpecailSelect.Description := Item.Description;
                                        SpecailSelect."Comments Fluent" := Item."FTT-CST Comments Fluent";
                                        SpecailSelect."Unit Price" := Item."Unit Price";
                                        SpecailSelect.Insert();
                                    until Item.Next = 0;
                                Commit();
                                SpecailSelect.SetRange("Filter No.", Rec."Filter No.");

                                FTTItemList.LookupMode(true);
                                FTTItemList.SetTableView(SpecailSelect);

                                if FTTItemList.RunModal() = Action::LookupOK then begin
                                    AddLicenseLine(LicencesFilters);
                                    Rec.VALIDATE("FTT-CST Licences Filters", LicencesFilters);
                                    CurrPage.Update();
                                end;

                                MakeBackupDependencyFilters(Rec, false)
                            end;

                        }



                        field("FTT-CST Standard taker feed"; Rec."FTT-CST Standard taker feed")
                        {

                            ApplicationArea = All;
                            Caption = 'STANDARD TAKER FEED';
                            Editable = true;
                            trigger OnLookup(var Text: Text): Boolean;
                            var
                                ItemList2: page "Item List";
                                DependencyItem2: Record Item;
                                LicencesFilters2: text[1024];
                                LicencesFilters: text[1024];
                                Item: record Item;
                                FTTItemList: page "FTT-CST Item List";
                                DependencyItem: Record Item;
                                SpecailSelect: Record "FTT-CST Special Select";
                            begin
                                /*
                                DependencyItem.SetFilter("Item Category Code", 'STANDARD TAKER FEED');
                                ItemList.LookupMode(true);
                                ItemList.SetTableView(DependencyItem);
                                if ItemList.RunModal() = Action::LookupOK then begin
                                    //if DependancyFilter <> '' then
                                    //    DependancyFilter := DependancyFilter + '|' + ItemList.GetSelectionFilter() else
                                    DependancyFilter := ItemList.GetSelectionFilter();
                                    Rec.VALIDATE("FTT-CST Standard taker feed", ItemList.GetSelectionFilter());
                                    Rec.Modify();

                                    if DependancyFilter <> '' then
                                        CurrPage.SelectedDepItems.Page.SetFilters(DependancyFilter, Rec."Filter No.", LocationCode, 2);
                                    CurrPage.Update();
                                end;
                                */

                                Item.SetFilter("Item Category Code", 'STANDARD TAKER FEED');
                                SpecailSelect.SetRange("Filter No.", Rec."Filter No.");
                                SpecailSelect.DeleteAll();

                                if Item.FindSet() then
                                    repeat
                                        SpecailSelect.Init;
                                        SpecailSelect."Item No." := Item."No.";
                                        SpecailSelect."Filter No." := Rec."Filter No.";
                                        SpecailSelect.Description := Item.Description;
                                        SpecailSelect."Comments Fluent" := Item."FTT-CST Comments Fluent";
                                        SpecailSelect."Unit Price" := Item."Unit Price";
                                        SpecailSelect.Insert();
                                    until Item.Next = 0;
                                Commit();
                                SpecailSelect.SetRange("Filter No.", Rec."Filter No.");

                                FTTItemList.LookupMode(true);
                                FTTItemList.SetTableView(SpecailSelect);

                                if FTTItemList.RunModal() = Action::LookupOK then begin
                                    AddFeedLines(LicencesFilters, 'STANDARD TAKER FEED');
                                    Rec.VALIDATE("FTT-CST Standard taker feed", LicencesFilters);
                                    CurrPage.Update();
                                end;
                                MakeBackupDependencyFilters(Rec, false)
                            end;
                        }
                        field("FTT-CST NON Standard taker feed"; Rec."FTT-CST NON Standard taker")
                        {

                            ApplicationArea = All;
                            Caption = 'NS TAKER FEED';
                            Editable = true;
                            trigger OnLookup(var Text: Text): Boolean;
                            var
                                ItemList2: page "Item List";
                                DependencyItem2: Record Item;
                                LicencesFilters2: text[1024];
                                LicencesFilters: text[1024];
                                Item: record Item;
                                FTTItemList: page "FTT-CST Item List";
                                DependencyItem: Record Item;
                                SpecailSelect: Record "FTT-CST Special Select";
                            begin
                                /*
                                DependencyItem.SetFilter("Item Category Code", 'NS TAKER FEED');
                                ItemList.LookupMode(true);
                                ItemList.SetTableView(DependencyItem);
                                if ItemList.RunModal() = Action::LookupOK then begin
                                    //if DependancyFilter <> '' then
                                    //    DependancyFilter := DependancyFilter + '|' + ItemList.GetSelectionFilter() else
                                    DependancyFilter := ItemList.GetSelectionFilter();
                                    Rec.VALIDATE("FTT-CST NON Standard taker", ItemList.GetSelectionFilter());

                                    if DependancyFilter <> '' then
                                        CurrPage.SelectedDepItems.Page.SetFilters(DependancyFilter, Rec."Filter No.", LocationCode, 3);
                                    CurrPage.Update();
                                end;
                                */
                                Item.SetFilter("Item Category Code", 'NS TAKER FEED');
                                SpecailSelect.SetRange("Filter No.", Rec."Filter No.");
                                SpecailSelect.DeleteAll();

                                if Item.FindSet() then
                                    repeat
                                        SpecailSelect.Init;
                                        SpecailSelect."Item No." := Item."No.";
                                        SpecailSelect."Filter No." := Rec."Filter No.";
                                        SpecailSelect.Description := Item.Description;
                                        SpecailSelect."Comments Fluent" := Item."FTT-CST Comments Fluent";
                                        SpecailSelect."Unit Price" := Item."Unit Price";
                                        SpecailSelect.Insert();
                                    until Item.Next = 0;
                                Commit();
                                SpecailSelect.SetRange("Filter No.", Rec."Filter No.");

                                FTTItemList.LookupMode(true);
                                FTTItemList.SetTableView(SpecailSelect);

                                if FTTItemList.RunModal() = Action::LookupOK then begin
                                    AddFeedLines(LicencesFilters, 'NS MAKER FEED');
                                    Rec.VALIDATE("FTT-CST Non standard taker", LicencesFilters);
                                    CurrPage.Update();
                                end;
                                MakeBackupDependencyFilters(Rec, false)
                            end;
                        }
                        field("FTT-CST Standard maker feed"; Rec."FTT-CST Standard maker feed")
                        {
                            ApplicationArea = All;
                            Caption = 'STANDARD MAKER FEED';
                            Editable = true;

                            trigger OnLookup(var Text: Text): Boolean;
                            var
                                LicencesFilters: text[1024];
                                Item: record Item;
                                FTTItemList: page "FTT-CST Item List";
                                DependencyItem: Record Item;
                                SpecailSelect: Record "FTT-CST Special Select";
                            begin
                                /*DependencyItem.SetFilter("Item Category Code", 'STANDARD MAKER FEED');
                                ItemList.LookupMode(true);
                                ItemList.SetTableView(DependencyItem);
                                if ItemList.RunModal() = Action::LookupOK then begin
                                    //if DependancyFilter <> '' then
                                    //    DependancyFilter := DependancyFilter + '|' + ItemList.GetSelectionFilter() else
                                    DependancyFilter := ItemList.GetSelectionFilter();
                                    Rec.VALIDATE("FTT-CST Standard maker feed", ItemList.GetSelectionFilter());


                                    CurrPage.SelectedDepItems.Page.SetFilters(DependancyFilter, Rec."Filter No.", LocationCode, 4);
                                    CurrPage.Update();
                                end;
                                */
                                Item.SetFilter("Item Category Code", 'STANDARD MAKER FEED');
                                SpecailSelect.SetRange("Filter No.", Rec."Filter No.");
                                SpecailSelect.DeleteAll();

                                if Item.FindSet() then
                                    repeat
                                        SpecailSelect.Init;
                                        SpecailSelect."Item No." := Item."No.";
                                        SpecailSelect."Filter No." := Rec."Filter No.";
                                        SpecailSelect.Description := Item.Description;
                                        SpecailSelect."Unit Price" := Item."Unit Price";
                                        SpecailSelect."Comments Fluent" := Item."FTT-CST Comments Fluent";
                                        SpecailSelect.Insert();
                                    until Item.Next = 0;
                                Commit();
                                SpecailSelect.SetRange("Filter No.", Rec."Filter No.");

                                FTTItemList.LookupMode(true);
                                FTTItemList.SetTableView(SpecailSelect);

                                if FTTItemList.RunModal() = Action::LookupOK then begin
                                    AddFeedLines(LicencesFilters, 'STANDARD MAKER FEED');
                                    Rec.VALIDATE("FTT-CST Standard maker feed", LicencesFilters);
                                    CurrPage.Update();
                                end;
                                MakeBackupDependencyFilters(Rec, false)
                            end;

                        }
                        field("FTT-CST NON Standard maker"; Rec."FTT-CST NON Standard maker")
                        {
                            ApplicationArea = All;
                            Caption = 'NS MAKER FEED';
                            Editable = true;

                            trigger OnLookup(var Text: Text): Boolean;
                            var
                                ItemList: page "Item List";
                                LicencesFilters: text[1024];
                                Item: record Item;
                                FTTItemList: page "FTT-CST Item List";
                                DependencyItem: Record Item;
                                SpecailSelect: Record "FTT-CST Special Select";

                            begin
                                /*DependencyItem.SetFilter("Item Category Code", 'NS MAKER FEED');
                                ItemList.LookupMode(true);
                                ItemList.SetTableView(DependencyItem);
                                if ItemList.RunModal() = Action::LookupOK then begin
                                    DependancyFilter := ItemList.GetSelectionFilter();
                                    Rec.VALIDATE("FTT-CST NON Standard maker", ItemList.GetSelectionFilter());


                                    CurrPage.SelectedDepItems.Page.SetFilters(DependancyFilter, Rec."Filter No.", LocationCode, 5);
                                    CurrPage.Update();
                                end
                                */
                                Item.SetFilter("Item Category Code", 'NS MAKER FEED');
                                SpecailSelect.SetRange("Filter No.", Rec."Filter No.");
                                SpecailSelect.DeleteAll();

                                if Item.FindSet() then
                                    repeat
                                        SpecailSelect.Init;
                                        SpecailSelect."Item No." := Item."No.";
                                        SpecailSelect."Filter No." := Rec."Filter No.";
                                        SpecailSelect.Description := Item.Description;
                                        SpecailSelect."Unit Price" := Item."Unit Price";
                                        SpecailSelect."Comments Fluent" := Item."FTT-CST Comments Fluent";
                                        SpecailSelect.Insert();
                                    until Item.Next = 0;
                                Commit();
                                SpecailSelect.SetRange("Filter No.", Rec."Filter No.");

                                FTTItemList.LookupMode(true);
                                FTTItemList.SetTableView(SpecailSelect);

                                if FTTItemList.RunModal() = Action::LookupOK then begin
                                    AddFeedLines(LicencesFilters, 'NS MAKER FEED');
                                    Rec.VALIDATE("FTT-CST NON Standard Maker", LicencesFilters);
                                    CurrPage.Update();
                                end;
                                MakeBackupDependencyFilters(Rec, false)
                            end;
                        }
                        field("FTT-CST Integration"; Rec."FTT-CST Integration")
                        {
                            ApplicationArea = All;
                            Caption = 'INTEGRATION';
                            Editable = true;
                            trigger OnValidate()
                            var
                                DepItems: record "FTT-CST Dependancy Item";
                            begin
                                CurrPage.SelectedItems.Page.SetFilters(Rec."FTT-CST Integration");
                                CurrPage.Update();
                                CurrPage.Update(true);
                                DepItems.SetRange("Filter No.", Rec."Filter No.");
                                DepItems.SetRange("FTT-CST Integration", TRUE);
                                DepItems.DeleteAll();
                                Commit();
                            end;


                            trigger OnLookup(var Text: Text): Boolean;
                            var
                                ItemList: page "Item List";
                                DependencyItem: Record Item;
                                LicencesFilters: text[1024];
                            begin
                                DependencyItem.SetFilter("Item Category Code", 'INSTALLATION');
                                ItemList.LookupMode(true);
                                ItemList.SetTableView(DependencyItem);
                                if ItemList.RunModal() = Action::LookupOK then begin
                                    DependancyFilter := ItemList.GetSelectionFilter();
                                    Rec.VALIDATE("FTT-CST Integration", ItemList.GetSelectionFilter());
                                    CurrPage.SelectedDepItems.Page.SetFilters(DependancyFilter, Rec."Filter No.", LocationCode, 11, Rec."Sales Document No.");
                                    ConVisible := true;
                                    CurrPage.Update();
                                end;
                                MakeBackupDependencyFilters(Rec, false)
                            end;
                        }
                    }
                    group("CROSS СONNECT")
                    {
                        Visible = AddCrossConnectVisible;
                        ShowCaption = false;
                        field("Cross Connect"; Rec."FTT-CST Cross Connect")
                        {
                            caption = 'ADD CROSS CONNECT';
                            ApplicationArea = all;
                            Editable = true;
                            trigger OnValidate()
                            var
                                CrossConnect: Page "FTT-CST Cross Connect";
                                recCrossConnect: record "FTT-CST Cross Connect";
                                DependencyItems: record "FTT-CST Dependancy Item";
                            begin
                                recCrossConnect.SetRange("Filter No.", rec."Filter No.");
                                recCrossConnect.DeleteAll();

                                DependencyItems.SetRange("Filter No.", Rec."Filter No.");
                                DependencyItems.SetRange("FTT-CST Cross Connect", true);
                                if DependencyItems.FindSet() then
                                    DependencyItems.DeleteAll();
                                Commit();

                                DependencyItems.RESET;
                                if Rec."FTT-CST Cross Connect" then begin
                                    DependencyItems.SetRange("Filter No.", Rec."Filter No.");
                                    DependencyItems.SetRange("FTT-CST FEED", true);
                                    if DependencyItems.FindSet() then
                                        repeat
                                            recCrossConnect.Init();
                                            recCrossConnect."Filter No." := DependencyItems."Filter No.";
                                            recCrossConnect."Item No." := DependencyItems."No.";
                                            recCrossConnect.Description := DependencyItems.Description;
                                            if СheckIFFeedTypeIsNS(DependencyItems."No.") then begin
                                                recCrossConnect."Quantity 2" := 2;
                                                recCrossConnect."Quantity 4" := 2;
                                            end else begin
                                                recCrossConnect."Quantity 1" := 1;
                                                recCrossConnect."Quantity 3" := 1;
                                            end;
                                            recCrossConnect.Insert();
                                        until DependencyItems.next = 0;
                                    Commit();
                                    recCrossConnect.SetRange("Filter No.", Rec."Filter No.");
                                    CrossConnect.LookupMode(true);
                                    CrossConnect.SetTableView(recCrossConnect);
                                    if CrossConnect.RunModal() = Action::LookupOK then begin
                                        AddCrossConnect();

                                    end else begin
                                        ///ConVisible := false;
                                        //ConectivityVisible := false;
                                        Rec."FTT-CST Cross Connect" := false;
                                    end;
                                end;
                            end;
                        }
                    }
                    group("Confirm Document")
                    {
                        //Visible = ConfirmDocumentVisible;
                        Visible = false;
                        ShowCaption = false;
                        field(ConfirmDocument; ConfirmDocument)
                        {
                            Caption = 'CONFIRM SELECTED ITEMS';
                            trigger OnValidate()
                            begin
                                if (rec."FTT-CST Licences Filters" <> '') or
                                (Rec."FTT-CST NON Standard maker" <> '') or
                                (Rec."FTT-CST NON Standard taker" <> '') or
                                (Rec."FTT-CST Standard maker feed" <> '') or
                                (Rec."FTT-CST Standard taker feed" <> '')
                                then
                                    if rec."FTT-CST Integration" = '' then
                                        ERROR('Integration can not be blank');
                                if Rec."FTT-CST Conectivity" = Rec."FTT-CST Conectivity"::Yes then
                                    if not Rec."FTT-CST Cross Connect" then
                                        error('Cross connect should be added');
                            end;
                        }
                    }

                    group(RedundancyGroup)
                    {
                        Visible = false;
                        ShowCaption = false;
                        field(Redundancy2; RedundencyVisible)
                        {
                            caption = 'Redundancy';

                            trigger OnValidate()
                            var
                                DepItems: Record "FTT-CST Dependancy Item";
                            begin
                                if not RedundencyVisible then
                                    rec."FTT-CST Redundency" := '';
                                CurrPage.Update(true);
                                DepItems.SetRange("Filter No.", Rec."Filter No.");
                                DepItems.SetRange("FTT-CST Redundency", TRUE);
                                DepItems.DeleteAll();
                                Commit();
                                CurrPage.Update();
                            end;
                        }
                    }
                    field(DR2; DRVisible)
                    {
                        caption = 'DR';
                        Visible = false;
                        trigger OnValidate()
                        var
                            DepItems: Record "FTT-CST Dependancy Item";
                        begin
                            if not DRVisible then
                                rec."FTT-CST DR" := '';
                            CurrPage.Update(true);
                            DepItems.SetRange("Filter No.", Rec."Filter No.");
                            DepItems.SetRange("FTT-CST DR", TRUE);
                            DepItems.DeleteAll();
                            Commit();
                            CurrPage.Update();
                            Commit();
                            CurrPage.Update();
                        end;
                    }
                }
            }


            part(SelectedItems; "Item List")
            {
                Visible = false;
            }
            part(SelectedDepItems; "FTT-CST Dependency Item")
            {
                ApplicationArea = Basic, Suite;
                Editable = true;
                Enabled = true;
                SubPageLink = "Filter No." = FIELD("Filter No.");
                UpdatePropagation = Both;
                SubPageView = sorting("Location Code", Level);
            }

        }
    }
    actions
    {
        area(navigation)
        {
            group(Process)
            {
                action("CROSS CONNECT2")
                {
                    Caption = 'Add CROSS CONNECT';
                    ApplicationArea = all;
                    trigger OnAction()
                    begin
                        Message('Add CROSS CONNECT');
                    end;
                }
            }
        }
    }
    trigger OnOpenPage()
    var
        DependancyItem: Record "FTT-CST Dependancy Item";
    begin
        DependancyFilter := '';
        /*
        Rec."FTT-CST Cross Connect" := false;
        if Rec.FindLast() then begin
            Rec."FTT-CST CPU" := '';
            Rec."FTT-CST HARDWARE" := '';
            Rec."FTT-CST Licences Filters" := '';
            Rec."FTT-CST NON Standard maker" := '';
            Rec."FTT-CST Standard maker feed" := '';
            rec."FTT-CST Standard taker feed" := '';
            rec."FTT-CST NON Standard taker" := '';
            Rec."FTT-CST DR" := '';
            rec."FTT-CST Redundency" := '';
            rec."FTT-CST Integration" := '';
            rec."FTT-CST Location Code" := '';
            Rec."FTT-CST Cross Connect" := false;
            Rec.Modify()
        end else begin
            Rec.Init();
            Rec."Filter No." := 1;
            Rec."FTT-CST Location Code" := 'BLANK';
            Rec."FTT-CST Cross Connect" := false;
            Rec.Insert;
        end;
        if DependancyFilter = '' then begin
            CurrPage.SelectedDepItems.Page.SetFilters('0', Rec."Filter No.", LocationCode, 0);
            CurrPage.Update();
        end;
        */
        DependancyItem.SetRange("Filter No.", Rec."Filter No.");
        DependancyItem.DeleteAll();
    end;



    internal procedure SetFilters(SalespersonPurchaserCode: Code[20])
    begin
        SalespersonPurchaserCodeGlobal := SalespersonPurchaserCode;
    end;

    procedure AddCrossConnect()
    var
        CrossConnect: record "FTT-CST Cross Connect";
        DepItems: record "FTT-CST Dependancy Item";
        Item: Record Item;
        SalesReceivablesSetup: Record "Sales & Receivables Setup";
        Qty1: Decimal;
        Qty2: Decimal;
        Qty3: Decimal;
        Qty4: Decimal;
    begin
        SalesReceivablesSetup.Get();
        Qty1 := 0;
        Qty2 := 0;
        Qty3 := 0;
        Qty4 := 0;

        CrossConnect.SetRange("Filter No.", rec."Filter No.");
        if CrossConnect.FindSet() then
            repeat
                Qty1 := Qty1 + CrossConnect."Quantity 1";
                Qty2 := Qty2 + CrossConnect."Quantity 2";
                Qty3 := Qty3 + CrossConnect."Quantity 3";
                Qty4 := Qty4 + CrossConnect."Quantity 4";
            until CrossConnect.next = 0;
        Item.Reset;
        item.SetRange("Item Category Code", SalesReceivablesSetup."FTT-CST Shared MRC CC Category");
        if Item.FindFirst() and (Qty1 > 0) then begin
            DepItems.Init();
            DepItems."Location Code" := LocationCode;
            DepItems."Filter No." := Rec."Filter No.";
            DepItems.Level := 12;
            DepItems."No." := Item."No.";
            DepItems."FTT-CST Quantity" := Qty1;
            DepItems.Description := Item.Description;
            DepItems."FTT-CST Comments Fluent" := Item."FTT-CST Comments Fluent";
            DepItems."Unit Price" := Item."Unit Price";
            DepItems."FTT-CST Parent Category Code" := 'CROSS-CONNECT';
            DepItems."FTT-CST Cross Connect" := True;
            DepItems."Sales Document No." := Rec."Sales Document No.";
            DepItems.Insert();
        end;
        Item.Reset;
        Item.SetRange("Item Category Code", SalesReceivablesSetup."FTT-CST Shared NRC CC Category");
        if Item.FindFirst() and (Qty3 > 0) then begin
            DepItems.Init();
            DepItems."Location Code" := LocationCode;
            DepItems."Filter No." := Rec."Filter No.";
            DepItems.Level := 13;
            DepItems."No." := Item."No.";
            DepItems."FTT-CST Quantity" := Qty3;
            DepItems.Description := Item.Description;
            DepItems."FTT-CST Comments Fluent" := Item."FTT-CST Comments Fluent";
            DepItems."Unit Price" := Item."Unit Price";
            DepItems."FTT-CST Cross Connect" := True;
            DepItems."FTT-CST Parent Category Code" := 'CROSS-CONNECT';
            DepItems."Sales Document No." := Rec."Sales Document No.";
            DepItems.Insert();
        end;

        Item.Reset;
        Item.SetRange("Item Category Code", SalesReceivablesSetup."FTT-CST Ded. MRC CC Category");
        if item.FindFirst() and (Qty2 > 0) then begin
            DepItems.Init();
            DepItems."Location Code" := LocationCode;
            DepItems."Filter No." := Rec."Filter No.";
            DepItems.Level := 14;
            DepItems."No." := Item."No.";
            DepItems."FTT-CST Quantity" := Qty2;
            DepItems.Description := Item.Description;
            DepItems."FTT-CST Comments Fluent" := Item."FTT-CST Comments Fluent";
            DepItems."Unit Price" := Item."Unit Price";
            DepItems."FTT-CST Cross Connect" := True;
            DepItems."FTT-CST Parent Category Code" := 'CROSS-CONNECT';
            DepItems."Sales Document No." := Rec."Sales Document No.";
            DepItems.Insert();
        end;

        Item.Reset;
        Item.SetRange("Item Category Code", SalesReceivablesSetup."FTT-CST Ded. NRC CC Category");
        if Item.FindFirst() and (Qty4 > 0) then begin
            DepItems.Init();
            DepItems."Location Code" := LocationCode;
            DepItems."Filter No." := Rec."Filter No.";
            DepItems.Level := 15;
            DepItems."No." := Item."No.";
            DepItems."FTT-CST Quantity" := Qty4;
            DepItems.Description := Item.Description;
            DepItems."Unit Price" := Item."Unit Price";
            DepItems."FTT-CST Comments Fluent" := Item."FTT-CST Comments Fluent";
            DepItems."FTT-CST Cross Connect" := True;
            DepItems."FTT-CST Parent Category Code" := 'CROSS-CONNECT';
            DepItems."Sales Document No." := Rec."Sales Document No.";
            DepItems.Insert();
        end;
    end;

    procedure AddHardwareConnect(var pFilter: text[1024])
    var
        DepItems: record "FTT-CST Dependancy Item";
        Item: Record Item;
        SalesReceivablesSetup: Record "Sales & Receivables Setup";
        SpecialSelect: record "FTT-CST Special Select";
    begin
        pFilter := '';
        SalesReceivablesSetup.Get();
        SpecialSelect.SetRange("Filter No.", Rec."Filter No.");
        if SpecialSelect.FindSet() then
            repeat
                if SpecialSelect.Quantity > 0 then begin
                    DepItems.Init();
                    DepItems."Location Code" := LocationCode;
                    DepItems."Filter No." := Rec."Filter No.";
                    DepItems."No." := SpecialSelect."Item No.";
                    DepItems."FTT-CST Quantity" := SpecialSelect.Quantity;
                    DepItems.Description := SpecialSelect.Description;
                    DepItems."Unit Price" := SpecialSelect."Unit Price";
                    DepItems."Item Category Code" := 'HARDWARE';
                    DepItems."FTT-CST Parent Category Code" := 'HARDWARE';
                    DepItems."FTT-CST Comments" := SpecialSelect.Comments;
                    DepItems."FTT-CST Comments Fluent" := SpecialSelect."Comments Fluent";

                    DepItems.Optional := SpecialSelect.Optional;
                    DepItems."Sales Document No." := Rec."Sales Document No.";
                    DepItems.Level := 8;
                    DepItems.Insert();
                    if pFilter = '' then
                        pFilter := SpecialSelect."Item No." else
                        pFilter := pFilter + '|' + SpecialSelect."Item No.";
                end;
            until SpecialSelect.next = 0;
    end;

    procedure AddHostingLine(var pFilter: text[1024])
    var
        DepItems: record "FTT-CST Dependancy Item";
        Item: Record Item;
        SalesReceivablesSetup: Record "Sales & Receivables Setup";
        SpecialSelect: record "FTT-CST Special Select";
    begin
        pFilter := '';
        SalesReceivablesSetup.Get();
        SpecialSelect.SetRange("Filter No.", Rec."Filter No.");
        if SpecialSelect.FindSet() then
            repeat
                if SpecialSelect.Quantity > 0 then begin
                    DepItems.Init();
                    DepItems."Location Code" := LocationCode;
                    DepItems."Filter No." := Rec."Filter No.";
                    DepItems."No." := SpecialSelect."Item No.";
                    DepItems."FTT-CST Quantity" := SpecialSelect.Quantity;
                    DepItems.Description := SpecialSelect.Description;
                    DepItems."Unit Price" := SpecialSelect."Unit Price";
                    DepItems."FTT-CST Comments" := SpecialSelect.Comments;
                    DepItems."FTT-CST Comments Fluent" := SpecialSelect."Comments Fluent";
                    DepItems.Optional := SpecialSelect.Optional;
                    DepItems."FTT-CST Parent Category Code" := 'HOSTING';
                    DepItems."Sales Document No." := Rec."Sales Document No.";
                    DepItems.Level := 10;
                    DepItems.Insert();
                    if pFilter = '' then
                        pFilter := SpecialSelect."Item No." else
                        pFilter := pFilter + '|' + SpecialSelect."Item No.";
                end;
            until SpecialSelect.next = 0;
    end;

    procedure AddLicenseLine(var pFilter: text[1024])
    var
        DepItems: record "FTT-CST Dependancy Item";
        Item: Record Item;
        SalesReceivablesSetup: Record "Sales & Receivables Setup";
        SpecialSelect: record "FTT-CST Licence Select";
    begin
        pFilter := '';
        SalesReceivablesSetup.Get();
        SpecialSelect.SetRange("Filter No.", Rec."Filter No.");
        if SpecialSelect.FindSet() then
            repeat
                if SpecialSelect.Quantity > 0 then begin
                    DepItems.Init();
                    DepItems."Location Code" := LocationCode;
                    DepItems."Filter No." := Rec."Filter No.";
                    DepItems."No." := SpecialSelect."Item No.";
                    DepItems."FTT-CST Quantity" := SpecialSelect.Quantity;
                    DepItems.Description := SpecialSelect.Description;
                    DepItems."Unit Price" := SpecialSelect."Unit Price";
                    DepItems."FTT-CST Comments" := SpecialSelect.Comments;
                    DepItems."FTT-CST Comments Fluent" := SpecialSelect."Comments Fluent";
                    DepItems.Optional := SpecialSelect.Optional;
                    DepItems."FTT-CST Parent Category Code" := 'LICENSE';
                    DepItems.Level := 1;
                    DepItems."FTT-CST Use for Discount" := true;
                    DepItems."Sales Document No." := Rec."Sales Document No.";
                    DepItems.Insert();
                    if pFilter = '' then
                        pFilter := SpecialSelect."Item No." else
                        pFilter := pFilter + '|' + SpecialSelect."Item No.";
                end;
            until SpecialSelect.next = 0;
    end;

    procedure AddSpecialLines(var pFilter: text[1024]; GroupCode: code[20])
    var
        DepItems: record "FTT-CST Dependancy Item";
        Item: Record Item;
        SalesReceivablesSetup: Record "Sales & Receivables Setup";
        SpecialSelect: record "FTT-CST Licence Select";
    begin
        pFilter := '';
        SalesReceivablesSetup.Get();
        SpecialSelect.SetRange("Filter No.", Rec."Filter No.");
        if SpecialSelect.FindSet() then
            repeat
                if SpecialSelect.Quantity > 0 then begin
                    DepItems.Init();
                    DepItems."Location Code" := LocationCode;
                    DepItems."Filter No." := Rec."Filter No.";
                    DepItems."No." := SpecialSelect."Item No.";
                    DepItems."FTT-CST Quantity" := SpecialSelect.Quantity;
                    DepItems.Description := SpecialSelect.Description;
                    DepItems."Unit Price" := SpecialSelect."Unit Price";
                    DepItems."FTT-CST Comments" := SpecialSelect.Comments;
                    DepItems."FTT-CST Comments Fluent" := SpecialSelect."Comments Fluent";
                    DepItems.Optional := SpecialSelect.Optional;
                    DepItems."FTT-CST Use for Discount" := true;
                    DepItems."Sales Document No." := Rec."Sales Document No.";
                    case GroupCode of
                        'LICENSE':
                            DepItems.Level := 1;
                        'STANDARD TAKER FEED':
                            DepItems.Level := 2;
                        'NS TAKER FEED':
                            DepItems.Level := 3;
                        'STANDARD MAKER FEED':
                            DepItems.Level := 4;
                        'NS MAKER FEED':
                            DepItems.Level := 5;
                    end;
                    DepItems.Insert();
                    if pFilter = '' then
                        pFilter := SpecialSelect."Item No." else
                        pFilter := pFilter + '|' + SpecialSelect."Item No.";
                end;
            until SpecialSelect.next = 0;
    end;

    procedure AddFeedLines(var pFilter: text[1024]; GroupCode: code[20])
    var
        DepItems: record "FTT-CST Dependancy Item";
        Item: Record Item;
        SalesReceivablesSetup: Record "Sales & Receivables Setup";
        SpecialSelect: record "FTT-CST Special Select";
    begin
        pFilter := '';
        SalesReceivablesSetup.Get();
        SpecialSelect.SetRange("Filter No.", Rec."Filter No.");
        if SpecialSelect.FindSet() then
            repeat
                if SpecialSelect.Quantity > 0 then begin
                    DepItems.Init();
                    DepItems."Location Code" := LocationCode;
                    DepItems."Filter No." := Rec."Filter No.";
                    DepItems."No." := SpecialSelect."Item No.";
                    DepItems."FTT-CST Quantity" := SpecialSelect.Quantity;
                    DepItems.Description := SpecialSelect.Description;
                    DepItems."Unit Price" := SpecialSelect."Unit Price";
                    DepItems."FTT-CST FEED" := true;
                    DepItems."FTT-CST Comments" := SpecialSelect.Comments;
                    DepItems."FTT-CST Comments Fluent" := SpecialSelect."Comments Fluent";
                    DepItems.Optional := SpecialSelect.Optional;
                    DepItems."FTT-CST Use for Discount" := true;
                    DepItems."FTT-CST Parent Category Code" := 'FEED';
                    DepItems."Sales Document No." := Rec."Sales Document No.";
                    case GroupCode of
                        'LICENSE':
                            DepItems.Level := 1;
                        'STANDARD TAKER FEED':
                            DepItems.Level := 2;
                        'NS TAKER FEED':
                            DepItems.Level := 3;
                        'STANDARD MAKER FEED':
                            DepItems.Level := 4;
                        'NS MAKER FEED':
                            DepItems.Level := 5;
                    end;
                    DepItems.Insert();
                    if pFilter = '' then
                        pFilter := SpecialSelect."Item No." else
                        pFilter := pFilter + '|' + SpecialSelect."Item No.";
                end;
            until SpecialSelect.next = 0;
    end;



    procedure AddSetUpLine(var pFilter: text[1024])
    var
        DepItems: record "FTT-CST Dependancy Item";
        Item: Record Item;
        SalesReceivablesSetup: Record "Sales & Receivables Setup";
        SpecialSelect: record "FTT-CST Special Select";
    begin
        pFilter := '';
        SalesReceivablesSetup.Get();
        SpecialSelect.SetRange("Filter No.", Rec."Filter No.");
        if SpecialSelect.FindSet() then
            repeat
                if SpecialSelect.Quantity > 0 then begin
                    DepItems.Init();
                    DepItems."Location Code" := LocationCode;
                    DepItems."Filter No." := Rec."Filter No.";
                    DepItems."No." := SpecialSelect."Item No.";
                    DepItems."FTT-CST Quantity" := SpecialSelect.Quantity;
                    DepItems.Description := SpecialSelect.Description;
                    DepItems."Unit Price" := SpecialSelect."Unit Price";
                    DepItems."FTT-CST Comments" := SpecialSelect.Comments;
                    DepItems."FTT-CST Comments Fluent" := SpecialSelect."Comments Fluent";
                    DepItems.Optional := SpecialSelect.Optional;
                    DepItems."FTT-CST Parent Category Code" := 'HARDWARE';
                    DepItems."Sales Document No." := Rec."Sales Document No.";
                    DepItems.Level := 9;
                    DepItems.Insert();
                    if pFilter = '' then
                        pFilter := SpecialSelect."Item No." else
                        pFilter := pFilter + '|' + SpecialSelect."Item No.";
                end;
            until SpecialSelect.next = 0;
    end;

    procedure СheckIFFeedTypeIsNS(ItemNo: code[20]): Boolean;
    var
        Item: record Item;
        SalesReceivables: Record "Sales & Receivables Setup";
    begin
        if Item.Get(ItemNo) then;
        if (Item."Item Category Code" = 'NS MAKER FEED') or (Item."Item Category Code" = 'NS TAKER FEED') then
            exit(true) else
            exit(false);
    end;

    procedure ResetSelectedFilters()
    begin
        //Rec."FTT-CST Type of Site" := rec."FTT-CST Type of Site"::Blank;
        //Rec."FTT-CST Component Option" := Rec."FTT-CST Component Option"::Blank;
        Rec."FTT-CST Type of Site" := rec."FTT-CST Type of Site"::Blank;
        Rec."FTT-CST Conectivity" := Rec."FTT-CST Conectivity"::Blank;
        Rec."FTT-CST DR" := '';
        Rec."FTT-CST Redundency" := '';

        Rec."FTT-CST CPU" := '';
        Rec."FTT-CST HARDWARE" := '';
        Rec."FTT-CST Licences Filters" := '';
        Rec."FTT-CST NON Standard maker" := '';
        Rec."FTT-CST Standard maker feed" := '';
        Rec."FTT-CST Standard taker feed" := '';
        Rec."FTT-CST NON Standard taker" := '';

        DRVisible := false;
        RedundencyVisible := false;
        HMVisible := false;
        HardwareVisible := false;
        TypeSiteVisible := false;
        AddCrossConnectVisible := false;
        ConfirmDocument := false;
        PrimaryVisible := false;
        Rec.Modify();
        CurrPage.Update();
    end;

    procedure ResetSelectedFilters2()
    begin
        Rec."FTT-CST Type of Site" := rec."FTT-CST Type of Site"::Blank;
        Rec."FTT-CST Component Option" := Rec."FTT-CST Component Option"::Blank;
    end;

    procedure MakeBackupDependencyFilters(var DepFlters: record "FTT-CST Dependency Filters"; UpdateLayout: boolean): Boolean
    var
        CopyDedependecyFilters: record "FTT-CST Dep. Filters Copy";
    begin
        if CopyDedependecyFilters.GET(DepFlters."Sales Document No.", DepFlters."Filter No.", DepFlters."FTT-CST Location Code") and UpdateLayout then begin
            begin
                DepFlters.TransferFields(CopyDedependecyFilters);
                DepFlters."FTT-CST Redundency" := CopyDedependecyFilters."FTT-CST Redundency";
                DepFlters.Modify();
                if UpdateLayout then begin
                    CompLocVisible := CopyDedependecyFilters.ComLosVisible;
                    PrimaryVisible := CopyDedependecyFilters.PrimaryVisible;
                    ConVisible := CopyDedependecyFilters.ConVisible;
                    IntegrationVisible := CopyDedependecyFilters.IntegrationVisible;
                    ConectivityVisible := CopyDedependecyFilters.ConectivityVisible;
                    TypeSiteVisible := CopyDedependecyFilters.TypeSiteVisible;
                    RedundencyVisible := CopyDedependecyFilters.RedundencyVisible;
                    HMVisible := CopyDedependecyFilters.HMVisible;
                    DRVisible := CopyDedependecyFilters.DRVisible;
                    HardwareVisible := CopyDedependecyFilters.HardwareVisible;
                    LocTypeVisible := CopyDedependecyFilters.LocTypeVisible;
                    AddCrossConnectVisible := CopyDedependecyFilters.AddCrossConnectVisible
                end;
                CurrPage.Update();
                exit(true);
            end;
        end;

        if CopyDedependecyFilters.GET(DepFlters."Sales Document No.", DepFlters."Filter No.", DepFlters."FTT-CST Location Code") and not UpdateLayout then begin
            begin
                CopyDedependecyFilters.TransferFields(DepFlters);
                CopyDedependecyFilters.ComLosVisible := CompLocVisible;
                CopyDedependecyFilters.PrimaryVisible := PrimaryVisible;
                CopyDedependecyFilters.ConVisible := ConVisible;
                CopyDedependecyFilters.IntegrationVisible := IntegrationVisible;
                CopyDedependecyFilters.ConectivityVisible := ConnectivityVisible;
                CopyDedependecyFilters.TypeSiteVisible := TypeSiteVisible;
                CopyDedependecyFilters.RedundencyVisible := RedundencyVisible;
                CopyDedependecyFilters.HMVisible := HMVisible;
                CopyDedependecyFilters.DRVisible := DRVisible;
                CopyDedependecyFilters.HardwareVisible := HardwareVisible;
                CopyDedependecyFilters.LocTypeVisible := LocTypeVisible;
                CopyDedependecyFilters.AddCrossConnectVisible := AddCrossConnectVisible;
                CopyDedependecyFilters.Modify();
            end;
        end;

        if NOT CopyDedependecyFilters.GET(DepFlters."Sales Document No.", DepFlters."Filter No.", DepFlters."FTT-CST Location Code") then begin
            CopyDedependecyFilters.Init;
            CopyDedependecyFilters.TransferFields(DepFlters);
            CopyDedependecyFilters.ComLosVisible := CompLocVisible;
            CopyDedependecyFilters.PrimaryVisible := PrimaryVisible;
            CopyDedependecyFilters.ConVisible := ConVisible;
            CopyDedependecyFilters.IntegrationVisible := IntegrationVisible;
            CopyDedependecyFilters.ConectivityVisible := ConnectivityVisible;
            CopyDedependecyFilters.TypeSiteVisible := TypeSiteVisible;
            CopyDedependecyFilters.RedundencyVisible := RedundencyVisible;
            CopyDedependecyFilters.HMVisible := HMVisible;
            CopyDedependecyFilters.DRVisible := DRVisible;
            CopyDedependecyFilters.HardwareVisible := HardwareVisible;
            CopyDedependecyFilters.LocTypeVisible := LocTypeVisible;
            CopyDedependecyFilters.AddCrossConnectVisible := AddCrossConnectVisible;
            if CopyDedependecyFilters.Insert() then;
            if DepFlters."FTT-CST Component Option" <> DepFlters."FTT-CST Component Option"::Blank then
                exit(false);
        end;
    end;

    var
        "FTT-CST Salesp. Benef. Filter": Code[20];
        SalespersonPurchaserCodeGlobal: Code[20];
        "FTT-CST Total Amount (LCY)": Decimal;
        "FTT-CST Date Filter": Text;
        DependancyFilter: Text[1024];
        [InDataSet]
        PrimaryVisible: Boolean;
        [InDataSet]
        DRVisible: Boolean;
        [InDataSet]
        RedundencyVisible2: Boolean;
        [InDataSet]
        CrossConnect: boolean;
        [InDataSet]
        ConectivityVisible: Boolean;
        LondonLocation: Boolean;
        SINGAPORELocation: Boolean;
        NewYorkLocation: Boolean;
        TokyoLocation: Boolean;
        COPENHAGENLocation: Boolean;
        MALAYSIALocation: Boolean;
        LocationCode: code[20];
        PrevLocationCode: code[20];
        [InDataSet]
        AddCrossConnectVisible: Boolean;
        LocTypeHosted: Boolean;
        LocTypeNonHosted: Boolean;
        LocTypeUnknown: Boolean;
        [InDataSet]
        TypeSiteVisible: Boolean;
        RedundencyVisible: Boolean;
        IntegrationVisible: Boolean;
        HMVisible: Boolean;
        HardwareVisible: Boolean;
        CompLocVisible: boolean;
        ConnectivityVisible: Boolean;
        LocTypeVisible: Boolean;
        [InDataSet]
        ConfirmDocument: Boolean;
        ConfirmDocumentVisible: Boolean;
        ConVisible: Boolean;
        CHICAGOLocation: Boolean;

}