page 50029 "FTT-CST Comm. Agr. Subform"
{
    PageType = ListPart;
    SourceTable = "FTT-CST Comm. Agrm. Lines";
    AutoSplitKey = true;
    RefreshOnActivate = true;

    layout
    {
        area(content)
        {
            repeater(Lines)
            {

                field("Line No."; rec."Line No.")
                {
                    ApplicationArea = All;
                    Visible = false;
                }

                field("Salesperson Code"; Rec."Salesperson Code")
                {
                    ApplicationArea = all;

                }
                field("Customer Type"; Rec."Customer Type")
                {
                    ApplicationArea = all;

                }
                field("Customer No."; Rec."Customer No.")
                {
                    ApplicationArea = all;
                }


                field("Item Category Type"; Rec."Item Category Type")
                {
                    ApplicationArea = all;
                }
                field("Category No."; Rec."Category No.")
                {
                    ApplicationArea = all;
                }
                field("Agreement Period"; Rec."Agreement Period")
                {
                    ApplicationArea = all;
                }
                field("Commission %"; Rec."Commission %")
                {
                    ApplicationArea = all;
                }

            }

        }


    }




    var
        myInt: Integer;
}