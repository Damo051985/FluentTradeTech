page 60031 "Opportunity Entry List"
{
    ApplicationArea = Basic, Suite;
    Caption = 'Opportunity Entry List';
    PageType = List;
    SourceTable = "Opportunity Entry";
    UsageCategory = Lists;
    Editable = false;
    LinksAllowed = False;

    layout
    {
        area(Content)
        {
            repeater(General)
            {
                field("Opportunity No."; Rec."Opportunity No.")
                {
                    ToolTip = 'Specifies the number of the opportunity to which this entry applies.';
                }
                field(Active; Rec.Active)
                {
                    ToolTip = 'Specifies that the opportunity entry is active.';
                }
                field("Sales Cycle Stage"; Rec."Sales Cycle Stage")
                {
                    ToolTip = 'Specifies the sales cycle stage currently of the opportunity.';
                }
                field("Sales Cycle Stage Description"; Rec."Sales Cycle Stage Description")
                {
                    ToolTip = 'Specifies a description of the sales cycle that is related to the task. The description is copied from the sales cycle card.';
                }
                field("Date of Change"; Rec."Date of Change")
                {
                    ToolTip = 'Specifies the date this opportunity entry was last changed.';
                }
                field("Estimated Close Date"; Rec."Estimated Close Date")
                {
                    ToolTip = 'Specifies the estimated date when the opportunity entry will be closed.';
                }
                field("Estimated Value (LCY)"; Rec."Estimated Value (LCY)")
                {
                    ToolTip = 'Specifies the estimated value of the opportunity entry.';
                }
                field("Calcd. Current Value (LCY)"; Rec."Calcd. Current Value (LCY)")
                {
                    ToolTip = 'Specifies the calculated current value of the opportunity entry.';
                }
                field("Completed %"; Rec."Completed %")
                {
                    ToolTip = 'Specifies the percentage of the sales cycle that has been completed for this opportunity entry.';
                }
                field("Chances of Success %"; Rec."Chances of Success %")
                {
                    ToolTip = 'Specifies the chances of success of the opportunity entry.';
                }
                field("Probability %"; Rec."Probability %")
                {
                    ToolTip = 'Specifies the probability of the opportunity resulting in a sale.';
                }
            }
        }
    }
    actions
    {
        area(navigation)
        {
            group("&Line")
            {
                Caption = '&Line';
                Image = Line;
                action("Show Document")
                {
                    ApplicationArea = Basic, Suite;
                    Caption = 'Show Document';
                    Image = View;
                    ShortCutKey = 'Shift+F7';
                    ToolTip = 'Open the document that the selected line exists on.';

                    trigger OnAction()
                    var
                        PageManagement: Codeunit "Page Management";
                        lOppCard: Page "Opportunity Card";
                        lOpp: Record Opportunity;
                    begin
                        Clear(lOppCard);
                        lOpp.SETFILTER("No.", Rec."Opportunity No."); //GET Doesn't work. Use Setfilter
                        IF lOpp.FINDFIRST then begin
                            lOppCard.SetTableView(lOpp);
                            lOppCard.RUN;
                        end;

                    end;
                }
            }
        }

        area(Promoted)
        {
            group(Category_Process)
            {
                Caption = 'Process', Comment = 'Generated from the PromotedActionCategories property index 1.';

                actionref("Show Document_Promoted"; "Show Document")
                {
                }

            }
        }

    }
    Var
        opporEntry: Record "Opportunity Entry";
}
