page 60020 "FTT-CST Smart Dep by Location"
{
    ApplicationArea = All;
    Caption = 'Item Category Hierarchy and Dependencies';
    DeleteAllowed = true;
    InsertAllowed = true;
    Editable = true;
    PageType = Document;
    RefreshOnActivate = true;
    SourceTable = "FTT-CST Dependency Filters";

    layout
    {
        area(Content)
        {
            group(General)
            {
                ShowCaption = false;
                group(Locations)
                {
                    Caption = 'LOCATIONS';
                    field(LondonLocation; LondonLocation)
                    {
                        Caption = 'LONDON';
                        ApplicationArea = all;
                        trigger OnValidate()
                        begin

                            MakeOFFAllLocations();
                            if LondonLocation then begin
                                Rec."FTT-CST Location Code" := 'LONDON';
                                Rec."FTT-CST Sublocation" := rec."FTT-CST Sublocation"::LD4;
                                SublocationVisible := true;
                                LocTypeVisible := true;
                                Rec.Modify();
                            end;

                            if LondonLocation then begin
                                NewYorkLocation := false;
                                SINGAPORELocation := false;
                                TokyoLocation := false;
                                MALAYSIALocation := false;
                                COPENHAGENLocation := false;
                                CHICAGOLocation := false;

                                LocationCode := 'LONDON';
                                if PrevLocationCode = '' then
                                    PrevLocationCode := 'LONDON';
                                SublocationVisible := true;
                                CompLocVisible := false;
                                PrimaryVisible := false;
                                ConVisible := false;
                                IntegrationVisible := false;
                                ConectivityVisible := false;
                            end;
                            if (COPENHAGENLocation = false)
                            and (SINGAPORELocation = false)
                            and (NewYorkLocation = false) and
                            (TokyoLocation = false)
                            and (LondonLocation = false)
                            and (MALAYSIALocation = false)
                            and (CHICAGOLocation = false)
                                 then
                                SublocationVisible := false
                            else begin
                                SublocationVisible := true;
                                LocTypeVisible := true;
                            end;

                            if LondonLocation then
                                if not MakeBackupDependencyFilters(Rec, true) then begin
                                    ResetSelectedFilters2();
                                    ResetSelectedFilters();
                                end;
                            CurrPage.Update();
                        end;

                    }
                    field(NewYorkLocation; NewYorkLocation)
                    {
                        Caption = 'NEW YORK';
                        trigger OnValidate()
                        begin
                            MakeOFFAllLocations();
                            if NewYorkLocation then begin
                                Rec."FTT-CST Location Code" := 'NEW YORK';
                                Rec."FTT-CST Sublocation" := rec."FTT-CST Sublocation"::NY2;
                                SublocationVisible := true;
                                LocTypeVisible := true;
                                Rec.Modify();

                                LondonLocation := false;
                                SINGAPORELocation := false;
                                TokyoLocation := false;
                                LocationCode := 'NEW YORK';
                                if PrevLocationCode = '' then
                                    PrevLocationCode := 'NEW YORK';
                                MALAYSIALocation := false;
                                COPENHAGENLocation := false;
                                CHICAGOLocation := false;
                                HardwareVisible := false;
                                CompLocVisible := false;
                                PrimaryVisible := false;
                                ConVisible := false;
                                IntegrationVisible := false;
                                ConectivityVisible := false;
                                SublocationVisible := true;
                                LocTypeVisible := true;
                            end;

                            if NewYorkLocation then
                                IF NOT MakeBackupDependencyFilters(Rec, true) THEN BEGIN
                                    ResetSelectedFilters2();
                                    ResetSelectedFilters();
                                END;

                            if (COPENHAGENLocation = false)
                            and (SINGAPORELocation = false)
                            and (NewYorkLocation = false) and
                            (TokyoLocation = false)
                            and (LondonLocation = false)
                            and (MALAYSIALocation = false)
                            and (CHICAGOLocation = false)
                                 then begin
                                SublocationVisible := false;
                                LocTypeVisible := false;
                            end
                            else begin
                                SublocationVisible := true;
                                LocTypeVisible := true;
                            end;
                            CurrPage.Update();
                        end;

                    }
                    field(TOKYOLocation; TokyoLocation)
                    {
                        Caption = 'TOKYO';
                        trigger OnValidate()
                        begin
                            MakeOFFAllLocations();
                            if TokyoLocation then begin
                                if TokyoLocation then begin
                                    Rec."FTT-CST Location Code" := 'TOKYO';
                                    Rec."FTT-CST Sublocation" := rec."FTT-CST Sublocation"::TY3;
                                    SublocationVisible := true;
                                    LocTypeVisible := true;
                                    Rec.Modify();
                                end;
                                NewYorkLocation := false;
                                LondonLocation := false;
                                SINGAPORELocation := false;
                                LocationCode := 'TOKYO';
                                if PrevLocationCode = '' then
                                    PrevLocationCode := 'TOKYO';
                                MALAYSIALocation := false;
                                COPENHAGENLocation := false;
                                CHICAGOLocation := false;

                                CompLocVisible := false;
                                PrimaryVisible := false;
                                ConVisible := false;
                                IntegrationVisible := false;
                                ConectivityVisible := false;
                                SublocationVisible := true;
                                LocTypeVisible := true;
                            end;
                            if (COPENHAGENLocation = false) and (SINGAPORELocation = false) and (NewYorkLocation = false) and
                            (TokyoLocation = false) and (LondonLocation = false) and (MALAYSIALocation = false) and (CHICAGOLocation = false)
                                 then
                                SublocationVisible := false else
                                SublocationVisible := true;
                            if TokyoLocation then
                                IF NOT MakeBackupDependencyFilters(Rec, true) THEN BEGIN
                                    ResetSelectedFilters2();
                                    ResetSelectedFilters();
                                END;
                            CurrPage.Update();
                        end;

                    }
                    field(SINGAPORELocation; SINGAPORELocation)
                    {
                        Caption = 'SINGAPORE';
                        trigger OnValidate()
                        begin
                            MakeOFFAllLocations();
                            if SINGAPORELocation then begin
                                Rec."FTT-CST Location Code" := 'SINGAPORE';
                                rec."FTT-CST Sublocation" := rec."FTT-CST Sublocation"::SG1;
                                SublocationVisible := true;
                                LocTypeVisible := true;
                                Rec.Modify();
                                NewYorkLocation := false;
                                LondonLocation := false;
                                TokyoLocation := false;
                                COPENHAGENLocation := false;
                                MALAYSIALocation := false;
                                CHICAGOLocation := false;

                                LocationCode := 'SINGAPORE';
                                CompLocVisible := false;
                                PrimaryVisible := false;
                                ConVisible := false;
                                IntegrationVisible := false;
                                ConectivityVisible := false;
                                SublocationVisible := true;
                                LocTypeVisible := true;
                            end;
                            if (COPENHAGENLocation = false) and (SINGAPORELocation = false) and (NewYorkLocation = false) and
(TokyoLocation = false) and (LondonLocation = false) and (MALAYSIALocation = false) and (CHICAGOLocation = false)
     then
                                SublocationVisible := false else begin
                                SublocationVisible := true;
                                LocTypeVisible := true;
                            end;
                            if SINGAPORELocation then
                                IF NOT MakeBackupDependencyFilters(Rec, true) THEN BEGIN
                                    ResetSelectedFilters2();
                                    ResetSelectedFilters();
                                END;
                            CurrPage.Update();
                        end;

                    }
                    // COPENHAGEN, MALAYSIA
                    field(COPENHAGENLocation; COPENHAGENLocation)
                    {
                        Caption = 'COPENHAGEN';
                        trigger OnValidate()
                        begin
                            MakeOFFAllLocations();
                            if COPENHAGENLocation then begin
                                Rec."FTT-CST Location Code" := 'COPENHAGEN';
                                Rec."FTT-CST Sublocation" := rec."FTT-CST Sublocation"::None;
                                SublocationVisible := true;
                                LocTypeVisible := true;
                                Rec.Modify();
                                NewYorkLocation := false;
                                LondonLocation := false;
                                TokyoLocation := false;
                                MALAYSIALocation := false;
                                CHICAGOLocation := false;

                                LocationCode := 'COPENHAGEN';
                                SINGAPORELocation := false;
                                CompLocVisible := false;
                                ;
                                PrimaryVisible := false;
                                ConVisible := false;
                                IntegrationVisible := false;
                                ConectivityVisible := false;
                                SublocationVisible := true;
                                LocTypeVisible := true;
                            end;
                            if COPENHAGENLocation then
                                IF NOT MakeBackupDependencyFilters(Rec, true) THEN BEGIN
                                    ResetSelectedFilters2();
                                    ResetSelectedFilters();
                                END;

                            if (COPENHAGENLocation = false)
                        and (SINGAPORELocation = false)
                        and (NewYorkLocation = false) and
                        (TokyoLocation = false)
                        and (LondonLocation = false)
                        and (MALAYSIALocation = false)
                        and (CHICAGOLocation = false)
                             then begin
                                SublocationVisible := false;
                                LocTypeVisible := false;
                            end
                            else begin
                                SublocationVisible := true;
                                LocTypeVisible := true;
                            end;
                            CurrPage.Update();
                        end;

                    }
                    field(MALAYSIALocation; MALAYSIALocation)
                    {
                        Caption = 'MALAYSIA';
                        trigger OnValidate()
                        begin
                            MakeOFFAllLocations();
                            if MALAYSIALocation then begin
                                Rec."FTT-CST Location Code" := 'MALAYSIA';
                                Rec."FTT-CST Sublocation" := rec."FTT-CST Sublocation"::None;
                                SublocationVisible := true;
                                LocTypeVisible := true;
                                Rec.Modify();
                                NewYorkLocation := false;
                                LondonLocation := false;
                                TokyoLocation := false;
                                COPENHAGENLocation := false;
                                SINGAPORELocation := false;
                                CHICAGOLocation := false;

                                LocationCode := 'MALAYSIA';
                                CompLocVisible := true;
                                PrimaryVisible := false;
                                ConVisible := false;
                                IntegrationVisible := false;
                                ConectivityVisible := false;
                                SublocationVisible := true;
                                LocTypeVisible := true;
                            end;
                            if (COPENHAGENLocation = false) and (SINGAPORELocation = false) and (NewYorkLocation = false) and
                            (TokyoLocation = false) and (LondonLocation = false) and (MALAYSIALocation = false)
                                 then
                                SublocationVisible := false else begin
                                SublocationVisible := true;
                                LocTypeVisible := true;
                            end;

                            if MALAYSIALocation then
                                IF NOT MakeBackupDependencyFilters(Rec, true) THEN BEGIN
                                    ResetSelectedFilters2();
                                    ResetSelectedFilters();
                                END;
                            CurrPage.Update();
                        end;

                    }
                    field(CHICAGOLocation; CHICAGOLocation)
                    {
                        Caption = 'CHICAGO';
                        trigger OnValidate()
                        begin
                            MakeOFFAllLocations();
                            if CHICAGOLocation then
                                if CHICAGOLocation then begin
                                    Rec."FTT-CST Location Code" := 'CHICAGO';
                                    Rec."FTT-CST Sublocation" := rec."FTT-CST Sublocation"::None;
                                    SublocationVisible := true;
                                    LocTypeVisible := true;
                                    Rec.Modify();
                                    NewYorkLocation := false;
                                    LondonLocation := false;
                                    TokyoLocation := false;
                                    COPENHAGENLocation := false;
                                    SINGAPORELocation := false;
                                    MALAYSIALocation := false;

                                    LocationCode := 'CHICAGO';
                                    CompLocVisible := true;
                                    PrimaryVisible := false;
                                    ConVisible := false;
                                    IntegrationVisible := false;
                                    ConectivityVisible := false;
                                    SublocationVisible := true;
                                    LocTypeVisible := true;
                                end;
                            if (COPENHAGENLocation = false) and (SINGAPORELocation = false) and (NewYorkLocation = false) and
                            (TokyoLocation = false) and (LondonLocation = false) and (MALAYSIALocation = false) and (CHICAGOLocation = false)
                                 then
                                SublocationVisible := false else begin
                                SublocationVisible := true;
                                LocTypeVisible := true;
                            end;
                            if CHICAGOLocation then
                                IF NOT MakeBackupDependencyFilters(Rec, true) THEN BEGIN
                                    ResetSelectedFilters2();
                                    ResetSelectedFilters();
                                END;
                            CurrPage.Update();
                        end;

                    }
                }

                group(Grou2)
                {
                    ShowCaption = false;
                    Visible = SublocationVisible;
                    group(Grou1)
                    {
                        ShowCaption = false;
                        Visible = SublocationVisible;
                        field("FTT-CST Sublocation"; Rec."FTT-CST Sublocation")
                        {
                            ApplicationArea = all;
                            Caption = 'SUBLOCATION';
                            trigger OnValidate()
                            var
                                DepItems: Record "FTT-CST Dependancy Item";
                            begin
                                if Rec."FTT-CST Sublocation" <> 0 then begin
                                    LocTypeVisible := true;
                                end;

                                if (rec."FTT-CST Sublocation" <> 0) and (rec."FTT-CST Sublocation" <> xRec."FTT-CST Sublocation") then begin
                                    DepItems.SetRange("Sales Document No.", rec."Sales Document No.");
                                    DepItems.SetRange("Location Code", LocationCode);
                                    DepItems.ModifyAll("FTT-CST Sublocation", rec."FTT-CST Sublocation");
                                end;
                                MakeBackupDependencyFilters(Rec, false);
                            end;
                        }
                    }

                    group(Grou22)
                    {
                        ShowCaption = false;
                        Visible = LocTypeVisible;
                        field("FTT-CST Component Option"; Rec."FTT-CST Component Option")
                        {
                            ApplicationArea = All;
                            Caption = 'LOCATION TYPE';
                            trigger OnValidate()
                            begin
                                if rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::NonHosted then begin
                                    HardwareVisible := false;
                                end else
                                    AddCrossConnectVisible := false;

                                if rec."FTT-CST Component Option" <> rec."FTT-CST Component Option"::Blank then begin
                                    TypeSiteVisible := true;
                                end else
                                    TypeSiteVisible := false;
                                if rec."FTT-CST Component Option" <> rec."FTT-CST Component Option"::Blank then
                                    TypeSiteVisible := true;

                                if (COPENHAGENLocation = false) and (SINGAPORELocation = false) and (NewYorkLocation = false) and
                                    (TokyoLocation = false) and (LondonLocation = false) and (MALAYSIALocation = false)
                                    then
                                    CompLocVisible := false else
                                    CompLocVisible := true;
                                if rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Blank then begin
                                    HMVisible := false;
                                    IntegrationVisible := false;
                                    ConVisible := false;
                                    TypeSiteVisible := false;
                                    DRVisible := false;
                                    RedundencyVisible := false;
                                    HardwareVisible := false;
                                    ResetSelectedFilters();
                                end;
                                if rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Blank then begin
                                    TypeSiteVisible := true;
                                    HMVisible := false;
                                    ConVisible := false;
                                    IntegrationVisible := false;
                                    HMVisible := false;
                                    IntegrationVisible := false;
                                    ConVisible := false;
                                    TypeSiteVisible := false;
                                    DRVisible := false;
                                    RedundencyVisible := false;
                                    HardwareVisible := false;
                                end;
                                if (xRec."FTT-CST Component Option" <> rec."FTT-CST Component Option") and
                                (xRec."FTT-CST Component Option" <> xrec."FTT-CST Component Option"::Blank) then begin
                                    TypeSiteVisible := true;
                                    HMVisible := false;
                                    ConVisible := false;
                                    IntegrationVisible := false;
                                    HMVisible := false;
                                    IntegrationVisible := false;
                                    DRVisible := false;
                                    RedundencyVisible := false;
                                    HardwareVisible := false;
                                    PrimaryVisible := false;
                                    ConfirmDocumentVisible := false;
                                    AddCrossConnectVisible := false;
                                    ResetSelectedFilters();
                                    if rec."FTT-CST Component Option" <> rec."FTT-CST Component Option"::Blank then
                                        TypeSiteVisible := true;

                                end;

                                if rec."FTT-CST Component Option" <> rec."FTT-CST Component Option"::Blank then begin
                                    if rec."FTT-CST Type of Site2" <> rec."FTT-CST Type of Site2"::Blank then begin
                                        rec."FTT-CST Type of Site2" := rec."FTT-CST Type of Site2"::Blank;
                                        rec."FTT-CST Conectivity" := rec."FTT-CST Conectivity"::Blank;
                                        rec."FTT-CST Integration" := '';
                                        rec."FTT-CST DR" := '';
                                        rec.Modify();
                                        TypeSiteVisible := true;
                                        HardwareVisible := false;
                                        AddCrossConnectVisible := false;
                                        ConVisible := false;
                                    end;
                                end;

                                if Rec."FTT-CST Component Option" <> xRec."FTT-CST Component Option" then begin
                                    if rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::NonHosted then begin
                                        rec."FTT-CST Type of Site2" := rec."FTT-CST Type of Site2"::Blank;
                                        rec."FTT-CST Conectivity" := rec."FTT-CST Conectivity"::Blank;
                                        rec."FTT-CST Integration" := '';
                                        rec."FTT-CST DR" := '';
                                        rec.Modify();
                                        HardwareVisible := false;
                                        RedundencyVisible := false;
                                        IntegrationVisible := false;
                                        SublocationVisible := true;
                                        LocTypeVisible := true;
                                        TypeSiteVisible := true;
                                    end;
                                end;

                                if Rec."FTT-CST Component Option" <> xRec."FTT-CST Component Option" then begin
                                    if rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Hosted then begin
                                        rec."FTT-CST Type of Site2" := rec."FTT-CST Type of Site2"::Blank;
                                        rec."FTT-CST Conectivity" := rec."FTT-CST Conectivity"::Blank;
                                        rec."FTT-CST Integration" := '';
                                        rec."FTT-CST DR" := '';
                                        rec.Modify();
                                        HardwareVisible := false;
                                        RedundencyVisible := false;
                                        IntegrationVisible := false;
                                        SublocationVisible := true;
                                        LocTypeVisible := true;
                                        TypeSiteVisible := true;
                                    end;
                                end;

                                if Rec."FTT-CST Component Option" <> xRec."FTT-CST Component Option" then begin
                                    if rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Unknown then begin
                                        rec."FTT-CST Type of Site2" := rec."FTT-CST Type of Site2"::Blank;
                                        rec."FTT-CST Conectivity" := rec."FTT-CST Conectivity"::Blank;
                                        rec."FTT-CST Integration" := '';
                                        rec."FTT-CST DR" := '';
                                        rec.Modify();
                                        HardwareVisible := false;
                                        RedundencyVisible := false;
                                        IntegrationVisible := false;
                                        SublocationVisible := true;
                                        LocTypeVisible := true;
                                        TypeSiteVisible := true;
                                    end;
                                end;

                                if Rec."FTT-CST Component Option" <> xRec."FTT-CST Component Option" then begin
                                    if rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Blank then begin
                                        rec."FTT-CST Type of Site2" := rec."FTT-CST Type of Site2"::Blank;
                                        rec."FTT-CST Conectivity" := rec."FTT-CST Conectivity"::Blank;
                                        rec."FTT-CST Integration" := '';
                                        rec."FTT-CST DR" := '';
                                        rec.Modify();

                                        HardwareVisible := false;
                                        RedundencyVisible := false;
                                        IntegrationVisible := false;
                                        SublocationVisible := true;
                                        LocTypeVisible := true;
                                        TypeSiteVisible := false;
                                    end;
                                end;


                                MakeBackupDependencyFilters(Rec, false);
                                ConVisible := false;
                                CurrPage.Update();
                            end;
                        }

                        group(TypeofSiteGroup)
                        {
                            Visible = TypeSiteVisible;
                            ShowCaption = false;
                            field("FTT-CST Type of Site"; Rec."FTT-CST Type of Site2")
                            {
                                ApplicationArea = All;
                                Caption = 'TYPE OF SITE';

                                trigger OnValidate()
                                begin

                                    if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::RedDR) then begin
                                        DRVisible := true;
                                        HardwareVisible := false;
                                    end;

                                    if Rec."FTT-CST Type of Site" = rec."FTT-CST Type of Site"::None then begin
                                        HardwareVisible := true;
                                    end;

                                    if (Rec."FTT-CST Type of Site" = rec."FTT-CST Type of Site"::Both) and (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::NonHosted) then begin
                                        HardwareVisible := false;
                                        RedundencyVisible := true;
                                        DRVisible := true;
                                        ConfirmDocumentVisible := false;
                                        PrimaryVisible := false;
                                        HardwareVisible := false;
                                        AddCrossConnectVisible := false;
                                        ConVisible := false;
                                        HMVisible := false;
                                    end;

                                    if rec."FTT-CST Type of Site" = rec."FTT-CST Type of Site"::Blank then begin
                                        HardwareVisible := false;
                                        HMVisible := false;
                                        RedundencyVisible := false;
                                        DRVisible := false;
                                        PrimaryVisible := false;
                                        IntegrationVisible := false;
                                        ConVisible := false;
                                    end;

                                    if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::Primary)
                                    or (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryDR)
                                    or (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryRed)
                                    or (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryRedDR)
                                        then begin
                                        PrimaryVisible := true;
                                        ConVisible := false;
                                        IntegrationVisible := false;
                                    end;

                                    if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::None) then begin
                                        if (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::NonHosted) then begin
                                            HardwareVisible := false;
                                            DRVisible := false;
                                            RedundencyVisible := false;
                                            ConVisible := true;
                                        end;

                                        if rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Unknown then begin
                                            HardwareVisible := true;
                                            ConVisible := false;
                                        end;

                                        if rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Hosted then begin
                                            begin
                                                HardwareVisible := true;
                                                PrimaryVisible := false;
                                                AddCrossConnectVisible := false;
                                                ConfirmDocumentVisible := false;
                                                rec."FTT-CST Redundency" := '';
                                                rec."FTT-CST DR" := '';

                                            end;
                                        end;
                                    end;

                                    if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::DR) then begin
                                        DRVisible := true;
                                        HardwareVisible := false;
                                    end;

                                    if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::RedDR) then begin
                                        RedundencyVisible := true;
                                        DRVisible := true;
                                        HardwareVisible := false;
                                    end;

                                    if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::Redundancy) then begin
                                        RedundencyVisible := true;
                                        HardwareVisible := false;
                                    end;

                                    if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::Blank) then begin
                                        RedundencyVisible := false;
                                        HardwareVisible := false;
                                        AddCrossConnectVisible := false;
                                    end;


                                    MakeBackupDependencyFilters(Rec, false);
                                    CurrPage.Update();
                                end;

                            }
                        }
                        group(Primary)
                        {
                            visible = PrimaryVisible;
                            Caption = '';
                            field("FTT-CST Licences Filters"; Rec."FTT-CST Licences Filters Desc.")
                            {
                                ApplicationArea = All;
                                Caption = 'LICENSES';
                                Editable = true;
                                trigger OnLookup(var Text: Text): Boolean;
                                var
                                    ItemList: page "Item List";
                                    FTTItemList2: page "FTT-CST License List";
                                    FTTItemList: page "FTT-CST Item List";
                                    DependencyItem: Record Item;
                                    Item: record Item;
                                    LicencesFilters: text[1024];
                                    SpecailSelect2: Record "FTT-CST Licence Select";
                                    SpecailSelect: Record "FTT-CST Special Select";
                                    LicencesFiltersDesc: text[1024];
                                begin
                                    Item.SetFilter("Item Category Code", 'LICENSE');
                                    SpecailSelect.SetRange("Filter No.", Rec."Filter No.");
                                    SpecailSelect.DeleteAll();

                                    if Item.FindSet() then
                                        repeat
                                            SpecailSelect.Init;
                                            SpecailSelect."Item No." := Item."No.";
                                            SpecailSelect."Filter No." := Rec."Filter No.";
                                            SpecailSelect.Description := Item.Description;
                                            SpecailSelect."Customer Price Group" := Rec."Customer Price Group";
                                            SpecailSelect."Posting Date" := Rec."Posting Date";
                                            SpecailSelect."Currency Code" := Rec."Currency Code";
                                            SpecailSelect."Comments Fluent" := Item."FTT-CST Comments Fluent";
                                            if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryDR) then
                                                SpecailSelect.DR := SpecailSelect.dr::Yes;
                                            if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryRed) then
                                                SpecailSelect.Redundancy := SpecailSelect.Redundancy::Yes;
                                            if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::RedDR) then begin
                                                SpecailSelect.Redundancy := SpecailSelect.Redundancy::Yes;
                                                SpecailSelect.DR := SpecailSelect.DR::Yes;
                                            end;
                                            if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryRedDR) then begin
                                                SpecailSelect.Redundancy := SpecailSelect.Redundancy::Yes;
                                                SpecailSelect.DR := SpecailSelect.DR::Yes;
                                            end;
                                            SpecailSelect."Integr." := SpecailSelect."Integr."::Yes; //NRD

                                            SpecailSelect."Unit Price" := Item."Unit Price";

                                            SpecailSelect.Insert(true);
                                        until Item.Next = 0;
                                    Commit();
                                    SpecailSelect.SetRange("Filter No.", Rec."Filter No.");

                                    FTTItemList.LookupMode(true);
                                    FTTItemList.MakePriceVisible(true);
                                    FTTItemList.MakeRedDRVisible(true);
                                    FTTItemList.MakeIntegVisible(true); //NRD
                                    FTTItemList.MakeitemGroupVisible(true); //NRD
                                    FTTItemList.SetTableView(SpecailSelect);

                                    if FTTItemList.RunModal() = Action::LookupOK then begin
                                        AddLicenseLine(LicencesFilters);
                                        AddLicenseLineDesc(LicencesFiltersDesc);

                                        AddIntegration(0);
                                        Rec.VALIDATE("FTT-CST Licences Filters", LicencesFilters);
                                        Rec.Validate("FTT-CST Licences Filters Desc.", LicencesFiltersDesc);
                                        CurrPage.Update();
                                    end;

                                    if Rec."FTT-CST Licences Filters" <> '' then begin
                                        if rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryDR then
                                            DRVisible := true;
                                        if rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryRed then
                                            RedundencyVisible := true;
                                        if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::Primary) then
                                            IntegrationVisible := true;

                                        if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryRedDR) then begin
                                            DRVisible := true;
                                            RedundencyVisible := true;
                                        end;
                                    end;
                                    MakeBackupDependencyFilters(Rec, false)
                                end;

                            }



                            field("FTT-CST Standard taker feed"; Rec."FTT-CST Standard taker feed desc.")
                            {

                                ApplicationArea = All;
                                Caption = 'STANDARD TAKER FEED';
                                Editable = true;
                                trigger OnLookup(var Text: Text): Boolean;
                                var
                                    ItemList2: page "Item List";
                                    DependencyItem2: Record Item;
                                    LicencesFilters2: text[1024];
                                    LicencesFilters: text[1024];
                                    Item: record Item;
                                    FTTItemList: page "FTT-CST Item List";
                                    DependencyItem: Record Item;
                                    SpecailSelect: Record "FTT-CST Special Select";
                                    SalesReceivables: Record "Sales & Receivables Setup";
                                begin
                                    SalesReceivables.Get();
                                    Item.SetFilter("Item Category Code", 'STANDARD TAKER FEED');
                                    Item.SetFilter("Item Category Code", SalesReceivables."FTT-CST STANDARD TAKER FEED");

                                    SpecailSelect.SetRange("Filter No.", Rec."Filter No.");
                                    SpecailSelect.DeleteAll();

                                    if Item.FindSet() then
                                        repeat
                                            SpecailSelect.Init;
                                            SpecailSelect."Item No." := Item."No.";
                                            SpecailSelect."Filter No." := Rec."Filter No.";
                                            SpecailSelect.Description := Item.Description;
                                            SpecailSelect."Posting Date" := Rec."Posting Date";
                                            SpecailSelect."Comments Fluent" := Item."FTT-CST Comments Fluent";
                                            SpecailSelect."Customer Price Group" := Rec."Customer Price Group";
                                            SpecailSelect."Posting Date" := Rec."Posting Date";
                                            SpecailSelect."Currency Code" := Rec."Currency Code";

                                            if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryDR) then
                                                SpecailSelect.DR := SpecailSelect.dr::Yes;
                                            if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryRed) then
                                                SpecailSelect.Redundancy := SpecailSelect.Redundancy::Yes;
                                            if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::RedDR) then begin
                                                SpecailSelect.Redundancy := SpecailSelect.Redundancy::Yes;
                                                SpecailSelect.DR := SpecailSelect.DR;
                                            end;
                                            if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryRedDR) then begin
                                                SpecailSelect.Redundancy := SpecailSelect.Redundancy::Yes;
                                                SpecailSelect.DR := SpecailSelect.DR::Yes;
                                            end;
                                            SpecailSelect."Integr." := SpecailSelect."Integr."::Yes; //NRD
                                            SpecailSelect."Unit Price" := Item."Unit Price";
                                            SpecailSelect.Insert(true);
                                        until Item.Next = 0;
                                    Commit();
                                    SpecailSelect.SetRange("Filter No.", Rec."Filter No.");

                                    FTTItemList.LookupMode(true);
                                    FTTItemList.MakePriceVisible(true);
                                    FTTItemList.MakeRedDRVisible(true);
                                    FTTItemList.MakeIntegVisible(true); //NRD
                                    FTTItemList.MakeitemGroupVisible(true); //NRD
                                    FTTItemList.SetTableView(SpecailSelect);

                                    if FTTItemList.RunModal() = Action::LookupOK then begin
                                        AddFeedLines(LicencesFilters, SalesReceivables."FTT-CST STANDARD TAKER FEED", true);
                                        AddFeedLinesDesc(LicencesFiltersDesc, SalesReceivables."FTT-CST STANDARD TAKER FEED");
                                        AddIntegration(0);
                                        Rec.VALIDATE("FTT-CST Standard taker feed desc.", LicencesFiltersDesc);
                                        Rec.VALIDATE("FTT-CST Standard taker feed", LicencesFilters);

                                        CurrPage.Update();
                                    end;

                                    if Rec."FTT-CST Standard taker feed" <> '' then begin
                                        if rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryDR then
                                            DRVisible := true;
                                        if rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryRed then
                                            RedundencyVisible := true;
                                        if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::Primary) then
                                            IntegrationVisible := true;
                                        if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryRedDR) then begin
                                            DRVisible := true;
                                            RedundencyVisible := true;
                                        end;

                                    end;

                                    MakeBackupDependencyFilters(Rec, false)
                                end;
                            }
                            field("FTT-CST NON Standard taker feed"; Rec."FTT-CST NON Standard taker desc.")
                            {

                                ApplicationArea = All;
                                Caption = 'NS TAKER FEED';
                                Editable = true;
                                trigger OnLookup(var Text: Text): Boolean;
                                var
                                    ItemList2: page "Item List";
                                    DependencyItem2: Record Item;
                                    LicencesFilters2: text[1024];
                                    LicencesFilters: text[1024];
                                    LicencesFiltersDesc: text[1024];
                                    Item: record Item;
                                    FTTItemList: page "FTT-CST Item List";
                                    DependencyItem: Record Item;
                                    SpecailSelect: Record "FTT-CST Special Select";
                                begin
                                    Item.SetFilter("Item Category Code", 'NS TAKER FEED');
                                    SpecailSelect.SetRange("Filter No.", Rec."Filter No.");
                                    SpecailSelect.DeleteAll();

                                    if Item.FindSet() then
                                        repeat
                                            SpecailSelect.Init;
                                            SpecailSelect."Item No." := Item."No.";
                                            SpecailSelect."Filter No." := Rec."Filter No.";
                                            SpecailSelect.Description := Item.Description;
                                            SpecailSelect."Posting Date" := Rec."Posting Date";
                                            SpecailSelect."Comments Fluent" := Item."FTT-CST Comments Fluent";
                                            SpecailSelect."Customer Price Group" := Rec."Customer Price Group";
                                            SpecailSelect."Posting Date" := Rec."Posting Date";
                                            SpecailSelect."Currency Code" := Rec."Currency Code";
                                            if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryDR) then
                                                SpecailSelect.DR := SpecailSelect.dr::Yes;
                                            if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryRed) then
                                                SpecailSelect.Redundancy := SpecailSelect.Redundancy::Yes;
                                            if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::RedDR) then begin
                                                SpecailSelect.Redundancy := SpecailSelect.Redundancy::Yes;
                                                SpecailSelect.DR := SpecailSelect.DR;
                                            end;
                                            if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryRedDR) then begin
                                                SpecailSelect.Redundancy := SpecailSelect.Redundancy::Yes;
                                                SpecailSelect.DR := SpecailSelect.DR::Yes;
                                            end;
                                            SpecailSelect."Unit Price" := Item."Unit Price";
                                            SpecailSelect."Integr." := SpecailSelect."Integr."::Yes; //NRD
                                            SpecailSelect.Insert(true);
                                        until Item.Next = 0;
                                    Commit();
                                    SpecailSelect.SetRange("Filter No.", Rec."Filter No.");

                                    FTTItemList.LookupMode(true);
                                    FTTItemList.SetTableView(SpecailSelect);
                                    FTTItemList.MakePriceVisible(true);
                                    FTTItemList.MakeIntegVisible(true); //NRD
                                    FTTItemList.MakeitemGroupVisible(true); //NRD
                                    FTTItemList.MakeRedDRVisible(true);

                                    if FTTItemList.RunModal() = Action::LookupOK then begin
                                        AddFeedLines(LicencesFilters, SalesReceivables."FTT-CST NS MAKER FEED", true);
                                        AddFeedLinesDesc(LicencesFiltersDesc, SalesReceivables."FTT-CST NS MAKER FEED");

                                        AddIntegration(0);
                                        Rec.VALIDATE("FTT-CST Non standard taker desc.", LicencesFiltersDesc);
                                        Rec.VALIDATE("FTT-CST Non standard taker", LicencesFilters);
                                        CurrPage.Update();
                                    end;

                                    if Rec."FTT-CST NON Standard taker" <> '' then begin
                                        if rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryDR then
                                            DRVisible := true;
                                        if rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryRed then
                                            RedundencyVisible := true;
                                        if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::Primary) then
                                            IntegrationVisible := true;
                                        if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryRedDR) then begin
                                            DRVisible := true;
                                            RedundencyVisible := true;
                                        end;
                                    end;
                                    MakeBackupDependencyFilters(Rec, false)
                                end;
                            }
                            field("FTT-CST Standard maker feed"; Rec."FTT-CST Standard maker feed desc.")
                            {
                                ApplicationArea = All;
                                Caption = 'STANDARD MAKER FEED';
                                Editable = true;

                                trigger OnLookup(var Text: Text): Boolean;
                                var
                                    LicencesFilters: text[1024];
                                    LicencesFiltersDesc: text[1024];
                                    Item: record Item;
                                    FTTItemList: page "FTT-CST Item List";
                                    DependencyItem: Record Item;
                                    SpecailSelect: Record "FTT-CST Special Select";
                                begin
                                    Item.SetFilter("Item Category Code", 'STANDARD MAKER FEED');
                                    SpecailSelect.SetRange("Filter No.", Rec."Filter No.");
                                    SpecailSelect.DeleteAll();

                                    if Item.FindSet() then
                                        repeat
                                            SpecailSelect.Init;
                                            SpecailSelect."Item No." := Item."No.";
                                            SpecailSelect."Filter No." := Rec."Filter No.";
                                            SpecailSelect.Description := Item.Description;
                                            SpecailSelect."Unit Price" := Item."Unit Price";
                                            SpecailSelect."Posting Date" := Rec."Posting Date";
                                            SpecailSelect."Comments Fluent" := Item."FTT-CST Comments Fluent";
                                            SpecailSelect."Customer Price Group" := Rec."Customer Price Group";
                                            SpecailSelect."Posting Date" := Rec."Posting Date";
                                            SpecailSelect."Currency Code" := Rec."Currency Code";
                                            if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryDR) then
                                                SpecailSelect.DR := SpecailSelect.dr::Yes;
                                            if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryRed) then
                                                SpecailSelect.Redundancy := SpecailSelect.Redundancy::Yes;
                                            if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::RedDR) then begin
                                                SpecailSelect.Redundancy := SpecailSelect.Redundancy::Yes;
                                                SpecailSelect.DR := SpecailSelect.DR::Yes;
                                            end;
                                            if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryRedDR) then begin
                                                SpecailSelect.Redundancy := SpecailSelect.Redundancy::Yes;
                                                SpecailSelect.DR := SpecailSelect.DR::Yes;
                                            end;
                                            SpecailSelect."Integr." := SpecailSelect."Integr."::Yes; //NRD
                                            SpecailSelect.Insert(true);
                                        until Item.Next = 0;
                                    Commit();
                                    SpecailSelect.SetRange("Filter No.", Rec."Filter No.");

                                    FTTItemList.LookupMode(true);
                                    FTTItemList.MakePriceVisible(true);
                                    FTTItemList.MakeIntegVisible(true); //NRD
                                    FTTItemList.MakeitemGroupVisible(true); //NRD
                                    FTTItemList.MakeRedDRVisible(true);
                                    FTTItemList.SetTableView(SpecailSelect);

                                    if FTTItemList.RunModal() = Action::LookupOK then begin
                                        AddFeedLines(LicencesFilters, SalesReceivables."FTT-CST STANDARD MAKER FEED", true);
                                        AddFeedLinesDesc(LicencesFiltersDesc, SalesReceivables."FTT-CST STANDARD MAKER FEED");
                                        AddIntegration(0);
                                        Rec.VALIDATE("FTT-CST Standard maker feed Desc.", LicencesFiltersDesc);
                                        Rec.VALIDATE("FTT-CST Standard maker feed", LicencesFilters);
                                        CurrPage.Update();
                                    end;

                                    if Rec."FTT-CST Standard maker feed" <> '' then begin
                                        if rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryDR then
                                            DRVisible := true;
                                        if rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryRed then
                                            RedundencyVisible := true;
                                        if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::Primary) then
                                            IntegrationVisible := true;
                                        if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryRedDR) then begin
                                            DRVisible := true;
                                            RedundencyVisible := true;
                                        end;
                                    end;
                                    MakeBackupDependencyFilters(Rec, false)
                                end;

                            }
                            field("FTT-CST NON Standard maker"; Rec."FTT-CST NON Standard maker desc.")
                            {
                                ApplicationArea = All;
                                Caption = 'NS MAKER FEED';
                                Editable = true;

                                trigger OnLookup(var Text: Text): Boolean;
                                var
                                    ItemList: page "Item List";
                                    LicencesFilters: text[1024];
                                    LicencesFiltersDesc: text[1024];
                                    Item: record Item;
                                    FTTItemList: page "FTT-CST Item List";
                                    DependencyItem: Record Item;
                                    SpecailSelect: Record "FTT-CST Special Select";

                                begin
                                    Item.SetFilter("Item Category Code", 'NS MAKER FEED');
                                    SpecailSelect.SetRange("Filter No.", Rec."Filter No.");
                                    SpecailSelect.DeleteAll();

                                    if Item.FindSet() then
                                        repeat
                                            SpecailSelect.Init;
                                            SpecailSelect."Item No." := Item."No.";
                                            SpecailSelect."Filter No." := Rec."Filter No.";
                                            SpecailSelect.Description := Item.Description;
                                            SpecailSelect."Unit Price" := Item."Unit Price";
                                            SpecailSelect."Posting Date" := Rec."Posting Date";
                                            SpecailSelect."Customer Price Group" := Rec."Customer Price Group";
                                            SpecailSelect."Posting Date" := Rec."Posting Date";
                                            SpecailSelect."Currency Code" := Rec."Currency Code";
                                            if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryDR) then
                                                SpecailSelect.DR := SpecailSelect.dr::Yes;
                                            if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryRed) then
                                                SpecailSelect.Redundancy := SpecailSelect.Redundancy::Yes;
                                            if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::RedDR) then begin
                                                SpecailSelect.Redundancy := SpecailSelect.Redundancy::Yes;
                                                SpecailSelect.DR := SpecailSelect.DR;
                                            end;
                                            if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryRedDR) then begin
                                                SpecailSelect.Redundancy := SpecailSelect.Redundancy::Yes;
                                                SpecailSelect.DR := SpecailSelect.DR::Yes;
                                            end;
                                            SpecailSelect."Integr." := SpecailSelect."Integr."::Yes; //NRD
                                            SpecailSelect."Comments Fluent" := Item."FTT-CST Comments Fluent";
                                            SpecailSelect.Insert(true);
                                        until Item.Next = 0;
                                    Commit();
                                    SpecailSelect.SetRange("Filter No.", Rec."Filter No.");

                                    FTTItemList.LookupMode(true);
                                    FTTItemList.MakePriceVisible(true);
                                    FTTItemList.MakeRedDRVisible(true);
                                    FTTItemList.MakeIntegVisible(true); //NRD
                                    FTTItemList.MakeitemGroupVisible(true); //NRD
                                    FTTItemList.SetTableView(SpecailSelect);

                                    if FTTItemList.RunModal() = Action::LookupOK then begin
                                        AddFeedLines(LicencesFilters, 'NS MAKER FEED', true);
                                        AddFeedLinesDesc(LicencesFiltersDesc, SalesReceivables."FTT-CST NS MAKER FEED");
                                        AddIntegration(0);
                                        Rec.VALIDATE("FTT-CST NON Standard Maker Desc.", LicencesFiltersDesc);
                                        Rec.Validate("FTT-CST NON Standard Maker", LicencesFilters);
                                        CurrPage.Update();
                                    end;

                                    if Rec."FTT-CST NON Standard Maker" <> '' then begin
                                        if rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryDR then
                                            DRVisible := true;
                                        if rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryRed then
                                            RedundencyVisible := true;
                                        if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::Primary) then
                                            IntegrationVisible := true;
                                        if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryRedDR) then begin
                                            DRVisible := true;
                                            RedundencyVisible := true;
                                        end;
                                    end;
                                    MakeBackupDependencyFilters(Rec, false)
                                end;
                            }
                        }

                        group(DR)
                        {
                            Caption = '';
                            Visible = DRVisible;
                            field("FTT-CST DR"; Rec."FTT-CST DR Description")
                            {
                                ApplicationArea = All;
                                Caption = 'DR';
                                Editable = true;
                                trigger OnValidate()
                                begin
                                end;

                                trigger OnLookup(var Text: Text): Boolean;
                                var
                                    ItemList2: page "Item List";
                                    DependencyItem2: Record Item;
                                    LicencesFilters2: text[1024];
                                    LicencesFilters: text[1024];
                                    LicencesFiltersDesc: text[1024];
                                    Item: record Item;
                                    FTTItemList: page "FTT-CST Item List";
                                    DependencyItem: Record Item;
                                    SpecailSelect: Record "FTT-CST Special Select";
                                    SalesReceivables: Record "Sales & Receivables Setup";
                                begin
                                    SalesReceivables.Get();
                                    Item.SetFilter("Item Category Code", SalesReceivables."FTT-CST DR Category");
                                    SpecailSelect.SetRange("Filter No.", Rec."Filter No.");
                                    SpecailSelect.DeleteAll();

                                    if Item.FindSet() then
                                        repeat
                                            SpecailSelect.Init;
                                            SpecailSelect."Item No." := Item."No.";
                                            SpecailSelect."Filter No." := Rec."Filter No.";
                                            SpecailSelect.Description := Item.Description;
                                            SpecailSelect."Posting Date" := Rec."Posting Date";
                                            SpecailSelect."FTT-CST Sublocation" := rec."FTT-CST Sublocation";
                                            SpecailSelect."Customer Price Group" := Rec."Customer Price Group";
                                            SpecailSelect."Posting Date" := Rec."Posting Date";
                                            SpecailSelect."Currency Code" := Rec."Currency Code";
                                            SpecailSelect."Comments Fluent" := Item."FTT-CST Comments Fluent";
                                            SpecailSelect."Unit Price" := Item."Unit Price";
                                            SpecailSelect."Recalculation %" := Item."FTT-CST Redundancy PriceCalc %";
                                            SpecailSelect."Integr." := SpecailSelect."Integr."::Yes; //NRD
                                            SpecailSelect.Insert(true);
                                        until Item.Next = 0;
                                    Commit();
                                    SpecailSelect.SetRange("Filter No.", Rec."Filter No.");

                                    FTTItemList.LookupMode(true);
                                    FTTItemList.MakePriceVisible(false);
                                    FTTItemList.MakeRedDRVisible(false);
                                    FTTItemList.MakeIntegVisible(true); //NRD
                                    FTTItemList.MakeitemGroupVisible(false);//NRD
                                    FTTItemList.MakePercentageVisible(true);
                                    FTTItemList.SetTableView(SpecailSelect);

                                    if FTTItemList.RunModal() = Action::LookupOK then begin
                                        AddFeedLines(LicencesFilters, SalesReceivables."FTT-CST DR Category", FALSE);
                                        AddFeedLinesDesc(LicencesFiltersDesc, SalesReceivables."FTT-CST DR Category");
                                        UpdateDRLines(Rec."Filter No.", LocationCode);
                                        AddIntegration(0);

                                        Rec.VALIDATE("FTT-CST DR", LicencesFilters);
                                        Rec.Validate("FTT-CST DR Description", LicencesFiltersDesc);
                                        CurrPage.Update();
                                    end;

                                    if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::DR) and (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Hosted) then begin
                                        if Rec."FTT-CST DR" <> '' then
                                            HardwareVisible := true else begin
                                            HardwareVisible := false;
                                        end;
                                    end;

                                    if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::RedDR) and (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Hosted) then begin
                                        if (Rec."FTT-CST DR" <> '') and (rec."FTT-CST Redundency" <> '') then begin
                                            HardwareVisible := true;
                                            IntegrationVisible := true;
                                        end
                                    end;

                                    if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryDR) and ((rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Hosted) or (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Unknown)) then begin
                                        if (Rec."FTT-CST DR" <> '') then begin
                                            IntegrationVisible := true;
                                        end
                                        else begin
                                            HardwareVisible := false;
                                        end;
                                    end;

                                    if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::DR) and (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::NonHosted) then begin
                                        if Rec."FTT-CST DR" <> '' then begin
                                            IntegrationVisible := true;
                                        end
                                        else begin
                                            ConVisible := false;
                                        end;
                                    end;

                                    if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::DR) and ((rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Hosted) or (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Unknown)) then begin
                                        if Rec."FTT-CST DR" <> '' then begin
                                            IntegrationVisible := true;
                                        end
                                        else begin
                                            ConVisible := false;
                                        end;
                                    end;

                                    if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryDR) and (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::NonHosted) then begin
                                        if (Rec."FTT-CST DR" <> '') then
                                            ConVisible := true;
                                    end;
                                    CurrPage.Update();
                                    MakeBackupDependencyFilters(Rec, false)
                                end;

                            }
                        }
                        group(Redundency)
                        {
                            Visible = RedundencyVisible;
                            Caption = '';
                            Editable = true;
                            field("FTT-CST Redandency"; Rec."FTT-CST Redun Desc.")
                            {
                                ApplicationArea = All;
                                Caption = 'REDUNDANCY';
                                trigger OnValidate()
                                begin
                                    CurrPage.SelectedItems.Page.SetFilters(Rec."FTT-CST DR");
                                    CurrPage.Update();
                                end;

                                trigger OnLookup(var Text: Text): Boolean;
                                var
                                    ItemList2: page "Item List";
                                    DependencyItem2: Record Item;
                                    LicencesFilters2: text[1024];
                                    LicencesFilters: text[1024];
                                    LicencesFiltersDesc: text[1024];
                                    Item: record Item;
                                    FTTItemList: page "FTT-CST Item List";
                                    DependencyItem: Record Item;
                                    SpecailSelect: Record "FTT-CST Special Select";
                                    SalesReceivables: Record "Sales & Receivables Setup";
                                begin
                                    SalesReceivables.Get();
                                    Item.SetFilter("Item Category Code", SalesReceivables."FTT-CST Redundancy Category");
                                    SpecailSelect.SetRange("Filter No.", Rec."Filter No.");
                                    SpecailSelect.DeleteAll();
                                    if Item.FindSet() then
                                        repeat
                                            SpecailSelect.Init;
                                            SpecailSelect."Item No." := Item."No.";
                                            SpecailSelect."Filter No." := Rec."Filter No.";
                                            SpecailSelect.Description := Item.Description;
                                            SpecailSelect."Posting Date" := Rec."Posting Date";
                                            SpecailSelect."FTT-CST Sublocation" := rec."FTT-CST Sublocation";
                                            SpecailSelect."Comments Fluent" := Item."FTT-CST Comments Fluent";
                                            SpecailSelect."Recalculation %" := Item."FTT-CST Redundancy PriceCalc %";
                                            SpecailSelect."Unit Price" := Item."Unit Price";
                                            SpecailSelect."Customer Price Group" := Rec."Customer Price Group";
                                            SpecailSelect."Posting Date" := Rec."Posting Date";
                                            SpecailSelect."Currency Code" := Rec."Currency Code";
                                            SpecailSelect."Integr." := SpecailSelect."Integr."::Yes; //NRD
                                            SpecailSelect.Insert(true);
                                        until Item.Next = 0;
                                    Commit();
                                    SpecailSelect.SetRange("Filter No.", Rec."Filter No.");

                                    FTTItemList.LookupMode(true);
                                    FTTItemList.MakePriceVisible(false);
                                    FTTItemList.MakeRedDRVisible(false);
                                    FTTItemList.MakeIntegVisible(true); //NRD
                                    FTTItemList.MakeitemGroupVisible(false);
                                    FTTItemList.MakePercentageVisible(true);
                                    FTTItemList.SetTableView(SpecailSelect);


                                    if FTTItemList.RunModal() = Action::LookupOK then begin
                                        AddFeedLines(LicencesFilters, SalesReceivables."FTT-CST Redundancy Category", false);
                                        AddFeedLinesDesc(LicencesFiltersDesc, SalesReceivables."FTT-CST Redundancy Category");
                                        UpdateRedLines(Rec."Filter No.", LocationCode);
                                        AddIntegration(0);
                                        Rec.VALIDATE("FTT-CST REDUNDENCY", LicencesFilters);
                                        Rec.Validate("FTT-CST Redun Desc.", LicencesFiltersDesc);
                                        CurrPage.Update();
                                    end;
                                    if rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Hosted then begin

                                        if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::Redundancy) then begin
                                            if Rec."FTT-CST Redundency" <> '' then
                                                IntegrationVisible := true;
                                        end;

                                        if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::RedDR) then begin
                                            if (Rec."FTT-CST DR" <> '') and (rec."FTT-CST Redundency" <> '') then
                                                IntegrationVisible := true;
                                        end;


                                        if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryRedDR) then begin
                                            if (Rec."FTT-CST DR" <> '') or (rec."FTT-CST Redundency" <> '') then
                                                IntegrationVisible := true;
                                        end;
                                        if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryRed) then begin
                                            if (rec."FTT-CST Redundency" <> '') then
                                                IntegrationVisible := true;
                                        end;
                                    end;

                                    if rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::NonHosted then begin
                                        IntegrationVisible := true;

                                        if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::RedDR) and (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::NonHosted) then begin
                                            if (Rec."FTT-CST DR" <> '') and (rec."FTT-CST Redundency" <> '') then
                                                IntegrationVisible := true;
                                        end;


                                        if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::Redundancy) and (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::NonHosted) then begin
                                            if (rec."FTT-CST Redundency" <> '') then
                                                IntegrationVisible := true;
                                        end;


                                        if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryRed) and (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::NonHosted) then begin
                                            if (Rec."FTT-CST Redundency" <> '') then
                                                IntegrationVisible := true;
                                        end;
                                    end;
                                    if rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Unknown
                                    then begin
                                        if (Rec."FTT-CST Redundency" <> '') then
                                            IntegrationVisible := true;
                                    end;

                                    CurrPage.Update();
                                    MakeBackupDependencyFilters(Rec, false);
                                end;
                            }
                        }
                        group(IntegrationGroup)
                        {
                            Visible = IntegrationVisible;
                            Caption = '';
                            ShowCaption = false;
                            field("FTT-CST Integration"; Rec."FTT-CST Integration Desc.")
                            {
                                ApplicationArea = All;
                                Caption = 'INTEGRATION';
                                Editable = true;
                                Visible = true;
                                trigger OnValidate()
                                var
                                    DepItems: record "FTT-CST Dependancy Item";
                                begin
                                    /*CurrPage.SelectedItems.Page.SetFilters(Rec."FTT-CST Integration");
                                    CurrPage.Update();
                                    CurrPage.Update(true);
                                    DepItems.SetRange("Filter No.", Rec."Filter No.");
                                    DepItems.SetRange("FTT-CST Integration", TRUE);
                                    DepItems.DeleteAll();
                                    Commit();
                                    */
                                end;


                                trigger OnLookup(var Text: Text): Boolean;
                                var
                                    ItemList: page "FTT-CST Item List";
                                    DependencyItem: Record "FTT-CST Special Select";
                                    DependencyItem2: Record Item;
                                    LicencesFilters: text[1024];
                                    LicencesFiltersDesc: text[1024];
                                    RecItem: record Item;
                                    Item: record Item;
                                    PageDialog: page "FTT-CST Dialog";
                                    PriceCalcPerc: Decimal;
                                    SpecialSelect: record "FTT-CST Special Select";
                                    SalesReceivables: Record "Sales & Receivables Setup";
                                begin
                                    SalesReceivables.Get();
                                    LicencesFiltersDesc := '';
                                    //Item.SetFilter("Item Category Code", 'INSTALLATION);//ivs
                                    Item.SetRange("Item Category Code", SalesReceivables."FTT-CST Integration Category");
                                    SpecialSelect.SetRange("Filter No.", Rec."Filter No.");
                                    SpecialSelect.DeleteAll();
                                    if Item.FindSet() then
                                        repeat
                                            SpecialSelect.Init;
                                            SpecialSelect."Item No." := Item."No.";
                                            SpecialSelect."Filter No." := Rec."Filter No.";
                                            SpecialSelect.Description := Item.Description;
                                            SpecialSelect."Customer Price Group" := Rec."Customer Price Group";
                                            SpecialSelect."Posting Date" := Rec."Posting Date";
                                            SpecialSelect."Currency Code" := Rec."Currency Code";
                                            SpecialSelect.Integration := true;
                                            SpecialSelect."Comments Fluent" := Item."FTT-CST Comments Fluent";
                                            SpecialSelect."Recalculation %" := Item."FTT-CST Integr PriceCalc %";
                                            SpecialSelect."Unit Price" := Item."Unit Price";
                                            SpecialSelect."Integr." := SpecialSelect."Integr."::No; //NRD
                                            SpecialSelect.Insert(true);
                                        until Item.Next = 0;
                                    Commit();
                                    ItemList.LookupMode(true);
                                    ItemList.SetTableView(SpecialSelect);
                                    ItemList.MakePercentageVisible(True);
                                    ItemList.MakeIntegVisible(false); //NRD
                                    ItemList.MakePriceVisible(true);
                                    if ItemList.RunModal() = Action::LookupOK then begin
                                        LicencesFiltersDesc := rec."FTT-CST Integration Desc.";
                                        if ItemList.GetSelectionFilter() <> '' then begin
                                            DependencyItem2.SetFilter("No.", ItemList.GetSelectionFilter());
                                            if DependencyItem2.FindSet() then
                                                repeat
                                                    if LicencesFiltersDesc = '' then begin
                                                        if DependencyItem."Recalculation %" > 0 then
                                                            LicencesFiltersDesc := DependencyItem.Description + '(' + Format(DependencyItem."Recalculation %") + '%)'
                                                        else
                                                            LicencesFiltersDesc := DependencyItem.Description
                                                    end else
                                                        LicencesFiltersDesc := LicencesFiltersDesc + '|' + DependencyItem2.Description;

                                                until DependencyItem2.Next = 0;
                                            AddIntegrationCode(ItemList.GetSelectionFilter());
                                        end;
                                    end;
                                    ConVisible := true;
                                    CurrPage.Update();

                                    MakeBackupDependencyFilters(Rec, false);


                                    if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::DR) and (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Hosted) then begin
                                        if (Rec."FTT-CST Integration Dec." <> 0) then begin
                                            HardwareVisible := true;
                                            ConectivityVisible := false;
                                            ConVisible := false;
                                        end;
                                    end;

                                    if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::DR) and (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::NonHosted) then begin
                                        if (Rec."FTT-CST Integration Dec." <> 0) then begin
                                            ConectivityVisible := true;
                                            ConVisible := true;
                                            HardwareVisible := false;
                                        end;
                                    end;


                                    if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::Redundancy) and (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Hosted) then begin
                                        if (Rec."FTT-CST Integration Dec." <> 0) then begin
                                            HardwareVisible := true;
                                            ConectivityVisible := false;
                                            ConVisible := false;
                                        end;
                                    end;

                                    if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::Redundancy) and (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::NonHosted) then begin
                                        if (Rec."FTT-CST Integration Dec." <> 0) then begin
                                            ConectivityVisible := true;
                                            ConVisible := true;
                                            HardwareVisible := false;
                                        end;
                                    end;


                                    if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::Primary) and (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Hosted) then begin
                                        if (Rec."FTT-CST Integration Dec." <> 0) then begin
                                            HardwareVisible := true;
                                            ConectivityVisible := false;
                                            ConVisible := false;
                                        end;
                                    end;

                                    if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::Primary) and (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::NonHosted) then begin
                                        if (Rec."FTT-CST Integration Dec." <> 0) then begin
                                            ConectivityVisible := true;
                                            ConVisible := true;
                                            HardwareVisible := false;
                                        end;
                                    end;

                                    if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryRedDR) and (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::NonHosted) then begin
                                        if (Rec."FTT-CST Integration Dec." <> 0) then begin
                                            ConectivityVisible := true;
                                            ConVisible := true;
                                            HardwareVisible := false;
                                        end;
                                    end;

                                    if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryRedDR) and (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Hosted) then begin
                                        if (Rec."FTT-CST Integration Dec." <> 0) then begin
                                            ConectivityVisible := false;
                                            ConVisible := false;
                                            HardwareVisible := true;
                                        end;
                                    end;

                                    if (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::RedDR) and (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Hosted) then begin
                                        if (Rec."FTT-CST Integration Dec." <> 0) then begin
                                            ConectivityVisible := false;
                                            ConVisible := false;
                                            HardwareVisible := true;
                                        end;
                                    end;
                                    if ((rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryDR) or (rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::PrimaryRed))
                                    and (rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Hosted) then begin
                                        if (Rec."FTT-CST Integration Dec." <> 0) then begin
                                            ConectivityVisible := false;
                                            ConVisible := false;
                                            HardwareVisible := true;
                                        end;
                                    end;
                                end;
                            }
                        }
                        group(HardwareGroup)
                        {
                            ShowCaption = false;
                            Visible = HardwareVisible;
                            field("FTT-CST HARDWARE"; Rec."FTT-CST HARDWARE Desc.")
                            {
                                ApplicationArea = All;
                                Caption = 'HARDWARE';
                                Editable = true;
                                trigger OnLookup(var Text: Text): Boolean;
                                var
                                    ItemList: page "FTT-CST Item List V2";
                                    DependencyItem: Record Item;
                                    LicencesFilters: text[1024];
                                    HardwareFilters: text[1024];
                                    HardwareFiltersDesc: text[1024];
                                    SetUpLines: text[1024];
                                    SpecailSelect: record "FTT-CST Special Select";
                                    SalesReceivables: Record "Sales & Receivables Setup";
                                    DependencyItem2: Record "FTT-CST Dependancy Item";
                                    pQty: Decimal;
                                begin
                                    SalesReceivables.GET();
                                    DependencyItem.SetFilter("Item Category Code", SalesReceivables."FTT-CST HARDWARE");
                                    SpecailSelect.SetRange("Filter No.", Rec."Filter No.");
                                    SpecailSelect.DeleteAll();

                                    if DependencyItem.FindSet() then
                                        repeat
                                            SpecailSelect.Init;
                                            SpecailSelect."Item No." := DependencyItem."No.";
                                            SpecailSelect."Filter No." := Rec."Filter No.";
                                            SpecailSelect.Description := DependencyItem.Description;
                                            SpecailSelect."Posting Date" := Rec."Posting Date";
                                            SpecailSelect."Customer Price Group" := Rec."Customer Price Group";
                                            SpecailSelect."Posting Date" := Rec."Posting Date";
                                            SpecailSelect."Currency Code" := Rec."Currency Code";
                                            SpecailSelect."Comments Fluent" := DependencyItem."FTT-CST Comments Fluent";
                                            SpecailSelect."Unit Price" := DependencyItem."Unit Price";
                                            SpecailSelect.Insert(true);
                                        until DependencyItem.Next = 0;
                                    Commit();
                                    SpecailSelect.SetRange("Filter No.", Rec."Filter No.");

                                    ItemList.LookupMode(true);
                                    ItemList.SetTableView(SpecailSelect);
                                    if ItemList.RunModal() = Action::LookupOK then begin
                                        AddHardwareConnect(HardwareFilters, HardwareFiltersDesc);
                                        //AddHardwareConnect(HardwareFiltersDesc);

                                        Rec."FTT-CST HARDWARE" := HardwareFilters;
                                        if rec."FTT-CST HARDWARE Desc." = '' then
                                            rec."FTT-CST HARDWARE Desc." := HardwareFiltersDesc else
                                            rec."FTT-CST HARDWARE Desc." := rec."FTT-CST HARDWARE Desc." + '|' + HardwareFiltersDesc;

                                        Rec.Modify();
                                        Commit;
                                        if Rec."FTT-CST HARDWARE" <> '' then begin //NRd 
                                            if Confirm('Do you want to add "Servers set up" proportionally?') then begin
                                                clear(ItemList);

                                                pQty := 0;
                                                DependencyItem2.SetRange("Sales Document No.", rec."Sales Document No.");
                                                DependencyItem2.SetRange("Filter No.", Rec."Filter No.");
                                                DependencyItem2.SetRange("Location Code", Rec."FTT-CST Location Code");
                                                DependencyItem2.SetFilter("Item Category Code", SalesReceivables."FTT-CST HARDWARE");
                                                if DependencyItem2.FindSet() then
                                                    repeat
                                                        pQty := pQty + DependencyItem2."FTT-CST Quantity";
                                                    until DependencyItem2.next = 0;

                                                DependencyItem.SetFilter("Item Category Code", SalesReceivables."FTT-CST Servers Set Up");
                                                SpecailSelect.SetRange("Filter No.", Rec."Filter No.");
                                                SpecailSelect.DeleteAll();

                                                if DependencyItem.FindSet() then
                                                    repeat
                                                        SpecailSelect.Init;
                                                        SpecailSelect."Item No." := DependencyItem."No.";
                                                        SpecailSelect."Filter No." := Rec."Filter No.";
                                                        SpecailSelect.Description := DependencyItem.Description;
                                                        SpecailSelect."Posting Date" := Rec."Posting Date";
                                                        SpecailSelect."Comments Fluent" := DependencyItem."FTT-CST Comments Fluent";
                                                        SpecailSelect."Customer Price Group" := Rec."Customer Price Group";
                                                        SpecailSelect."Posting Date" := Rec."Posting Date";
                                                        SpecailSelect."Currency Code" := Rec."Currency Code";
                                                        SpecailSelect."Unit Price" := DependencyItem."Unit Price";
                                                        SpecailSelect.Quantity := pQty;
                                                        SpecailSelect.Insert(true);
                                                    until DependencyItem.Next = 0;
                                                Commit();
                                                SpecailSelect.SetRange("Filter No.", Rec."Filter No.");

                                                ItemList.LookupMode(true);
                                                ItemList.SetTableView(SpecailSelect);

                                                if ItemList.RunModal() = Action::LookupOK then begin
                                                    AddSetUpLine(SetUpLines);
                                                end;
                                            end;
                                        end;
                                        if Rec."FTT-CST HARDWARE" <> '' then begin
                                            if rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Hosted then begin
                                                HMVisible := true;
                                                //IntegrationVisible := false;
                                            end;
                                            if Rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::NonHosted then begin
                                                HMVisible := false;
                                                //IntegrationVisible := true;
                                            end;
                                            if Rec."FTT-CST Component Option" = rec."FTT-CST Component Option"::Unknown then begin
                                                HMVisible := true;
                                            end;

                                        end else begin
                                            HMVisible := false;
                                            //IntegrationVisible := true;
                                        end;

                                        CurrPage.Update();
                                    end;
                                    MakeBackupDependencyFilters(Rec, false)
                                end;
                            }
                        }
                        group(HMGroup)
                        {
                            ShowCaption = false;
                            Visible = HMVisible;
                            field("FTT-CST CPU"; Rec."FTT-CST CPU Desc.")
                            {
                                ApplicationArea = All;
                                Caption = 'HOSTING AND MANAGEMENT';
                                Editable = true;

                                trigger OnValidate()
                                var
                                    DependencyItem2: record "FTT-CST Dependancy Item";
                                    pQty: Decimal;
                                begin
                                    CurrPage.SelectedItems.Page.SetFilters(Rec."FTT-CST CPU");
                                    CurrPage.Update();
                                end;

                                trigger OnLookup(var Text: Text): Boolean;
                                var
                                    ItemList: page "FTT-CST Item List V2";
                                    DependencyItem: Record "FTT-CST Special Select";
                                    DependencyItem2: Record "FTT-CST Dependancy Item";
                                    Item: record Item;
                                    LicencesFilters: text[1024];
                                    SalesReceivablesSetup: Record "Sales & Receivables Setup";
                                    SpecailSelect: Record "FTT-CST Special Select";
                                    FTTCSTCPU: text[1024];
                                    FTTCSTCPUDesc: text[1024];
                                    pQty: Decimal;
                                begin
                                    pQty := 0;
                                    SalesReceivablesSetup.Get();
                                    DependencyItem2.SetRange("Sales Document No.", rec."Sales Document No.");
                                    DependencyItem2.SetRange("Filter No.", Rec."Filter No.");
                                    DependencyItem2.SetRange("Location Code", Rec."FTT-CST Location Code");
                                    DependencyItem2.SetFilter("Item Category Code", SalesReceivablesSetup."FTT-CST HARDWARE");

                                    if DependencyItem2.FindSet() then
                                        repeat
                                            pQty := pQty + DependencyItem2."FTT-CST Quantity";
                                        until DependencyItem2.next = 0;

                                    SalesReceivablesSetup.Get();
                                    SalesReceivablesSetup.TestField("FTT-CST Hosting and management");
                                    Item.SetRange("Item Category Code", SalesReceivablesSetup."FTT-CST Hosting and management");
                                    SpecailSelect.SetRange("Filter No.", Rec."Filter No.");
                                    SpecailSelect.DeleteAll();

                                    if Item.FindSet() then
                                        repeat
                                            SpecailSelect.Init;
                                            SpecailSelect."Item No." := Item."No.";
                                            SpecailSelect."Filter No." := Rec."Filter No.";
                                            SpecailSelect.Description := Item.Description;
                                            SpecailSelect."Posting Date" := Rec."Posting Date";
                                            SpecailSelect."Comments Fluent" := Item."FTT-CST Comments Fluent";
                                            SpecailSelect."Unit Price" := Item."Unit Price";
                                            SpecailSelect."Customer Price Group" := Rec."Customer Price Group";
                                            SpecailSelect."Posting Date" := Rec."Posting Date";
                                            SpecailSelect."Currency Code" := Rec."Currency Code";
                                            SpecailSelect.Quantity := pQty;
                                            SpecailSelect.Insert(true);
                                        until Item.Next = 0;

                                    Commit();
                                    SpecailSelect.SetRange("Filter No.", Rec."Filter No.");
                                    ItemList.LookupMode(true);
                                    ItemList.SetTableView(SpecailSelect);
                                    if ItemList.RunModal() = Action::LookupOK then begin

                                        AddHostingLIne(FTTCSTCPU, FTTCSTCPUDesc);

                                        Rec."FTT-CST CPU" := FTTCSTCPU;
                                        if rec."FTT-CST CPU Desc." = '' then
                                            Rec."FTT-CST CPU Desc." := FTTCSTCPUDesc else
                                            Rec."FTT-CST CPU Desc." := Rec."FTT-CST CPU Desc." + '|' + FTTCSTCPUDesc;
                                        Rec.Modify;
                                    end;
                                    ConVisible := true;
                                    MakeBackupDependencyFilters(Rec, false)
                                end;
                            }
                        }
                        group(ConGrou)
                        {
                            ShowCaption = false;
                            Visible = ConVisible;
                            Editable = true;
                            field("FTT-CST Conectivity"; rec."FTT-CST Conectivity")
                            {
                                ApplicationArea = All;
                                Caption = 'CONNECTIVITY';
                                ToolTip = 'Specifies the Conectivity that will be used to filter.';

                                trigger OnValidate()
                                begin
                                    if rec."FTT-CST Conectivity" = Rec."FTT-CST Conectivity"::Yes then begin
                                        AddCrossConnectVisible := true;
                                    end;
                                    if rec."FTT-CST Conectivity" = Rec."FTT-CST Conectivity"::Blank then begin
                                        AddCrossConnectVisible := false;
                                        Rec."FTT-CST Cross Connect" := false;
                                        Rec.Modify();
                                    end;

                                    if rec."FTT-CST Conectivity" = Rec."FTT-CST Conectivity"::No then begin
                                        if rec."FTT-CST Type of Site2" = rec."FTT-CST Type of Site2"::None then begin
                                            AddCrossConnectVisible := false;
                                            Rec."FTT-CST Cross Connect" := false;
                                            Rec.Modify();

                                        end;

                                        if Rec."FTT-CST Conectivity" = Rec."FTT-CST Conectivity"::Blank then begin
                                            PrimaryVisible := false;
                                            CompLocVisible := false;
                                        end;
                                        MakeBackupDependencyFilters(Rec, false);

                                        CurrPage.Update();
                                    end;
                                end;
                            }
                        }

                        group("CROSS СONNECT")
                        {
                            Visible = AddCrossConnectVisible;
                            ShowCaption = false;
                            field("Cross Connect"; Rec."FTT-CST Cross Connect")
                            {
                                Caption = 'ADD CROSS CONNECT';
                                ApplicationArea = all;
                                Editable = true;
                                trigger OnValidate()
                                var
                                    CrossConnect: Page "FTT-CST Cross Connect";
                                    recCrossConnect: record "FTT-CST Cross Connect";
                                    DependencyItems: record "FTT-CST Dependancy Item";
                                begin
                                    recCrossConnect.SetRange("Filter No.", rec."Filter No.");
                                    recCrossConnect.DeleteAll();
                                    Commit();

                                    DependencyItems.SetRange("Filter No.", Rec."Filter No.");
                                    DependencyItems.SetRange("FTT-CST Cross Connect", true);
                                    DependencyItems.SetRange("Location Code", LocationCode);
                                    if DependencyItems.FindSet() then
                                        DependencyItems.DeleteAll();
                                    Commit();

                                    DependencyItems.RESET;
                                    if Rec."FTT-CST Cross Connect" then begin
                                        DependencyItems.SetRange("Filter No.", Rec."Filter No.");
                                        DependencyItems.SetRange("Location Code", LocationCode);
                                        DependencyItems.SetRange("FTT-CST FEED", true);
                                        if DependencyItems.FindSet() then
                                            repeat
                                                recCrossConnect.Init();
                                                recCrossConnect."Filter No." := DependencyItems."Filter No.";
                                                recCrossConnect."Item No." := DependencyItems."No.";
                                                recCrossConnect.Description := DependencyItems.Description;
                                                if СheckIFFeedTypeIsNS(DependencyItems."No.") then begin
                                                    recCrossConnect."Quantity 2" := 2;
                                                    recCrossConnect."Quantity 4" := 2;
                                                end else begin
                                                    recCrossConnect."Quantity 1" := 1;
                                                    recCrossConnect."Quantity 3" := 1;
                                                end;
                                                recCrossConnect."Item Category Code" := DependencyItems."Item Category Code"; //NRd
                                                recCrossConnect.Insert();
                                            until DependencyItems.next = 0;
                                        Commit();
                                        recCrossConnect.SetRange("Filter No.", Rec."Filter No.");
                                        CrossConnect.LookupMode(true);
                                        CrossConnect.SetTableView(recCrossConnect);
                                        if CrossConnect.RunModal() = Action::LookupOK then begin
                                            AddCrossConnect();
                                            Commit();
                                            AddCrossConnect2Table(); //NRD
                                            Commit();
                                        end else begin
                                            Rec."FTT-CST Cross Connect" := false;
                                        end;
                                    end;
                                    MakeBackupDependencyFilters(Rec, false);
                                end;
                            }
                        }
                        group("ADDINTERNATIONALLINE")
                        {
                            Visible = AddCrossConnectVisible;
                            ShowCaption = false;
                            field("ADD INTERNATIONAL LINE"; Rec."FTT-CST International Line")
                            {
                                Caption = 'ADD INTERNATIONAL LINE';
                                ApplicationArea = all;
                                Editable = true;
                                trigger OnValidate()
                                begin
                                    AddInternationalLine2();
                                end;
                            }
                        }

                        group("Confirm Document")
                        {
                            //Visible = ConfirmDocumentVisible;
                            Visible = false;
                            ShowCaption = false;
                            field(ConfirmDocument; ConfirmDocument)
                            {
                                Caption = 'CONFIRM SELECTED ITEMS';
                                trigger OnValidate()
                                begin
                                    if (rec."FTT-CST Licences Filters" <> '') or
                                    (Rec."FTT-CST NON Standard maker" <> '') or
                                    (Rec."FTT-CST NON Standard taker" <> '') or
                                    (Rec."FTT-CST Standard maker feed" <> '') or
                                    (Rec."FTT-CST Standard taker feed" <> '')
                                    then
                                        if rec."FTT-CST Integration" <> '' then
                                            ERROR('Integration can not be blank');
                                    if Rec."FTT-CST Conectivity" = Rec."FTT-CST Conectivity"::Yes then
                                        if not Rec."FTT-CST Cross Connect" then
                                            error('Cross connect should be added');
                                end;
                            }
                        }
                    }
                }
            }
            part(SelectedItems; "Item List")
            {
                Visible = false;
            }
            part(SelectedDepItems; "FTT-CST Dependency Item")
            {
                ApplicationArea = Basic, Suite;
                Editable = true;
                Enabled = true;
                SubPageLink = "Filter No." = FIELD("Filter No."), "Sales Document No." = field("Sales Document No."); // NRD
                UpdatePropagation = Both;
                SubPageView = sorting("Location Code", Level);
            }

        }
    }

    actions
    {
        area(navigation)
        {
            group(Process)
            {
                action("CROSS CONNECT2")
                {
                    Caption = 'Add CROSS CONNECT';
                    ApplicationArea = all;
                    trigger OnAction()
                    begin
                        Message('Add CROSS CONNECT');
                    end;
                }
                //"ADD INTERNATIONAL LINE"
            }
        }
    }
    trigger OnOpenPage()
    var
        DependancyItem: Record "FTT-CST Dependancy Item";
    begin
        SalesReceivables.GET();
        DependancyFilter := '';
        DependancyItem.SetRange("Filter No.", Rec."Filter No.");
        DependancyItem.SetRange("Sales Document No.", rec."Sales Document No.");
        DependancyItem.DeleteAll();
    end;



    internal procedure SetFilters(SalespersonPurchaserCode: Code[20])
    begin
        SalespersonPurchaserCodeGlobal := SalespersonPurchaserCode;
    end;

    procedure AddCrossConnect()
    var
        CrossConnect: record "FTT-CST Cross Connect";
        DepItems: record "FTT-CST Dependancy Item";
        Item: Record Item;
        SalesReceivablesSetup: Record "Sales & Receivables Setup";
        Qty1: Decimal;
        Qty2: Decimal;
        Qty3: Decimal;
        Qty4: Decimal;
    begin
        SalesReceivablesSetup.Get();
        Qty1 := 0;
        Qty2 := 0;
        Qty3 := 0;
        Qty4 := 0;

        CrossConnect.SetRange("Filter No.", rec."Filter No.");
        if CrossConnect.FindSet() then
            repeat
                Qty1 := Qty1 + CrossConnect."Quantity 1";
                Qty2 := Qty2 + CrossConnect."Quantity 2";
                Qty3 := Qty3 + CrossConnect."Quantity 3";
                Qty4 := Qty4 + CrossConnect."Quantity 4";
            until CrossConnect.next = 0;
        Item.Reset;
        item.SetRange("Item Category Code", SalesReceivablesSetup."FTT-CST Shared MRC CC Category");
        if Item.FindFirst() and (Qty1 > 0) then begin
            DepItems.Init();
            DepItems."Location Code" := LocationCode;
            DepItems."FTT-CST Sublocation" := Rec."FTT-CST Sublocation";
            DepItems."FTT-CST Component Option" := Rec."FTT-CST Component Option";
            DepItems."Filter No." := Rec."Filter No.";
            DepItems.Level := 12;
            DepItems."No." := Item."No.";
            DepItems."FTT-CST Quantity" := Qty1;
            DepItems.Description := Item.Description;
            DepItems."FTT-CST Comments Fluent" := Item."FTT-CST Comments Fluent";
            DepItems."Unit Price" := Item."Unit Price";
            DepItems."FTT-CST Parent Category Code" := SalesReceivablesSetup."FTT-CST Parent CROSS CONNECT";
            DepItems."FTT-CST Cross Connect" := True;
            DepItems."Sales Document No." := Rec."Sales Document No.";
            DepItems."FTT-CST Use for Discount" := false;
            DepItems.Insert();
        end;
        Item.Reset;
        Item.SetRange("Item Category Code", SalesReceivablesSetup."FTT-CST Shared NRC CC Category");
        if Item.FindFirst() and (Qty3 > 0) then begin
            DepItems.Init();
            DepItems."Location Code" := LocationCode;
            DepItems."FTT-CST Sublocation" := Rec."FTT-CST Sublocation";
            DepItems."FTT-CST Component Option" := Rec."FTT-CST Component Option";
            DepItems."Filter No." := Rec."Filter No.";
            DepItems.Level := 13;
            DepItems."No." := Item."No.";
            DepItems."FTT-CST Quantity" := Qty3;
            DepItems.Description := Item.Description;
            DepItems."FTT-CST Comments Fluent" := Item."FTT-CST Comments Fluent";
            DepItems."Unit Price" := Item."Unit Price";
            DepItems."FTT-CST Cross Connect" := True;
            DepItems."FTT-CST Parent Category Code" := SalesReceivablesSetup."FTT-CST Parent CROSS CONNECT";
            DepItems."Sales Document No." := Rec."Sales Document No.";
            DepItems."FTT-CST Use for Discount" := false;
            DepItems.Insert();
        end;

        Item.Reset;
        Item.SetRange("Item Category Code", SalesReceivablesSetup."FTT-CST Ded. MRC CC Category");
        if item.FindFirst() and (Qty2 > 0) then begin
            DepItems.Init();
            DepItems."Location Code" := LocationCode;
            DepItems."FTT-CST Sublocation" := Rec."FTT-CST Sublocation";
            DepItems."FTT-CST Component Option" := Rec."FTT-CST Component Option";
            DepItems."Filter No." := Rec."Filter No.";
            DepItems.Level := 14;
            DepItems."No." := Item."No.";
            DepItems."FTT-CST Quantity" := Qty2;
            DepItems.Description := Item.Description;
            DepItems."FTT-CST Comments Fluent" := Item."FTT-CST Comments Fluent";
            DepItems."Unit Price" := Item."Unit Price";
            DepItems."FTT-CST Cross Connect" := True;
            DepItems."FTT-CST Parent Category Code" := SalesReceivablesSetup."FTT-CST Parent CROSS CONNECT";
            DepItems."Sales Document No." := Rec."Sales Document No.";
            DepItems."FTT-CST Use for Discount" := false;
            DepItems.Insert();
        end;

        Item.Reset;
        Item.SetRange("Item Category Code", SalesReceivablesSetup."FTT-CST Ded. NRC CC Category");
        if Item.FindFirst() and (Qty4 > 0) then begin
            DepItems.Init();
            DepItems."Location Code" := LocationCode;
            DepItems."FTT-CST Sublocation" := Rec."FTT-CST Sublocation";
            DepItems."FTT-CST Component Option" := Rec."FTT-CST Component Option";
            DepItems."Filter No." := Rec."Filter No.";
            DepItems.Level := 15;
            DepItems."No." := Item."No.";
            DepItems."FTT-CST Quantity" := Qty4;
            DepItems.Description := Item.Description;
            DepItems."Unit Price" := Item."Unit Price";
            DepItems."FTT-CST Comments Fluent" := Item."FTT-CST Comments Fluent";
            DepItems."FTT-CST Cross Connect" := True;
            DepItems."FTT-CST Parent Category Code" := SalesReceivablesSetup."FTT-CST Parent CROSS CONNECT";
            DepItems."Sales Document No." := Rec."Sales Document No.";
            DepItems."FTT-CST Use for Discount" := false;
            DepItems.Insert();
        end;
    end;

    procedure AddCrossConnect2Table()
    var
        CrossConnect: record "FTT-CST Cross Connect";
        CrossConnectHeader: record "FTT-CST Cross Connect Hdr";
        CrossConnectLines: Record "FTT-CST Cross Connect Lines";
        CrossConnectLines2: record "FTT-CST Cross Connect Lines";
        DocType: enum "Sales Document Type";
    begin

        DocType := rec."Document Type"; //NRD

        CrossConnectLines2.Reset();
        CrossConnectLines2.SetRange("Document Type", DocType);
        CrossConnectLines2.SetRange("Document No.", rec."Sales Document No.");
        CrossConnectLines2.SetRange("FTT-CST Location Code", LocationCode);
        if CrossConnectLines2.FindSet() then
            CrossConnectLines2.DeleteAll();

        CrossConnectHeader.Reset();
        CrossConnectHeader.SetRange("Document Type", DocType);
        CrossConnectHeader.SetRange("Document No.", rec."Sales Document No.");
        //CrossConnectHeader.SetRange("Cross Connect Status", CrossConnectHeader."Cross Connect Status"::Open);
        if not CrossConnectHeader.FindFirst() then begin

            CrossConnectHeader.Init();
            CrossConnectHeader."Document Type" := DocType;
            CrossConnectHeader."Document No." := rec."Sales Document No.";
            CrossConnectHeader.validate("Customer No.", rec."Sell-to Customer No.");
            CrossConnectHeader."Cross Connect Status" := CrossConnectHeader."Cross Connect Status"::Open;
            IF CrossConnectHeader.Insert() THEN begin
                Commit();
                CrossConnect.SetRange("Filter No.", rec."Filter No.");
                if CrossConnect.FindSet() then
                    repeat
                        CrossConnectLines.Init();
                        CrossConnectLines."Document Type" := DocType;
                        CrossConnectLines."Document No." := rec."Sales Document No.";
                        CrossConnectLines."Item No." := CrossConnect."Item No.";
                        CrossConnectLines."FTT-CST Location Code" := LocationCode;
                        CrossConnectLines.Description := CrossConnect.Description;
                        CrossConnectLines."Quantity 1" := CrossConnect."Quantity 1";
                        CrossConnectLines."Quantity 2" := CrossConnect."Quantity 2";
                        CrossConnectLines."Quantity 3" := CrossConnect."Quantity 3";
                        CrossConnectLines."Quantity 4" := CrossConnect."Quantity 4";
                        CrossConnectLines."Item Category Code" := CrossConnect."Item Category Code";
                        CrossConnectLines.Insert();
                    until CrossConnect.next = 0;
            end;
        end else begin

            CrossConnect.SetRange("Filter No.", rec."Filter No.");
            if CrossConnect.FindSet() then
                repeat
                    CrossConnectLines.Init();
                    CrossConnectLines."Document Type" := DocType;
                    CrossConnectLines."Document No." := rec."Sales Document No.";
                    CrossConnectLines."FTT-CST Location Code" := LocationCode;
                    CrossConnectLines."Item No." := CrossConnect."Item No.";
                    CrossConnectLines.Description := CrossConnect.Description;
                    CrossConnectLines."Quantity 1" := CrossConnect."Quantity 1";
                    CrossConnectLines."Quantity 2" := CrossConnect."Quantity 2";
                    CrossConnectLines."Quantity 3" := CrossConnect."Quantity 3";
                    CrossConnectLines."Quantity 4" := CrossConnect."Quantity 4";
                    CrossConnectLines."Item Category Code" := CrossConnect."Item Category Code";
                    CrossConnectLines.Insert();
                until CrossConnect.Next() = 0;
        end;
    end;

    procedure AddHardwareConnect(var pFilter: text[1024]; var pFilterDesc: text[1024])
    var
        DepItems: record "FTT-CST Dependancy Item";
        Item: Record Item;
        SalesReceivablesSetup: Record "Sales & Receivables Setup";
        SpecialSelect: record "FTT-CST Special Select";
    begin
        pFilter := '';
        SalesReceivablesSetup.Get();
        SpecialSelect.SetRange("Filter No.", Rec."Filter No.");
        if SpecialSelect.FindSet() then
            repeat
                if SpecialSelect.Quantity > 0 then begin
                    DepItems.Init();
                    DepItems."Location Code" := LocationCode;
                    DepItems."FTT-CST Sublocation" := Rec."FTT-CST Sublocation";
                    DepItems."FTT-CST Component Option" := Rec."FTT-CST Component Option";
                    DepItems."Filter No." := Rec."Filter No.";
                    DepItems."No." := SpecialSelect."Item No.";
                    DepItems."FTT-CST Quantity" := SpecialSelect.Quantity;
                    DepItems.Description := SpecialSelect.Description;
                    DepItems."Unit Price" := SpecialSelect."Unit Price";
                    DepItems."Item Category Code" := SalesReceivablesSetup."FTT-CST HARDWARE";
                    DepItems."FTT-CST Parent Category Code" := SalesReceivablesSetup."FTT-CST HARDWARE";
                    DepItems."FTT-CST Comments" := SpecialSelect.Comments;
                    DepItems."FTT-CST Comments Fluent" := SpecialSelect."Comments Fluent";



                    DepItems.Optional := SpecialSelect.Optional;
                    DepItems."Sales Document No." := Rec."Sales Document No.";
                    DepItems.Level := 8;
                    DepItems.Insert();
                    if pFilter = '' then
                        pFilter := SpecialSelect."Item No." else
                        pFilter := pFilter + '|' + SpecialSelect."Item No.";

                    if pFilterDesc = '' then
                        pFilterDesc := SpecialSelect.Description else
                        pFilterDesc := pFilterDesc + '|' + SpecialSelect.Description;

                end;
            until SpecialSelect.next = 0;
    end;

    procedure AddHostingLine(var pFilter: text[1024]; var pFilterDesc: text[1024])
    var
        DepItems: record "FTT-CST Dependancy Item";
        Item: Record Item;
        SalesReceivablesSetup: Record "Sales & Receivables Setup";
        SpecialSelect: record "FTT-CST Special Select";
    begin
        pFilter := '';
        SalesReceivablesSetup.Get();
        SpecialSelect.SetRange("Filter No.", Rec."Filter No.");
        if SpecialSelect.FindSet() then
            repeat
                if SpecialSelect.Quantity > 0 then begin
                    DepItems.Init();
                    DepItems."Location Code" := LocationCode;
                    DepItems."FTT-CST Sublocation" := Rec."FTT-CST Sublocation";
                    DepItems."FTT-CST Component Option" := Rec."FTT-CST Component Option";
                    DepItems."FTT-CST Use for Discount" := false;
                    DepItems."Filter No." := Rec."Filter No.";
                    DepItems."No." := SpecialSelect."Item No.";
                    DepItems."FTT-CST Quantity" := SpecialSelect.Quantity;
                    DepItems.Description := SpecialSelect.Description;
                    DepItems."Unit Price" := SpecialSelect."Unit Price";
                    DepItems."FTT-CST Comments" := SpecialSelect.Comments;
                    DepItems."FTT-CST Comments Fluent" := SpecialSelect."Comments Fluent";
                    DepItems.Optional := SpecialSelect.Optional;
                    DepItems."FTT-CST Parent Category Code" := SalesReceivablesSetup."FTT-CST Hosting and management";
                    DepItems."Sales Document No." := Rec."Sales Document No.";
                    DepItems.Level := 10;
                    DepItems.Insert();
                    if pFilter = '' then
                        pFilter := SpecialSelect."Item No." else
                        pFilter := pFilter + '|' + SpecialSelect."Item No.";

                    if pFilterDesc = '' then
                        pFilterDesc := SpecialSelect.Description else
                        pFilterDesc := pFilterDesc + '|' + SpecialSelect.Description;
                end;
            until SpecialSelect.next = 0;
    end;

    procedure AddLicenseLine(var pFilter: text[1024])
    var
        DepItems: record "FTT-CST Dependancy Item";
        Item: Record Item;
        SalesReceivablesSetup: Record "Sales & Receivables Setup";
        SpecialSelect: Record "FTT-CST Special Select";
    begin
        pFilter := '';
        SalesReceivablesSetup.Get();
        SpecialSelect.SetRange("Filter No.", Rec."Filter No.");
        if SpecialSelect.FindSet() then
            repeat
                if SpecialSelect.Quantity > 0 then begin
                    DepItems.Init();
                    DepItems."Location Code" := LocationCode;
                    DepItems."FTT-CST Sublocation" := Rec."FTT-CST Sublocation";
                    DepItems."FTT-CST Component Option" := Rec."FTT-CST Component Option";
                    DepItems."Filter No." := Rec."Filter No.";
                    DepItems."No." := SpecialSelect."Item No.";

                    DepItems."FTT-CST Quantity" := SpecialSelect.Quantity;

                    DepItems.Description := SpecialSelect.Description;
                    DepItems."Unit Price" := SpecialSelect."Unit Price";
                    DepItems."FTT-CST Comments" := SpecialSelect.Comments;
                    DepItems."FTT-CST Comments Fluent" := SpecialSelect."Comments Fluent";
                    DepItems.Optional := SpecialSelect.Optional;
                    DepItems.Redundancy := SpecialSelect.Redundancy;
                    DepItems.DR := SpecialSelect.DR;
                    DepItems."Integr." := SpecialSelect."Integr."; //NRD
                    DepItems."FTT-CST Use for DR" := true;
                    DepItems."FTT-CST Use For Red" := true;
                    DepItems."FTT-CST Parent Category Code" := SalesReceivablesSetup."FTT-CST LICENSE";
                    DepItems.Level := 1;
                    DepItems."FTT-CST Use for Discount" := true;
                    DepItems."Sales Document No." := Rec."Sales Document No.";
                    DepItems.Insert();
                    if pFilter = '' then
                        pFilter := SpecialSelect."Item No." else
                        pFilter := pFilter + '|' + SpecialSelect."Item No.";
                end;
            until SpecialSelect.next = 0;
    end;

    procedure AddLicenseLineDesc(var pFilter: text[1024])
    var
        DepItems: record "FTT-CST Dependancy Item";
        Item: Record Item;
        SalesReceivablesSetup: Record "Sales & Receivables Setup";
        SpecialSelect: Record "FTT-CST Special Select";
    begin
        pFilter := '';
        SalesReceivablesSetup.Get();
        SpecialSelect.SetRange("Filter No.", Rec."Filter No.");
        if SpecialSelect.FindSet() then
            repeat
                if SpecialSelect.Quantity > 0 then begin
                    if pFilter = '' then
                        pFilter := SpecialSelect.Description else
                        pFilter := pFilter + '|' + SpecialSelect.Description;
                end;
            until SpecialSelect.next = 0;
    end;

    procedure AddSpecialLines(var pFilter: text[1024]; GroupCode: code[20])
    var
        DepItems: record "FTT-CST Dependancy Item";
        Item: Record Item;
        SalesReceivablesSetup: Record "Sales & Receivables Setup";
        SpecialSelect: record "FTT-CST Licence Select";
    begin
        pFilter := '';
        SalesReceivablesSetup.Get();
        SpecialSelect.SetRange("Filter No.", Rec."Filter No.");
        if SpecialSelect.FindSet() then
            repeat
                if SpecialSelect.Quantity > 0 then begin
                    DepItems.Init();
                    DepItems."Location Code" := LocationCode;
                    DepItems."FTT-CST Sublocation" := Rec."FTT-CST Sublocation";
                    DepItems."FTT-CST Component Option" := Rec."FTT-CST Component Option";
                    DepItems."Filter No." := Rec."Filter No.";
                    DepItems."No." := SpecialSelect."Item No.";
                    DepItems."FTT-CST Quantity" := SpecialSelect.Quantity;
                    DepItems.Description := SpecialSelect.Description;
                    DepItems."Unit Price" := SpecialSelect."Unit Price";
                    DepItems."FTT-CST Comments" := SpecialSelect.Comments;
                    DepItems."FTT-CST Comments Fluent" := SpecialSelect."Comments Fluent";
                    DepItems.Optional := SpecialSelect.Optional;
                    DepItems."FTT-CST Use for Discount" := true;
                    DepItems."Sales Document No." := Rec."Sales Document No.";
                    case GroupCode of
                        'LICENSE':
                            begin
                                DepItems.Level := 1;
                                DepItems."FTT-CST Parent Category Code" := SalesReceivablesSetup."FTT-CST LICENSE";
                            end;
                        'STANDARD TAKER FEED':
                            DepItems.Level := 2;
                        'NS TAKER FEED':
                            DepItems.Level := 3;
                        'STANDARD MAKER FEED':
                            DepItems.Level := 4;
                        'NS MAKER FEED':
                            DepItems.Level := 5;
                    end;
                    if DepItems.Level in [3, 4, 5] then
                        DepItems."FTT-CST Parent Category Code" := SalesReceivablesSetup."FTT-CST Parent FEED";

                    if DepItems.level in [1, 2, 3, 4, 5] then begin
                        DepItems."FTT-CST Use for DR" := true;
                        DepItems."FTT-CST Use for Red" := true;
                        DepItems."FTT-CST Use for Discount" := true;
                    end;
                    DepItems.Insert();
                    if pFilter = '' then
                        pFilter := SpecialSelect."Item No." else
                        pFilter := pFilter + '|' + SpecialSelect."Item No.";
                end;
            until SpecialSelect.next = 0;
    end;

    procedure AddFeedLines(var pFilter: text[1024]; GroupCode: code[20]; CrossConnect: boolean)
    var
        DepItems: record "FTT-CST Dependancy Item";
        Item2: Record Item;
        SalesReceivablesSetup: Record "Sales & Receivables Setup";
        SpecialSelect: record "FTT-CST Special Select";
        RecItem: Record Item;
        ItemModify: Record item;
        PageDialog: page "FTT-CST Dialog";
        PriceCalcPerc: Decimal;
        EntryNo: Integer;
    begin
        pFilter := '';
        SalesReceivablesSetup.Get();
        SpecialSelect.SetRange("Filter No.", Rec."Filter No.");
        if SpecialSelect.FindSet() then
            repeat
                if SpecialSelect.Quantity > 0 then begin
                    DepItems.Init();
                    DepItems."Location Code" := LocationCode;
                    DepItems."FTT-CST Sublocation" := Rec."FTT-CST Sublocation";
                    DepItems."FTT-CST Component Option" := Rec."FTT-CST Component Option";
                    DepItems."Filter No." := Rec."Filter No.";
                    DepItems."No." := SpecialSelect."Item No.";
                    DepItems."FTT-CST Quantity" := SpecialSelect.Quantity;
                    DepItems.Description := SpecialSelect.Description;
                    DepItems."Unit Price" := SpecialSelect."Unit Price";
                    DepItems."FTT-CST FEED" := CrossConnect;
                    if SpecialSelect."FTT-CST Sublocation" <> SpecialSelect."FTT-CST Sublocation"::Blank then
                        DepItems."FTT-CST Sublocation" := SpecialSelect."FTT-CST Sublocation";
                    DepItems."FTT-CST Comments" := SpecialSelect.Comments;
                    DepItems."FTT-CST Comments Fluent" := SpecialSelect."Comments Fluent";
                    DepItems.Optional := SpecialSelect.Optional;
                    DepItems."FTT-CST Location Type" := SpecialSelect."FTT-CST Location Type";
                    DepItems.Redundancy := SpecialSelect.Redundancy;
                    DepItems."Integr." := SpecialSelect."Integr."; //NRD
                    if Item2.Get(SpecialSelect."Item No.") then
                        DepItems."Item Category Code" := Item2."Item Category Code"; //NRD

                    if (GroupCode = SalesReceivablesSetup."FTT-CST LICENSE") or
                    (GroupCode = SalesReceivablesSetup."FTT-CST NS MAKER FEED") or
                    (GroupCode = SalesReceivablesSetup."FTT-CST STANDARD MAKER FEED") or
                    (GroupCode = SalesReceivablesSetup."FTT-CST NS TAKER FEED") or
                    (GroupCode = SalesReceivablesSetup."FTT-CST STANDARD TAKER FEED") then begin
                        DepItems."FTT-CST Use for DR" := true;
                        DepItems."FTT-CST Use for Red" := true;
                    end;

                    DepItems.DR := SpecialSelect.DR;
                    DepItems."FTT-CST Use for Discount" := true;
                    DepItems."FTT-CST Parent Category Code" := SalesReceivablesSetup."FTT-CST Parent FEED";

                    if GroupCode = SalesReceivablesSetup."FTT-CST DR Category" then begin
                        DepItems."FTT-CST Parent Category Code" := SalesReceivablesSetup."FTT-CST DR Category";
                        DepItems."FTT-CST DR" := true;
                        DepItems.level := 7;
                    end;

                    if GroupCode = SalesReceivablesSetup."FTT-CST Redundancy Category" then begin
                        DepItems."FTT-CST Parent Category Code" := SalesReceivablesSetup."FTT-CST Redundancy Category";
                        DepItems."FTT-CST Redundency" := true;
                        DepItems.Level := 6;
                    end;
                    DepItems."Sales Document No." := Rec."Sales Document No.";
                    //DepItems."FTT-CST Cross Connect" := CrossConnect;
                    case GroupCode of
                        SalesReceivablesSetup."FTT-CST LICENSE":
                            DepItems.Level := 1;
                        SalesReceivablesSetup."FTT-CST STANDARD TAKER FEED":
                            DepItems.Level := 2;
                        SalesReceivablesSetup."FTT-CST NS TAKER FEED":
                            DepItems.Level := 3;
                        SalesReceivablesSetup."FTT-CST STANDARD MAKER FEED":
                            DepItems.Level := 4;
                        SalesReceivablesSetup."FTT-CST NS MAKER FEED":
                            DepItems.Level := 5;
                        SalesReceivablesSetup."FTT-CST DR Category":
                            DepItems.Level := 7;
                        SalesReceivablesSetup."FTT-CST Redundancy Category":
                            DepItems.Level := 6;
                    end;
                    DepItems."FTT-CST RED/DR PriceCalc %" := SpecialSelect."Recalculation %";
                    DepItems.Insert();

                    if pFilter = '' then
                        pFilter := SpecialSelect."Item No." else
                        pFilter := pFilter + '|' + SpecialSelect."Item No.";
                end;
            until SpecialSelect.next = 0;
    end;

    procedure AddFeedLinesDesc(var pFilter: text[1024]; GroupCode: code[20])
    var
        DepItems: record "FTT-CST Dependancy Item";
        Item: Record Item;
        SalesReceivablesSetup: Record "Sales & Receivables Setup";
        SpecialSelect: record "FTT-CST Special Select";
    begin
        pFilter := '';
        SalesReceivablesSetup.Get();
        SpecialSelect.SetRange("Filter No.", Rec."Filter No.");
        if SpecialSelect.FindSet() then
            repeat
                if SpecialSelect.Quantity > 0 then begin
                    if pFilter = '' then
                        pFilter := SpecialSelect.Description else
                        pFilter := pFilter + '|' + SpecialSelect.Description;
                end;
            until SpecialSelect.next = 0;
    end;



    procedure AddSetUpLine(var pFilter: text[1024])
    var
        DepItems: record "FTT-CST Dependancy Item";
        Item: Record Item;
        SalesReceivablesSetup: Record "Sales & Receivables Setup";
        SpecialSelect: record "FTT-CST Special Select";
    begin
        pFilter := '';
        SalesReceivablesSetup.Get();
        SpecialSelect.SetRange("Filter No.", Rec."Filter No.");
        //SpecialSelect.SetRange(f);
        if SpecialSelect.FindSet() then
            repeat
                if SpecialSelect.Quantity > 0 then begin
                    if DepItems.Get(rec."FTT-CST Location Code", Rec."Filter No.", SpecialSelect."Item No.", rec."Sales Document No.") then begin
                        DepItems."FTT-CST Quantity" := SpecialSelect.Quantity;
                        DepItems.Modify()
                    end else begin
                        DepItems.Init();
                        DepItems."Location Code" := LocationCode;
                        DepItems."FTT-CST Sublocation" := Rec."FTT-CST Sublocation";
                        DepItems."FTT-CST Component Option" := Rec."FTT-CST Component Option";
                        DepItems."Filter No." := Rec."Filter No.";
                        DepItems."No." := SpecialSelect."Item No.";
                        DepItems."FTT-CST Quantity" := SpecialSelect.Quantity;
                        DepItems.Description := SpecialSelect.Description;
                        DepItems."Unit Price" := SpecialSelect."Unit Price";
                        DepItems."FTT-CST Comments" := SpecialSelect.Comments;
                        DepItems."FTT-CST Comments Fluent" := SpecialSelect."Comments Fluent";
                        DepItems.Optional := SpecialSelect.Optional;
                        DepItems."FTT-CST Parent Category Code" := SalesReceivablesSetup."FTT-CST HARDWARE";
                        DepItems."Sales Document No." := Rec."Sales Document No.";
                        DepItems.Level := 9;
                        DepItems.Insert();
                    end;
                    if pFilter = '' then
                        pFilter := SpecialSelect."Item No." else
                        pFilter := pFilter + '|' + SpecialSelect."Item No.";
                end;
            until SpecialSelect.next = 0;
    end;

    procedure СheckIFFeedTypeIsNS(ItemNo: code[20]): Boolean;
    var
        Item: record Item;
        SalesReceivables: Record "Sales & Receivables Setup";
    begin
        SalesReceivables.Get();
        if Item.Get(ItemNo) then;
        if (Item."Item Category Code" = SalesReceivables."FTT-CST NS MAKER FEED") or (Item."Item Category Code" = SalesReceivables."FTT-CST NS TAKER FEED") then
            exit(true) else
            exit(false);
    end;

    procedure ResetSelectedFilters()
    begin
        //Rec."FTT-CST Type of Site" := rec."FTT-CST Type of Site"::Blank;
        //Rec."FTT-CST Component Option" := Rec."FTT-CST Component Option"::Blank;
        Rec."FTT-CST Type of Site" := rec."FTT-CST Type of Site"::Blank;
        Rec."FTT-CST Conectivity" := Rec."FTT-CST Conectivity"::Blank;
        Rec."FTT-CST DR" := '';
        Rec."FTT-CST Redundency" := '';

        Rec."FTT-CST CPU" := '';
        Rec."FTT-CST HARDWARE" := '';
        Rec."FTT-CST Licences Filters" := '';
        Rec."FTT-CST NON Standard maker" := '';
        Rec."FTT-CST Standard maker feed" := '';
        Rec."FTT-CST Standard taker feed" := '';
        Rec."FTT-CST NON Standard taker" := '';
        Rec."FTT-CST Cross Connect" := false;
        //Rec."FTT-CST Sublocation" := rec."FTT-CST Sublocation"::Blank;

        DRVisible := false;
        RedundencyVisible := false;
        HMVisible := false;
        HardwareVisible := false;
        TypeSiteVisible := false;
        //LocTypeVisible := false;
        AddCrossConnectVisible := false;
        ConfirmDocument := false;
        PrimaryVisible := false;
        if (COPENHAGENLocation = false)
                            and (SINGAPORELocation = false)
                            and (NewYorkLocation = false) and
                            (TokyoLocation = false)
                            and (LondonLocation = false)
                            and (MALAYSIALocation = false)
                            and (CHICAGOLocation = false)
                                 then begin
            SublocationVisible := false;
            LocTypeVisible := false;
        end
        else begin
            SublocationVisible := true;
            LocTypeVisible := true;
        end;
        Rec.Modify();
        CurrPage.Update();
    end;

    procedure ResetSelectedFilters2()
    begin
        //Rec."FTT-CST Sublocation" := rec."FTT-CST Sublocation"::Blank;
        Rec."FTT-CST Type of Site" := rec."FTT-CST Type of Site"::Blank;
        Rec."FTT-CST Component Option" := Rec."FTT-CST Component Option"::Blank;
        Rec."FTT-CST Conectivity" := Rec."FTT-CST Conectivity"::Blank;
        Rec."FTT-CST International Line" := false;
        Rec.Modify();
    end;

    procedure MakeBackupDependencyFilters(var DepFlters: record "FTT-CST Dependency Filters"; UpdateLayout: boolean): Boolean
    var
        CopyDedependecyFilters: record "FTT-CST Dep. Filters Copy";
    begin
        if CopyDedependecyFilters.GET(DepFlters."Sales Document No.", DepFlters."Filter No.", DepFlters."FTT-CST Location Code") and UpdateLayout then begin
            begin
                DepFlters.TransferFields(CopyDedependecyFilters);
                DepFlters."FTT-CST Redundency" := CopyDedependecyFilters."FTT-CST Redundency";
                DepFlters."FTT-CST Cross Connect" := CopyDedependecyFilters."FTT-CST Cross Connect";
                DepFlters."FTT-CST Conectivity" := CopyDedependecyFilters."FTT-CST Conectivity";
                DepFlters."FTT-CST Sublocation" := CopyDedependecyFilters."FTT-CST Sublocation";
                DepFlters.Modify();
                if UpdateLayout then begin
                    CompLocVisible := CopyDedependecyFilters.ComLosVisible;
                    PrimaryVisible := CopyDedependecyFilters.PrimaryVisible;
                    ConVisible := CopyDedependecyFilters.ConVisible;
                    IntegrationVisible := CopyDedependecyFilters.IntegrationVisible;
                    ConectivityVisible := CopyDedependecyFilters.ConectivityVisible;
                    TypeSiteVisible := CopyDedependecyFilters.TypeSiteVisible;
                    RedundencyVisible := CopyDedependecyFilters.RedundencyVisible;
                    HMVisible := CopyDedependecyFilters.HMVisible;
                    DRVisible := CopyDedependecyFilters.DRVisible;
                    HardwareVisible := CopyDedependecyFilters.HardwareVisible;
                    LocTypeVisible := CopyDedependecyFilters.LocTypeVisible;
                    AddCrossConnectVisible := CopyDedependecyFilters.AddCrossConnectVisible;
                    SublocationVisible := CopyDedependecyFilters.SublocationVisible;

                end;
                CurrPage.Update();
                exit(true);
            end;
        end;

        if CopyDedependecyFilters.GET(DepFlters."Sales Document No.", DepFlters."Filter No.", DepFlters."FTT-CST Location Code") and not UpdateLayout then begin
            begin
                CopyDedependecyFilters.TransferFields(DepFlters);
                CopyDedependecyFilters."FTT-CST Redundency" := DepFlters."FTT-CST Redundency";
                CopyDedependecyFilters."FTT-CST Cross Connect" := DepFlters."FTT-CST Cross Connect";
                CopyDedependecyFilters."FTT-CST Conectivity" := DepFlters."FTT-CST Conectivity";
                CopyDedependecyFilters."FTT-CST Sublocation" := DepFlters."FTT-CST Sublocation";
                CopyDedependecyFilters.ComLosVisible := CompLocVisible;
                CopyDedependecyFilters.PrimaryVisible := PrimaryVisible;
                CopyDedependecyFilters.ConVisible := ConVisible;
                CopyDedependecyFilters.IntegrationVisible := IntegrationVisible;
                CopyDedependecyFilters.ConectivityVisible := ConnectivityVisible;
                CopyDedependecyFilters.TypeSiteVisible := TypeSiteVisible;
                CopyDedependecyFilters.RedundencyVisible := RedundencyVisible;
                CopyDedependecyFilters.HMVisible := HMVisible;
                CopyDedependecyFilters.DRVisible := DRVisible;
                CopyDedependecyFilters.HardwareVisible := HardwareVisible;
                CopyDedependecyFilters.LocTypeVisible := LocTypeVisible;
                CopyDedependecyFilters.AddCrossConnectVisible := AddCrossConnectVisible;
                CopyDedependecyFilters.SublocationVisible := SublocationVisible;
                CopyDedependecyFilters.Modify();
            end;
        end;

        if NOT CopyDedependecyFilters.GET(DepFlters."Sales Document No.", DepFlters."Filter No.", DepFlters."FTT-CST Location Code") then begin
            CopyDedependecyFilters.Init;
            CopyDedependecyFilters.TransferFields(DepFlters);
            CopyDedependecyFilters."FTT-CST Redundency" := DepFlters."FTT-CST Redundency";
            CopyDedependecyFilters."FTT-CST Cross Connect" := DepFlters."FTT-CST Cross Connect";
            CopyDedependecyFilters."FTT-CST Conectivity" := DepFlters."FTT-CST Conectivity";
            CopyDedependecyFilters.ComLosVisible := CompLocVisible;
            CopyDedependecyFilters.PrimaryVisible := PrimaryVisible;
            CopyDedependecyFilters.ConVisible := ConVisible;
            CopyDedependecyFilters.IntegrationVisible := IntegrationVisible;
            CopyDedependecyFilters.ConectivityVisible := ConnectivityVisible;
            CopyDedependecyFilters.TypeSiteVisible := TypeSiteVisible;
            CopyDedependecyFilters.RedundencyVisible := RedundencyVisible;
            CopyDedependecyFilters.HMVisible := HMVisible;
            CopyDedependecyFilters.DRVisible := DRVisible;
            CopyDedependecyFilters.HardwareVisible := HardwareVisible;
            CopyDedependecyFilters.LocTypeVisible := LocTypeVisible;
            CopyDedependecyFilters.AddCrossConnectVisible := AddCrossConnectVisible;
            CopyDedependecyFilters.SublocationVisible := SublocationVisible;
            if CopyDedependecyFilters.Insert() then;
            if DepFlters."FTT-CST Component Option" <> DepFlters."FTT-CST Component Option"::Blank then
                exit(false);
        end;
    end;

    procedure MakeOFFAllLocations()
    begin
        begin
            rec."FTT-CST Component Option" := rec."FTT-CST Component Option"::Blank;
            rec."FTT-CST Type of Site" := rec."FTT-CST Type of Site"::Blank;
            rec."FTT-CST Conectivity" := Rec."FTT-CST Conectivity"::Blank;
            rec."FTT-CST Location" := '';
            rec."FTT-CST Sublocation" := 0;
            rec."FTT-CST Standard Maker Feed" := '';
            rec."FTT-CST Standard Maker Feed Desc." := '';
            rec."FTT-CST Standard Taker Feed" := '';
            rec."FTT-CST Standard Taker Feed Desc." := '';
            rec."FTT-CST NON Standard Maker" := '';
            rec."FTT-CST NON Standard Maker Desc." := '';
            rec."FTT-CST NON Standard Taker" := '';
            rec."FTT-CST NON Standard Taker Desc." := '';
            rec."FTT-CST Licences Filters Desc." := '';
            rec."FTT-CST Licences Filters" := '';
            rec."FTT-CST DR" := '';
            rec."FTT-CST DR Description" := '';
            rec."FTT-CST HARDWARE" := '';
            rec."FTT-CST HARDWARE Desc." := '';
            rec."FTT-CST Integration Dec." := 0;
            rec."FTT-CST Integration Desc." := '';
            rec."FTT-CST Redundency" := '';
            rec."FTT-CST Redun Desc." := '';
            rec."FTT-CST CPU Desc." := '';
            rec."FTT-CST CPU" := '';
            rec.Modify();

            LocTypeVisible := false;
            TypeSiteVisible := false;
            PrimaryVisible := false;
            DRVisible := false;
            RedundencyVisible := false;
            ConVisible := false;
            HMVisible := false;
            IntegrationVisible := false;
            AddCrossConnectVisible := false;
            HardwareVisible := false;
            TypeSiteVisible := false;
            HardwareVisible := false;
            CurrPage.Update(true);
        end;
    end;

    procedure AddIntegration(Percentage: Decimal)
    var
        DepItems: record "FTT-CST Dependancy Item";
        Item: Record Item;
        SalesReceivablesSetup: Record "Sales & Receivables Setup";

    begin
        SalesReceivablesSetup.Get();
        Item.SetRange("Item Category Code", SalesReceivablesSetup."FTT-CST Integration Category");
        Item.SetFilter("FTT-CST Integr PriceCalc %", '>%1', 0);

        if Item.FindFirst() then
            repeat
                DepItems.SetRange("Filter No.", rec."Filter No.");
                //DepItems.SetRange("Item Category Code", 'INTEGRATION');
                DepItems.SetRange("Item Category Code", SalesReceivablesSetup."FTT-CST Integration Category");
                DepItems.SetRange("Location Code", Rec."FTT-CST Location Code");
                DepItems.SetRange("No.", Item."No.");
                if not DepItems.FindSet() then begin
                    DepItems.Init();
                    DepItems."Location Code" := LocationCode;
                    DepItems."FTT-CST Sublocation" := Rec."FTT-CST Sublocation";
                    DepItems."FTT-CST Component Option" := Rec."FTT-CST Component Option";
                    DepItems."FTT-CST Use for Discount" := true;
                    DepItems."Filter No." := Rec."Filter No.";
                    DepItems."No." := Item."No.";
                    DepItems."FTT-CST Quantity" := 1;
                    DepItems.Description := Item.Description;
                    DepItems."Unit Price" := Item."Unit Price";

                    DepItems."Item Category Code" := SalesReceivablesSetup."FTT-CST Integration Category";
                    DepItems."FTT-CST Parent Category Code" := SalesReceivablesSetup."FTT-CST Integration Category";
                    //DepItems.Optional := Item.Optional;
                    DepItems."Sales Document No." := Rec."Sales Document No.";
                    DepItems."FTT-CST Use for Discount" := false;
                    DepItems."FTT-CST Integration" := true;
                    DepItems."FTT-CST RED/DR PriceCalc %" := Item."FTT-CST Integr PriceCalc %";
                    DepItems.Level := 11;
                    DepItems.Insert();
                    Rec."FTT-CST Integration Desc." := Item.Description + ' (' + format(Item."FTT-CST Integr PriceCalc %") + '%)';
                    Rec."FTT-CST Integration Dec." := Item."FTT-CST Integr PriceCalc %";

                    IntegrationVisible := true;
                    HardwareVisible := true;
                    CurrPage.Update();
                end else begin
                    if Percentage <> 0 then begin
                        DepItems."FTT-CST RED/DR PriceCalc %" := Percentage;
                        Rec."FTT-CST Integration Desc." := FORMAT(Percentage) + '%';
                        Rec."FTT-CST Integration Dec." := Percentage;
                        DepItems.Modify();
                    end;
                end;
            until Item.Next() = 0;
    end;

    procedure AddIntegrationCode(FilterSelectedItems: text[1024]);
    var
        DepItems: record "FTT-CST Dependancy Item";
        Item: Record Item;
        SalesReceivablesSetup: Record "Sales & Receivables Setup";
        SpecialSelect: record "FTT-CST Special Select";
        //SpecialSelect: record Item;
        Percentage: Decimal;
        LicencesFiltersDesc: text[1024];
    begin
        SalesReceivablesSetup.Get();
        SpecialSelect.SetRange("Filter No.", Rec."Filter No.");
        SpecialSelect.SetFilter(Quantity, '>%1', 0);
        if SpecialSelect.FindSet() then
            repeat
                if not DepItems.GET(Rec."FTT-CST Location Code", Rec."Filter No.", SpecialSelect."Item No.", rec."Sales Document No.") then begin
                    DepItems.Init();
                    DepItems."Location Code" := LocationCode;
                    DepItems."FTT-CST Sublocation" := Rec."FTT-CST Sublocation";
                    DepItems."FTT-CST Component Option" := Rec."FTT-CST Component Option";
                    DepItems."Filter No." := Rec."Filter No.";
                    DepItems."No." := SpecialSelect."Item No.";
                    //NRD
                    if SpecialSelect.Quantity <= 1 then
                        DepItems."FTT-CST Quantity" := 1
                    else
                        DepItems."FTT-CST Quantity" := SpecialSelect.Quantity;
                    //+
                    DepItems.Description := SpecialSelect.Description;
                    DepItems."Unit Price" := SpecialSelect."Unit Price";

                    //DepItems."Item Category Code" := 'INTEGRATION';
                    //DepItems."FTT-CST Parent Category Code" := 'INTEGRATION';
                    DepItems."Item Category Code" := SalesReceivablesSetup."FTT-CST Integration Category";
                    DepItems."FTT-CST Parent Category Code" := SalesReceivablesSetup."FTT-CST Integration Category";
                    DepItems.Optional := SpecialSelect.Optional;
                    DepItems."Sales Document No." := Rec."Sales Document No.";
                    DepItems."FTT-CST Integration" := true;
                    DepItems."FTT-CST RED/DR PriceCalc %" := SpecialSelect."Recalculation %";
                    DepItems."Integr." := SpecialSelect."Integr."; //NRD
                    DepItems.Level := 11;
                    DepItems.Insert();

                    Rec."FTT-CST Integration Desc." := Format(Item."FTT-CST Integr PriceCalc %") + '%';
                    Rec."FTT-CST Integration Dec." := Item."FTT-CST Integr PriceCalc %";

                end else begin
                    DepItems."FTT-CST RED/DR PriceCalc %" := SpecialSelect."Recalculation %";
                    Rec."FTT-CST Integration Desc." := FORMAT(SpecialSelect."Recalculation %") + '%';
                    Rec."FTT-CST Integration Dec." := SpecialSelect."Recalculation %";
                    DepItems.Modify();
                end;
            until SpecialSelect.Next() = 0;


        DepItems.SetRange("Filter No.", Rec."Filter No.");
        DepItems.SetRange("Location Code", Rec."FTT-CST Location Code");
        //DepItems.SetRange("Item Category Code", 'INTEGRATION');
        DepItems.SetRange("Item Category Code", SalesReceivablesSetup."FTT-CST Integration Category");

        LicencesFiltersDesc := '';
        if DepItems.FindSet() then
            repeat
                if LicencesFiltersDesc = '' then begin
                    if DepItems."FTT-CST RED/DR PriceCalc %" > 0 then
                        LicencesFiltersDesc := DepItems.Description + '(' + Format(DepItems."FTT-CST RED/DR PriceCalc %") + '%)'
                    else
                        LicencesFiltersDesc := DepItems.Description
                end else
                    if DepItems."FTT-CST RED/DR PriceCalc %" > 0 then
                        LicencesFiltersDesc := LicencesFiltersDesc + '|' + DepItems.Description + '(' + Format(DepItems."FTT-CST RED/DR PriceCalc %") + '%)'
                    else
                        LicencesFiltersDesc := LicencesFiltersDesc + '|' + DepItems.Description;
            until DepItems.next = 0;

        Rec."FTT-CST Integration Desc." := LicencesFiltersDesc;
        Rec.Modify();
        IntegrationVisible := true;
        HardwareVisible := true;
        CurrPage.Update();
    end;

    procedure UpdateDRLines(FilterNo: Integer; LocationCode: Code[20])
    var
        DepItems: record "FTT-CST Dependancy Item";
    begin
        DepItems.SetRange("Filter No.", FilterNo);
        DepItems.SetRange(DR, DepItems.DR::Yes);
        DepItems.SetRange("Location Code", LocationCode);
        if DepItems.Count = 0 then begin
            DepItems.Reset();
            DepItems.SetRange("Filter No.", FilterNo);

            if DepItems.FindSet() then
                repeat
                    if DepItems."FTT-CST Use for DR" then begin
                        DepItems.DR := DepItems.DR::Yes;
                        DepItems.Modify();
                    end;
                until
            DepItems.next = 0;
        end;
    end;

    procedure UpdateRedLines(FilterNo: Integer; LocationCode: Code[20])
    var
        DepItems: record "FTT-CST Dependancy Item";
    begin
        DepItems.SetRange("Filter No.", FilterNo);
        DepItems.SetRange(Redundancy, DepItems.Redundancy::Yes);
        DepItems.SetRange("Location Code", LocationCode);
        if DepItems.Count = 0 then begin
            DepItems.Reset();
            DepItems.SetRange("Filter No.", FilterNo);
            DepItems.SetRange("Sales Document No.", Rec."Sales Document No.");

            if DepItems.FindSet() then
                repeat
                    if DepItems."FTT-CST Use for Red" then begin
                        DepItems.Redundancy := DepItems.Redundancy::Yes;
                        DepItems.Modify();
                    end;
                until
            DepItems.next = 0;
        end;


    end;

    procedure AddInternationalLine2()
    var
        ItemList: page "Item List";
        FTTItemList2: page "FTT-CST License List";
        FTTItemList: page "FTT-CST Item List";
        DependencyItem: Record Item;
        Item: record Item;
        LicencesFilters: text[1024];
        SpecailSelect2: Record "FTT-CST Licence Select";
        SpecailSelect: Record "FTT-CST Special Select";
        SalesReceivablesSetup: record "Sales & Receivables Setup";
        LicencesFiltersDesc: text[1024];

    begin
        SalesReceivablesSetup.GET();
        Item.SetFilter("Item Category Code", SalesReceivablesSetup."FTT-CST INTERNATIONAL Line");
        SpecailSelect.SetRange("Filter No.", Rec."Filter No.");
        SpecailSelect.DeleteAll();

        if Item.FindSet() then
            repeat
                SpecailSelect.Init;
                SpecailSelect."Item No." := Item."No.";
                SpecailSelect."Filter No." := Rec."Filter No.";
                SpecailSelect.Description := Item.Description;
                SpecailSelect."Comments Fluent" := Item."FTT-CST Comments Fluent";
                SpecailSelect."Customer Price Group" := Rec."Customer Price Group";
                SpecailSelect."Posting Date" := Rec."Posting Date";
                SpecailSelect."Currency Code" := Rec."Currency Code";
                SpecailSelect."Unit Price" := Item."Unit Price";
                SpecailSelect.Quantity := 0;
                SpecailSelect.Insert(true);
            until Item.Next = 0;
        Commit();
        SpecailSelect.SetRange("Filter No.", Rec."Filter No.");

        FTTItemList.LookupMode(true);
        FTTItemList.MakePriceVisible(true);
        FTTItemList.MakeRedDRVisible(false);
        FTTItemList.MakeSublocationVisible(false);
        FTTItemList.SetTableView(SpecailSelect);

        if FTTItemList.RunModal() = Action::LookupOK then begin
            AddIntegrationLine(LicencesFilters);
            CurrPage.Update();
        end else begin
            Rec."FTT-CST International Line" := false;
        end;
        CurrPage.Update();
        MakeBackupDependencyFilters(Rec, false)
    end;

    procedure AddIntegrationLine(var pFilter: text[1024])
    var
        DepItems: record "FTT-CST Dependancy Item";
        Item: Record Item;
        SalesReceivablesSetup: Record "Sales & Receivables Setup";
        SpecialSelect: Record "FTT-CST Special Select";
    begin
        pFilter := '';
        SalesReceivablesSetup.Get();
        SpecialSelect.SetRange("Filter No.", Rec."Filter No.");
        if SpecialSelect.FindSet() then
            repeat
                if SpecialSelect.Quantity > 0 then begin
                    DepItems.Init();
                    DepItems."Location Code" := LocationCode;
                    DepItems."FTT-CST Sublocation" := Rec."FTT-CST Sublocation";
                    DepItems."FTT-CST Component Option" := Rec."FTT-CST Component Option";
                    DepItems."Currency Code" := Rec."Currency Code";
                    DepItems."Filter No." := Rec."Filter No.";
                    DepItems."No." := SpecialSelect."Item No.";
                    DepItems."FTT-CST Quantity" := SpecialSelect.Quantity;
                    DepItems.Description := SpecialSelect.Description;
                    DepItems."Unit Price" := SpecialSelect."Unit Price";
                    DepItems."FTT-CST Comments" := SpecialSelect.Comments;
                    DepItems."FTT-CST Comments Fluent" := SpecialSelect."Comments Fluent";
                    DepItems.Optional := SpecialSelect.Optional;
                    DepItems.Redundancy := SpecialSelect.Redundancy;
                    DepItems.DR := SpecialSelect.DR;
                    DepItems."FTT-CST Use for DR" := true;
                    DepItems."FTT-CST Use For Red" := true;
                    DepItems."FTT-CST Parent Category Code" := SalesReceivablesSetup."FTT-CST INTERNATIONAL Line";
                    DepItems.Level := 15;
                    DepItems."FTT-CST Use for Discount" := false;
                    DepItems."Sales Document No." := Rec."Sales Document No.";
                    DepItems.Insert();

                    if pFilter = '' then
                        pFilter := SpecialSelect."Item No." else
                        pFilter := pFilter + '|' + SpecialSelect."Item No.";
                end;
            until SpecialSelect.next = 0;
    end;

    var
        SalesReceivables: record "Sales & Receivables Setup";
        "FTT-CST Salesp. Benef. Filter": Code[20];
        SalespersonPurchaserCodeGlobal: Code[20];
        "FTT-CST Total Amount (LCY)": Decimal;
        "FTT-CST Date Filter": Text;
        DependancyFilter: Text[1024];
        [InDataSet]
        PrimaryVisible: Boolean;
        [InDataSet]
        DRVisible: Boolean;
        [InDataSet]
        RedundencyVisible2: Boolean;
        [InDataSet]
        CrossConnect: boolean;
        [InDataSet]
        ConectivityVisible: Boolean;
        LondonLocation: Boolean;
        SINGAPORELocation: Boolean;
        NewYorkLocation: Boolean;
        TokyoLocation: Boolean;
        COPENHAGENLocation: Boolean;
        MALAYSIALocation: Boolean;
        LocationCode: code[20];
        PrevLocationCode: code[20];
        [InDataSet]
        AddCrossConnectVisible: Boolean;
        LocTypeHosted: Boolean;
        LocTypeNonHosted: Boolean;
        LocTypeUnknown: Boolean;
        [InDataSet]
        TypeSiteVisible: Boolean;
        RedundencyVisible: Boolean;
        IntegrationVisible: Boolean;
        HMVisible: Boolean;
        HardwareVisible: Boolean;
        CompLocVisible: boolean;
        ConnectivityVisible: Boolean;
        LocTypeVisible: Boolean;
        [InDataSet]
        ConfirmDocument: Boolean;
        ConfirmDocumentVisible: Boolean;
        ConVisible: Boolean;
        CHICAGOLocation: Boolean;
        SublocationVisible: Boolean;
        LicencesFiltersDesc: text[1024];

}