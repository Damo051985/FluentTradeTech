page 50008 "Gmail Inbound/Outbound"
{
    PageType = List;
    Caption = 'Email Thread History';
    ApplicationArea = All;
    UsageCategory = Lists;
    SourceTable = "GMAIL Email Relation";
    SourceTableTemporary = true;
    DeleteAllowed = false;
    InsertAllowed = false;
    ModifyAllowed = false;
    RefreshOnActivate = true;
    Permissions = tabledata "Sent Email" = r;

    layout
    {
        area(Content)
        {
            repeater(ListCombined)
            {
                field(Subject; Rec.Subject)
                {
                    ApplicationArea = All;
                    trigger OnDrillDown()
                    var
                        recGmailInboundOutbound: Record "Gmail Inbound/Outbound";
                        recSentEmail: Record "Sent Email";
                    begin
                        if rec."Email Type" = rec."Email Type"::Inbox then begin
                            if not recGmailInboundOutbound.Get(rec."Inbox Entry No.") then
                                exit;
                            OpenReceived(recGmailInboundOutbound);

                        end;

                    end;
                }
                field("ContactName"; gContName)
                {
                    ApplicationArea = all;
                    Caption = 'Contact';
                    Editable = False;
                }
                field("Created by User"; Rec."Created by User")
                {
                    ApplicationArea = all;
                }
                field("Date Created"; Rec."Date Created")
                {
                    ApplicationArea = all;
                }

                field("GMAIL Thread Count"; GmailThreadCount(rec."Thread ID"))
                {
                    ApplicationArea = all;
                    Caption = 'Thread Count';

                    trigger OnDrillDown()
                    begin
                        OpenReleated(rec."Thread ID");
                    end;
                }
                field("Estimated Sales Value (LCY)"; GmailThreadTotal(rec."Thread ID"))
                {
                    Caption = 'Estimated Sales Value';
                    ToolTip = 'Specifies the total of Estimated Sales Value';
                    //trigger OnDrillDown()
                    //begin
                    //OpenReleated2(rec."Thread ID");
                    //end;
                }

            }
        }
    }


    trigger OnOpenPage()
    var
        recGmailInbound: Record "GMAIL Email Relation";
        recGmailEmailRelation: Record "GMAIL Email Relation" temporary;
        UserSetup: Record "User Setup";
    begin
        if UserSetup.Get(UserId) then
            if not UserSetup."GMAIL Admin Access" then
                Error('Account %1 doesn''t have GMAIL Admin access!', UserId);
        recGmailEmailRelation.DeleteAll();
        recGmailInbound.Reset();
        if recGmailInbound.FindSet() then
            repeat
                if (recGmailInbound."Thread ID" <> '') AND (recGmailInbound."Email Type" IN [recGmailInbound."Email Type"::Inbox,
                     recGmailInbound."Email Type"::Sent]) then begin
                    recGmailEmailRelation.Reset();
                    recGmailEmailRelation.SetRange(recGmailEmailRelation."Thread ID", recGmailInbound."Thread ID");
                    if not recGmailEmailRelation.FindFirst() then begin
                        recGmailEmailRelation := recGmailInbound;
                        if recGmailEmailRelation.Insert() then begin
                            Commit();
                            rec := recGmailEmailRelation;
                            rec.Insert();
                        end;
                    end;
                end;
            until recGmailInbound.Next() = 0;


        // rec.FilterGroup(2);
        // rec.SetRange(Rec."Created by User", UserId);
        // rec.FilterGroup(0);

        Rec.SetCurrentKey("Date Created");
        Rec.Ascending(false);


    end;

    local procedure GmailThreadCount(pEMailthrreadID: Text[250]): Integer
    var
        recGmailReceived: Record "Gmail Inbound/Outbound";
    begin
        if pEMailthrreadID = '' then
            exit(0);

        recGmailReceived.Reset();
        recGmailReceived.SetRange("Thread ID", pEMailthrreadID);
        if recGmailReceived.FindSet() then
            exit(recGmailReceived.Count);
    end;

    local procedure GmailThreadTotal(pEMailthreadID: Text[250]): Decimal
    var
        pagGmailInboxList: Page "GMAIL Filter Emails";
        recGmailInboux: Record "Gmail Inbound/Outbound";
        FTTCSTEstimated: Record "FTT-CST Estimated Value Mod";
        lTotal: Decimal;
    begin
        Clear(pagGmailInboxList);
        lTotal := 0;
        recGmailInboux.Reset();
        recGmailInboux.SetAscending(EntryNo, FAlse);
        recGmailInboux.SetFilter("Thread ID", '%1', pEmailthreadID);
        if recGmailInboux.FindSET() then BEGIN
            Repeat
                recGmailInboux.CalcFields("Estimated Sales Value (LCY)");
                lTotal := recGmailInboux."Estimated Sales Value (LCY)";
            Until (recGmailInboux.Next = 0) OR (lTotal <> 0);
            Exit(lTotal);
        End;
    end;

    procedure OpenReceived(ReceivedEmail: Record "Gmail Inbound/Outbound")
    var
        EmailViewer: Page "Email Inbox Viewer";
    begin
        EmailViewer.SetRecord(ReceivedEmail);
        EmailViewer.Run();
    end;


    procedure OpenReleated(pEmailthreadID: text[250])
    var
        pagGmailInboxList: Page "GMAIL Filter Emails";
        recGmailInboux: Record "Gmail Inbound/Outbound";
    begin
        Clear(pagGmailInboxList);
        recGmailInboux.Reset();
        recGmailInboux.SetFilter("Thread ID", '%1', pEmailthreadID);
        if recGmailInboux.FindSet() then
            pagGmailInboxList.SetTableView(recGmailInboux);
        pagGmailInboxList.Run();
    end;

    procedure OpenRelated2(pEmailthreadID: text[250]): Decimal
    var
        pagGmailInboxList: Page "GMAIL Filter Emails";
        recGmailInboux: Record "Gmail Inbound/Outbound";
        FTTCSTEstimated: Record "FTT-CST Estimated Value Mod";
        FTTValueMod: Page "FTT-CST Estimated Value Mod";
    begin
        Clear(pagGmailInboxList);
        Clear(FTTValueMod);
        recGmailInboux.Reset();
        recGmailInboux.SetAscending(EntryNo, False);
        recGmailInboux.SetFilter("Thread ID", '%1', pEmailthreadID);
        if recGmailInboux.Findfirst() then BEGIN
            FTTCSTEstimated.RESET;
            FTTCSTEstimated.SetRange("Linked No.", recGmailInboux."GMAIL Inbox ID");
            FTTCSTEstimated.SetRange("Linked Source Table ID", 50001);
            IF FTTCSTEstimated.FINDSET then begin
                FTTValueMod.SetTableView(FTTCSTEstimated);
                FTTValueMod.RUN();
            END;
        End;
    end;

    Local procedure GetContactName(pint: Integer; pCode: Code[30])
    var
        lCust: Record Customer;
        lCont: Record Contact;
        lOpp: Record Opportunity;
    Begin
        gContName := '';
        case pInt of
            1:
                IF lOpp.GET(pCode) then
                    IF lCont.GET(lOpp."Contact No.") then
                        gContName := lCont.Name;
            2:
                IF lCust.GET(pCode) then
                    gContName := lCust.Name;
            3:
                IF lCont.GET(pCode) then
                    gContName := lCont.Name;
        END;
    End;

    trigger OnAfterGetRecord()
    var
    Begin
        GetContactName(Rec."Linked Document Type".AsInteger(), Rec."Linked Document No.");
    End;

    var
        gContName: Text[250];
}