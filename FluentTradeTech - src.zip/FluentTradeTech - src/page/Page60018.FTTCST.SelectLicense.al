page 60018 "FTT-CST License List"
{
    PageType = ListPlus;
    Editable = true;
    ApplicationArea = All;
    SourceTable = "FTT-CST Licence Select";
    Caption = 'License';

    layout
    {
        area(Content)
        {
            repeater(GroupName)
            {
                field(Name; Rec."Item No.")
                {
                    ApplicationArea = All;

                }
                field(Redundancy; Rec.Redundancy)
                {
                    ApplicationArea = all;
                }
                field(DR; Rec.DR)
                {
                    ApplicationArea = All;
                }
                field(Description; Rec.Description)
                {
                    ApplicationArea = All;

                }
                field("FTT-CST Quanity"; Rec."Quantity")
                {
                    trigger OnValidate()
                    begin
                    end;
                }
                field("Unit Price"; Rec."Unit Price")
                {
                    ApplicationArea = All;
                }
                field(Optional; Rec.Optional)
                {
                    Visible = true;
                    ApplicationArea = All;

                }
                field("Comments Fluent"; Rec."Comments Fluent")
                {
                    Visible = true;
                    ApplicationArea = all;
                }
                field(Comments; Rec.Comments)
                {
                    Visible = true;
                    ApplicationArea = All;

                }

            }
        }
    }

    actions
    {
        area(Processing)
        {
            action(ActionName)
            {
                ApplicationArea = All;

                trigger OnAction();
                begin

                end;
            }
        }
    }
    procedure GetSelectionFilter(): Text
    var
        Item: Record Item;
        SelectionFilterManagement: Codeunit SelectionFilterManagement;
    begin
        CurrPage.SetSelectionFilter(Item);
        exit(SelectionFilterManagement.GetSelectionFilterForItem(Item));
    end;

    trigger OnAfterGetRecord()
    begin
        //Rec."Quantity" := 0;
    end;
}