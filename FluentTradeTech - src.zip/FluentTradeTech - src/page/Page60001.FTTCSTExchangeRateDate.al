page 60001 "FTT-CST ExchangeRateDate"
{
    ApplicationArea = All;
    Caption = 'Exchange Rate';
    PageType = StandardDialog;

    layout
    {
        area(Content)
        {
            field("Exchange Rate Date"; ExchangeRateDate)
            {
                ApplicationArea = All;
            }
        }
    }

    trigger OnOpenPage()
    begin
        ExchangeRateDate := WorkDate();
    end;

    procedure GetExchangeRateDate(): Date
    begin
        if ExchangeRateDate = 0D then
            Error(ExchangeRateDateErr);
        exit(ExchangeRateDate);
    end;

    var
        ExchangeRateDate: Date;
        ExchangeRateDateErr: Label 'Exchange Rate Date can not be empty';
}
