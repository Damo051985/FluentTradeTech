page 50023 "FTT-CST CreateRenewals"
{
    ApplicationArea = All;
    Caption = 'Creation of Renewals';
    PageType = StandardDialog;

    layout
    {
        area(Content)
        {

            field("Main Order No."; OrderNo)
            {
                ApplicationArea = All;
                Caption = 'Main Order No.';
                Editable = false;
            }
            field("Previous Renewal Starting Date"; PrevStartingDate)
            {
                ApplicationArea = All;
                Caption = 'Previous Renewal Starting Date';
                Editable = false;
            }
            field("Previous Renewal Ending Date"; PrevEndingDate)
            {
                ApplicationArea = All;
                Editable = false;
                Caption = 'Previous Renewal Ending Date';
            }

            field("New Starting Date"; StartingDate)
            {
                ApplicationArea = All;
                Caption = 'New Renewal Starting Date';
            }
            field("New Ending Date"; EndingDate)
            {
                ApplicationArea = All;
                Caption = 'New Renewal Ending Date';
            }
            field(IncAdditions; IncAdditions)
            {
                ApplicationArea = All;
                Caption = 'Include all additions from this date range';
                ToolTip = 'all additions record covered by this date range will be added in lines';
            }
        }
    }

    trigger OnQueryClosePage(CloseAction: Action): Boolean
    begin
        if CloseAction = Action::OK then begin
            if StartingDate = 0D then
                Error(StartingDateEmptyErr);
        end;
    end;

    trigger OnOpenPage()
    begin
        StartingDate := CalcDate('1Y', PrevStartingDate);
        EndingDate := CalcDate('1Y', PrevEndingDate);
    end;

    procedure GetDate2(): Date
    begin
        exit(StartingDate);
    end;

    procedure GetDate3(): Date
    begin
        if EndingDate = 0D then
            exit(0D);

        exit(EndingDate);
    end;

    procedure GetInc(): Boolean
    begin
        exit(IncAdditions);
    end;

    procedure SetDate1(pDate1: Date)
    begin
        PrevStartingDate := pDate1;

    end;

    procedure SetDate2(pDate2: Date)
    begin
        PrevEndingDate := pDate2;
    end;

    procedure SetOrderNo(pOrderCode: code[50])
    begin
        OrderNo := pOrderCode;
    end;

    var
        StartingDate: Date;
        EndingDate: Date;
        PrevStartingDate: Date;
        PrevEndingDate: Date;
        IncAdditions: Boolean;
        OrderNo: code[50];
        StartingDateEmptyErr: Label 'Date can not be empty';
}
