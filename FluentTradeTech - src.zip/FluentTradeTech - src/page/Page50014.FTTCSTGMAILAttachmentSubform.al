page 50014 "GMAIL Attachment Listpart"
{
    Caption = 'GMAIL Attachment';
    PageType = ListPart;
    ApplicationArea = All;
    SourceTable = "GMAIL Attachment";
    RefreshOnActivate = true;
    DeleteAllowed = false;

    layout
    {
        area(Content)
        {
            repeater(Group)
            {
                field("File Name"; Rec."File Name")
                {
                    ApplicationArea = All;
                    trigger OnDrillDown()
                    var
                        TenantMedia: Record "Tenant Media";
                        InStreamPic: InStream;
                        FileName: Text;
                        recEmailAttachement: Record "GMAIL Attachment";
                    begin
                        recEmailAttachement.Reset();
                        recEmailAttachement.SetRange(EntryNo, rec.EntryNo);
                        if recEmailAttachement.FindFirst() then
                            if not recEmailAttachement.data.HasValue then
                                exit;

                        if TenantMedia.Get(recEmailAttachement.data.MediaId) then begin
                            TenantMedia.CalcFields(Content);
                            if TenantMedia.Content.HasValue then begin
                                FileName := rec."File Name";
                                TenantMedia.Content.CreateInStream(InStreamPic);
                                DownloadFromStream(InStreamPic, '', '', '', FileName);
                            end;
                        end;
                    end;
                }
                field("Mime Type"; Rec."Mime Type")
                {
                    ApplicationArea = all;
                }

            }
        }
    }
}