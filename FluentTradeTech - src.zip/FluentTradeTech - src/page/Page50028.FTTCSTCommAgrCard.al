page 50028 "FTT-CST Comm. Agreement Card"
{
    PageType = Card;
    ApplicationArea = All;
    SourceTable = "FTT-CST Comm. Agrm. Header";
    RefreshOnActivate = True;

    layout
    {
        area(Content)
        {
            group(General)
            {
                field("Agreement No."; Rec."Agreement No.")
                {
                    ApplicationArea = All;
                    Editable = false;

                }
                field("Document Date"; Rec."Document Date")
                {
                    ApplicationArea = all;
                    Enabled = IsEditableField;

                }
                field("Salesperson Type"; Rec."Salesperson Type")
                {
                    Caption = 'Type';
                    ApplicationArea = all;
                    Enabled = IsEditableField;

                    trigger OnValidate()
                    var
                        myInt: Integer;
                    begin
                        CurrPage.Update(false);
                    end;
                }

                field("Type No."; Rec."Type No.")
                {
                    ApplicationArea = all;
                    Enabled = IsEditableField;

                }
                field("Supervisor Code"; Rec."Supervisor Code")
                {
                    ApplicationArea = all;
                    Enabled = false;
                }
                field(Description; Rec.Description)
                {
                    ApplicationArea = all;
                    Enabled = IsEditableField;
                }
                field("Agr. Starting Date"; Rec."Agr. Starting Date")
                {
                    ApplicationArea = all;
                    Enabled = IsEditableField;
                    Caption = 'Starting Date';
                }
                field("Agr. Ending Date"; Rec."Agr. Ending Date")
                {
                    ApplicationArea = all;
                    Enabled = IsEditableField;
                    Caption = 'Ending Date';
                }
                field("Agreement Period"; Rec."Agreement Period")
                {
                    ApplicationArea = all;
                    Enabled = IsEditableField;
                    Visible = false;
                }
                field("Settlement Type"; Rec."Settlement Type")
                {
                    ApplicationArea = all;
                    Enabled = IsEditableField;
                }
                field("Payment Method Code"; Rec."Payment Method Code")
                {
                    ApplicationArea = all;
                    Enabled = IsEditableField;
                }
                field("PDC Bank Account No."; Rec."PDC Bank Account No.")
                {
                    ApplicationArea = all;
                    Caption = 'Bank Account No.';
                    Enabled = IsEditableField;

                }
                field(Status; Rec.Status)
                {
                    ApplicationArea = all;
                    Enabled = false;
                }
            }
            group(Lines)
            {

                part(AggrmentLines; "FTT-CST Comm. Agr. Subform")
                {
                    ApplicationArea = all;
                    UpdatePropagation = Both;
                    Enabled = IsEditableField;
                    SubPageLink = "Agreement No." = FIELD("Agreement No.");
                }
            }
        }
    }

    actions
    {
        area(Processing)
        {
            action("Re-Open")
            {
                ApplicationArea = All;
                Caption = 'Re-Open';
                Image = ReOpen;
                Promoted = true;
                PromotedIsBig = true;
                PromotedCategory = Process;
                trigger OnAction()
                begin
                    if rec.Status = rec.Status::"De-Activated" then begin
                        if not Confirm('Do you want to Re-Open this Commission Agreement?', false) then
                            exit;
                        rec.Status := rec.Status::Open;
                        rec.Modify();
                        IsEditableField := true;
                        CurrPage.Update(false);
                    end else
                        Error('Only Deactivated Agreement is allowed to Re-Open');
                end;
            }
            action("Activated")
            {
                ApplicationArea = All;
                Caption = 'Activate';
                Image = Default;
                Promoted = true;
                PromotedIsBig = true;
                PromotedCategory = Process;
                trigger OnAction()
                begin
                    if rec.Status = rec.Status::"Open" then begin
                        if not Confirm('Do you want to Activate this Commission Agreement?', false) then
                            exit;
                        rec.TestField("Payment Method Code");
                        rec.TestField("PDC Bank Account No.");
                        rec.Status := rec.Status::Activated;
                        rec.Modify();
                        IsEditableField := false;
                        CurrPage.Update(false);
                    end else
                        Error('Only Open Agreement is allowed to Activate');
                end;
            }
            action("Deactivated")
            {
                ApplicationArea = All;
                Caption = 'Deactivate';
                Image = Delete;
                Promoted = true;
                PromotedIsBig = true;
                PromotedCategory = Process;

                trigger OnAction()
                begin
                    if rec.Status = rec.Status::Activated then begin
                        if not Confirm('Do you want to Deactivate this Commission Agreement?', false) then
                            exit;
                        rec.Status := rec.Status::"De-Activated";
                        rec.Modify();
                        IsEditableField := false;
                        CurrPage.Update(false);
                    end else
                        Error('Only Activated Agreement is allowed to Deactivate');
                end;
            }

        }
    }

    trigger OnOpenPage()
    var
        myInt: Integer;
    begin
        if rec.Status = rec.Status::Open then
            IsEditableField := true
        else
            IsEditableField := false;
    end;

    var
        IsEditableField: Boolean;
}