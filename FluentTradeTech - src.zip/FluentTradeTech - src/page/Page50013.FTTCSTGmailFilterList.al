page 50013 "GMAIL Filter Emails"
{
    PageType = List;
    Caption = 'GMAIL Filter Emails';
    ApplicationArea = all;
    SourceTable = "Gmail Inbound/Outbound";
    Permissions = tabledata "Gmail Inbound/Outbound" = rimd;
    RefreshOnActivate = true;
    InsertAllowed = false;
    DeleteAllowed = false;
    ModifyAllowed = false;
    layout
    {
        area(Content)
        {
            repeater(ReceivedEmails)
            {

                field("Thread ID"; Rec."Thread ID")
                {
                    Visible = false;
                }
                field("Email Type"; Rec."Email Type")
                {
                    ApplicationArea = all;
                }

                field(Desc; Rec.Subject)
                {

                    ToolTip = 'Specifies a subject of the email that was received.';
                    Editable = false;
                    trigger OnDrillDown()
                    begin
                        Open(Rec);
                    end;
                }

                field(DateTimeSent; Rec."Date Received")
                {
                    Caption = 'Received/Sent';

                    ToolTip = 'Specifies the date and time the email was received.';
                    Editable = false;
                }

                field(SentFrom; rec."Sent From")
                {

                    Caption = 'Sent From';
                    ToolTip = 'Specifies the email address that this email was sent from.';
                    Editable = false;
                }
                field(SentTo; rec."Sent To")
                {

                    Caption = 'Sent To';
                    ToolTip = 'Specifies the email address that this email was sent to.';
                    Editable = false;

                }

            }
        }

    }
    actions
    {
        area(Navigation)
        {
            action(EmailRelation)
            {
                ApplicationArea = All;
                Caption = 'Email Relation';
                ToolTip = 'Specify the Email where it belongs.';
                Image = BusinessRelation;
                Promoted = true;
                PromotedCategory = Process;
                PromotedOnly = true;

                trigger OnAction()
                var
                    pagGmailInboxRelation: page "GMAIL Email Inbox Relation";
                    recGmailInbox: Record "GMAIL Email Relation";
                begin
                    Clear(pagGmailInboxRelation);
                    recGmailInbox.Reset();
                    recGmailInbox.SetRange("Email Type", recGmailInbox."Email Type"::Inbox);
                    recGmailInbox.SetFilter("Inbox Entry No.", '%1', rec.EntryNo);
                    recGmailInbox.SetRange("Thread ID", rec."Thread ID");

                    pagGmailInboxRelation.SetTableView(recGmailInbox);
                    pagGmailInboxRelation.Run();

                end;
            }


        }
    }

    trigger OnOpenPage()
    begin
        Rec.SetCurrentKey("Thread ID", "Date Received");
        Rec.Ascending(false);
    end;


    procedure Open(ReceivedEmail: Record "Gmail Inbound/Outbound")
    var
        EmailViewer: Page "Email Inbox Viewer";
    begin
        EmailViewer.SetRecord(ReceivedEmail);
        EmailViewer.Run();
    end;



    var

        ERROR001: Label 'Token has been expired already!';
}