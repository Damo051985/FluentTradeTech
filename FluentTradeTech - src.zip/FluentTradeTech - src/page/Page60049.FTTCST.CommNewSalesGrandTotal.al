page 60049 "Comm. New Sales Grand Total"
{
    ApplicationArea = All;
    Caption = 'Grand Total';
    PageType = ListPart;
    SourceTable = "Commision New Sales";
    SourceTableView = where("Type" = filter("Grand Total"));

    layout
    {
        area(Content)
        {
            repeater(General)
            {
                field("Invoice No."; Rec."Invoice No.")
                {
                    ToolTip = 'Specifies the value of the Invoice No. field.', Comment = '%';
                }
                field("Invoice Status"; Rec."Invoice Status")
                {
                    ToolTip = 'Specifies the value of the Invoice Status field.', Comment = '%';
                }
                field("Customer Code"; Rec."Customer Code")
                {
                    ToolTip = 'Specifies the value of the Customer Code field.', Comment = '%';
                }
                field("Customer Name"; Rec."Customer Name")
                {
                    ToolTip = 'Specifies the value of the Customer Name field.', Comment = '%';
                }
                field("Salesperson Code"; Rec."Salesperson Code")
                {
                    ToolTip = 'Specifies the value of the Salesperson Code field.', Comment = '%';
                }
                field("Salesperson Name"; Rec."Salesperson Name")
                {
                    ToolTip = 'Specifies the value of the Salesperson Name field.', Comment = '%';
                }
                field(GTotalFld50; Rec.GTotalFld50)
                {
                    ToolTip = 'Specifies the value of the Invoice Amount Currency field.', Comment = '%';
                }
                field(GTotalFld60; Rec.GTotalFld60)
                {
                    ToolTip = 'Specifies the value of the Invoice Amount LCY field.', Comment = '%';
                }
                field(GTotalFld70; Rec.GTotalFld70)
                {
                    ToolTip = 'Specifies the value of the Eligible Currency field.', Comment = '%';
                }
                field(GTotalFld80; Rec.GTotalFld80)
                {
                    ToolTip = 'Specifies the value of the Eligible LCY field.', Comment = '%';
                }
                field(GTotalFld90; Rec.GTotalFld90)
                {
                    ToolTip = 'Specifies the value of the Commision Currency field.', Comment = '%';
                }
                field(GTotalFld100; Rec.GTotalFld100)
                {
                    ToolTip = 'Specifies the value of the Commision LCY field.', Comment = '%';
                }
            }
        }
    }
}
