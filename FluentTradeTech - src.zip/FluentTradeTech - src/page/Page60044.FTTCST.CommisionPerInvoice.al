page 60044 "Commision Per Invoice"
{
    ApplicationArea = All;
    Caption = 'Commission Per Invoice';
    PageType = Card;
    UsageCategory = Lists;
    SourceTable = "Commision per Invoice";
    Editable = False;
    RefreshOnActivate = true;
    Permissions = TableData "Sales Invoice Header" = rm;

    layout
    {
        area(Content)
        {
            group(General)
            {
                Caption = 'General';

                field("Invoice No."; Rec."Invoice No.")
                {
                    ToolTip = 'Specifies the value of the Invoice No. field.', Comment = '%';
                    Visible = False;
                }
            }
            part("CommPerInvSub"; "Comm. Per Inv. Subform")
            {
                ApplicationArea = Basic, Suite;
            }
            part("CommPerInvGrand"; "Comm. Per Inv. Grand Total")
            {
                ApplicationArea = Basic, Suite;
            }
        }
    }
    actions
    {
        area(processing)
        {
            action(UpdateCommPerInv)
            {
                ApplicationArea = All;
                Caption = 'Update Commission Per Invoice';
                Visible = True;
                trigger OnAction()
                var
                    lCommRep: Codeunit "Commission Reports";
                begin
                    lCommRep.InsertInvoiceNo();
                end;
            }
            action(DeleteLines)
            {
                ApplicationArea = All;
                Caption = 'Delete Lines';
                Visible = False;
                trigger OnAction()
                var
                    lCommPerInv: Record "Commision Per Invoice";
                    lSIH: Record "Sales Invoice Header";
                begin
                    IF lCommPerInv.FINDSET then
                        lCommPerInv.DELETEALL;

                    IF lSIH.FINDSET then
                        lSIH.ModifyAll("Inserted in Report 2", FALSE);
                end;
            }
        }
    }
    Trigger OnOpenPage()
    var
        lCommRep: Codeunit "Commission Reports";
    Begin
        lCommRep.InsertInvoiceNo();
    End;

    var
        gVis: Boolean;
        UserSet: Record "User Setup";
}
