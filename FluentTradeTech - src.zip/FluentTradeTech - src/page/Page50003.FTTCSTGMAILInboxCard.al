
page 50003 "Email Inbox Viewer"
{
    PageType = Document;
    SourceTable = "Gmail Inbound/Outbound";
    Caption = 'Thread Email';
    Permissions = tabledata "Gmail Inbound/Outbound" = rimd;
    DataCaptionExpression = '';
    DeleteAllowed = false;
    InsertAllowed = false;
    ModifyAllowed = false;
    Extensible = true;

    layout
    {
        area(Content)
        {
            group("Email Details")
            {
                grid("Email Details Grid")
                {
                    group("Email Inner Details")
                    {
                        ShowCaption = false;

                        field(Account; rec."Sent From")
                        {
                            ShowMandatory = true;
                            ApplicationArea = All;
                            Caption = 'From';
                            ToolTip = 'Specifies the account from which the email was sent.';
                            Editable = false;
                        }

                        field(ToField; rec."Sent To")
                        {
                            ShowMandatory = true;
                            Caption = 'To';
                            ApplicationArea = All;
                            ToolTip = 'Specifies the email recipients.';
                            Editable = false;
                            Importance = Promoted;
                        }

                        field(CcField; rec.Recipients)
                        {
                            Caption = 'Cc';
                            ApplicationArea = All;
                            ToolTip = 'Specifies the email CC recipients.';
                            Editable = false;
                            Importance = Additional;
                        }

                        field(BccField; rec.BCC)
                        {
                            Caption = 'Bcc';
                            ApplicationArea = All;
                            ToolTip = 'Specifies the email BCC recipients.';
                            Editable = false;
                            Importance = Additional;
                        }

                        field(SubjectField; rec.Subject)
                        {
                            Caption = 'Subject';
                            ApplicationArea = All;
                            ToolTip = 'Specifies the subject of the sent email.';
                            Editable = false;
                            Importance = Promoted;
                        }
                    }
                }
            }

            group(HTMLFormattedBody)
            {
                ShowCaption = false;
                Caption = ' ';
                Visible = true;

                field("Email Editor"; EmailBody)
                {
                    Caption = 'Message';
                    ApplicationArea = All;
                    ToolTip = 'Specifies the content of the email.';
                    MultiLine = true;
                    ExtendedDatatype = RichContent;
                    Editable = false;
                }
            }

            // group(RawTextBody)
            // {
            //     ShowCaption = false;
            //     Caption = ' ';
            //     Visible = true;
            //     field("Email Editor"; EmailBody)
            //     {
            //         ApplicationArea = All;
            //         ShowCaption = false;
            //         Caption = 'Message';
            //         ToolTip = 'Specifies the content of the email.';
            //         MultiLine = true;
            //         Editable = false;
            //     }
            // }
            group(Attachment)
            {
                part(AttachmentLines; "GMAIL Attachment Listpart")
                {
                    ApplicationArea = Basic, Suite;
                    SubPageLink = "GMAIL Inbox ID" = FIELD("GMAIL Inbox ID");
                }
            }

        }
    }

    actions
    {


    }
    procedure GetBody() BodyText: Text
    var
        BodyInStream: InStream;
    begin
        rec.CalcFields("Message Content");

        Rec."Message Content".CreateInStream(BodyInStream, TextEncoding::UTF8);
        BodyInStream.Read(BodyText);
    end;

    trigger OnAfterGetRecord()
    begin

        EmailBody := Base64Convert.FromBase64(codGmailcustom.Base64URLtoBase64(GetBody()));

        if rec.Subject <> '' then
            CurrPage.Caption(rec.Subject)
        else
            CurrPage.Caption(PageCaptionTxt); // fallback to default caption

    end;

    trigger OnOpenPage()
    begin
        if Rec.EntryNo = 0 then
            exit;

        CurrPage.SetTableView(Rec);
    end;

    var
        EmailBody: Text;
        PageCaptionTxt: Label 'Received Email';

        Base64Convert: Codeunit "Base64 Convert";

        codGmailcustom: Codeunit "Gmail Integration";

}
