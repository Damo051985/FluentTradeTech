page 60004 "FTT-CST Commission Entries"
{
    ApplicationArea = All;
    Caption = 'Lines';
    DeleteAllowed = false;
    InsertAllowed = false;
    ModifyAllowed = false;
    PageType = ListPart;
    RefreshOnActivate = true;
    SourceTable = "FTT-CST Commision Entry";

    layout
    {
        area(Content)
        {
            repeater(Contents)
            {
                Editable = false;
                ShowCaption = false;
                field("Entry No."; Rec."Entry No.")
                {
                    Editable = false;
                    ToolTip = 'Specifies the number of the entry.';
                }
                field("Salesperson Code"; Rec."Salesperson Code")
                {
                    ToolTip = 'Specifies a salesperson code that initiated creation of commission entry.';
                }
                field("Commission Beneficiary Code"; Rec."Commission Beneficiary Code")
                {
                    ToolTip = 'Specifies a beneficiary salesperson code of commission entry.';
                }
                field("Posting Date"; Rec."Created Date")
                {
                    ToolTip = 'Specifies a date of commission entry.';
                }
                field("Commission Amount (LCY)"; Rec."Commission Amount (LCY)")
                {
                    ToolTip = 'Specifies an amount of commission entry.';
                }
            }
        }
    }

    procedure SetFilters(SalespBenef: Code[20]; DateFilter: Text) Amount: Decimal
    begin
        if SalespBenef <> '' then
            Rec.SetRange("Commission Beneficiary Code", SalespBenef)
        else
            Rec.SetRange("Commission Beneficiary Code");

        if DateFilter <> '' then
            Rec.SetFilter("Created Date", DateFilter)
        else
            Rec.SetRange("Created Date");

        Rec.CalcSums("Commission Amount (LCY)");
        Amount := Rec."Commission Amount (LCY)";
        if Rec.FindSet() then;
        CurrPage.Update(false);
    end;


}
