page 60023 "Revenue Report Subform"
{
    ApplicationArea = Basic, Suite;
    Caption = 'Over 50%';
    PageType = ListPart;
    SourceTable = "Revenue Report";
    SourceTableView = where("Line Type" = filter("Over 50 %"), Type = filter(<> "Total"));
    Editable = True;

    layout
    {
        area(Content)
        {
            repeater(General)
            {

                field("Type"; Rec."Type")
                {
                    ToolTip = 'Specifies the value of the Type field.';
                    StyleExpr = gStyle;
                    Editable = EditTF;
                }
                field("Salesperson Code"; Rec."Salesperson Code")
                {
                    ToolTip = 'Specifies the value of the Salesperson Code field.';
                    StyleExpr = gStyle;
                    Editable = EditTF;
                }
                field("Customer/Prospect"; Rec."Customer/Prospect")
                {
                    ToolTip = 'Specifies the value of the Customer/Prospect field.';
                    StyleExpr = gStyle;
                    Editable = EditTF;
                }
                field("ARR - Previous Contracts"; Rec."ARR - Previous Contracts")
                {
                    ToolTip = 'Specifies the value of the ARR - Previous Contracts field.';
                    StyleExpr = gStyle;
                    Editable = False;
                    DecimalPlaces = 0 : 2;
                    trigger OnDrillDown()
                    var
                        lSH: Record "Sales Header";
                        lSL: Record "Sales Line";
                        lSL2: Record "Sales Line";
                        lSLp: Page "Sales Lines";
                    Begin
                        IF (Rec."Document No." = '') OR (Rec."ARR - Previous Contracts" = 0) then
                            Exit;
                        CLEAR(lSL);
                        lSL.SetRange("Document Type", Rec."Document type");
                        lSL.Setfilter("Document No.", Rec."Document No.");
                        lSL.SetRange("FTT-CST Optional", lSL."FTT-CST Optional"::No);
                        lSL.SETFILTER("FTT-CST Cost Type", '<>%1', lSL."FTT-CST Cost Type"::NRC);
                        IF lSL.FindSet() THEN BEGIN
                            Clear(lSLp);
                            lSLp.SetTableView(lSL);
                            lSLp.RUN;
                        END;
                    End;
                }
                field("ARR - Additional Products"; Rec."ARR - Additional Products")
                {
                    ToolTip = 'Specifies the value of the ARR - Additional Products field.';
                    StyleExpr = gStyle;
                    Editable = False;
                    DecimalPlaces = 0 : 2;
                    trigger OnDrillDown()
                    var
                        lSH: Record "Sales Header";
                        lSL: Record "Sales Line";
                        lSL2: Record "Sales Line";
                        lSLp: Page "Sales Lines";
                    Begin
                        IF (Rec."DocNo.2" = '') OR (Rec."ARR - Additional Products" = 0) then
                            Exit;
                        CLEAR(lSL);
                        lSL.SetRange("Document Type", Rec."DocType2");
                        lSL.Setfilter("Document No.", Rec."DocNo.2");
                        lSL.SetRange("FTT-CST Optional", lSL."FTT-CST Optional"::No);
                        lSL.SETFILTER("FTT-CST Cost Type", '<>%1', lSL."FTT-CST Cost Type"::NRC);
                        IF lSL.FindSet() THEN BEGIN
                            Clear(lSLp);
                            lSLp.SetTableView(lSL);
                            lSLp.RUN;
                        END;
                    End;
                }
                field("ARR Contract in Progress"; Rec."ARR Contract in Progress")
                {
                    ToolTip = 'Specifies the value of the ARR Contract in Progress field.';
                    StyleExpr = gStyle;
                    Editable = False;
                    DecimalPlaces = 0 : 2;
                    trigger OnDrillDown()
                    var
                        lopp: Record Opportunity;
                        lOppPg: Page "Opportunity Card";
                        lSH: Record "Sales Header";
                        lSL: Record "Sales Line";
                        lSL2: Record "Sales Line";
                        lSLp: Page "Sales Lines";
                        lOppEntList: Page "Opportunity Entry List";
                        lOppEnt: Record "Opportunity Entry";
                    Begin
                        IF (Rec."DocNo.3" = '') OR (Rec."ARR Contract in Progress" = 0) then
                            Exit;
                        CLEAR(lSL);
                        lSL.SetRange("Document Type", Rec."DocType3");
                        lSL.Setfilter("Document No.", Rec."DocNo.3");
                        lSL.SetRange("FTT-CST Optional", lSL."FTT-CST Optional"::No);
                        lSL.SETFILTER("FTT-CST Cost Type", '<>%1', lSL."FTT-CST Cost Type"::NRC);
                        IF lSL.FindSet() THEN BEGIN
                            Clear(lSLp);
                            lSLp.SetTableView(lSL);
                            lSLp.RUN;
                        END else begin
                            Clear(lOppEntList);
                            Clear(lOppEnt);
                            lOppEnt.SETFILTER("Opportunity No.", Rec."DocNo.3");
                            IF lOppEnt.FINDSET then BEGIN
                                lOppEntList.SetTableView(lOppEnt);
                                lOppEntList.RUN;
                            End;
                        end;
                    End;
                }
                field("NRC Contract in Progress"; Rec."NRC Contract in Progress")
                {
                    ToolTip = 'Specifies the value of the NRC Contract in Progress field.';
                    StyleExpr = gStyle;
                    Editable = False;
                    DecimalPlaces = 0 : 2;
                    trigger OnDrillDown()
                    var
                        lopp: Record Opportunity;
                        lOppPg: Page "Opportunity Card";
                        lSH: Record "Sales Header";
                        lSL: Record "Sales Line";
                        lSL2: Record "Sales Line";
                        lSLp: Page "Sales Lines";
                        lOppEntList: Page "Opportunity Entry List";
                        lOppEnt: Record "Opportunity Entry";
                    Begin
                        IF (Rec."DocNo.4" = '') OR (Rec."NRC Contract in Progress" = 0) then
                            Exit;
                        CLEAR(lSL);
                        lSL.SetRange("Document Type", Rec."DocType4");
                        lSL.Setfilter("Document No.", Rec."DocNo.4");
                        lSL.SetRange("FTT-CST Optional", lSL."FTT-CST Optional"::No);
                        lSL.SETFILTER("FTT-CST Cost Type", '%1', lSL."FTT-CST Cost Type"::NRC);
                        IF lSL.FindSet() THEN BEGIN
                            Clear(lSLp);
                            lSLp.SetTableView(lSL);
                            lSLp.RUN;
                        END ELSE begin
                            Clear(lOppEntList);
                            Clear(lOppEnt);
                            lOppEnt.SETFILTER("Opportunity No.", Rec."DocNo.3");
                            IF lOppEnt.FINDSET then BEGIN
                                lOppEntList.SetTableView(lOppEnt);
                                lOppEntList.RUN;
                            End;
                        end;
                    End;
                }
                field("ARR Total Revenue"; Rec."ARR Total Revenue")
                {
                    ToolTip = 'Specifies the value of the ARR Total Revenue field.';
                    StyleExpr = 'Strong';
                    Editable = False;
                    DecimalPlaces = 0 : 2;
                }
                field("NRC Total Revenue"; Rec."NRC Total Revenue")
                {
                    ToolTip = 'Specifies the value of the NRC Total Revenue field.';
                    StyleExpr = 'Strong';
                    Editable = False;
                    DecimalPlaces = 0 : 2;
                }
                field(Connectivity; Rec.Connectivity)
                {
                    ToolTip = 'Specifies the value of the Connectivity field.';
                    StyleExpr = gStyle;
                    Editable = False;
                    DecimalPlaces = 0 : 2;
                }

                field(Distribution; Rec.Distribution)
                {
                    ToolTip = 'Specifies the value of the Distribution field.';
                    StyleExpr = gStyle;
                    Editable = False;
                    DecimalPlaces = 0 : 2;
                }
                field("Risk and Others"; Rec."Risk and Others")
                {
                    ToolTip = 'Specifies the value of the Risk and Others field.';
                    StyleExpr = gStyle;
                    Editable = False;
                    DecimalPlaces = 0 : 2;
                }
                field("Other YRC"; Rec."Other YRC")
                {
                    ToolTip = 'Specifies the value of the Other YRC field.';
                    StyleExpr = gStyle;
                    Editable = False;
                    DecimalPlaces = 0 : 2;
                }
                field("Line Type"; Rec."Line Type")
                {
                    ToolTip = 'Specifies the value of the Line Type field.';
                    Visible = False;
                    Editable = False;
                    StyleExpr = gStyle;
                }
                field("New Proj. Stage"; Rec."New Proj. Stage")
                {
                    ToolTip = 'Specifies the value of the New Project Stage field.';
                    StyleExpr = gStyle;
                    Editable = False;
                    Visible = False;
                }
                field("internal Comments"; Rec."Internal Comments")
                {
                    ToolTip = 'Specifies the value of the Internal Comments field.';
                    StyleExpr = gStyle;

                }
            }
        }
    }
    Local Procedure initializedFields()
    var
    Begin
    End;

    Trigger OnOpenPage()
    var
        lSL: Record "Sales Line";
        lRev: Record "Revenue Report";
    Begin
        EditTF := True;
        Clear(CustSubs);
        CustSubs.GETSOPrimaryHosted50percentPrimRen;
        lRev.INIT;
        lRev."Customer/Prospect" := 'Total for Over 50 %';
        lRev.Type := lRev.Type::Total;
        lRev."Line Type" := lRev."Line Type"::"Over 50 %";
        IF lRev.Insert THEN;
    End;

    trigger OnAfterGetRecord()
    var
    Begin
        IF Rec.Type = Rec.Type::Total then
            gStyle := 'Strong'
        Else
            gStyle := 'Standard';
    End;

    Trigger OnAfterGetCurrRecord()
    var
        lSL: Record "Sales Line";
    Begin
        IF (Rec.Type = Rec.Type::"Grand Total") or (Rec.Type = Rec.Type::"Total") then
            EditTF := False
        Else
            EditTF := True;

    End;

    trigger OnInsertRecord(BelowxRec: Boolean): Boolean
    var
    Begin
        IF (Rec.Type = Rec.Type::"Grand Total") or (Rec.Type = Rec.Type::"Total") THEN
            Error('Not allowed to insert type Total!');
    End;

    Trigger OnDeleteRecord(): Boolean
    var
    Begin
        IF (Rec.Type = Rec.Type::"Grand Total") or (Rec.Type = Rec.Type::"Total") THEN
            Error('Not allowed to delete Total!');
    End;

    var
        CustSubs: Codeunit FTTCSTCustomSubcriber;
        EditTF: Boolean;
        gStyle: Text[30];
}
