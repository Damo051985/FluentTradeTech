page 60002 "FTT-CST UpdateQtyForInvoice"
{
    ApplicationArea = All;
    Caption = 'Update Quantity For Invoice';
    PageType = StandardDialog;
    SourceTable = "Sales Header";

    layout
    {
        area(Content)
        {
            field("FTT-CST Inv. Starting Date"; InvoiceStartingDate)
            {
                ApplicationArea = All;
                Caption = 'Invoice Starting Date';
            }

            field("FTT-CST Inv. Ending Date"; InvoiceEndingDate)
            {
                ApplicationArea = All;
                Caption = 'Invoice Ending Date';
            }
        }
    }

    trigger OnQueryClosePage(CloseAction: Action): Boolean
    begin
        if CloseAction = Action::OK then begin
            if InvoiceStartingDate = 0D then
                Error(InvoiceStartingDateEmptyErr);

            if InvoiceEndingDate = 0D then
                Error(InvoiceEndingDateEmptyErr);

            if InvoiceStartingDate > InvoiceEndingDate then
                Error(InvoiceStartingDateErr);
        end;
    end;

    procedure GetInvoiceStartingDate(): Date
    begin
        exit(InvoiceStartingDate);
    end;

    procedure GetInvoiceEndingDate(): Date
    begin
        exit(InvoiceEndingDate);
    end;

    var
        InvoiceEndingDate: Date;
        InvoiceStartingDate: Date;
        InvoiceEndingDateEmptyErr: Label 'Invoice Ending Date can not be empty';
        InvoiceStartingDateEmptyErr: Label 'Invoice Starting Date can not be empty';
        InvoiceStartingDateErr: Label 'Invoice Starting Date should be less than or equal to Invoice Ending Date';
}
