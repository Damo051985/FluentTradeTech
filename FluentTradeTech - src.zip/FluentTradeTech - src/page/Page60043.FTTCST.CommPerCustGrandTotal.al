page 60043 "Comm. Per Cust. Grand Total"
{
    ApplicationArea = All;
    Caption = 'Grand Total';
    PageType = ListPart;
    SourceTable = "Commision Per Customer";
    SourceTableView = where("Type" = filter("Grand Total"));


    layout
    {
        area(Content)
        {
            repeater(General)
            {
                field("Customer Code"; Rec."Customer Code")
                {
                    ToolTip = 'Specifies the value of the Customer Code field.';
                }
                field("Customer Name"; Rec."Customer Name")
                {
                    ToolTip = 'Specifies the value of the Customer Name field.';
                }
                field("Salesperson Code"; Rec."Salesperson Code")
                {
                    ToolTip = 'Specifies the value of the Salesperson Code field.';
                }
                field("Salesperson Name"; Rec."Salesperson Name")
                {
                    ToolTip = 'Specifies the value of the Salesperson Name field.';
                }
                field(GTotalFld50; Rec.GTotalFld50)
                {
                    ToolTip = 'Specifies the value of the Invoice Amount Currency field.';
                }
                field(GTotalFld60; Rec.GTotalFld60)
                {
                    ToolTip = 'Specifies the value of the Invoice Amount LCY field.';
                }
                field(GTotalFld70; Rec.GTotalFld70)
                {
                    ToolTip = 'Specifies the value of the Eligible Currency field.';
                }
                field(GTotalFld80; Rec.GTotalFld80)
                {
                    ToolTip = 'Specifies the value of the Eligible LCY field.';
                }
                field(GTotalFld90; Rec.GTotalFld90)
                {
                    ToolTip = 'Specifies the value of the Commision Currency field.';
                }
                field(GTotalFld100; Rec.GTotalFld100)
                {
                    ToolTip = 'Specifies the value of the Commision LCY field.';
                }
            }
        }
    }
}
