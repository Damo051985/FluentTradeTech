page 60021 "FTT-CST Quote Statistics"
{
    ApplicationArea = All;
    Caption = 'Recurring Item Sales Lines';
    PageType = CardPart;
    SourceTable = "Sales Header";
    UsageCategory = None;

    layout
    {
        area(Content)
        {

            field("No. of Opportunities"; NoofOpportunities)
            {
                ApplicationArea = RelationshipMgmt;
                ToolTip = 'Specifies the number of open opportunities involving the contact. The field is not editable.';
                trigger OnDrillDown()
                var
                    OppotrunityEntry: Record "Opportunity Entry";
                    OpportunityEntries: Page "Opportunity Entries";
                    Oppotrunity: Record Opportunity;
                    OpportunityList: page "Opportunity List";
                    CompanyName: code[20];
                begin
                    if rec."Document Type" = rec."Document Type"::Quote then begin
                        Clear(OpportunityEntries);
                        OppotrunityEntry.SetRange("FTT-CST Sales Quote No.", Rec."No.");
                        OppotrunityEntry.SetRange(Active, true);
                        if OppotrunityEntry.FindSet() then begin
                            OpportunityEntries.SetTableView(OppotrunityEntry);
                            OpportunityEntries.RunModal()
                        end;
                    end else begin
                        Clear(OpportunityList);
                        Oppotrunity.SetRange("Sales Document Type", Oppotrunity."Sales Document Type"::Order);
                        Oppotrunity.SetRange("Sales Document No.", rec."No.");
                        if Oppotrunity.FindSet() then
                            OpportunityList.SetTableView(Oppotrunity);
                        OpportunityList.RunModal();
                    end;
                end;
            }
        }
    }
    actions
    {
        area(Processing)
        {
            action(AddNewOpportLinked)
            {
                ApplicationArea = All;
                Caption = 'Assign Opportunity';
                Image = Add;

                trigger OnAction()
                var
                    pagOpportunityLsit: page "Opportunity List";
                    recOpportunity: Record Opportunity;
                    recOpportunity2: Record Opportunity;
                    recOpportunityEntry: record "Opportunity Entry";
                    recContact: Record Contact;
                begin
                    clear(pagOpportunityLsit);
                    if not recContact.get(rec."Sell-to Contact No.") then
                        exit;

                    recOpportunity.Reset();
                    recOpportunity.SetRange("Contact Company No.", recContact."Company No.");
                    recOpportunity.SetFilter(Status, '<>%1', recOpportunity.Status::"Not Started");
                    recOpportunity.SetFilter("Sales Document No.", '=%1', '');
                    if recOpportunity.FindSet() then begin
                        Commit();
                        pagOpportunityLsit.LookupMode(true);
                        pagOpportunityLsit.SetTableView(recOpportunity);
                        if pagOpportunityLsit.RunModal() <> Action::LookupOK then
                            exit;

                        if not Confirm('Do you want to proceed on updating all selected Opportunity?', false) then
                            exit;

                        pagOpportunityLsit.SetSelectionFilter(recOpportunity2);
                        if recOpportunity2.FindSet() then
                            repeat
                                if rec."Document Type" = rec."Document Type"::Quote then
                                    recOpportunity2.Validate("Sales Document Type", recOpportunity2."Sales Document Type"::Quote)
                                else if rec."Document Type" = rec."Document Type"::Order then
                                    recOpportunity2.Validate("Sales Document Type", recOpportunity2."Sales Document Type"::Order);
                                Commit();
                                recOpportunity2."Sales Document No." := rec."No.";
                                recOpportunity2.Modify();

                                if rec."Document Type" = rec."Document Type"::Quote then begin
                                    recOpportunityEntry.Reset();
                                    recOpportunityEntry.SetRange("Opportunity No.", recOpportunity2."No.");
                                    if recOpportunityEntry.FindSet() then
                                        recOpportunityEntry.ModifyAll("FTT-CST Sales Quote No.", rec."No.");
                                end;
                            until recOpportunity2.Next() = 0;

                        Message('Successfully Added!');
                        CurrPage.Update();
                    end else
                        Error('No Record Found!');

                end;
            }
        }
    }
    trigger OnAfterGetRecord()
    var
        Oppotrunity: Record "Opportunity Entry";
        CompanyName: code[20];
        Opporunity2: Record Opportunity;
    begin
        UpdateOpportunity();
        if rec."Document Type" = rec."Document Type"::Quote then begin
            Oppotrunity.SetRange("FTT-CST Sales Quote No.", Rec."No.");
            Oppotrunity.SetRange(Active, true);

            NoofOpportunities := Oppotrunity.Count();
        end else if rec."Document Type" = rec."Document Type"::Order then begin
            Opporunity2.SetRange("Sales Document Type", Opporunity2."Sales Document Type"::Order);
            Opporunity2.SetRange("Sales Document No.", Rec."No.");

            NoofOpportunities := Opporunity2.Count();
        end;
    end;

    procedure UpdateOpportunity()
    var
        Opportunity: record "Opportunity Entry";
        Contact: Record Contact;
    begin
        if Opportunity.FindSet() then
            repeat
                if Contact.get(Opportunity."Contact Company No.") then begin
                    Opportunity."FTT-CST Company Name" := Contact."Company Name";
                    Opportunity.Modify();
                end;
            until Opportunity.next = 0;
    end;

    var
        [InDataSet]
        NoofOpportunities: Integer;
}
