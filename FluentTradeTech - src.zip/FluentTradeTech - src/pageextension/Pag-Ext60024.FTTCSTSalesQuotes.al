pageextension 60024 "FTT-CST SalesQuotes" extends "Sales Quotes"
{
    layout
    {
        modify("Your Reference")
        {
            ApplicationArea = all;
            Visible = true;
        }
        modify("Due Date")
        {
            Caption = 'RFP due date';
        }
        addafter("Due Date")
        {
            field("FTT-CST Agr. Starting Date"; Rec."FTT-CST Agr. Starting Date")
            {
                ApplicationArea = all;
            }
        }
        addafter(Status)
        {
            field("FTT-CST Final Quote"; Rec."FTT-CST Final Quote")
            {
                ApplicationArea = all;
            }

        }
        addafter("Sell-to Customer Name")
        {
            field(ContactName; GetContactName(rec."Sell-to Contact No."))
            {
                ApplicationArea = all;
                Visible = true;
                Caption = 'Contact Name';
            }
        }
    }

    actions
    {
        addafter(AttachAsPDF)
        {
            action("FTT-CST Create Pricing Prop")
            {
                ApplicationArea = All;
                Caption = 'Generate Pricing Proposition';
                Ellipsis = true;
                Image = PrintChecklistReport;
                ToolTip = 'Generate a printed template of pricing proposal';

                trigger OnAction()
                var
                    codGMAILIntegSpreed: Codeunit "GMAIL Integ.Spreadsheet";
                    OptionMenu: Label 'Generate to Excel,Generate to Word';
                    OptionConfirm: Label 'Choose one of the following options:';
                    Options: Text[50];
                    Selected: Integer;
                begin
                    Options := OptionMenu;
                    Selected := StrMenu(Options, 1, OptionConfirm);
                    case Selected of
                        1:
                            begin
                                codGMAILIntegSpreed.UpdateCRMTemplatefromSalesQuote(rec, false);
                            end;
                        2:
                            Error('Not Available as of this moment');
                    end;
                end;
            }
        }
        addafter(AttachAsPDF_Promoted)
        {
            actionref("FTT-CST Create Pricing Prop_Promoted"; "FTT-CST Create Pricing Prop")
            {
            }
        }
    }
    local procedure GetContactName(pCode: Code[20]): Text
    var
        lContact: Record Contact;
    begin
        if lContact.get(pCode) then
            exit(lContact.Name);

        exit('');
    end;

}
