pageextension 60003 "FTT-CST CustomerCard" extends "Customer Card"
{
    layout
    {
        modify(SalesHistSelltoFactBox)
        {
            Visible = false;
        }
        modify(CustomerStatisticsFactBox)
        {
            Visible = false;
        }
        modify(Control1905532107)
        {
            Visible = false;
        }
        addafter("Responsibility Center")
        {
            field(Prospect; Rec.Prospect)
            {
                ApplicationArea = all;
            }
        }
        addafter("Language Code")
        {
            field("FTT-CST Notif. Mail Gr. Code"; Rec."FTT-CST Notif. Mail Gr. Code")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies mailing group for the notification creation.';
            }

        }

        addfirst(factboxes)
        {
            part(MyPagePart; "FTT-CST Customer Statistics")
            {
                //ApplicationArea = All;
                Caption = 'Opportunities';
                ApplicationArea = RelationshipMgmt;
                SubPageLink = "No." = FIELD("No."),
                              "Date Filter" = FIELD("Date Filter");
            }
            part(GmailInboxPart; "GMAIL Inbox factbox")
            {
                //ApplicationArea = All;
                Caption = 'Emails';
                ApplicationArea = all;
                SubPageLink = "Linked Document No." = FIELD("No.");
                Visible = false;
            }
            // part(GmailSentPart; "GMAIL Sent factbox")
            // {
            //     //ApplicationArea = All;
            //     Caption = 'Outbound';
            //     ApplicationArea = all;
            //     SubPageLink = "Linked Document No." = FIELD("No.");
            // }
        }

        moveafter(General; Statistics)
        moveafter(Statistics; Payments)
        modify(Control149)
        {
            Visible = false;
        }
    }
    actions
    {
        modify(PriceLists)
        {
            PromotedIsBig = true;
            PromotedOnly = true;
            Promoted = true;
            PromotedCategory = Process;

        }
        modify(Email)
        {
            ApplicationArea = all;
            Visible = false;

        }
        addafter(WordTemplate)
        {
            action(Email2)
            {
                ApplicationArea = All;
                Caption = 'Send Email';
                Image = Email;
                ToolTip = 'Send an email to this customer.';
                trigger OnAction()
                var
                    TempEmailItem: Record "Email Item" temporary;
                    EmailScenario: Enum "Email Scenario";
                    userSetup: Record "User Setup";
                    SignatureCustom: Codeunit "Fluent Custom Subscriber";
                    isEmailSigInc: Boolean;
                    GmailMaintenanceSetup: Record "GMAIL Maintenance Setup";
                begin
                    if not GmailMaintenanceSetup.Get() then
                        exit;

                    isEmailSigInc := false;
                    if userSetup.Get(UserId) then begin
                        if userSetup."Email Signature Included" then begin
                            userSetup.TestField("Job Position");
                            userSetup.TestField("E-Mail");
                            userSetup.TestField("Phone No.");
                            // userSetup.TestField("CRM Email");
                            isEmailSigInc := true;
                        end
                    end else
                        Error('User Setup does not exist for this ID : %1', UserId);

                    TempEmailItem.AddSourceDocument(Database::Customer, Rec.SystemId);
                    TempEmailitem."Send to" := Rec."E-Mail";
                    if GmailMaintenanceSetup."Add to BCC as Default" then
                        TempEmailItem."Send CC" := GmailMaintenanceSetup."CRM Email";

                    if isEmailSigInc then
                        TempEmailItem.SetBodyText(SignatureCustom.GenerateSignatureEmailBodyReport(userSetup));

                    TempEmailItem.Send(false, EmailScenario::Default);
                end;
            }
        }
    }
    trigger OnOpenPage()
    begin
        AmountOnPostedInvoices2 := 100;
    end;

    var
        CustomerMgt: Codeunit "Customer Mgt.";
        CountOpportunity: Decimal;

        CustomerOpportunityMsg: Label 'Ongoing Opportunity (%1)', Comment = 'Ongoing Opportunity (4)';
        AmountOnPostedInvoices2: Integer;
        PostedInvoicesMsg: Label 'Ongoing Opportunity (%1)', Comment = 'Ongoing Opportunity (5)';

}
