pageextension 60028 "FTT-CST SalesPurchaserCard" extends "Salesperson/Purchaser Card"
{
    layout
    {
        addafter("Next Task Date")
        {
            field("Comm. Vendor No."; Rec."Comm. Vendor No.")
            {
                ApplicationArea = all;
            }
            field("User ID"; Rec."User ID")
            {
                ApplicationArea = all;
            }
        }
    }

    actions
    {

        addlast(processing)
        {
            action("FTT-CST Salesp. Comm. Rates")
            {
                ApplicationArea = All;
                Caption = 'Salesperson Commission Rates';
                Image = SalesTaxStatement;
                RunObject = page "FTT-CST Salesp. Comm. Rates";
                RunPageLink = "Salesperson Code" = field(Code);
                ToolTip = 'Set up commission rate per item category for salesperson.';
            }
            // action("FTT-CST Salesp. Comm. Entries")
            // {
            //     ApplicationArea = All;
            //     Caption = 'Commission Entries';
            //     Image = LedgerEntries;
            //     ToolTip = 'View the history of Sales commission that was calculated for the Salesperson.';

            //     trigger OnAction()
            //     var
            //         FTTCSTCommisionFilter: Page "FTT-CST Commision Filter";
            //     begin
            //         FTTCSTCommisionFilter.SetFilters(Rec.Code);
            //         FTTCSTCommisionFilter.RunModal();
            //     end;
            // }
            action("FTT-CST Salesp. Comm. Entries")
            {
                ApplicationArea = All;
                Caption = 'Commission Ledger Entries';
                Image = LedgerEntries;
                ToolTip = 'View the history of Sales commission that was calculated for the Salesperson.';

                trigger OnAction()
                var
                    recCommLedgerEntry: record "FTT-CST Commission Entries";
                    pagCommLedgerEntry: page "FTT-CST Commission Entries2";

                begin
                    Clear(pagCommLedgerEntry);
                    recCommLedgerEntry.Reset();
                    recCommLedgerEntry.SetFilter("Salesperson Code", rec.Code);
                    if recCommLedgerEntry.FindSet() then begin
                        pagCommLedgerEntry.SetTableView(recCommLedgerEntry);
                        pagCommLedgerEntry.run();
                    end else
                        Error('No Record Found!');
                end;
            }
        }
        addafter(Email_Promoted)
        {
            actionref("FTT-CST Salesp. Comm. Rates_Promoted"; "FTT-CST Salesp. Comm. Rates")
            {
            }
            actionref("FTT-CST Salesp. Comm. Entries_Promted"; "FTT-CST Salesp. Comm. Entries")
            {
            }

        }
    }

}
