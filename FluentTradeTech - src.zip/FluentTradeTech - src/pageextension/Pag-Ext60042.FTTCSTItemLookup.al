pageextension 60042 FTTCSTItemLookup extends "Item Lookup"
{
    layout
    {
        addafter("Description")
        {
            field("DefDim"; DefDimCode)
            {
                ApplicationArea = all;
                Caption = 'Item Group';
            }
        }
    }
    trigger OnAfterGetRecord()
    var
        lDefDim: Record "Default Dimension";
    Begin
        IF lDefDim.GET(27, Rec."No.", 'ITEM GROUP') then
            DefDimCode := lDefDim."Dimension Value Code";
    End;

    var
        DefDimCode: Code[50];

}
