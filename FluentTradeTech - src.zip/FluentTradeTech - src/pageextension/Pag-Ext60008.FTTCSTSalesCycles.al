pageextension 60008 "FTT-CST SalesCycles" extends "Sales Cycles"
{
    layout
    {
        addafter("Probability Calculation")
        {
            field("FTT-CST Default Mailing Group"; Rec."FTT-CST Default Mailing Group")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies that for this sales cycle stage e-mail notification.';
            }
        }
    }
}