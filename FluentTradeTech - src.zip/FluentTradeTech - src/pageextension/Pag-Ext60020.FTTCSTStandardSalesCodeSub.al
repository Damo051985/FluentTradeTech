pageextension 60020 "FTT-CST StandardSalesCodeSub" extends "Standard Sales Code Subform"
{
    layout
    {
        addafter("Amount Excl. VAT")
        {
            field("FTT-CST Lines Calc. Type"; Rec."FTT-CST Lines Calc. Type")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies the price calculation type for the standard sales line.';
            }

            field("FTT-CST Price Percentage, %"; Rec."FTT-CST Price Percentage, %")
            {
                ApplicationArea = All;
                Editable = Rec."FTT-CST Lines Calc. Type" = "FTT-CST UnitPriceCalcType"::Calculated;
                ToolTip = 'Specifies the percentage for price calculation for the standard sales line.';
            }
        }
    }
}