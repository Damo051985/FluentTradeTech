pageextension 60035 "FTT-CST ItemCategories" extends "Item Categories"
{
    layout
    {
        addafter(Description)
        {
            field("FTT-CST Redundancy Base Item"; Rec."FTT-CST Redundancy Base Item")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies that the pricing for redundancy items will be determined by the price of items within this category.';
            }
            field("FTT-CST DR Base Item"; Rec."FTT-CST DR Base Item")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies that the pricing for dr items will be determined by the price of items within this category.';
            }
            field("FTT-CST  Integration Base Item"; Rec."FTT-CST  Integration Base Item")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies that the pricing for Integration items will be determined by the price of items within this category.';
            }

        }
    }
    actions
    {
        addafter(Recalculate)
        {
            action(ExportItemCategory)
            {
                Caption = 'Export Item Category';
                Promoted = true;
                PromotedCategory = Process;
                Image = Export;
                ApplicationArea = All;

                trigger OnAction()
                var
                    ItemCategory: record "Item Category";
                    ExportItemCategory: XmlPort "FTT-CST Export ItemCategory";
                begin
                    ExportItemCategory.SetTableView(ItemCategory);
                    ExportItemCategory.Run();
                end;
            }
            action(ImportItemCategory)
            {
                Caption = 'Import Item Category';
                Promoted = true;
                PromotedCategory = Process;
                Image = Export;
                ApplicationArea = All;

                trigger OnAction()
                var
                    ItemCategory: record "Item Category";
                    ImportItemCategory: XmlPort "FTT-CST Import ItemCategory";
                begin
                    ItemCategory.DeleteAll();
                    CurrPage.SetSelectionFilter(ItemCategory);
                    ImportItemCategory.SetTableView(ItemCategory);
                    ImportItemCategory.Run();
                end;
            }
        }
    }
}
