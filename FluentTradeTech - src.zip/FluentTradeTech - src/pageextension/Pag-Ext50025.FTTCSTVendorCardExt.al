pageextension 50025 "FTT-CST Vendor Card" extends "Vendor Card"
{
    layout
    {
        addafter("Purchaser Code")
        {
            field("Vendor Commission"; Rec."Vendor Commission")
            {
                ApplicationArea = all;
            }
        }
    }
}