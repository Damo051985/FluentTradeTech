pageextension 60032 "FTT-CST BlanketSalesOrderSub" extends "Blanket Sales Order Subform"
{
    layout
    {
        addbefore(Quantity)
        {
            field("FTT-CST Cost Type"; Rec."FTT-CST Cost Type")
            {
                ApplicationArea = All;
                HideValue = Rec.Type <> "Sales Line Type"::Item;
                ToolTip = 'Specifies a cost type of the item.';
            }
        }
    }
}
