pageextension 50004 "Sales Resp. Center Ext" extends "Responsibility Center Card"
{
    layout
    {
        addafter("Location Code")
        {
            field("Sales Manager ID"; Rec."Sales Manager ID")
            {
                ApplicationArea = all;
            }
        }
    }

    actions
    {
        // Add changes to page actions here
    }

    var
        myInt: Integer;
}