pageextension 60007 "FTT-CST OpportunitySub" extends "Opportunity Subform"
{
    layout
    {
        //NRD - Fix Estimated Value based on the Currency 
        modify("Estimated Value (LCY)")
        {
            ApplicationArea = all;
            Caption = 'Estimated Value';
        }
        modify("Calcd. Current Value (LCY)")
        {
            ApplicationArea = all;
            Caption = 'Calcd. Current Value';
            Visible = False;
        }
        addbefore("Estimated Value (LCY)")
        {
            field("Estimated Value - Currency"; Rec."Estimated Value - Currency")
            {
                ApplicationArea = all;
                Editable = false;
            }
        }
        addafter("Estimated Value (LCY)")
        {
            field("FTT-CST Estimated Value (LCY)"; Rec."FTT-CST Estimated Value (LCY)")
            {
                ApplicationArea = all;
                Visible = False;
            }

        }
        addafter("Calcd. Current Value (LCY)")
        {
            field("FTT Calcd. Current Value (LCY)"; Rec."FTT Calcd. Current Value (LCY)")
            {
                ApplicationArea = all;
                Visible = False;
            }
        }
        modify("Chances of Success %")
        {
            ApplicationArea = all;
            Visible = False;
        }
    }
    //+
    actions
    {
        addfirst(Processing)
        {
            action("FTT-CST Create Stage Notif.")
            {
                ApplicationArea = All;
                Caption = 'Create Stage Notification';
                Image = Email;
                ToolTip = 'Create a notification for the specific stage step.';

                trigger OnAction()
                var
                    OpportunityEntry: Record "Opportunity Entry";
                    SalesCycleStageNotificationMgt: Codeunit "FTT-CST Sal Cycle St Notif Mgt";
                    ErrorMsg: Label 'Notification can be created only for one %1 record at the same time.';
                begin
                    CurrPage.SetSelectionFilter(OpportunityEntry);
                    if OpportunityEntry.Count > 1 then
                        Error(StrSubstNo(ErrorMsg, Rec.TableCaption));
                    if SalesCycleStageNotificationMgt.EmailSalesCycleStageNotification(Rec) then
                        Message('Notification has been created');
                end;
            }
            action("SalesCycle")
            {
                ApplicationArea = All;
                Caption = 'Sales Cycle Stages';
                Image = Stages;
                ToolTip = 'Open Sales Cycle Stages page.';

                trigger OnAction()
                var
                    lOpp: Record "Opportunity";
                    lSC: Record "Sales Cycle";
                    lSCS: Record "Sales Cycle Stage";
                    lSCSPage: Page "Sales Cycle Stages";
                Begin
                    IF lOpp.GET(Rec."Opportunity No.") THEN
                        IF lSC.GET(lOpp."Sales Cycle Code") THEN begin
                            Clear(lSCS);
                            lSCS.SetRange("Sales Cycle Code", lSC.Code);
                            IF lSCS.FINDSET THEN begin
                                Clear(lSCSPage);
                                lSCSPage.SetTableView(lSCS);
                                lSCSPage.RUN;
                            end;
                        end;
                End;
            }
        }
    }
    //NRD - Fix Estimated Value based on the Currency 
    trigger OnInsertRecord(BelowxRec: Boolean): Boolean
    var
        Contact_l: Record Contact;
        Currency_l: Record Currency;
        CurrencyExchangeRate_l: Record "Currency Exchange Rate";
        CurrExcValue: Decimal;
    begin

        if not Contact_l.get(rec."Contact No.") then
            exit;

        if Contact_l."Currency Code" = '' then begin
            Rec."FTT-CST Estimated Value (LCY)" := Rec."Estimated Value (LCY)";
            Rec."FTT Calcd. Current Value (LCY)" := Rec."Calcd. Current Value (LCY)";
            rec."FTT Updated" := true;
            rec."Estimated Value - Currency" := Contact_l."Currency Code";
            Rec.Modify();
        end else begin
            if not Currency_l.get(Contact_l."Currency Code") then
                exit;


            CurrencyExchangeRate_l.Reset();
            CurrencyExchangeRate_l.SetRange("Currency Code", Currency_l.Code);
            if CurrencyExchangeRate_l.FindLast() then
                CurrExcValue := CurrencyExchangeRate_l."Exchange Rate Amount";

            Rec."FTT-CST Estimated Value (LCY)" := Rec."Estimated Value (LCY)" * CurrExcValue;
            Rec."FTT Calcd. Current Value (LCY)" := Rec."Calcd. Current Value (LCY)" * CurrExcValue;
            rec."FTT Updated" := true;
            rec."Estimated Value - Currency" := Contact_l."Currency Code";
            Rec.Modify();
        end;
    end;

    trigger OnAfterGetRecord()
    var
        Contact_l: Record Contact;
        Currency_l: Record Currency;
        CurrencyExchangeRate_l: Record "Currency Exchange Rate";
        CurrExcValue: Decimal;
    begin

        if not Contact_l.get(rec."Contact No.") then
            exit;

        if Contact_l."Currency Code" = '' then begin
            if Rec."FTT Updated" = false then begin
                Rec."FTT-CST Estimated Value (LCY)" := Rec."Estimated Value (LCY)";
                Rec."FTT Calcd. Current Value (LCY)" := Rec."Calcd. Current Value (LCY)";
                rec."FTT Updated" := true;
                rec."Estimated Value - Currency" := Contact_l."Currency Code";
                Rec.Modify();
            end;
        end else begin
            if Rec."FTT Updated" = false then begin
                if not Currency_l.get(Contact_l."Currency Code") then
                    exit;


                CurrencyExchangeRate_l.Reset();
                CurrencyExchangeRate_l.SetRange("Currency Code", Currency_l.Code);
                if CurrencyExchangeRate_l.FindLast() then
                    CurrExcValue := CurrencyExchangeRate_l."Exchange Rate Amount";

                Rec."FTT-CST Estimated Value (LCY)" := Rec."Estimated Value (LCY)" * CurrExcValue;
                Rec."FTT Calcd. Current Value (LCY)" := Rec."Calcd. Current Value (LCY)" * CurrExcValue;
                rec."FTT Updated" := true;
                rec."Estimated Value - Currency" := Contact_l."Currency Code";
                Rec.Modify();
            end;
        end;
    end;
    //+


}