pageextension 60018 "FTT-CST SalesReceivablesSetup" extends "Sales & Receivables Setup"
{
    layout
    {
        addafter("Disable Search by Name")
        {
            field("MSA Control in SO Posting"; Rec."MSA Control in SO Posting")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies whether to control an attached MSA document before sales order posting.';
            }
            field("FTT-CST Redundancy Category"; Rec."FTT-CST Redundancy Category")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies the item category that includes the redundancy items.';
            }
            field("FTT-CST DR Category"; Rec."FTT-CST DR Category")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies the item category that includes the dr items.';
            }
            field("FTT-CST Integration Category"; Rec."FTT-CST Integration Category")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies the item category that includes the Integration items.';
            }
            field("FTT-CST Parent CROSS CONNECT"; Rec."FTT-CST Parent CROSS CONNECT")
            {
                ApplicationArea = all;
            }
            field("FTT-CST Shared MRC CC Category"; Rec."FTT-CST Shared MRC CC Category")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies the item category that includes the Shared MRC Cross Connect items.';

            }
            field("FTT-CST Ded. MRC CC Category"; Rec."FTT-CST Ded. MRC CC Category")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies the item category that includes the Dedicated MRC Cross Connect items.';

            }
            field("FTT-CST Shared NRC CC Category"; Rec."FTT-CST Shared NRC CC Category")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies the item category that includes the Shared NRC Cross Connect items.';

            }
            field("FTT-CST Ded. NRC CC Category"; Rec."FTT-CST Ded. NRC CC Category")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies the item category that includes the Dedicated MRC Cross Connect items.';

            }
            field("FTT-CST HARDWARE"; Rec."FTT-CST HARDWARE")
            {
                ApplicationArea = all;
            }
            field("FTT-CST Hosting and management"; Rec."FTT-CST Hosting and management")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies the item category that includes the Hosting and Management items.';
            }
            field("FTT-CST Servers Set Up"; Rec."FTT-CST Servers Set Up")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies the item category that includes the Servers Set Up items.';
            }
            field("FTT-CST LICENSE"; Rec."FTT-CST LICENSE")
            {
                ApplicationArea = all;
            }
            field("FTT-CST Parent FEED"; Rec."FTT-CST Parent FEED")
            {
                ApplicationArea = all;
            }
            field("FTT-CST STANDARD MAKER FEED"; Rec."FTT-CST STANDARD MAKER FEED")
            {
                ApplicationArea = all;
            }
            field("FTT-CST NS MAKER FEED"; Rec."FTT-CST NS MAKER FEED")
            {
                ApplicationArea = all;
            }
            field("FTT-CST STANDARD TAKER FEED"; Rec."FTT-CST STANDARD TAKER FEED")
            {
                ApplicationArea = all;
            }
            field("FTT-CST NS TAKER FEED"; Rec."FTT-CST NS TAKER FEED")
            {
                ApplicationArea = all;
            }
            field("FTT-CST INTERNATIONAL LIne"; Rec."FTT-CST INTERNATIONAL Line")
            {
                ApplicationArea = all;
            }

        }
        addafter("Salesperson Dimension Code")
        {
            field("FTT-CST Item Region Dim. Code"; Rec."FTT-CST Item Region Dim. Code")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies the dimension code for item regions in the price proposal document.';
            }
        }
    }
}
