pageextension 50023 "P. Sales Inv List Ext." extends "Posted Sales Invoices"
{
    layout
    {
        addafter("Remaining Amount")
        {
            field("Total Comm. Base Amt. (LCY)"; Rec."Total Comm. Base Amt. (LCY)")
            {
                ApplicationArea = all;
            }
            field("Total Comm. Base Amt"; Rec."Total Comm. Base Amt")
            {
                ApplicationArea = all;
            }
        }
    }

    actions
    {
        // Add changes to page actions here
    }

    var
        myInt: Integer;
}