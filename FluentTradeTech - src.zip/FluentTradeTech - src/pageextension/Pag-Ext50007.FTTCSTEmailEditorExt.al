pageextension 50007 "Email Editor Ext." extends "Email Editor"
{

    layout
    {
        // Add changes to page layout here
    }

    actions
    {
        modify(Send)
        {

            trigger OnBeforeAction()
            var
                EmailAccount: Record "Email Account";
                UserSetup: Record "User Setup";

            begin
                EmailAccount.DeleteAll();
                CodEmailAccount.GetAllAccounts(EmailAccount);

                if not UserSetup.Get(UserId) then
                    exit;
                UserSetup.TestField("E-Mail");

                EmailAccount.Reset();
                EmailAccount.SetRange("Email Address", UserSetup."E-Mail");
                if EmailAccount.FindFirst() then begin
                    if EmailAccount."Account Id" <> CodFLuetCustomsub.ReadInternalFieldInEmailOutbox(Rec.Id) then
                        Error('Incorrect Email Address in From! \ This should be %1.', EmailAccount."Email Address");
                end else
                    Error('Email Address %1 does not exist in Email Account Record.', EmailAccount."Email Address");
            end;
        }
    }


    var
        CodFLuetCustomsub: Codeunit "Fluent Custom Subscriber";
        CodEmailAccount: Codeunit "Email Account";
}