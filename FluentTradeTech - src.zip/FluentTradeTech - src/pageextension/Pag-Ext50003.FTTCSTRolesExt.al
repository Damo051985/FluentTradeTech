pageextension 50003 RolesExt extends Roles
{
    trigger OnOpenPage()
    var
        UserPermissions: Codeunit "User Permissions";
    begin
        if not UserPermissions.IsSuper(UserSecurityId()) then
            Error('Only super user can open Roles!');
    end;
}