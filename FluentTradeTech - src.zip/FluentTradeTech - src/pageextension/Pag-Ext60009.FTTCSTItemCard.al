pageextension 60009 "FTT-CST ItemCard" extends "Item Card"
{
    layout
    {
        addafter("Base Unit of Measure")
        {
            field("FTT-CST Cost Type"; Rec."FTT-CST Cost Type")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies a cost type of the item.';
            }
            field("FTT-CST Salesp. Comm. Type"; Rec."FTT-CST Salesp. Comm. Type")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies the commission type of salesperson for specific item.';
            }
            field("FTT-CST Redundancy PriceCalc %"; Rec."FTT-CST Redundancy PriceCalc %")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies the percentage for price calculation for the redundancy items.';
                Visible = false;
            }
            field("FTT-CST Red. Backup PCalc %"; Rec."FTT-CST Red. Backup PCalc %")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies the percentage for price calculation for the redundancy items.';
            }

            field("FTT-CST Type of Site"; Rec."FTT-CST Type of Site")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies the Type of Site for items.';
            }

            field("FTT-CST Integr PriceCalc %"; Rec."FTT-CST Integr PriceCalc %")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies the percentage for price calculation for the redundancy items.';
                Visible = false;

            }
            field("FTT-CST Backup Integr. Calc %"; rec."FTT-CST Backup Integr. Calc %")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies the percentage for price calculation for the redundancy items.';

            }
            field("FTT-CST Comments Fluent"; Rec."FTT-CST Comments Fluent")
            {
                ApplicationArea = All;
            }
            field("FTT-CST Shared CC NOT Allowed"; Rec."FTT-CST Shared CC NOT Allowed")
            {
                ApplicationArea = all;
            }
            //NRD
            field("SDP Items"; Rec."SDP Items")
            {
                ApplicationArea = all;
            }
            //>>dan 081524
            field("FTT License type"; Rec."FTT License Type")
            {
                ApplicationArea = all;
            }

            //<<dan 081524
            //NRD
            field("FTT-CST Eligible"; Rec."FTT-CST Eligible")
            {
                ApplicationArea = all;
            }
            field("FTT-CST Coeffficient"; Rec."FTT-CST Coeffficient")
            {
                ApplicationArea = all;
            }

            //+
        }
        Modify("Base Unit of Measure")
        {
            Visible = False;
        }
        Modify("Sales Unit of Measure")
        {
            Visible = False;
        }

    }

    actions
    {
        addlast(Sales)
        {
            action("FTT-CST Recurring Sales Lines")
            {
                ApplicationArea = All;
                Caption = 'Recurring Sales Line';
                Image = ItemWorksheet;
                RunObject = page "FTT-CST Stn. Item Sales Codes";
                RunPageLink = "Item No." = field("No.");
                ToolTip = 'Set up recurring sales lines for the item that can quickly be inserted on a sales document for the customer.';
            }
        }
    }
}
