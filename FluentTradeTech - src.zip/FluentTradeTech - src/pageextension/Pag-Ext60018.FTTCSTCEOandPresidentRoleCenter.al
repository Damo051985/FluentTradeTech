pageextension 60037 "FTT-CST CEO and Pres RC" extends "CEO and President Role Center"
{
    layout
    {
        addfirst(Control1900724808)
        {
            part(Control1907692088; "FTT-CST Opportunity List")
            {
                ApplicationArea = Basic, Suite;
            }
            part("ActivitiesSales"; "O365 Activities")
            {
                AccessByPermission = TableData "Activities Cue" = I;
                ApplicationArea = Basic, Suite;
            }
            part(ApprovalsActivities; "Approvals Activities")
            {
                ApplicationArea = Suite;
            }
            //>>Dan 082824
            part(Control6; "Sales Pipeline Chart")
            {
                ApplicationArea = RelationshipMgmt;
            }
            part(Control11; "Relationship Performance")
            {
                ApplicationArea = RelationshipMgmt;
            }
            part(Control1; "Sales & Relationship Mgr. Act.")
            {
                ApplicationArea = RelationshipMgmt;
            }
            //<<Dan 082824
        }
    }


    actions
    {
        addafter(Budgets)
        {
            Group("All Reports")
            {
                //>>dan 092224
                action(RevReport)
                {
                    ApplicationArea = Basic, Suite;
                    Caption = 'Revenue in contract sizes report';
                    Image = "Document";
                    RunObject = page "Revenue Report";
                    ToolTip = 'Revenue in contract sizes report';
                }
                action(LostOpp)
                {
                    ApplicationArea = Basic, Suite;
                    Caption = 'Lost Opportunity report';
                    Image = "Document";
                    RunObject = page "LostOpportunity2";
                    ToolTip = 'Lost Opportunity report';
                }
                Group("Commission reports")
                {
                    action(CommPerCust)
                    {
                        ApplicationArea = Basic, Suite;
                        Caption = 'Commission Per Customer';
                        Image = "Document";
                        RunObject = page "Commision Per Customer";
                        ToolTip = 'Commission Per Customer';
                    }
                    action(CommPerInv)
                    {
                        ApplicationArea = Basic, Suite;
                        Caption = 'Commission Per Invoice';
                        Image = "Document";
                        RunObject = page "Commision Per Invoice";
                        ToolTip = 'Commission Per Invoice';
                    }
                    action(CommNewSales)
                    {
                        ApplicationArea = Basic, Suite;
                        Caption = 'Commission New Sales';
                        Image = "Document";
                        RunObject = page "Commision New Sales";
                        ToolTip = 'Commission New Sales';
                    }
                }
                Group("Customers evolution reports")
                {
                    /*
                    action("Upsell")
                    {
                        ApplicationArea = Basic, Suite;
                        Caption = 'Upsell History';
                        Image = "Document";
                        RunObject = page "FTT-CST Upsell";
                        ToolTip = 'Upsell History';
                    }
                    action("UpsellRep")
                    {
                        ApplicationArea = Basic, Suite;
                        Caption = 'Upsell Report';
                        Image = "Document";
                        RunObject = page "Upsell Report";
                        ToolTip = 'Upsell Report';
                    }
                    action(Cancellation)
                    {
                        ApplicationArea = Basic, Suite;
                        Caption = 'Cancelation History';
                        Image = "Document";
                        RunObject = page "FTT-CST Cancelation";
                        ToolTip = 'Cancelation History';
                    }
                    action(CancellationRep)
                    {
                        ApplicationArea = Basic, Suite;
                        Caption = 'Cancelation Report';
                        Image = "Document";
                        RunObject = page "CancelationReport";
                        ToolTip = 'Cancelation Report';
                    }
                    action(CustEvoHist)
                    {
                        ApplicationArea = Basic, Suite;
                        Caption = 'Customer Evolution History';
                        Image = "Document";
                        RunObject = page "Customer Evolution History";
                        ToolTip = 'Customer Evolution History';
                    }
                    action(CustEvoRep)
                    {
                        ApplicationArea = Basic, Suite;
                        Caption = 'Customer Evolution Report';
                        Image = "Document";
                        RunObject = page "Customer Evolution Report";
                        ToolTip = 'Customer Evolution Report';
                    }
                    */
                    /*
                    action(CustEvoReport)
                    {
                        ApplicationArea = Basic, Suite;
                        Caption = 'Customer Evolution Report';
                        Image = "Document";
                        RunObject = page "Customer Evolution Report";
                        ToolTip = 'Customer Evolution Report';
                    }
                    */
                }
            }
            /*
            Group("Documents")
            {
                //>>dan 092224
                action(SOWS)
                {
                    ApplicationArea = Basic, Suite;
                    Caption = 'SOWs';
                    Image = "Document";
                    RunObject = page "SOWs Lists";
                    ToolTip = 'Revenue in contract sizes report';
                }
                action(NDAS)
                {
                    ApplicationArea = Basic, Suite;
                    Caption = 'NDAs';
                    Image = "Document";
                    RunObject = page "NDA Lists";
                    ToolTip = 'Lost Opportunity report';
                }
            }
            */
            //<<dan 092224
            action(Opportunity)
            {
                ApplicationArea = Basic, Suite;
                Caption = 'Opportunities';
                Image = "List";
                RunObject = page "Opportunity List";
                ToolTip = 'View a list of your Opportunity.';
            }

            action("FTT-CST SOW")
            {
                ApplicationArea = Basic, Suite;
                Caption = 'Sales Documents';
                Ellipsis = true;
                Image = Attachments;
                RunObject = page "FTT-CST SOW Attachment";
            }

            action("FTT-CST Items")
            {
                ApplicationArea = Basic, Suite;
                Caption = 'Items';
                Ellipsis = true;
                Image = Item;
                RunObject = page "Item List";
            }
            action("FTT-CST CPG")
            {
                ApplicationArea = Basic, Suite;
                Ellipsis = true;
                Caption = 'Customer Price Groups';
                RunObject = page "Customer Price Groups";
                Image = Price;
            }
        }
        addafter(Customers)
        {
            action(GMAILInboundEmails)
            {
                ApplicationArea = All;
                Caption = 'Emails';
                RunObject = page "GMAIL Received Emails";
            }
            action(GMAILOutboundEmails)
            {
                ApplicationArea = All;
                Caption = 'Email Thread History';
                RunObject = page "Gmail Inbound/Outbound";
            }

        }
    }

}