pageextension 60041 FTTCSTFinanceMngrRC extends "Finance Manager Role Center"
{
    actions
    {
        addafter("Chart of Accounts")
        {
            Group("All Reports")
            {
                //>>dan 092224
                action(RevReport)
                {
                    ApplicationArea = Basic, Suite;
                    Caption = 'Revenue in contract sizes report';
                    Image = "Document";
                    RunObject = page "Revenue Report";
                    ToolTip = 'Revenue in contract sizes report';
                }
                action(LostOpp)
                {
                    ApplicationArea = Basic, Suite;
                    Caption = 'Lost Opportunity report';
                    Image = "Document";
                    RunObject = page "LostOpportunity2";
                    ToolTip = 'Lost Opportunity report';
                }
            }
        }
    }
}
