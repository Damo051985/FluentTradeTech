pageextension 60036 "FTT-CST ItemCategoryCard" extends "Item Category Card"
{
    layout
    {
        addafter("Parent Category")
        {

            field("FTT-CST Redundancy Base Item"; Rec."FTT-CST Redundancy Base Item")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies that the pricing for redundancy items will be determined by the price of items within this category.';
            }
            field("FTT-CST DR Base Item"; Rec."FTT-CST DR Base Item")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies that the pricing for dr items will be determined by the price of items within this category.';
            }
        }
    }
}