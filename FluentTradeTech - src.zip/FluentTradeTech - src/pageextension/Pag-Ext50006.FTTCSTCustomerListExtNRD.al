pageextension 50006 "Customer List Ext. NRD" extends "Customer List"
{
    layout
    {
        addafter(Contact)
        {
            field(Prospect; Rec.Prospect)
            {
                ApplicationArea = all;

            }
        }
    }
    actions
    {
        addlast(processing)
        {
            action(SyncronizeEmail)
            {
                ApplicationArea = All;
                Caption = 'Synchronize Gmail';
                Promoted = true;
                PromotedIsBig = true;
                PromotedOnly = true;
                PromotedCategory = Process;
                Image = UpdateXML;
                Visible = false;
                trigger OnAction()
                var
                    GmailIntegCdu: codeunit "Gmail Integration";
                    recUserSetup: Record "User Setup";
                begin
                    if not recUserSetup.Get(UserId) then
                        exit;

                    // if (CurrentDateTime > recUserSetup."Token Expiration DateTime") then
                    //     Error(ERROR001);

                    if not Confirm('Do you want to proceed on the GMAIL Synchronization?') then
                        exit;

                    // //  if GuiAllowed then
                    // GmailIntegCdu.ShowGMAILList(recUserSetup."E-Mail", recUserSetup."API Token Key", 1, false);
                    // Commit();

                    // GmailIntegCdu.ShowGMAILList(recUserSetup."E-Mail", recUserSetup."API Token Key", 2, false);
                    // Commit();

                    Message('GMAIL Inbound/Outbound has been succesfully updated!');
                end;
            }
        }

        modify(Email)
        {
            ApplicationArea = all;
            Visible = false;

        }
        addafter(WordTemplate)
        {
            action(Email2)
            {
                ApplicationArea = All;
                Caption = 'Send Email';
                Image = Email;
                ToolTip = 'Send an email to this customer.';
                trigger OnAction()
                var
                    TempEmailItem: Record "Email Item" temporary;
                    EmailScenario: Enum "Email Scenario";
                    userSetup: Record "User Setup";
                    SignatureCustom: Codeunit "Fluent Custom Subscriber";
                    isEmailSigInc: Boolean;
                    GmailMaintenanceSetup: Record "GMAIL Maintenance Setup";
                begin
                    if not GmailMaintenanceSetup.Get() then
                        exit;
                    isEmailSigInc := false;
                    if userSetup.Get(UserId) then begin
                        if userSetup."Email Signature Included" then begin
                            userSetup.TestField("Job Position");
                            userSetup.TestField("E-Mail");
                            userSetup.TestField("Phone No.");
                            isEmailSigInc := true;
                        end
                    end else
                        Error('User Setup does not exist for this ID : %1', UserId);

                    TempEmailItem.AddSourceDocument(Database::Customer, Rec.SystemId);
                    TempEmailitem."Send to" := Rec."E-Mail";
                    if GmailMaintenanceSetup."Add to BCC as Default" then
                        TempEmailItem."Send CC" := GmailMaintenanceSetup."CRM Email";
                    if isEmailSigInc then
                        TempEmailItem.SetBodyText(SignatureCustom.GenerateSignatureEmailBodyReport(userSetup));

                    TempEmailItem.Send(false, EmailScenario::Default);
                end;
            }
        }


    }


    trigger OnOpenPage()
    var
        recUserSetup: Record "User Setup";
    begin

        if not recUserSetup.Get(UserId) then
            exit;

        if not recUserSetup."Prospect Visibilty" then begin
            rec.FilterGroup(2);
            rec.SetRange(Prospect, false);
            rec.FilterGroup(0);
        end else
            rec.Reset();
    end;

    var

        ERROR001: Label 'Token has been expired already!';

}