pageextension 60000 "FTT-CST ContactCard" extends "Contact Card"
{
    layout
    {
        addafter("Company Name")
        {
            //NRD
            field("Prospect Type"; Rec."Prospect Type")
            {
                ApplicationArea = all;
                trigger OnValidate()
                begin
                    if rec.Type <> rec.Type::Company then
                        Error('Type must be Company!');
                end;
            }
            //+
            field("FTT-CST Subsidiary No."; Rec."FTT-CST Subsidiary No.")
            {
                ApplicationArea = All;
                Editable = Rec.Type = Rec.Type::Person;
                ToolTip = 'Specifies the number for the contact''s subsidiary company.';
            }
            field("FTT-CST Subsidiary Name"; Rec."FTT-CST Subsidiary Name")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies the name of the subsidiary company. If the contact is a person, Specifies the name of the subsidiary company for which this contact works. This field is not editable.';
            }
        }
        //>>Dan
        addafter("Search Name")
        {
            field("FTT-CST Role"; Rec."FTT-CST Role")
            {
                ApplicationArea = All;
                Tooltip = 'Specifies the role for this contact.';
                Visible = gVisible;
            }
        }
        //<<Dan
        addafter("Language Code")
        {
            field("FTT-CST Notif. Mail Gr. Code"; Rec."FTT-CST Notif. Mail Gr. Code")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies mailing group for the notification creation.';
            }
        }
        addafter("Company Name")
        {
            field("CompanyName"; CompName)
            {
                ApplicationArea = All;
                Caption = 'Company Name';
            }
            field("ComtactName"; ContName)
            {
                ApplicationArea = All;
                Caption = 'Name';
                Visible = False;
            }
        }
        addfirst(factboxes)
        {
            part("Attached Documents"; "Document Attachment Factbox")
            {
                ApplicationArea = All;
                Caption = 'Attachments';
                SubPageLink = "Table ID" = const(Database::Contact), "No." = field("No.");
            }
            part(MyPagePart; "FTT-CST Contact Statistics")
            {
                //ApplicationArea = All;
                Caption = 'Opportunities';
                ApplicationArea = RelationshipMgmt;
                SubPageLink = "No." = FIELD("No."),
                              "Date Filter" = FIELD("Date Filter");
            }

            part(GmailInboxPart; "GMAIL Inbox factbox")
            {
                //ApplicationArea = All;
                Caption = 'Emails';
                ApplicationArea = all;
                SubPageLink = "Linked Document No." = FIELD("No.");
            }


        }
        modify(Control31)
        {
            Visible = false;
        }
        modify(Control41)
        {
            Visible = false;
        }
        modify(ContactIntEntriesSubform)
        {
            Visible = false;
        }
    }
    actions
    {
        modify(PriceLists)
        {
            PromotedIsBig = true;
            PromotedOnly = true;
            Promoted = true;
            PromotedCategory = Process;

        }
        modify(Email)
        {
            ApplicationArea = all;
            Visible = false;

        }
        addafter(WordTemplate)
        {
            action(Email2)
            {
                ApplicationArea = All;
                Caption = 'Send Email';
                Image = Email;
                ToolTip = 'Send an email to this contact.';
                trigger OnAction()
                var
                    TempEmailItem: Record "Email Item" temporary;
                    EmailScenario: Enum "Email Scenario";
                    userSetup: Record "User Setup";
                    SignatureCustom: Codeunit "Fluent Custom Subscriber";
                    isEmailSigInc: Boolean;
                    GmailMaintenanceSetup: Record "GMAIL Maintenance Setup";
                begin
                    if not GmailMaintenanceSetup.get() then
                        exit;

                    isEmailSigInc := false;
                    if userSetup.Get(UserId) then begin
                        if userSetup."Email Signature Included" then begin
                            userSetup.TestField("Job Position");
                            userSetup.TestField("E-Mail");
                            userSetup.TestField("Phone No.");
                            isEmailSigInc := true;
                        end
                    end else
                        Error('User Setup does not exist for this ID : %1', UserId);

                    TempEmailItem.AddSourceDocument(Database::Contact, Rec.SystemId);
                    TempEmailitem."Send to" := Rec."E-Mail";
                    if GmailMaintenanceSetup."Add to BCC as Default" then
                        TempEmailItem."Send CC" := GmailMaintenanceSetup."CRM Email";

                    if isEmailSigInc then
                        TempEmailItem.SetBodyText(SignatureCustom.GenerateSignatureEmailBodyReport(userSetup));

                    TempEmailItem.Send(false, EmailScenario::Default);
                end;
            }
        }
    }
    //>>dan
    trigger OnOpenPage()
    var
        MySesSet: SessionSettings;
        ProfileID: Code[50];
    Begin
        gVisible := False;
        MySesSet.Init;
        ProfileID := MySesSet.ProfileId;
        IF (ProfileID = 'FTT_SALES_DIRECTOR') OR (ProfileID = 'FTT_SALES_MANAGER') then
            gVisible := TRUE;
        ContName := Rec.Name;
        CompName := Rec."Company Name";
    End;
    //<<dan
    Var
        gVisible: Boolean;
        CompName, ContName : Text[200];
}

