pageextension 50017 "Update Opport. Ext." extends "Update Opportunity"
{

    layout
    {
        modify("Estimated Value (LCY)")
        {
            Caption = 'Estimated Value';
            CaptionClass = 'Estimated Value';
            Enabled = false;
        }
        modify("Date of Change")
        {
            Visible = false;
        }
        modify("Cancel Old To Do")
        {
            Visible = false;
        }
        //>>Dan

        addafter("Estimated Close Date")
        {
            field(LastChancesPercent; LastChances)
            {
                Caption = 'Last Chances of Success (%)';
                Editable = False;
                ApplicationArea = All;
                DecimalPlaces = 0 : 0;
                Visible = False;
            }
            field(LastEstCloseDate; LastEstClose)
            {
                Caption = 'Last Estimated Closing Date';
                Editable = False;
                ApplicationArea = All;
                Visible = False;
            }
        }
        //<<dan

    }

    actions
    {
        addlast(processing)
        {
            action("Set the Estimated Value (LCY)")
            {
                ApplicationArea = All;
                Caption = 'Set the Estimated Sales Value';
                Image = UpdateUnitCost;
                Enabled = True;
                Promoted = true;
                PromotedCategory = Process;
                PromotedIsBig = true;
                trigger OnAction()
                var
                    pagUpdateEstMod: page "FTT-CST Estimated Value Mod";
                    recEstValueMod: Record "FTT-CST Estimated Value Mod";
                    recOpportEntry: Record "Opportunity Entry";
                begin

                    Clear(pagUpdateEstMod);
                    recEstValueMod.Reset();
                    recEstValueMod.SetRange("Entry No.");
                    recEstValueMod.SetRange("Linked No.", rec."Opportunity No.");
                    recEstValueMod.SetRange("Linked Source Table ID", 5092);

                    pagUpdateEstMod.SetTableView(recEstValueMod);
                    if pagUpdateEstMod.RunModal() = Action::Cancel then
                        exit;

                    rec."Estimated Value (LCY)" := pagUpdateEstMod.GetTotalAmt();

                end;
            }
            action("SalesCycle")
            {
                ApplicationArea = All;
                Caption = 'Sales Cycle Stages';
                Image = Stages;
                ToolTip = 'Open Sales Cycle Stages page.';
                Enabled = True;
                Promoted = true;
                PromotedCategory = Process;
                PromotedIsBig = true;

                trigger OnAction()
                var
                    lOpp: Record "Opportunity";
                    lSC: Record "Sales Cycle";
                    lSCS: Record "Sales Cycle Stage";
                    lSCSPage: Page "Sales Cycle Stages";
                Begin
                    IF lOpp.GET(Rec."Opportunity No.") THEN
                        IF lSC.GET(lOpp."Sales Cycle Code") THEN begin
                            Clear(lSCS);
                            lSCS.SetRange("Sales Cycle Code", lSC.Code);
                            IF lSCS.FINDSET THEN begin
                                Clear(lSCSPage);
                                lSCSPage.SetTableView(lSCS);
                                lSCSPage.RUN;
                            end;
                        end;
                End;
            }
        }
    }

    trigger OnAfterGetCurrRecord()
    var
        recSalesCyclestage: Record "Sales Cycle Stage";
        recEstValueMod: record "FTT-CST Estimated Value Mod";
        recOpportunityEntry: Record "Opportunity Entry";
    begin
        salesQuoteNo := '';

        if not recSalesCyclestage.Get(rec."Sales Cycle Code", rec."Sales Cycle Stage") then
            exit;

        recOpportunityEntry.Reset();
        recOpportunityEntry.SetRange("Opportunity No.", rec."Opportunity No.");
        recOpportunityEntry.SetFilter("FTT-CST Sales Quote No.", '<>%1', '');
        if recOpportunityEntry.FindFirst() then
            salesQuoteNo := recOpportunityEntry."FTT-CST Sales Quote No.";

        if not recSalesCyclestage."Required Estimated Value" then begin
            recEstValueMod.Reset();
            recEstValueMod.SetRange("Linked No.", rec."Opportunity No.");
            if recEstValueMod.IsEmpty then
                rec."Estimated Value (LCY)" := 0.1;
        end;
    end;

    trigger OnQueryClosePage(CloseAction: Action): Boolean
    var
        SalesQteHeader: Record "Sales Header";
        recCustomer: Record Customer;
        recContact: Record Contact;
        recEstVal, recEstVal2, recEstVal3, recEstVal4 : Record "FTT-CST Estimated Value Mod";
        lTempLoc: Record Location temporary;
        TempRecEstVal: Record "FTT-CST Estimated Value Mod" temporary;
        lEntryNo: Integer;
        lLinkNo: Code[50];
    begin
        lEntryNo := 1;
        lLinkNo := '';

        if CloseAction in [ACTION::OK, ACTION::LookupOK] then begin

            rec.CheckEstValue();
            if rec."Sales Cycle Stage" = 11 then begin
                if SalesQteHeader.Get(SalesQteHeader."Document Type"::Quote, salesQuoteNo) then begin
                    if recCustomer.get(SalesQteHeader."Sell-to Customer No.") then begin
                        recCustomer.Prospect := false;
                        recCustomer.Modify();
                    end;
                end;

                //NRD
                recContact.Reset();
                recContact.SetFilter(recContact."Contact Business Relation", '=%1', recContact."Contact Business Relation"::Customer);
                recContact.SetFilter(recContact.type, '%1|%2', recContact.type::Company, recContact.Type::Person);
                recContact.SetFilter(recContact."Company No.", '%1', rec."Contact Company No.");
                if recContact.FindSet() then
                    recContact.ModifyAll("FTT-CST ContBusinessRelation", recContact."FTT-CST ContBusinessRelation"::Customer);
                //+
            end;

            Clear(recEstVal);
            Clear(recEstVal2);
            Clear(recEstVal3);
            IF TempRecEstVal.IsTemporary then
                TempRecEstVal.DELETEALL;

            recEstVal.SetRange("Original Opportunity No.", Rec."Opportunity No.");
            recEstVal.SetRange("Linked Source Table ID", 50001);
            IF recEstVal.FINDSET THEN begin
                repeat
                    IF lLinkNo <> recEstVal."Linked No." THEN BEGIN
                        lEntryNo += 1;
                        TempRecEstVal.INIT;
                        TempRecEstVal."Entry No." := lEntryNo;
                        TempRecEstVal."Linked No." := recEstVal."Linked No.";
                        TempRecEstVal."Linked Source Table ID" := 50001;
                        IF TempRecEstVal.INSERT THEN;
                    END;
                    lLinkNo := recEstVal."Linked No.";
                until recEstVal.Next = 0;
            end;

            TempRecEstVal.RESET;
            Clear(TempRecEstVal);
            IF TempRecEstVal.FINDSET THEN begin
                Repeat
                    recEstVal2.SetRange("Linked No.", Rec."Opportunity No.");
                    recEstVal2.SetRange("Linked Source Table ID", 5092);
                    IF recEstVal2.FINDSET THEN begin
                        repeat
                            recEstVal3.SetRange("Original opportunity No.", recEstVal2."Linked No.");
                            recEstVal3.SetRange("Linked No.", TempRecEstVal."Linked No.");
                            recEstVal3.SetRange("Linked Source Table ID", 50001);
                            recEstVal3.SetRange("Item No.", recEstVal2."Item No.");
                            IF recEstVal3.FINDFIRST THEN begin
                                IF recEstVal3.Quantity <> recEstVal2.Quantity then begin
                                    recEstVal3.Quantity := recEstVal2.Quantity;
                                    recEstVal3.Modify;
                                end;
                                IF recEstVal3."Region Code" <> recEstVal2."Region Code" then begin
                                    recEstVal3."Region Code" := recEstVal2."Region Code";
                                    recEstVal3.Modify;
                                end;
                                IF recEstVal3."FTT-CST Sublocation" <> recEstVal2."FTT-CST Sublocation" then begin
                                    recEstVal3."FTT-CST Sublocation" := recEstVal2."FTT-CST Sublocation";
                                    recEstVal3.Modify;
                                end;
                                IF recEstVal3."Unit Price Excl. VAT" <> recEstVal2."Unit Price Excl. VAT" then begin
                                    recEstVal3."Unit Price Excl. VAT" := recEstVal2."Unit Price Excl. VAT";
                                    recEstVal3.Modify;
                                end;
                                IF recEstVal3."FTT-CST Comments" <> recEstVal2."FTT-CST Comments" then begin
                                    recEstVal3."FTT-CST Comments" := recEstVal2."FTT-CST Comments";
                                    recEstVal3.Modify;
                                end;
                                IF recEstVal3."DR/Redundancy/Integ PriceCalc%" <> recEstVal2."DR/Redundancy/Integ PriceCalc%" then begin
                                    recEstVal3."DR/Redundancy/Integ PriceCalc%" := recEstVal2."DR/Redundancy/Integ PriceCalc%";
                                    recEstVal3.Modify;
                                end;
                            end else begin
                                recEstVal4.RESET;
                                recEstVal4.INIT;
                                recEstVal4."Entry No." := GetLastEntryNo + 1;
                                recEstVal4."Linked No." := TempRecEstVal."Linked No.";
                                recEstVal4."Linked Source Table ID" := 50001;
                                recEstVal4."Item No." := recEstVal2."Item No.";
                                recEstVal4."Item Category Coede" := recEstVal2."Item Category Coede";
                                recEstVal4.Description := recEstVal2.Description;
                                recEstVal4."FTT-CST Sublocation" := recEstVal2."FTT-CST Sublocation";
                                RecEstVal4."FTT-CST Component Option" := recEstVal2."FTT-CST Component Option";
                                recEstVal4."Region Code" := recEstVal2."Region Code";
                                recEstVal4.Quantity := recEstVal2.Quantity;
                                recEstVal4."Line Amount Total" := recEstVal2."Line Amount Total";
                                recEstVal4."Unit Price Excl. VAT" := recEstVal2."Unit Price Excl. VAT";
                                recEstVal4."DR/Redundancy/Integ PriceCalc%" := recEstVal2."DR/Redundancy/Integ PriceCalc%";
                                IF recEstVal4.INSERT(TRUE) THEN;
                            end;
                        Until recEstVal2.Next = 0;
                    end;
                Until TempRecEstVal.Next = 0;
            end;

        end else
            rec.CheckEstValue2();

    end;

    Local Procedure GetLastEntryNo(): Integer;
    var
        lRecExtVal: Record "FTT-CST Estimated Value Mod";
    Begin
        IF lRecExtVal.FINDLAST then
            Exit(lRecExtVal."Entry No.");
    End;

    trigger OnOpenPage()
    var

    Begin
        GetLastOppEntry();
    End;

    local procedure GetLastOppEntry()
    var
        lOppEnt: Record "Opportunity Entry";
    Begin
        Clear(lOppEnt);
        lOppEnt.SetRange("Opportunity No.", Rec."Opportunity No.");
        lOppEnt.SETFILTER(Active, '%1', TRUE);
        IF lOppEnt.FINDFIRST THEN begin
            LastChances := lOppEnt."Chances of Success %";
            LastEstClose := lOppEnt."Estimated Close Date";
            Rec.VALIDATE("Chances of Success %", LastChances);
            Rec.VALIDATE("Estimated Close Date", LastEstClose);
            Rec.Modify;
        end;
    End;

    var
        salesQuoteNo: code[50];
        LastChances: decimal;
        LastEstClose: date;
}