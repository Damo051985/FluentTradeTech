pageextension 60023 "FTT-CST PostedSalesInvoice" extends "Posted Sales Invoice"
{
    layout
    {
        addafter("Due Date")
        {
            field("FTT-CST Agr. Starting Date"; Rec."FTT-CST Agr. Starting Date")
            {
                ApplicationArea = All;
                Editable = false;
                ToolTip = 'Specifies a starting date of the agreement.';
            }
            field("FTT-CST Agr. Ending Date"; Rec."FTT-CST Agr. Ending Date")
            {
                ApplicationArea = All;
                Editable = false;
                ToolTip = 'Specifies an ending date of the agreement.';
            }
            field("FTT-CST Agr. Period Number"; Rec."FTT-CST Agr. Period Number")
            {
                ApplicationArea = All;
                Editable = false;
                Visible = false;
                ToolTip = 'Specifies a number of  the agreement period for the document that was posted.';
            }
            field("Commission Computed"; Rec."Commission Computed")
            {
                ApplicationArea = all;
            }
        }
    }
}
