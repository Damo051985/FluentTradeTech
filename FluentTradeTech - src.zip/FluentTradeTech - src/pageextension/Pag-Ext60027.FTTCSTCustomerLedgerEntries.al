pageextension 60027 "FTT-CST CustomerLedgerEntries" extends "Customer Ledger Entries"
{
    layout
    {
        addafter("Sales (LCY)")
        {
            field("FTT-CST Comm. Base Am. (LCY)"; Rec."FTT-CST Comm. Base Am. (LCY)")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies the total commission base amount to the customer entry.';
            }
        }
    }
}
