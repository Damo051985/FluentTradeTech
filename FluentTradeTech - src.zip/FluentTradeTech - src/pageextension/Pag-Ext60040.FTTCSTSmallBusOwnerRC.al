pageextension 60040 "FTTCST-SmallBusOwnerRC" extends "Small Business Owner RC"
{
    actions
    {
        addafter(Finance)
        {
            Group("All Reports")
            {
                //>>dan 092224
                action(RevReport)
                {
                    ApplicationArea = Basic, Suite;
                    Caption = 'Revenue in contract sizes report';
                    Image = "Document";
                    RunObject = page "Revenue Report";
                    ToolTip = 'Revenue in contract sizes report';
                }
                action(LostOpp)
                {
                    ApplicationArea = Basic, Suite;
                    Caption = 'Lost Opportunity report';
                    Image = "Document";
                    RunObject = page "LostOpportunity2";
                    ToolTip = 'Lost Opportunity report';
                }
            }
        }
    }
    //<<dan 092224
}
