pageextension 60031 "FTTCST SalesCreditMemo" extends "Sales Credit Memo"
{
    layout
    {
        addafter("Applies-to ID")
        {
            field("FTT-CST Agr. Period Number"; Rec."FTT-CST Agr. Period Number")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies a number of the agreement period for this sales order.';
            }
            field("FTT-CST Agr. Starting Date; Rec."; Rec."FTT-CST Agr. Starting Date")
            {
                ApplicationArea = All;
                Caption = 'Agreement Starting Date';
                ToolTip = 'Specifies a number of the agreement starting date for this sales credit memo.';
                Trigger OnValidate()
                var
                    lSL: Record "Sales Line";
                    YearInt: Integer;
                Begin
                    if rec."FTT-CST Agr. Starting Date" <> 0D then
                        Rec.Validate("FTT-CST Contract Length", 1);
                    Rec.ValidateSinceGoLiveDate();
                    Rec.Modify();

                    Clear(lSL);
                    lSL.SetRange("Document Type", Rec."Document Type");
                    lSL.SetRange("Document No.", Rec."No.");
                    IF lSL.FindSet then begin
                        YearInt := Date2DMY(Rec."FTT-CST Agr. Starting Date", 3);
                        lSL.MODIFYALL(lSL."FTT-CST Year", YearInt);
                    end;
                End;
            }
            field("FTT-CST Agr. Ending Date; Rec."; Rec."FTT-CST Agr. Ending Date")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies a number of the agreement ending date for this sales credit memo.';
            }
        }
    }
    actions
    {
        addafter(GetPostedDocumentLinesToReverse)
        {
            action("FTT-CST Update Qty. for Agr")
            {
                ApplicationArea = All;
                Caption = 'Update Quantity'; //NRD
                //Caption = 'Update Quantity for Agreement';
                Ellipsis = true;
                Image = UpdateUnitCost;
                ToolTip = 'Update Quantity based on the Agreement period and Item Type';

                trigger OnAction()
                begin
                    Rec.UpdateQuantity3();
                end;
            }
        }
    }
}