pageextension 60026 "FTT-CST Teams" extends Teams
{
    layout
    {
        addafter(Name)
        {
            field("FTT-CST Supervisor Code"; Rec."FTT-CST Supervisor Code")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies a salesperson that is a supervisor for a group of salespersons.';

                trigger OnValidate()
                begin
                    if Rec."FTT-CST Supervisor Code" <> xRec."FTT-CST Supervisor Code" then
                        Rec."FTT-CST Supervisor Reward, %" := 0;
                end;
            }
            field("FTT-CST Supervisor Reward, %"; Rec."FTT-CST Supervisor Reward, %")
            {
                ApplicationArea = All;
                Editable = Rec."FTT-CST Supervisor Code" <> '';
                ToolTip = 'Specifies a supervisor reward for a group of salespersons.';
            }
        }
    }
    actions
    {
        addafter(Salespeople)
        {
            action("FTT-CST Salesp. Comm. Entries")
            {
                ApplicationArea = All;
                Caption = 'Supervisor Ledger Entries';
                Image = LedgerEntries;
                ToolTip = 'View the history of Sales commission that was calculated for the Salesperson.';

                trigger OnAction()
                var
                    recCommLedgerEntry: record "FTT-CST SV Ledger Entry";
                    pagCommLedgerEntry: page "FTT-CST Supervisor Entry";
                begin
                    Clear(pagCommLedgerEntry);
                    recCommLedgerEntry.Reset();
                    recCommLedgerEntry.SetFilter(recCommLedgerEntry."Supervisor Code", rec."FTT-CST Supervisor Code");
                    if recCommLedgerEntry.FindSet() then begin
                        pagCommLedgerEntry.SetTableView(recCommLedgerEntry);
                        pagCommLedgerEntry.RunModal();
                    end else
                        Error('No Record Found!');
                end;
            }
        }
        addafter(Salespeople_Promoted)
        {
            actionref("FTT-CST Salesp. Comm. Entries_Promted"; "FTT-CST Salesp. Comm. Entries")
            {
            }
        }
    }
}
