pageextension 60021 "FTT-CST SalesQuote" extends "Sales Quote"
{
    layout
    {

        modify("Salesperson Code")
        {
            //FTTNimrod - 
            Editable = isEnabledfield;

            trigger OnAfterValidate()
            var
                RecSalesRep: Record "Responsibility Center";
                RecUserSetup: Record "User Setup";
                RecSalesHeader: Record "Sales Header";
            begin
                CurrPage.SalesLines.Page.Update(false);
                CurrPage.Update(true);
                if not RecSalesHeader.get(rec."Document Type", rec."No.") then
                    exit;

                if RecUserSetup.Get(UserId) then
                    if RecUserSetup."Sales Resp. Ctr. Filter" = '' then begin
                        RecSalesRep.Reset();
                        RecSalesRep.SetRange(Code, rec."Salesperson Code");
                        RecSalesRep.SetFilter("Sales Manager ID", '<>%1', '');
                        if RecSalesRep.FindFirst() then begin
                            RecSalesHeader.Validate("Responsibility Center", RecSalesRep.Code);
                            RecSalesHeader.Modify();
                        end else begin
                            RecSalesHeader.Validate("Responsibility Center", '');
                            RecSalesHeader.Modify();
                        end;
                        Commit();

                        CurrPage.Update(false);
                    end;

            end;
            //+
        }
        modify("Foreign Trade")
        {
            Visible = false;
        }
        modify("Shipping and Billing")
        {
            Visible = false;
        }
        modify("Requested Delivery Date")
        {
            Visible = false;
        }
        modify("Due Date")
        {
            Caption = 'RFP due date';
            Editable = isEnabledfield;
        }
        modify("Document Date")
        {
            Visible = false;
        }
        modify(Status)
        {
            Visible = false;
        }
        moveafter("Salesperson Code"; "Currency Code")
        addbefore("Currency Code")
        {
            field("FTT-CST Final Quote"; Rec."FTT-CST Final Quote")
            {
                ApplicationArea = all;
                Visible = true;
                Caption = 'Final Quote';
                ToolTip = 'Specify the final Quotation for the customer';
                trigger OnValidate()
                var
                    UserSetup: Record "User Setup";
                begin
                    if not UserSetup.Get(UserId) then
                        exit;

                    if rec."FTT-CST Final Quote" then begin
                        if not Confirm('Do you want to set this as Final Quotation for this Customer %1?', false, rec."Sell-to Customer Name") then begin
                            rec."FTT-CST Final Quote" := false;
                            exit;
                        end else
                            isEnabledfield := false;

                    end else if not rec."FTT-CST Final Quote" AND UserSetup."Sales Quote Admin" then
                            isEnabledfield := true
                    else
                        Error('%1 does''nt have a permission to modify this field!', UserId);


                end;
            }

        }
        modify("Currency Code")
        {
            Editable = isEnabledfield;

        }
        addafter("Currency Code")
        {
            field("FTT-CST Text001"; Text001)
            {
                ApplicationArea = all;
                Importance = Promoted;
                Editable = isEnabledfield;

                MultiLine = TRUE;
                Width = 200;

                Caption = '';
                ShowCaption = false;
            }
        }
        addafter("Opportunity No.")
        {
            field("InCludeInCustEvoRep"; Rec."Include To Cust. Evolution")
            {
                ApplicationArea = all;
            }
        }
        addafter("Due Date")
        {
            field("FTT-CST Agr. Starting Date"; Rec."FTT-CST Agr. Starting Date")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies a starting date of the agreement.';
                Editable = isEnabledfield;
                trigger OnValidate()
                begin
                    if rec."FTT-CST Agr. Starting Date" <> 0D then
                        Rec.Validate("FTT-CST Contract Length", 1);
                    Rec.ValidateSinceGoLiveDate();
                    Rec.Modify();
                end;
            }
            field("FTT-CST Contract Length"; Rec."FTT-CST Contract Length")
            {
                ApplicationArea = All;
                Visible = false;
            }

            field("FTT-CST Agr. Ending Date"; Rec."FTT-CST Agr. Ending Date")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies an ending date of the agreement.';
                Visible = false;
            }
            field("FTT-CST Component Option"; Rec."FTT-CST Component Option")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies an ending date of the agreement.';
                Visible = false;
            }
            field("FTT-CST Region Code"; Rec."FTT-CST Region Code")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies an ending date of the';
                Caption = 'Location Code';
                Visible = false;
            }
        }
        modify("Sell-to Customer No.")
        {
            Editable = isEnabledfield;
            Visible = isProspect; //NRD

        }
        modify("Sell-to Customer Name")
        {
            Editable = isEnabledfield;
            Visible = isProspect; //NRD
        }
        modify("Sell-to Address")
        {
            Editable = isEnabledfield;
        }
        modify("Sell-to Address 2")
        {
            Editable = isEnabledfield;
        }
        modify("Sell-to City")
        {
            Editable = isEnabledfield;
        }
        modify("Sell-to Post Code")
        {
            Editable = isEnabledfield;
        }
        modify("Sell-to Country/Region Code")
        {
            Editable = isEnabledfield;
        }
        modify("Sell-to Contact No.")
        {
            Visible = false;
            //Editable = isEnabledfield;
        }

        modify("Order Date")
        {
            Editable = isEnabledfield;
        }
        modify("Your Reference")
        {
            Editable = isEnabledfield;
        }
        modify("Campaign No.")
        {
            Editable = isEnabledfield;
        }
        modify("Opportunity No.")
        {
            Editable = isEnabledfield;
        }
        modify("Responsibility Center")
        {
            Visible = false;
        }
        modify(SalesLines)
        {
            Enabled = isEnabledfield;
        }
        modify("Invoice Details")
        {
            Enabled = isEnabledfield;
        }

        addafter("Sell-to Contact No.")
        {
            field(ContactName; GetContactName(rec."Sell-to Contact No."))
            {
                ApplicationArea = all;
                Visible = true;
                Caption = 'Contact Name';
            }
        }
        addfirst(factboxes)
        {
            part(MyPagePart; "FTT-CST Customer Statistics")
            {
                ApplicationArea = All;
                Caption = 'Opportunities';
                Visible = false;
                SubPageLink = "No." = FIELD("Sell-to Customer No."),
                              "Date Filter" = FIELD("Date Filter");

            }
            part(MyPagePart2; "FTT-CST Quote Statistics")
            {
                ApplicationArea = All;
                Caption = 'Opportunities';
                SubPageLink = "No." = FIELD("No.");

            }
        }

    }
    actions
    {
        addafter(GetRecurringSalesLines)
        {
            action("FTT-CST Update Qty. for Agr")
            {
                ApplicationArea = All;
                Caption = 'Update Quantity'; //NRD
                //Caption = 'Update Item Quantity for Agreement';
                Ellipsis = true;
                Image = UpdateUnitCost;
                ToolTip = 'Update Quantity based on the Agreement period and Item Type';

                trigger OnAction()
                begin
                    Rec.UpdateQuantity();
                end;
            }


            action("FTT-CST ITEM CHAD")
            {
                ApplicationArea = All;
                Caption = 'ITEM DEPENDENCIES';
                Ellipsis = true;
                Visible = false;
                Image = ItemCosts;

                trigger OnAction()
                var
                    varFilterPageBuilder: FilterPageBuilder;
                    Item: Record Item;
                    ItemListPage: page "Item List";
                    SelectionFilterManagement: Codeunit SelectionFilterManagement;
                    //Dependancy: page "FTT-CST Dependancy Filter";
                    Dependancy: page "FTT-CST Dep Filter by Location";
                    DependencyRec: Record "FTT-CST Dependency Filters";
                    ItemFilters: text[1024];
                    DependencyItems: record "FTT-CST Dependancy Item";
                    DepFiltersCopy: record "FTT-CST Dep. Filters Copy";
                    DepUtility: Codeunit "FTT-CST Dependency Utility";

                begin
                    DepUtility.CheckDependencySetup();
                    DependencyRec.SetRange("Sales Document No.", Rec."No.");
                    DependencyRec.DeleteAll();
                    DepFiltersCopy.SetRange("Sales Document No.", Rec."No.");
                    DepFiltersCopy.DeleteAll();
                    DependencyItems.SetRange("Sales Document No.", rec."No.");
                    DependencyItems.DeleteAll();


                    DepFiltersCopy.DeleteAll;
                    if DependencyRec.FindSet() then
                        repeat
                            DependencyItems.SetRange("Filter No.", DependencyRec."Filter No.");
                            DependencyRec.DeleteAll();

                            DepFiltersCopy.SetRange("Sales Document No.", DependencyRec."Sales Document No.");
                            DepFiltersCopy.SetRange("Filter No.", DependencyRec."Filter No.");
                            DepFiltersCopy.DeleteAll();
                        until DependencyRec.next = 0;

                    if not DependencyRec.GET(Rec."No.", 1) then begin
                        DependencyRec.Init();
                        DependencyRec."Filter No." := 1;
                        DependencyRec."Sales Document No." := Rec."No.";
                        DependencyRec.Insert();
                        Commit();
                    end;

                    Dependancy.LookupMode(true);
                    Dependancy.SetTableView(DependencyRec);
                    if Dependancy.RunModal() = Action::LookupOK then begin
                        Dependancy.GetRecord(DependencyRec);

                        if DependencyRec."FTT-CST Conectivity" = DependencyRec."FTT-CST Conectivity"::Yes then
                            //if not DependencyRec."FTT-CST Cross Connect" then
                            //    error('Please add Cross-Connect accordingly');

                        if DependencyRec."FTT-CST Licences Filters" <> '' then
                                ItemFilters := DependencyRec."FTT-CST Licences Filters";

                        if DependencyRec."FTT-CST NON Standard maker" <> '' then
                            if ItemFilters <> '' then
                                ItemFilters := ItemFilters + '|' + DependencyRec."FTT-CST NON Standard maker"
                            else
                                ItemFilters := DependencyRec."FTT-CST NON Standard maker";

                        if DependencyRec."FTT-CST Standard maker feed" <> '' then
                            if ItemFilters <> '' then
                                ItemFilters := ItemFilters + '|' + DependencyRec."FTT-CST Standard maker feed"
                            else
                                ItemFilters := DependencyRec."FTT-CST Standard maker feed";

                        if DependencyRec."FTT-CST Standard taker feed" <> '' then
                            if ItemFilters <> '' then
                                ItemFilters := ItemFilters + '|' + DependencyRec."FTT-CST Standard taker feed"
                            else
                                ItemFilters := DependencyRec."FTT-CST Standard taker feed";

                        if DependencyRec."FTT-CST NON Standard taker" <> '' then
                            if ItemFilters <> '' then
                                ItemFilters := ItemFilters + '|' + DependencyRec."FTT-CST NON Standard taker"
                            else
                                ItemFilters := DependencyRec."FTT-CST NON Standard taker";

                        if DependencyRec."FTT-CST CPU" <> '' then
                            if ItemFilters <> '' then
                                ItemFilters := ItemFilters + '|' + DependencyRec."FTT-CST CPU"
                            else
                                ItemFilters := DependencyRec."FTT-CST CPU";

                        if DependencyRec."FTT-CST HARDWARE" <> '' then
                            if ItemFilters <> '' then
                                ItemFilters := ItemFilters + '|' + DependencyRec."FTT-CST HARDWARE"
                            else
                                ItemFilters := DependencyRec."FTT-CST HARDWARE";

                        DependencyItems.SetRange("Filter No.", DependencyRec."Filter No.");
                        DependencyItems.SetRange("Sales Document No.", DependencyRec."Sales Document No.");

                        if DependencyItems.FindSet() then
                            repeat
                                if ItemFilters <> '' then
                                    ItemFilters := ItemFilters + '|' + DependencyItems."No." else
                                    ItemFilters := DependencyItems."No.";
                            until DependencyItems.next = 0;

                        InitNewLines(Rec, ItemFilters, DependencyRec."Filter No.");
                        Commit();
                        //UpdateCrossConnectStatus(); //NRD
                        Rec.UpdateQuantity();

                    end;
                end;


            }

            action("FTT-CST ITEM CHAD2")
            {
                ApplicationArea = All;
                Caption = 'Item Dependencies';
                Ellipsis = true;
                Image = AddAction;

                trigger OnAction()
                var
                    varFilterPageBuilder: FilterPageBuilder;
                    Item: Record Item;
                    ItemListPage: page "Item List";
                    SelectionFilterManagement: Codeunit SelectionFilterManagement;
                    Dependancy: page "FTT-CST Smart Dep by Location";
                    SmartDependancy: page "FTT-CST Smart Dep by Location";
                    DependencyRec: Record "FTT-CST Dependency Filters";
                    ItemFilters: text[1024];
                    DependencyItems: record "FTT-CST Dependancy Item";
                    DepFiltersCopy: record "FTT-CST Dep. Filters Copy";
                    CrossConnectHdr: Record "FTT-CST Cross Connect Hdr";

                begin
                    Rec.TestField("FTT-CST Agr. Starting Date");
                    Rec.TestField("FTT-CST Contract Length");
                    DependencyRec.SetRange("Sales Document No.", Rec."No.");
                    DependencyRec.DeleteAll();
                    DepFiltersCopy.SetRange("Sales Document No.", Rec."No.");
                    DepFiltersCopy.DeleteAll();
                    DependencyItems.SetRange("Sales Document No.", Rec."No.");
                    DependencyItems.DeleteAll();

                    DepFiltersCopy.DeleteAll;
                    if DependencyRec.FindSet() then
                        repeat
                            DependencyItems.SetRange("Filter No.", DependencyRec."Filter No.");
                            DependencyItems.SetRange("Sales Document No.", rec."No.");
                            DependencyItems.DeleteAll(); //NRD - Fix 

                            DepFiltersCopy.SetRange("Sales Document No.", DependencyRec."Sales Document No.");
                            DepFiltersCopy.SetRange("Filter No.", DependencyRec."Filter No.");
                            DepFiltersCopy.DeleteAll();
                        until DependencyRec.next = 0;

                    if not DependencyRec.GET(Rec."No.", 1) then begin
                        DependencyRec.Init();
                        DependencyRec."Filter No." := 1;
                        DependencyRec."Sales Document No." := Rec."No.";
                        DependencyRec."Document Type" := rec."Document Type"; // NRD
                        DependencyRec."Sell-to Customer No." := Rec."Sell-to Customer No.";
                        DependencyRec."Currency Code" := Rec."Currency Code";
                        DependencyRec."Currency Factor" := Rec."Currency Factor";
                        DependencyRec."Customer Price Group" := Rec."Customer Price Group";
                        DependencyRec."Posting Date" := Rec."Order Date";
                        DependencyRec.Insert();
                        Commit();
                    end;

                    Dependancy.LookupMode(true);
                    Dependancy.SetTableView(DependencyRec);
                    if Dependancy.RunModal() = Action::LookupOK then begin
                        Dependancy.GetRecord(DependencyRec);
                        if DependencyRec."FTT-CST Conectivity" = DependencyRec."FTT-CST Conectivity"::Yes then
                            if DependencyRec."FTT-CST Licences Filters" <> '' then
                                ItemFilters := DependencyRec."FTT-CST Licences Filters";

                        if DependencyRec."FTT-CST NON Standard maker" <> '' then
                            if ItemFilters <> '' then
                                ItemFilters := ItemFilters + '|' + DependencyRec."FTT-CST NON Standard maker"
                            else
                                ItemFilters := DependencyRec."FTT-CST NON Standard maker";

                        if DependencyRec."FTT-CST Standard maker feed" <> '' then
                            if ItemFilters <> '' then
                                ItemFilters := ItemFilters + '|' + DependencyRec."FTT-CST Standard maker feed"
                            else
                                ItemFilters := DependencyRec."FTT-CST Standard maker feed";

                        if DependencyRec."FTT-CST Standard taker feed" <> '' then
                            if ItemFilters <> '' then
                                ItemFilters := ItemFilters + '|' + DependencyRec."FTT-CST Standard taker feed"
                            else
                                ItemFilters := DependencyRec."FTT-CST Standard taker feed";

                        if DependencyRec."FTT-CST NON Standard taker" <> '' then
                            if ItemFilters <> '' then
                                ItemFilters := ItemFilters + '|' + DependencyRec."FTT-CST NON Standard taker"
                            else
                                ItemFilters := DependencyRec."FTT-CST NON Standard taker";

                        if DependencyRec."FTT-CST CPU" <> '' then
                            if ItemFilters <> '' then
                                ItemFilters := ItemFilters + '|' + DependencyRec."FTT-CST CPU"
                            else
                                ItemFilters := DependencyRec."FTT-CST CPU";

                        if DependencyRec."FTT-CST HARDWARE" <> '' then
                            if ItemFilters <> '' then
                                ItemFilters := ItemFilters + '|' + DependencyRec."FTT-CST HARDWARE"
                            else
                                ItemFilters := DependencyRec."FTT-CST HARDWARE";

                        DependencyItems.SetRange("Filter No.", DependencyRec."Filter No.");
                        if DependencyItems.FindSet() then
                            repeat
                                if ItemFilters <> '' then
                                    ItemFilters := ItemFilters + '|' + DependencyItems."No." else
                                    ItemFilters := DependencyItems."No.";
                            until DependencyItems.next = 0;
                        InitNewLines(Rec, ItemFilters, DependencyRec."Filter No.");
                        Commit();
                        UpdateCrossConnectStatus();
                        Rec.UpdateQuantity();
                    end else begin
                        CrossConnectHdr.Reset();
                        CrossConnectHdr.SetRange("Document Type", rec."Document Type");
                        CrossConnectHdr.SetRange("Document No.", rec."No.");
                        CrossConnectHdr.SetRange("Cross Connect Status", CrossConnectHdr."Cross Connect Status"::Open);
                        if CrossConnectHdr.FindFirst() then
                            CrossConnectHdr.Delete(true);
                    end;
                end;
            }
        }
        modify(Email)
        {
            trigger OnBeforeAction()
            var
                codGMAILIntegSpreed2: Codeunit "GMAIL Integ.Spreadsheet";
            begin
                codGMAILIntegSpreed2.UpdateCRMTemplatefromSalesQuote(rec, true);
                Commit();
            end;
        }
        addbefore(DocAttach)
        {

            //NRD - 
            action("FTT-CST Create Pricing Prop")
            {
                ApplicationArea = All;
                Caption = 'Generate Pricing Proposition';
                Ellipsis = true;
                Image = PrintChecklistReport;
                ToolTip = 'Generate a printed template of pricing proposal';

                trigger OnAction()
                var
                    codGMAILIntegSpreed: Codeunit "GMAIL Integ.Spreadsheet";
                    OptionMenu: Label 'Generate to Excel,Generate to Word';
                    OptionConfirm: Label 'Choose one of the following options:';
                    Options: Text[50];
                    Selected: Integer;
                    repSalesQuote: report 1304;
                    SalesHeader_l: Record "Sales Header";
                    Report: ReportFormat;
                    OutStream2: OutStream;
                    TempBlob: codeunit "Temp Blob";
                    Instream2: InStream;
                    txtFilename: Text;
                begin
                    Options := OptionMenu;
                    Selected := StrMenu(Options, 1, OptionConfirm);
                    case Selected of
                        1:
                            begin
                                ReInsertCrossConnect;
                                Commit();
                                codGMAILIntegSpreed.UpdateCRMTemplatefromSalesQuote(rec, false);
                            end;
                        2:
                            begin
                                //NRD
                                Clear(repSalesQuote);
                                // if not SalesHeader_l.get(rec."Document Type", rec."No.") then
                                //     exit;
                                SalesHeader_l.Reset();
                                SalesHeader_l.SetRange("Document Type", rec."Document Type");
                                SalesHeader_l.SetRange("No.", rec."No.");
                                if SalesHeader_l.FindFirst() then begin
                                    TempBlob.CreateOutStream(OutStream2);
                                    repSalesQuote.SetTableView(SalesHeader_l);
                                    repSalesQuote.UseRequestPage(false);
                                    repSalesQuote.SaveAs('', Report::Word, OutStream2);
                                    TempBlob.CreateInStream(Instream2);
                                    txtFilename := Format('SQ-' + SalesHeader_l."No." + '_' + SalesHeader_l."Ship-to Name" + '.docx');
                                    DownloadFromStream(Instream2, '', '', '', txtFilename);
                                end;

                            end;
                    end;
                end;
            }
            //+

            //NRD
            action(OpenCrossConnectRelated)
            {
                ApplicationArea = All;
                Caption = 'Open Cross Connect Related';
                Ellipsis = true;
                Image = InteractionLog;
                ToolTip = 'Open Cross Connecte Related to this Document';

                trigger OnAction()
                var
                    pagCrossConnectCard: page "FTT-CST Cross Connect Card";
                    CrossConnectHdr: Record "FTT-CST Cross Connect Hdr";
                begin
                    clear(pagCrossConnectCard);

                    CrossConnectHdr.Reset();
                    CrossConnectHdr.SetRange("Document Type", rec."Document Type");
                    CrossConnectHdr.SetRange("Document No.", rec."No.");
                    CrossConnectHdr.SetRange("Customer No.", rec."Sell-to Customer No.");
                    if not CrossConnectHdr.FindFirst() then
                        Error('No Record Found!');


                    pagCrossConnectCard.SetRecord(CrossConnectHdr);
                    pagCrossConnectCard.Run();
                end;
            }
            //+
        }
        addfirst(Category_Process)
        {
            actionref("FTT-CST Create Pricing Prop_Promoted"; "FTT-CST Create Pricing Prop")
            {
                Visible = true;
            }
            actionref("OpenCrossConnectRelated_Promoted"; OpenCrossConnectRelated)
            {
                Visible = true;
            }
        }
        addbefore("FTT-CST Create Pricing Prop_Promoted")
        {
            actionref("FTT-CST Update Qty. for Agr_Promoted"; "FTT-CST Update Qty. for Agr")
            {
                Visible = true;
            }
        }
        addbefore("FTT-CST Create Pricing Prop_Promoted")
        {
            actionref("FTT-CST ITEM CHAD_Promoted"; "FTT-CST ITEM CHAD")
            {
                Visible = true;
            }
            actionref("FTT-CST ITEM CHAD_Promoted2"; "FTT-CST ITEM CHAD2")
            {
                Visible = true;
            }
        }

        modify(DocAttach)
        {
            visible = false;
        }
        modify("Co&mments")
        {
            Visible = false;
        }
        modify(MakeInvoice)
        {
            Visible = false;
        }

    }
    trigger OnInsertRecord(BelowxRec: Boolean): Boolean
    begin
        Rec.Validate("Document Date", Today);
        Rec.Validate("FTT-CST Contract Length", 1);
    end;

    trigger OnAfterGetRecord()
    var
        GLSetup: record "General Ledger Setup";
    begin
        GLSetup.GET();
        if rec."Currency Code" <> '' then
            Text001 := StrSubstNo(Text002, Rec."Currency Code") else
            Text001 := StrSubstNo(Text002, GLSetup."LCY Code");


    end;

    trigger OnAfterGetCurrRecord()

    begin
        if rec."FTT-CST Final Quote" then
            isEnabledfield := false
        else
            isEnabledfield := true;
        //CurrPage.Update(false);

    end;

    trigger OnDeleteRecord(): Boolean
    var
        recConnectHeader: Record "FTT-CST Cross Connect Hdr";
    begin
        recConnectHeader.Reset();
        recConnectHeader.SetRange("Document Type", rec."Document Type");
        recConnectHeader.SetRange("Document No.", rec."No.");
        if recConnectHeader.FindFirst() then
            recConnectHeader.Delete(true);
    end;


    trigger OnOpenPage()
    var
        recCustomer: Record customer;
    begin
        if recCustomer.get(rec."Sell-to Customer No.") then begin
            if recCustomer.Prospect then
                isProspect := false
            else
                isProspect := true;
        end;

    end;

    local procedure UpdateCrossConnectStatus()
    var
        recCrossConnectHdr: Record "FTT-CST Cross Connect Hdr";
    begin
        recCrossConnectHdr.Reset();
        recCrossConnectHdr.SetRange("Document Type", rec."Document Type");
        recCrossConnectHdr.SetRange("Document No.", rec."No.");
        recCrossConnectHdr.SetRange("Customer No.", rec."Sell-to Customer No.");
        recCrossConnectHdr.SetRange("Cross Connect Status", recCrossConnectHdr."Cross Connect Status"::Open);
        if recCrossConnectHdr.FindFirst() then begin
            recCrossConnectHdr."Cross Connect Status" := recCrossConnectHdr."Cross Connect Status"::"Line Inserted";
            recCrossConnectHdr.Modify();
        end;
    end;

    procedure InitNewLines2(SalesHeader: Record "Sales Header"; SelectionFilter: Text[1024]; FilterNo: integer);
    var
        SalesLine: Record "Sales Line";
        ItemFilters: Record "FTT-CST Dependency Filters";
        LineNo: Integer;
        DependancyItem: Record "FTT-CST Dependancy Item";
        ItemCategotyCode: record "Item Category";
        ItemSt: record Item;
        DimensionValues: Record "Dimension Value";
        Currency: Record Currency;
        CurrExchRate: Record "Currency Exchange Rate";
    begin
        ItemFilters.Get(SalesHeader."No.", FilterNo);
        SalesHeader."FTT-CST Component Option" := ItemFilters."FTT-CST Component Option";
        SalesHeader."FTT-CST Region Code" := ItemFilters."FTT-CST Location Code";
        SalesHeader.Modify();

        SalesLine.SetRange("Document Type", SalesHeader."Document Type");
        SalesLine.SetRange("Document No.", SalesHeader."No.");
        IF SalesLine.FindLast() THEN
            LineNo := SalesLine."Line No." else
            LineNo := 0;

        DependancyItem.SetFilter("No.", SelectionFilter);
        DependancyItem.SetCurrentKey(Level);
        if DependancyItem.FindSet() then
            repeat
                SalesLine.Init();
                SalesLine."Line No." := LineNo + 10000;
                Salesline."Document No." := SalesHeader."No.";
                SalesLine."Document Type" := SalesHeader."Document Type";
                SalesLine.Validate(Type, SalesLine.Type::Item);
                SalesLine.Validate("No.", DependancyItem."No.");
                SalesLine.Validate("Sell-to Customer No.", SalesHeader."Sell-to Customer No.");
                SalesLine.Validate("Customer Price Group", SalesHeader."Customer Price Group");
                SalesLine.Validate("Customer Disc. Group", SalesHeader."Customer Disc. Group");
                SalesLine."Allow Line Disc." := SalesHeader."Allow Line Disc.";
                SalesLine."Transaction Type" := SalesHeader."Transaction Type";
                SalesLine."Transport Method" := SalesHeader."Transport Method";
                SalesLine."Bill-to Customer No." := SalesHeader."Bill-to Customer No.";
                SalesLine."Price Calculation Method" := SalesHeader."Price Calculation Method";
                SalesLine."Gen. Bus. Posting Group" := SalesHeader."Gen. Bus. Posting Group";
                SalesLine."VAT Bus. Posting Group" := SalesHeader."VAT Bus. Posting Group";

                if DependancyItem."FTT-CST Quantity" = 0 then
                    DependancyItem."FTT-CST Quantity" := 1;
                if DependancyItem."FTT-CST Quantity" <> 0 then
                    SalesLine.Validate(Quantity, DependancyItem."FTT-CST Quantity") else
                    SalesLine.Quantity := 1;
                LineNo := SalesLine."Line No.";
                SalesLine."FTT-CST Comments" := DependancyItem."FTT-CST Comments";
                SalesLine.Validate("FTT-CST Optional", DependancyItem.Optional);
                if DependancyItem.Optional = DependancyItem.Optional::Yes then
                    SalesLine.Validate(Quantity, 1);
                SalesLine."FTT-CST Use for Discount" := DependancyItem."FTT-CST Use for Discount";
                SalesLine."Allow Line Disc." := DependancyItem."FTT-CST Use for Discount";
                SalesLine."Allow Invoice Disc." := DependancyItem."FTT-CST Use for Discount";
                Salesline."FTT-CST Parent Item Cat. Code" := DependancyItem."FTT-CST Parent Category Code";
                SalesLine."FTT-CST Comments Fluent" := DependancyItem."FTT-CST Comments Fluent";
                SalesLine."FTT-CST DR" := DependancyItem.DR;
                SalesLine."FTT-CST Redundancy" := DependancyItem.Redundancy;
                SalesLine."FTT-CST Redundancy PriceCalc %" := DependancyItem."FTT-CST RED/DR PriceCalc %";
                SalesLine."FTT-CST Location Code" := DependancyItem."Location Code";
                SalesLine."FTT-CST Location Type" := DependancyItem."FTT-CST Location Type";
                SalesLine."FTT-CST Component Option" := DependancyItem."FTT-CST Component Option";
                SalesLine."FTT-CST Sublocation" := DependancyItem."FTT-CST Sublocation";
                SalesLine."Shortcut Dimension 1 Code" := SalesHeader."Shortcut Dimension 1 Code";
                SalesLine."Shortcut Dimension 2 Code" := SalesHeader."Shortcut Dimension 2 Code";

                if DependancyItem."Unit Price" > 0 then
                    SalesLine."Unit Price" := DependancyItem."Unit Price";

                SalesLine."FTT-CST Unit Price" := DependancyItem."Unit Price";

                if ItemSt.Get(DependancyItem."No.") then
                    SalesLine.Validate("FTT-CST Cost Type", ItemSt."FTT-CST Cost Type");
                SalesLine.ValidateShortcutDimCode(3, SalesLine."FTT-CST Location Code");
                //Add Dimesnsion for Sublocation
                DimensionValues.Reset;
                DimensionValues.SetRange("FTT-CST Sublocation", SalesLine."FTT-CST Sublocation");
                if DimensionValues.FindFirst() then
                    SalesLine.ValidateShortcutDimCode(4, DimensionValues.Code);

                SalesLine.Validate("Currency Code", SalesHeader."Currency Code");

                if SalesLine."Currency Code" <> '' then begin
                    Currency.Get(SalesLine."Currency Code");
                    SalesLine.Validate("Unit Price",
                    CurrExchRate.ExchangeAmtLCYToFCYOnlyFactor(DependancyItem."Unit Price", CurrExchRate.ExchangeRate(Today, SalesLine."Currency Code")));
                end;


                SalesLine.Validate("FTT-CST Optional", DependancyItem.Optional);


                if SalesLine."Currency Code" <> '' then begin
                    SalesLine."Unit Price" := Round(SalesLine."Unit Price", Currency."Amount Rounding Precision");
                    SalesLine."FTT-CST Unit Price" := Round(SalesLine."FTT-CST Unit Price", Currency."Amount Rounding Precision");
                    SalesLine.Amount := Round(SalesLine.Amount, Currency."Amount Rounding Precision");
                    SalesLine."FTT-CST Unit Price" := Round(SalesLine."FTT-CST Unit Price", Currency."Amount Rounding Precision");
                end else begin
                    SalesLine."Unit Price" := DependancyItem."Unit Price";
                    if DependancyItem.Optional = DependancyItem.Optional::Yes then
                        SalesLine."FTT-CST Unit Price" := 0.01;
                    SalesLine.VALIDATE("Unit Price", DependancyItem."Unit Price");
                end;

                SalesLine.Validate("FTT-CST Optional", DependancyItem.Optional);
                //if DependancyItem.Optional = DependancyItem.Optional::Yes then
                SalesLine.Validate(Quantity);

                SalesLine.Insert(true);
            until DependancyItem.Next() = 0;
    end;

    procedure InitNewLines(SalesHeader: Record "Sales Header"; SelectionFilter: Text[1024]; FilterNo: integer);
    var
        SalesLine: Record "Sales Line";
        ItemFilters: Record "FTT-CST Dependency Filters";
        LineNo: Integer;
        DependancyItem: Record "FTT-CST Dependancy Item";
        ItemCategotyCode: record "Item Category";
        ItemSt: record Item;
        DimensionValues: Record "Dimension Value";
        Currency: Record Currency;
        CurrExchRate: Record "Currency Exchange Rate";
    begin
        ItemFilters.Get(SalesHeader."No.", FilterNo);
        SalesHeader."FTT-CST Component Option" := ItemFilters."FTT-CST Component Option";
        SalesHeader."FTT-CST Region Code" := ItemFilters."FTT-CST Location Code";
        SalesHeader."FTT-CST Use for Renewal" := true;
        SalesHeader.Modify();

        SalesLine.SetRange("Document Type", SalesHeader."Document Type");
        SalesLine.SetRange("Document No.", SalesHeader."No.");
        IF SalesLine.FindLast() THEN
            LineNo := SalesLine."Line No." else
            LineNo := 0;

        DependancyItem.SetFilter("No.", SelectionFilter);
        DependancyItem.SetFilter("Sales Document No.", Rec."No."); //27.05.2024 IVS Added

        DependancyItem.SetCurrentKey(Level);
        if DependancyItem.FindSet() then
            repeat
                SalesLine.Init();
                SalesLine."Line No." := LineNo + 10000;
                Salesline."Document No." := SalesHeader."No.";
                SalesLine."Document Type" := SalesHeader."Document Type";
                SalesLine.Validate("Sell-to Customer No.", SalesHeader."Sell-to Customer No.");
                SalesLine.Validate("Customer Price Group", SalesHeader."Customer Price Group");
                SalesLine.Validate("Customer Disc. Group", SalesHeader."Customer Disc. Group");
                SalesLine.Validate("Currency Code", SalesHeader."Currency Code");
                SalesLine.Validate(Type, SalesLine.Type::Item);
                SalesLine.Validate("No.", DependancyItem."No.");
                SalesLine.Validate("Unit Price", DependancyItem."Unit Price");
                SalesLine.insert();

                //SalesLine."Allow Line Disc." := SalesHeader."Allow Line Disc.";
                SalesLine."Transaction Type" := SalesHeader."Transaction Type";
                SalesLine."Transport Method" := SalesHeader."Transport Method";
                SalesLine."Bill-to Customer No." := SalesHeader."Bill-to Customer No.";
                SalesLine."Price Calculation Method" := SalesHeader."Price Calculation Method";
                SalesLine."Gen. Bus. Posting Group" := SalesHeader."Gen. Bus. Posting Group";
                SalesLine."VAT Bus. Posting Group" := SalesHeader."VAT Bus. Posting Group";


                if DependancyItem."FTT-CST Quantity" > 1 then begin
                    SalesLine.Quantity := DependancyItem."FTT-CST Quantity";
                    SalesLine."FTT-CST Qty" := DependancyItem."FTT-CST Quantity";
                end else begin
                    SalesLine.Quantity := 1;
                    SalesLine."FTT-CST Qty" := 1;

                end;

                LineNo := SalesLine."Line No.";
                SalesLine."FTT-CST Comments" := DependancyItem."FTT-CST Comments";
                SalesLine.Validate("FTT-CST Optional", DependancyItem.Optional);

                if DependancyItem.Optional = DependancyItem.Optional::Yes then
                    SalesLine.Validate(Quantity, SalesLine.Quantity);

                SalesLine."FTT-CST Use for Discount" := DependancyItem."FTT-CST Use for Discount";
                SalesLine."Allow Line Disc." := DependancyItem."FTT-CST Use for Discount";
                SalesLine."Allow Invoice Disc." := DependancyItem."FTT-CST Use for Discount";

                Salesline."FTT-CST Parent Item Cat. Code" := DependancyItem."FTT-CST Parent Category Code";
                SalesLine."FTT-CST Comments Fluent" := DependancyItem."FTT-CST Comments Fluent";
                SalesLine."FTT-CST DR" := DependancyItem.DR;
                SalesLine."FTT-CST Integration" := DependancyItem."Integr."; //NRD
                SalesLine."FTT-CST Redundancy" := DependancyItem.Redundancy;
                SalesLine."FTT-CST Redundancy PriceCalc %" := DependancyItem."FTT-CST RED/DR PriceCalc %";
                SalesLine."FTT-CST Location Code" := DependancyItem."Location Code";
                SalesLine."FTT-CST Location Type" := DependancyItem."FTT-CST Location Type";
                SalesLine."FTT-CST Component Option" := DependancyItem."FTT-CST Component Option";
                SalesLine."FTT-CST Sublocation" := DependancyItem."FTT-CST Sublocation";
                SalesLine."Shortcut Dimension 1 Code" := SalesHeader."Shortcut Dimension 1 Code";
                SalesLine."Shortcut Dimension 2 Code" := SalesHeader."Shortcut Dimension 2 Code";
                SalesLine."FTT-CST Use for Renewal" := true;

                SalesLine."Unit Price" := DependancyItem."Unit Price";
                SalesLine."FTT-CST Unit Price" := DependancyItem."Unit Price";

                if ItemSt.Get(DependancyItem."No.") then
                    SalesLine.Validate("FTT-CST Cost Type", ItemSt."FTT-CST Cost Type");
                SalesLine."SDP Items" := ItemSt."SDP Items"; //NRD
                SalesLine.isRedundancyCalculated := false;  //NRD
                SalesLine.isDRCalculated := false;  //NRD
                SalesLine.isIntegCalculated := false;  //NRD

                SalesLine.ValidateShortcutDimCode(3, SalesLine."FTT-CST Location Code");
                //Add Dimesnsion for Sublocation
                DimensionValues.Reset;
                DimensionValues.SetRange("FTT-CST Sublocation", SalesLine."FTT-CST Sublocation");
                if DimensionValues.FindFirst() then
                    SalesLine.ValidateShortcutDimCode(4, DimensionValues.Code);


                SalesLine.Validate("FTT-CST Optional", DependancyItem.Optional);
                if DependancyItem.Optional = DependancyItem.Optional::Yes then
                    SalesLine.Validate(Quantity, SalesLine.Quantity);

                if (SalesLine."FTT-CST Cost Type" = SalesLine."FTT-CST Cost Type"::NRC) then // AND (SalesLine."FTT-CST Parent Item Cat. Code" = 'HARDWARE') then //NRD - Fixed the Unit Price and Line amount
                    SalesLine.Validate(Quantity, SalesLine.Quantity);

                SalesLine."Allow Invoice Disc." := SalesLine."FTT-CST Use for Discount";
                SalesLine."Allow Line Disc." := SalesLine."FTT-CST Use for Discount";
                if SalesLine.Modify() then;

            until DependancyItem.Next() = 0;
        // //NRD - Fixed the Unit Price and Line amount
        // SalesLine.Reset();
        // SalesLine.SetRange("Document Type", SalesLine."Document Type"::Quote);
        // SalesLine.SetRange("Document No.", SalesHeader."No.");
        // SalesLine.SetFilter("Line Amount", '%1', 0);
        // if SalesLine.FindSet() then
        //     repeat
        //         SalesLine.Validate(Quantity, SalesLine.Quantity);
        //         SalesLine.Modify(true);
        //         Commit();
        //     until SalesLine.next = 0;
        //+
        //DependancyItem.Reset();
        //DependancyItem.DeleteAll();
        DependancyItem.SetRange("Filter No.", FilterNo);
        DependancyItem.SetRange("Sales Document No.", rec."No.");
        DependancyItem.DeleteAll();
    end;

    local procedure GetContactName(pCode: Code[20]): Text
    var
        lContact: Record Contact;
    begin
        if lContact.get(pCode) then
            exit(lContact.Name);

        exit('');
    end;
    //NRD - 04112024 
    local procedure ReInsertCrossConnect()
    var
        recl_SalesLine: Record "Sales Line";
        CrossConnect: record "FTT-CST Cross Connect";
        CrossConnectHeader: record "FTT-CST Cross Connect Hdr";
        CrossConnectLines: Record "FTT-CST Cross Connect Lines";
        CrossConnectLines2: record "FTT-CST Cross Connect Lines";
        FeedLineCount: Integer;
        DocType: enum "Sales Document Type";
        TotalDedicatedNRCCodeperLocation: Integer;
        TotalDedicatedMRCCodeperLocation: Integer;
        TotalSharedNRCCodeperLocation: Integer;
        TotalSharedMRCCodeperLocation: Integer;
    begin
        DocType := DocType::Quote; //NRD

        CrossConnectHeader.Reset();
        CrossConnectHeader.SetRange("Document Type", DocType);
        CrossConnectHeader.SetRange("Document No.", rec."No.");
        if not CrossConnectHeader.FindFirst() then begin
            CrossConnectHeader.Init();
            CrossConnectHeader."Document Type" := DocType;
            CrossConnectHeader."Document No." := rec."No.";
            CrossConnectHeader.validate("Customer No.", rec."Sell-to Customer No.");
            CrossConnectHeader."Cross Connect Status" := CrossConnectHeader."Cross Connect Status"::"Line Inserted";
            IF CrossConnectHeader.Insert() THEN begin
                Commit();

                recl_SalesLine.Reset();
                recl_SalesLine.SetFilter("Document Type", '%1', rec."Document Type");
                recl_SalesLine.SetFilter("Document No.", '%1', rec."No.");
                recl_SalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1', 'FEED');
                recl_SalesLine.SetRange("FTT-CST Optional", recl_SalesLine."FTT-CST Optional"::No);
                if recl_SalesLine.FindSet() then
                    repeat
                        if ComputeDedicatedNRCCount(recl_SalesLine) <> 0 then
                            TotalDedicatedNRCCodeperLocation := ComputeDedicatedNRCCount(recl_SalesLine) / ComputeFeedLineCount(recl_SalesLine)
                        else
                            TotalDedicatedNRCCodeperLocation := 0;

                        if ComputeDedicatedMRCCount(recl_SalesLine) <> 0 then
                            TotalDedicatedMRCCodeperLocation := ComputeDedicatedMRCCount(recl_SalesLine) / ComputeFeedLineCount(recl_SalesLine)
                        else
                            TotalDedicatedMRCCodeperLocation := 0;

                        if ComputeSharedMRCCount(recl_SalesLine) <> 0 then
                            TotalSharedMRCCodeperLocation := ComputeSharedMRCCount(recl_SalesLine) / ComputeFeedLineCount(recl_SalesLine)
                        else
                            TotalSharedMRCCodeperLocation := 0;

                        if ComputeSharedNRCCount(recl_SalesLine) <> 0 then
                            TotalSharedNRCCodeperLocation := ComputeSharedNRCCount(recl_SalesLine) / ComputeFeedLineCount(recl_SalesLine)
                        else
                            TotalSharedNRCCodeperLocation := 0;

                        if (TotalDedicatedNRCCodeperLocation <> 0) OR (TotalDedicatedMRCCodeperLocation <> 0) OR (TotalSharedMRCCodeperLocation <> 0) OR (TotalSharedNRCCodeperLocation <> 0) then begin
                            CrossConnectLines.Init();
                            CrossConnectLines."Document Type" := DocType;
                            CrossConnectLines."Document No." := rec."No.";
                            CrossConnectLines."Item No." := recl_SalesLine."No.";
                            CrossConnectLines."FTT-CST Location Code" := recl_SalesLine."FTT-CST Location Code";
                            CrossConnectLines.Description := recl_SalesLine.Description;
                            CrossConnectLines."Quantity 1" := TotalSharedMRCCodeperLocation;
                            CrossConnectLines."Quantity 2" := TotalDedicatedMRCCodeperLocation;
                            CrossConnectLines."Quantity 3" := TotalSharedNRCCodeperLocation;
                            CrossConnectLines."Quantity 4" := TotalDedicatedNRCCodeperLocation;
                            CrossConnectLines."Item Category Code" := recl_SalesLine."Item Category Code";
                            CrossConnectLines.Insert();
                        end;
                    until recl_SalesLine.Next() = 0;

                Commit();

            end;
        end;
    end;

    local procedure ComputeDedicatedNRCCount(pSalesLine: Record "Sales Line"): Integer
    var
        recl_SalesLine: Record "Sales Line";
    begin
        //Dedicated cross connects - NRC
        recl_SalesLine.Reset();
        recl_SalesLine.SetRange("Document Type", pSalesLine."Document Type"::Quote);
        recl_SalesLine.SetRange("Document No.", pSalesLine."Document No.");
        recl_SalesLine.SetRange("No.", '1104');
        recl_SalesLine.SetRange("FTT-CST Location Code", pSalesLine."FTT-CST Location Code");
        if recl_SalesLine.FindFirst() then
            exit(recl_SalesLine."FTT-CST Qty");

        exit(0);
    end;

    local procedure ComputeFeedLineCount(pSalesLine: Record "Sales Line"): Integer
    var
        recl_SalesLine: Record "Sales Line";
    begin
        //Dedicated cross connects - NRC
        recl_SalesLine.Reset();
        recl_SalesLine.SetRange("Document Type", pSalesLine."Document Type"::Quote);
        recl_SalesLine.SetRange("Document No.", pSalesLine."Document No.");
        recl_SalesLine.SetFilter("FTT-CST Parent Item Cat. Code", '%1', 'FEED');
        recl_SalesLine.SetFilter("FTT-CST Location Code", '%1', pSalesLine."FTT-CST Location Code");
        if recl_SalesLine.FindSet() then
            exit(recl_SalesLine.Count);

        exit(0);
    end;

    local procedure ComputeDedicatedMRCCount(pSalesLine: Record "Sales Line"): Integer
    var
        recl_SalesLine: Record "Sales Line";
    begin
        //Dedicated cross connects - MRC
        recl_SalesLine.Reset();
        recl_SalesLine.SetRange("Document Type", pSalesLine."Document Type"::Quote);
        recl_SalesLine.SetRange("Document No.", pSalesLine."Document No.");
        recl_SalesLine.SetRange("No.", '1102');
        recl_SalesLine.SetRange("FTT-CST Location Code", pSalesLine."FTT-CST Location Code");
        if recl_SalesLine.FindFirst() then
            exit(recl_SalesLine."FTT-CST Qty");

        exit(0);
    end;

    local procedure ComputeSharedMRCCount(pSalesLine: Record "Sales Line"): Integer
    var
        recl_SalesLine: Record "Sales Line";
    begin
        //Shared cross connects - MRC
        recl_SalesLine.Reset();
        recl_SalesLine.SetRange("Document Type", pSalesLine."Document Type"::Quote);
        recl_SalesLine.SetRange("Document No.", pSalesLine."Document No.");
        recl_SalesLine.SetRange("No.", '1101');
        recl_SalesLine.SetRange("FTT-CST Location Code", pSalesLine."FTT-CST Location Code");
        if recl_SalesLine.FindFirst() then
            exit(recl_SalesLine."FTT-CST Qty");

        exit(0);
    end;

    local procedure ComputeSharedNRCCount(pSalesLine: Record "Sales Line"): Integer
    var
        recl_SalesLine: Record "Sales Line";
    begin
        //Shared cross connects - NRC
        recl_SalesLine.Reset();
        recl_SalesLine.SetRange("Document Type", pSalesLine."Document Type"::Quote);
        recl_SalesLine.SetRange("Document No.", pSalesLine."Document No.");
        recl_SalesLine.SetRange("No.", '1103');
        recl_SalesLine.SetRange("FTT-CST Location Code", pSalesLine."FTT-CST Location Code");
        if recl_SalesLine.FindFirst() then
            exit(recl_SalesLine."FTT-CST Qty");

        exit(0);
    end;
    //+
    var
        Text002: Label 'Fluent Trade Technologies software pricing methodology is based on the individual components and feeds that its clients utilise. This initial pricing proposal is presented in %1 and relates to the proposed initial project scope as Fluent understands it. Final written requirements are to be mutually agreed upon before a firm price proposal from Fluent. If relevant, additional hardware and infrastructure fees may also apply. ';
        Text001: text[450];

        isEnabledfield: Boolean; //NRD
        isProspect: Boolean; //NRD

}
