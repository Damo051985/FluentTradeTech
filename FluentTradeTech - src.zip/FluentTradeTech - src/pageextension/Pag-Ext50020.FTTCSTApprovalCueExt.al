pageextension 50020 "ApprovalCueExt" extends 9144
{
    layout
    {
        addafter("Requests to Approve")
        {
            field("Requests Rejected for Approval"; Rec."Requests Rejected for Approval")
            {
                ApplicationArea = Suite;
                DrillDownPageID = "Approval Entries";
                ToolTip = 'Specifies requests for certain documents, cards, or journal lines that the approver has been rejected already.';
            }
            field("Requests Approved"; Rec."Requests Approved")
            {
                ApplicationArea = Suite;
                DrillDownPageID = "Approval Entries";
                ToolTip = 'Specifies requests for certain documents, cards, or journal lines that your approver has been approved already.';
            }
        }

    }

    actions
    {
        // Add changes to page actions here
    }

    var
        myInt: Integer;
}