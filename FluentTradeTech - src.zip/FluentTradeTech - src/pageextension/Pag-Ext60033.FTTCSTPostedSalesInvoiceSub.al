pageextension 60033 "FTT-CST PostedSalesInvoiceSub" extends "Posted Sales Invoice Subform"
{
    layout
    {
        modify(FilteredTypeField)
        {
            Visible = false;
        }
        modify("Item Reference No.")
        {
            Visible = false;
        }
        modify("Allow Invoice Disc.")
        {
            Visible = true;
        }

        modify("Unit Price")
        {
            Visible = false;
        }

        modify("Invoice Discount Amount")
        {
            Editable = false;
            Caption = 'Discount Amount';
            Visible = true;
        }
        modify("Total Amount Incl. VAT")
        {
            Editable = false;
        }
        modify("ShortcutDimCode[3]")
        {
            Visible = true;
        }
        modify("ShortcutDimCode[4]")
        {
            Visible = true;
        }

        movebefore(Description; "ShortcutDimCode[3]")
        //movebefore(ShortcutDimCode4; ShortcutDimCode3)
        addafter("ShortcutDimCode[3]")
        {
            field("FTT-CST Parent Item Cat. Code"; Rec."FTT-CST Parent Item Cat. Code")
            {
                ApplicationArea = all;
                Visible = false;
            }
            field("FTT-CST Sublocation"; Rec."FTT-CST Sublocation")
            {
                ApplicationArea = all;
                Visible = true;
            }
            field("FTT-CST Component Option"; Rec."FTT-CST Component Option")
            {
                ApplicationArea = all;
            }
        }
        modify("Line Discount Amount")
        {
            Visible = false;
        }
        //modify("Invoice Discount Amount")

        addafter(Description)
        {

            field("FTT-CST Optional"; Rec."FTT-CST Optional")
            {
                ApplicationArea = All;
                Editable = false;
                Visible = true;
            }
            field("FTT-CST Redundancy"; Rec."FTT-CST Redundancy")
            {
                ApplicationArea = all;
                Visible = false;
            }
            field("FTT-CST DR"; Rec."FTT-CST DR")
            {
                ApplicationArea = all;
                Visible = false;
            }
            field("FTT-CST Redundancy PriceCalc %"; Rec."FTT-CST Redundancy PriceCalc %")
            {
                ApplicationArea = all;
                Visible = false;
            }
            field("FTT-CST Location Code"; Rec."FTT-CST Location Code")
            {
                ApplicationArea = all;
                Visible = false;
            }
        }
        addbefore(Quantity)
        {

            field("FTT-CST Unit Price"; Rec."FTT-CST Unit Price")
            {
                ApplicationArea = all;
                Caption = 'Unit Price';
                Visible = true;
                DecimalPlaces = 2 : 2;
            }
            field("FTT-CST Delivery PROD Date"; Rec."FTT-CST Delivery PROD Date")
            {
                ApplicationArea = All;
                Editable = Rec.Type = "Sales Line Type"::Item;
                Visible = false;
                ToolTip = 'Specifies an ending date of the agreement period for the line.';
            }
            field("FTT-CST Delivery UAT Date"; Rec."FTT-CST Delivery UAT Date")
            {
                ApplicationArea = All;
                Visible = false;
                Editable = Rec.Type = "Sales Line Type"::Item;
                ToolTip = 'Specifies an ending date of the agreement period for the line.';
            }
            field("FTT-CST Agreement Date To"; Rec."FTT-CST Agreement Date To")
            {
                ApplicationArea = All;
                Visible = false;
                Editable = Rec.Type = "Sales Line Type"::Item;
                ToolTip = 'Specifies an ending date of the agreement period for the line.';
            }

        }
        addafter("Line Amount")
        {
            field("FTT-CST Cost Type"; Rec."FTT-CST Cost Type")
            {
                ApplicationArea = All;
                Width = 8;
                Visible = true;
                HideValue = Rec.Type <> "Sales Line Type"::Item;
                ToolTip = 'Specifies a cost type of the item.';
            }
            field("FTT-CST Agreement Date From"; Rec."FTT-CST Agreement Date From")
            {
                ApplicationArea = all;
            }
            field("FTT-CST Comments Fluent"; Rec."FTT-CST Comments Fluent")
            {
                ApplicationArea = All;
                Editable = true;
                width = 10;
            }
            field("FTT-CST Comments"; Rec."FTT-CST Comments")
            {
                ApplicationArea = All;
                Editable = true;
                width = 10;
            }
            field("Agreement Period"; Rec."Agreement Period")
            {
                ApplicationArea = all;
            }
            //NRD
            field("FTT-CST Eligible"; Rec."FTT-CST Eligible")
            {
                ApplicationArea = all;
            }
            field("FTT-CST Salesp. Comm. Type"; Rec."FTT-CST Salesp. Comm. Type")
            {
                ApplicationArea = all;
            }
            field("Commission Rate %"; Rec."Commission Rate %")
            {
                ApplicationArea = all;
            }
            field("Commission Base Amount"; Rec."Commission Base Amount")
            {
                ApplicationArea = all;
            }
            field("Commission Base Amount (LCY)"; Rec."Commission Base Amount (LCY)")
            {
                ApplicationArea = all;
            }

            //+
        }

        addafter("Total Amount Incl. VAT")
        {
            group(gr1)
            {
                ShowCaption = false;
                field("Commission Sales"; CommAmount)
                {
                    Caption = 'Total Commission Base Amount (LCY)';
                    ApplicationArea = all;
                    Editable = false;
                }
                field("Commission Sales 2"; CommAmount2)
                {
                    Caption = 'Total Commission Base Amount';
                    ApplicationArea = all;
                    Editable = false;
                }
            }

        }


    }

    trigger OnAfterGetRecord()
    begin
        CalculateCommission(CommAmount, CommAmount2);
        //CurrPage.Update();
    end;

    trigger OnAfterGetCurrRecord()
    begin
        CalculateCommission(CommAmount, CommAmount2);
        //CurrPage.Update();
    end;

    trigger OnDeleteRecord(): Boolean
    begin
        CalculateCommission(CommAmount, CommAmount2);
        //CurrPage.Update();
    end;

    trigger OnModifyRecord(): Boolean
    begin
        CalculateCommission(CommAmount, CommAmount2);
    end;

    procedure CalculateCommission(var pCommAmount: Decimal; var pCommAmount2: Decimal)
    var
        SalesInvLine: record "Sales Invoice Line";

    begin
        pCommAmount := 0;

        SalesInvLine.SetRange("Document No.", Rec."Document No.");
        SalesInvLine.SetFilter("Commission Base Amount (LCY)", '<>%1', 0);
        SalesInvLine.SetRange("FTT-CST Optional", SalesInvLine."FTT-CST Optional"::No); //NRD
        if not SalesInvLine.FindSet() then
            pCommAmount := 0;
        pCommAmount2 := 0;


        if SalesInvLine.FindSet() then
            repeat
                pCommAmount2 := pCommAmount2 + SalesInvLine."Commission Base Amount";
                pCommAmount := pCommAmount + SalesInvLine."Commission Base Amount (LCY)";
            until SalesInvLine.next = 0;
    end;

    var
        CommAmount: Decimal;
        CommAmount2: Decimal;

}
