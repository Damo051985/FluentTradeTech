pageextension 60044 FTTCSTOpportunityEntriesExt extends "Opportunity Entries"
{
    layout
    {
        modify("Calcd. Current Value (LCY)")
        {
            Visible = False;
        }
        Modify("Estimated Value (LCY)")
        {
            Visible = False;
        }
        Modify("Chances of Success %")
        {
            Visible = False;
        }
        addafter("Sales Cycle Stage Description")
        {
            field("Estimated Value - Currency"; Rec."Estimated Value - Currency")
            {
                ApplicationArea = all;
            }
            field("Estimated Value"; Rec."Estimated Value (LCY)")
            {
                ApplicationArea = all;
                Caption = 'Estimated Value';
            }
        }
    }
}
