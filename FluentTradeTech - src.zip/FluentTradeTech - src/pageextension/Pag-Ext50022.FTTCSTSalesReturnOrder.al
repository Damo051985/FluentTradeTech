pageextension 50022 "Sales Return Order Ext." extends "Sales Return Order"
{
    layout
    {
        addafter("Order Date")
        {
            field("FTT-CST Agr. Starting Date"; Rec."FTT-CST Agr. Starting Date")
            {
                ApplicationArea = All;
                Caption = 'Agreement Starting Date'; //NRD
                ToolTip = 'Specifies a starting date of the agreement.';
                trigger OnValidate()
                var
                    lSL: Record "Sales Line";
                    YearInt: Integer;
                begin
                    if rec."FTT-CST Agr. Starting Date" <> 0D then
                        Rec.Validate("FTT-CST Contract Length", 1);
                    Rec.ValidateSinceGoLiveDate();
                    Rec.Modify();

                    Clear(lSL);
                    lSL.SetRange("Document Type", Rec."Document Type");
                    lSL.SetRange("Document No.", Rec."No.");
                    IF lSL.FindSet then begin
                        YearInt := Date2DMY(Rec."FTT-CST Agr. Starting Date", 3);
                        lSL.MODIFYALL(lSL."FTT-CST Year", YearInt);
                    end;
                end;
            }
            field("FTT-CST Agr. Ending Date"; Rec."FTT-CST Agr. Ending Date")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies an ending date of the agreement.';
            }
            field("FTT-CST Component Option"; Rec."FTT-CST Component Option")
            {
                ApplicationArea = All;
                Visible = false;
                ToolTip = 'Specifies an ending date of the agreement.';
            }
            field("FTT-CST Region Code"; Rec."FTT-CST Region Code")
            {
                ApplicationArea = All;
                Visible = false;
                ToolTip = 'Specifies an ending date of the';
                Caption = 'Location Code';
            }
            field("FTT-CST Agr. Period Number"; Rec."FTT-CST Agr. Period Number")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies a number of the agreement period for this sales order.';
            }
        }

    }

    actions
    {
        addbefore("Create &Whse. Receipt")
        {
            action("FTT-CST Update Qty. for Agr")
            {
                ApplicationArea = All;
                Caption = 'Update Quantity'; //NRD
                //Caption = 'Update Quantity for Agreement';
                Ellipsis = true;
                Image = UpdateUnitCost;
                ToolTip = 'Update Quantity based on the Agreement period and Item Type';
                Promoted = true;
                PromotedOnly = true;
                PromotedIsBig = true;
                PromotedCategory = Process;
                trigger OnAction()
                begin
                    Rec.UpdateQuantity3();
                end;
            }

        }
    }

    var
        myInt: Integer;
}