pageextension 60016 "FTT-CST SalesInvoiceSubform" extends "Sales Invoice Subform"
{
    layout
    {

        modify(FilteredTypeField)
        {
            Visible = false;
        }
        modify("Item Reference No.")
        {
            Visible = false;
        }
        modify("Allow Invoice Disc.")
        {
            Visible = true;
        }
        modify("Allow Item Charge Assignment")
        {
            visible = false;
        }
        modify("Unit Price")
        {
            Visible = false;
        }
        modify("Inv. Discount Amount")
        {
            Editable = false;
            Visible = false;
        }
        modify("Invoice Discount Amount")
        {
            Editable = false;
            Caption = 'Discount Amount';
            Visible = true;
        }
        modify("Total Amount Incl. VAT")
        {
            Editable = false;
        }
        modify(ShortcutDimCode3)
        {
            Visible = true;
        }
        modify(ShortcutDimCode4)
        {
            Visible = true;
        }

        movebefore(Description; ShortcutDimCode3)
        //movebefore(ShortcutDimCode4; ShortcutDimCode3)
        addafter(ShortcutDimCode3)
        {
            field("FTT-CST Parent Item Cat. Code"; Rec."FTT-CST Parent Item Cat. Code")
            {
                ApplicationArea = all;
                Visible = false;
            }
            field("FTT-CST Sublocation"; Rec."FTT-CST Sublocation")
            {
                ApplicationArea = all;
                Visible = true;
            }
            field("FTT-CST Component Option"; Rec."FTT-CST Component Option")
            {
                ApplicationArea = all;
            }
        }
        modify("Line Discount Amount")
        {
            Visible = false;
        }
        //modify("Invoice Discount Amount")
        modify(Type) //NRD
        {
            Visible = true;
        }
        addafter(Description)
        {

            field("FTT-CST Optional"; Rec."FTT-CST Optional")
            {
                ApplicationArea = All;
                Editable = false;
                Visible = true;
            }
            field("FTT-CST Redundancy"; Rec."FTT-CST Redundancy")
            {
                ApplicationArea = all;
                Visible = false;
            }
            field("FTT-CST DR"; Rec."FTT-CST DR")
            {
                ApplicationArea = all;
                Visible = false;
            }
            field("FTT-CST Redundancy PriceCalc %"; Rec."FTT-CST Redundancy PriceCalc %")
            {
                ApplicationArea = all;
                Visible = false;
            }
            field("FTT-CST Location Code"; Rec."FTT-CST Location Code")
            {
                ApplicationArea = all;
                Visible = false;
            }
        }
        addbefore(Quantity)
        {

            field("FTT-CST Unit Price"; Rec."FTT-CST Unit Price")
            {
                ApplicationArea = all;
                Caption = 'Unit Price';
                Visible = true;
                DecimalPlaces = 2 : 2;
                trigger OnValidate()
                var
                begin
                    if rec.Type = rec.Type::"G/L Account" then begin //NRD - Commission
                        rec.Validate("Unit Price", rec."FTT-CST Unit Price");
                        rec.Modify();
                    end;
                end;
            }
            field("FTT-CST Delivery PROD Date"; Rec."FTT-CST Delivery PROD Date")
            {
                ApplicationArea = All;
                Editable = Rec.Type = "Sales Line Type"::Item;
                Visible = false;
                ToolTip = 'Specifies an ending date of the agreement period for the line.';
            }
            field("FTT-CST Delivery UAT Date"; Rec."FTT-CST Delivery UAT Date")
            {
                ApplicationArea = All;
                Visible = false;
                Editable = Rec.Type = "Sales Line Type"::Item;
                ToolTip = 'Specifies an ending date of the agreement period for the line.';
            }
            field("FTT-CST Agreement Date To"; Rec."FTT-CST Agreement Date To")
            {
                ApplicationArea = All;
                Visible = false;
                Editable = Rec.Type = "Sales Line Type"::Item;
                ToolTip = 'Specifies an ending date of the agreement period for the line.';
            }

        }
        addafter("Line Amount")
        {
            field("FTT-CST Cost Type"; Rec."FTT-CST Cost Type")
            {
                ApplicationArea = All;
                Width = 8;
                Visible = true;
                HideValue = Rec.Type <> "Sales Line Type"::Item;
                ToolTip = 'Specifies a cost type of the item.';
            }
            field("FTT-CST Agreement Date From"; Rec."FTT-CST Agreement Date From")
            {
                ApplicationArea = all;
            }
            field("FTT-CST Comments Fluent"; Rec."FTT-CST Comments Fluent")
            {
                ApplicationArea = All;
                Editable = true;
                width = 10;
            }
            field("FTT-CST Comments"; Rec."FTT-CST Comments")
            {
                ApplicationArea = All;
                Editable = true;
                width = 10;
            }
            field("Agreement Period"; Rec."Agreement Period")
            {
                ApplicationArea = all;
            }
        }

        // modify("No.") //NRD - Temporary Disabled
        // {
        //     trigger OnAfterValidate()
        //     begin
        //         Commit();
        //         Clear(RecurringItemSalesMng);
        //         if RecurringItemSalesMng.CheckItemSalesType(Rec, "FTT-CST Stn. Item Sales Type"::"Always Ask") then
        //             RecurringItemSalesMng.InsertSalesLines(Rec, "FTT-CST Stn. Item Sales Type"::"Always Ask")
        //         else
        //             if RecurringItemSalesMng.CheckItemSalesType(Rec, "FTT-CST Stn. Item Sales Type"::Automatic) then
        //                 RecurringItemSalesMng.InsertSalesLines(Rec, "FTT-CST Stn. Item Sales Type"::Automatic);
        //     end;
        // }
        moveafter(Description; ShortcutDimCode3)
    }

    actions
    {
        addlast("F&unctions")
        {
            action("FTT-CST Get Rec. Item SL")
            {
                ApplicationArea = All;
                Caption = 'Get Recurring Item Sales Lines';
                Enabled = Rec.Type = "Sales Line Type"::Item;
                Image = ItemWorksheet;
                ToolTip = 'View a list of the standard sales lines that have been assigned to the item to be used for recurring sales.';

                trigger OnAction()
                begin
                    Clear(RecurringItemSalesMng);
                    RecurringItemSalesMng.InsertSalesLines(Rec, "FTT-CST Stn. Item Sales Type"::Manual);
                end;
            }

            action("FTT-CST Add Redundancy Line")
            {
                ApplicationArea = All;
                Caption = 'Add Redundancy Item Line';
                Image = ItemReservation;
                ToolTip = 'Insert a redundancy item with automatic price calculation.';

                trigger OnAction()
                var
                    FTTCSTCalculateRedundancy: Codeunit "FTT-CST CalculateRedundancy";
                begin
                    FTTCSTCalculateRedundancy.CalculateRedundancy(Rec."Document Type", Rec."Document No.");
                end;
            }
            action("FTT-CST Add DR Line")
            {
                ApplicationArea = All;
                Caption = 'Add DR Item Line';
                Image = ItemReservation;
                ToolTip = 'Insert a dr item with automatic price calculation.';

                trigger OnAction()
                var
                    FTTCSTCalculateRedundancy: Codeunit "FTT-CST CalculateRedundancy";
                begin
                    FTTCSTCalculateRedundancy.CalculateDR(Rec."Document Type", Rec."Document No.");
                end;
            }
            action("FTT-CST Add Integration Line")
            {
                ApplicationArea = All;
                Caption = 'Add Integration Item Line';
                //Image = ItemReservation;
                ToolTip = 'Insert a Integration item with automatic price calculation.';

                trigger OnAction()
                var
                    FTTCSTCalculateRedundancy: Codeunit "FTT-CST CalculateRedundancy";
                begin
                    FTTCSTCalculateRedundancy.CalculateInt(Rec."Document Type", Rec."Document No.");
                end;
            }
        }
    }

    var
        RecurringItemSalesMng: Codeunit "FTT-CST RecurringItemSalesMng";
}
