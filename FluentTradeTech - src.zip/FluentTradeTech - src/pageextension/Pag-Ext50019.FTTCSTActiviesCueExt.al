pageextension 50019 "0365ExtPage" extends "O365 Activities"
{
    layout
    {
        addafter("Ongoing Sales Invoices")
        {
            field("Ongoing Sales Credit Memo"; Rec."Ongoing Sales Credit Memo")
            {
                ApplicationArea = Basic, Suite;
                Caption = 'Sales Credit Memos';
                DrillDownPageID = "Sales Credit Memos";
                ToolTip = 'Specifies sales credit memo that are not yet posted or only partially posted.';
            }
            field("Ongoing Sales Return Order"; Rec."Ongoing Sales Return Order")
            {
                ApplicationArea = Basic, Suite;
                Caption = 'Sales Return Orders';
                DrillDownPageID = "Sales Return Order List";
                ToolTip = 'Specifies Sales Return Order that are not yet posted or only partially posted.';
            }
        }
    }

    actions
    {
        // Add changes to page actions here
    }

    var
        myInt: Integer;
}