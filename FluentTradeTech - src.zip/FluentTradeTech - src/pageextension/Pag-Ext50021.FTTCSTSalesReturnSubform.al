pageextension 50021 "FTT-CST SalesReturnSubform" extends "Sales Return Order Subform"
{

    layout
    {
        modify(FilteredTypeField)
        {
            Visible = false;
        }
        modify("Item Reference No.")
        {
            Visible = false;
        }
        modify("Allow Invoice Disc.")
        {
            Visible = true;
        }
        modify("Allow Item Charge Assignment")
        {
            visible = false;
        }
        modify("Unit Price")
        {
            Visible = false;
        }
        modify("Inv. Discount Amount")
        {
            Editable = false;
            Visible = false;
        }
        modify("Invoice Discount Amount")
        {
            Editable = false;
            Caption = 'Discount Amount';
            Visible = true;
        }
        modify("Total Amount Incl. VAT")
        {
            Editable = false;
        }
        modify(ShortcutDimCode3)
        {
            Visible = true;
        }
        modify(ShortcutDimCode4)
        {
            Visible = true;
        }

        movebefore(Description; ShortcutDimCode3)
        //movebefore(ShortcutDimCode4; ShortcutDimCode3)
        addafter(ShortcutDimCode3)
        {
            field("FTT-CST Parent Item Cat. Code"; Rec."FTT-CST Parent Item Cat. Code")
            {
                ApplicationArea = all;
                Visible = false;
            }
            field("FTT-CST Sublocation"; Rec."FTT-CST Sublocation")
            {
                ApplicationArea = all;
                Visible = true;
            }
            field("FTT-CST Component Option"; Rec."FTT-CST Component Option")
            {
                ApplicationArea = all;
            }
        }
        modify("Line Discount Amount")
        {
            Visible = false;
        }
        //modify("Invoice Discount Amount")

        addafter(Description)
        {

            field("FTT-CST Optional"; Rec."FTT-CST Optional")
            {
                ApplicationArea = All;
                Editable = false;
                Visible = true;
            }
            field("FTT-CST Redundancy"; Rec."FTT-CST Redundancy")
            {
                ApplicationArea = all;
                Visible = false;
            }
            field("FTT-CST DR"; Rec."FTT-CST DR")
            {
                ApplicationArea = all;
                Visible = false;
            }
            field("FTT-CST Redundancy PriceCalc %"; Rec."FTT-CST Redundancy PriceCalc %")
            {
                ApplicationArea = all;
                Visible = false;
            }
            field("FTT-CST Location Code"; Rec."FTT-CST Location Code")
            {
                ApplicationArea = all;
                Visible = false;
            }
        }
        addbefore(Quantity)
        {

            field("FTT-CST Unit Price"; Rec."FTT-CST Unit Price")
            {
                ApplicationArea = all;
                Caption = 'Unit Price';
                Visible = true;
                DecimalPlaces = 2 : 2;
            }
            field("FTT-CST Delivery PROD Date"; Rec."FTT-CST Delivery PROD Date")
            {
                ApplicationArea = All;
                Editable = Rec.Type = "Sales Line Type"::Item;
                Visible = false;
                ToolTip = 'Specifies an ending date of the agreement period for the line.';
            }
            field("FTT-CST Delivery UAT Date"; Rec."FTT-CST Delivery UAT Date")
            {
                ApplicationArea = All;
                Visible = false;
                Editable = Rec.Type = "Sales Line Type"::Item;
                ToolTip = 'Specifies an ending date of the agreement period for the line.';
            }
            field("FTT-CST Agreement Date To"; Rec."FTT-CST Agreement Date To")
            {
                ApplicationArea = All;
                Visible = false;
                Editable = Rec.Type = "Sales Line Type"::Item;
                ToolTip = 'Specifies an ending date of the agreement period for the line.';
            }

        }
        addafter("Line Amount")
        {
            field("FTT-CST Cost Type"; Rec."FTT-CST Cost Type")
            {
                ApplicationArea = All;
                Width = 8;
                Visible = true;
                HideValue = Rec.Type <> "Sales Line Type"::Item;
                ToolTip = 'Specifies a cost type of the item.';
            }
            field("FTT-CST Agreement Date From"; Rec."FTT-CST Agreement Date From")
            {
                ApplicationArea = all;
            }
            field("FTT-CST Comments Fluent"; Rec."FTT-CST Comments Fluent")
            {
                ApplicationArea = All;
                Editable = true;
                width = 10;
            }
            field("FTT-CST Comments"; Rec."FTT-CST Comments")
            {
                ApplicationArea = All;
                Editable = true;
                width = 10;
            }
        }


        addbefore(SubtotalExclVAT)
        {
            field("FTT License Sales"; LicenseSalesAmount)
            {
                Caption = 'License';
                ApplicationArea = all;
                Editable = false;
            }
            field("FTT Feed Sales"; FeedSalesAmount)
            {
                Caption = 'Feed';
                ApplicationArea = all;
                Editable = false;
            }
            field("FTT Redundancy Sales"; RedundancySalesAmount)
            {
                Caption = 'Redundancy';
                ApplicationArea = all;
                Editable = false;
            }
            field("FTT DR Sales"; DRSalesAmoount)
            {
                Caption = 'DR';
                ApplicationArea = all;
                Editable = false;
            }
            field("FTT DR Integration"; IntegrationSalesAmount)
            {
                Caption = 'Integration';
                ApplicationArea = all;
                Editable = false;
            }
            field("Hardware + Setup Sales"; SetupSalesAmount)
            {
                Caption = 'Hardware + Setup';
                ApplicationArea = all;
                Editable = false;
            }
            field("Hosting Management Sales"; HostingSalesAmount)
            {
                Caption = 'Hosting & Management';
                ApplicationArea = all;
                Editable = false;
            }
            field("Cross Сonnects - Total"; CrossConnectSalesAmount)
            {
                Caption = 'Connectivity';
                ApplicationArea = all;
                Editable = false;
            }
        }
        addafter("Total Amount Incl. VAT")
        {
            group(gr1)
            {
                ShowCaption = false;
                field("NRC Sales"; NRCSales)
                {
                    Caption = 'NRC';
                    ApplicationArea = all;
                    Editable = false;
                }
                field("MRC Sales"; WRCSales)
                {
                    Caption = 'YRC';
                    ApplicationArea = all;
                    Editable = false;
                }
            }
        }
        modify("Invoice Disc. Pct.")
        {
            Editable = true;
            trigger OnAfterValidate()
            begin
                CalculateLicenseSales(LicenseSalesAmount);
                CalculateFeedSales(FeedSalesAmount);
                CalculateRedundencySales(RedundancySalesAmount);
                CalculateDRSales(DRSalesAmoount);
                CalculateSetupSales(SetupSalesAmount);
                CalculateHostingSales(HostingSalesAmount);
                CalculateCrossConnectSales(CrossConnectSalesAmount);
                CalculateIntegrationSales(IntegrationSalesAmount);
                CalculateNRCWRC(NRCSales, WRCSales);
            end;
        }
    }
    actions
    {

        modify(Dimensions)
        {
            Visible = true;
        }

        addlast("&Line")
        {

            action("FTT-CST Add Redundancy Line")
            {
                ApplicationArea = All;
                Caption = 'Add Redundancy Item Line';
                Visible = true;
                Image = ItemReservation;
                ToolTip = 'Insert a redundancy item with automatic price calculation.';

                trigger OnAction()
                var
                    FTTCSTCalculateRedundancy: Codeunit "FTT-CST CalculateRedundancy";
                begin
                    FTTCSTCalculateRedundancy.CalculateRedundancy(Rec."Document Type", Rec."Document No.");
                end;
            }
            action("FTT-CST Add DR Line")
            {
                ApplicationArea = All;
                Caption = 'Add DR Item Line';
                Visible = true;
                //Image = Item;
                ToolTip = 'Insert a dr item with automatic price calculation.';

                trigger OnAction()
                var
                    FTTCSTCalculateRedundancy: Codeunit "FTT-CST CalculateRedundancy";
                begin
                    FTTCSTCalculateRedundancy.CalculateDR(Rec."Document Type", Rec."Document No.");
                end;
            }
            action("FTT-CST Add Integration Line")
            {
                ApplicationArea = All;
                Caption = 'Add Integration Item Line';
                Visible = true;
                //Image = ItemReservation;
                ToolTip = 'Insert a Integration item with automatic price calculation.';

                trigger OnAction()
                var
                    FTTCSTCalculateRedundancy: Codeunit "FTT-CST CalculateRedundancy";
                begin
                    FTTCSTCalculateRedundancy.CalculateInt(Rec."Document Type", Rec."Document No.");
                end;
            }
            action("FTT-CST Remove Connection")
            {
                ApplicationArea = All;
                Caption = 'Remove Connection to P. Sales Invoice';
                Visible = true;
                Image = RemoveLine;
                ToolTip = 'Remove a connection to linked Posted Sales Invoice.';

                trigger OnAction()
                var
                    recCrosConnection: Record "FTT-CST Cross Connect Lines";
                    recCrosConnectionTemp: Record "FTT-CST Cross ConnectLnsTemp";
                    pagCrossConnect: page "FTT-CST Cross ConnectLinesTemp";
                    recSalesLine: Record "Sales Line";
                    recPostedSalesHdr: Record "Sales Invoice Header";
                    SharedNRCQty: Decimal;
                    SharedMRCQty: Decimal;
                    DedicatedNRDQty: Decimal;
                    DedicatedMRCQty: Decimal;
                    Item: Record Item;
                begin
                    clear(pagCrossConnect);
                    SharedNRCQty := 0;
                    SharedMRCQty := 0;
                    DedicatedMRCQty := 0;
                    DedicatedNRDQty := 0;

                    recCrosConnectionTemp.DeleteAll();
                    if Rec.FindSet() then
                        repeat
                            if recPostedSalesHdr.get(Rec."FTT-CST Copied Document No.") then begin
                                recCrosConnection.Reset();
                                recCrosConnection.SetRange("Document Type", recCrosConnection."Document Type"::Order);
                                recCrosConnection.SetRange("Document No.", recPostedSalesHdr."Order No.");
                                recCrosConnection.SetRange("Item No.", Rec."No.");
                                recCrosConnection.SetRange("FTT-CST Location Code", Rec."FTT-CST Location Code");
                                if recCrosConnection.FindFirst() then begin
                                    recCrosConnectionTemp.Init();
                                    recCrosConnectionTemp.TransferFields(recCrosConnection);
                                    recCrosConnectionTemp.Insert();
                                end;
                            end;
                        until Rec.Next() = 0;
                    Commit();

                    recCrosConnectionTemp.Reset();
                    recCrosConnectionTemp.SetRange("Document Type", recCrosConnectionTemp."Document Type");
                    recCrosConnectionTemp.SetRange("Document No.", recPostedSalesHdr."Order No.");
                    recCrosConnectionTemp.FindSet();

                    pagCrossConnect.LookupMode(true);
                    pagCrossConnect.SetTableView(recCrosConnectionTemp);
                    if pagCrossConnect.RunModal() = Action::LookupOK then begin
                        pagCrossConnect.GetRecord(recCrosConnectionTemp);
                        if recCrosConnectionTemp.FindSet() then
                            repeat

                                recCrosConnection.Reset();
                                recCrosConnection.SetRange("Document Type", recCrosConnection."Document Type"::Order);
                                recCrosConnection.SetRange("Document No.", recCrosConnectionTemp."Document No.");
                                recCrosConnection.SetRange("Item No.", recCrosConnectionTemp."Item No.");
                                recCrosConnection.SetRange("FTT-CST Location Code", recCrosConnectionTemp."FTT-CST Location Code");
                                if recCrosConnection.FindFirst() then begin

                                    if recCrosConnection."Quantity 1" <> recCrosConnectionTemp."Quantity 1" then begin //SHARED MRC
                                        if recCrosConnectionTemp."Quantity 1" = 0 then
                                            SharedMRCQty += recCrosConnection."Quantity 1"
                                        else
                                            SharedMRCQty += (recCrosConnection."Quantity 1" - recCrosConnectionTemp."Quantity 1");

                                        Commit();
                                        recCrosConnection."Quantity 1" := recCrosConnectionTemp."Quantity 1";
                                        Message('Succesfully Removed the Cross Connect for this item %1!', recCrosConnectionTemp."Item No.");
                                    end;

                                    if recCrosConnection."Quantity 2" <> recCrosConnectionTemp."Quantity 2" then begin //DEDICATED MRC
                                        if recCrosConnectionTemp."Quantity 2" = 0 then
                                            DedicatedMRCQty += recCrosConnection."Quantity 2"
                                        else
                                            DedicatedMRCQty += (recCrosConnection."Quantity 2" - recCrosConnectionTemp."Quantity 2");
                                        Commit();

                                        recCrosConnection."Quantity 2" := recCrosConnectionTemp."Quantity 2";
                                        Message('Succesfully Removed the Cross Connect for this item %1!', recCrosConnectionTemp."Item No.");
                                    end;

                                    if recCrosConnection."Quantity 3" <> recCrosConnectionTemp."Quantity 3" then begin     //SHARED NRC
                                        if recCrosConnectionTemp."Quantity 3" = 0 then
                                            SharedNRCQty += recCrosConnection."Quantity 3"
                                        else
                                            SharedNRCQty += (recCrosConnection."Quantity 3" - recCrosConnectionTemp."Quantity 3");
                                        Commit();

                                        recCrosConnection."Quantity 3" := recCrosConnectionTemp."Quantity 3";
                                        Message('Succesfully Removed the Cross Connect for this item %1!', recCrosConnectionTemp."Item No.");
                                    end;

                                    if recCrosConnection."Quantity 4" <> recCrosConnectionTemp."Quantity 4" then begin  //DEDICATED NRC
                                        if recCrosConnectionTemp."Quantity 4" = 0 then
                                            DedicatedNRDQty += recCrosConnection."Quantity 4"
                                        else
                                            DedicatedNRDQty += (recCrosConnection."Quantity 4" - recCrosConnectionTemp."Quantity 4");
                                        Commit();

                                        recCrosConnection."Quantity 4" := recCrosConnectionTemp."Quantity 4";

                                        Message('Succesfully Removed the Cross Connect for this item %1!', recCrosConnectionTemp."Item No.");
                                    end;

                                    recCrosConnection.Modify();
                                end;

                            until recCrosConnectionTemp.Next() = 0;

                        if SharedMRCQty <> 0 then begin
                            if Item.Get('1101') then
                                CreateDocumentLine(rec."Document Type", rec."Document No.", '1101', Item."Unit Price", SharedMRCQty, true, Item."FTT-CST Cost Type");
                        end;

                        if SharedNRCQty <> 0 then begin
                            if Item.Get('1103') then
                                CreateDocumentLine(rec."Document Type", rec."Document No.", '1103', Item."Unit Price", SharedNRCQty, false, Item."FTT-CST Cost Type");
                        end;

                        if DedicatedMRCQty <> 0 then begin
                            if Item.Get('1102') then
                                CreateDocumentLine(rec."Document Type", rec."Document No.", '1102', Item."Unit Price", DedicatedMRCQty, true, Item."FTT-CST Cost Type");
                        end;

                        if DedicatedNRDQty <> 0 then begin
                            if Item.Get('1104') then
                                CreateDocumentLine(rec."Document Type", rec."Document No.", '1104', Item."Unit Price", DedicatedNRDQty, false, Item."FTT-CST Cost Type");
                        end;

                        CurrPage.Update(false);
                    end;

                end;
            }//+
        }


    }
    //NRD
    local procedure CreateDocumentLine(DocumentType: Enum "Sales Document Type"; DocumentNo: Code[20]; ItemNo: Code[20]; UnitPrice: Decimal; Qty: Decimal; MRC: Boolean; CostType2: Enum "FTT-CST Cost Type")
    var
        SalesLine: Record "Sales Line";
        MRCAmount: Decimal;
        SalesLineLast2: Record "Sales Line";
        item_l: Record Item;
        ItemCategory_l: Record "Item Category";
    begin
        SalesLine.Init();
        SalesLine."Document Type" := DocumentType;
        SalesLine."Document No." := DocumentNo;
        SalesLine."Line No." := GetLineNo(DocumentType, DocumentNo, SalesLineLast2);
        SalesLine.Validate(Type, "Sales Line Type"::Item);
        SalesLine.Validate("No.", ItemNo);
        if MRC then begin
            SalesLine.Validate(Quantity, Qty);
            MRCAmount := (UnitPrice * Qty) * 12;
            SalesLine.Validate("Unit Price", (MRCAmount / Qty));
            SalesLine.Validate("FTT-CST Unit Price", UnitPrice);
        end else begin
            SalesLine.Validate("Unit Price", UnitPrice);
            SalesLine.Validate("FTT-CST Unit Price", UnitPrice);
            SalesLine.Validate(Quantity, Qty);
        end;

        //NRD
        if item_l.Get(ItemNo) then
            if ItemCategory_l.Get(item_l."Item Category Code") then
                SalesLine."FTT-CST Parent Item Cat. Code" := ItemCategory_l."Parent Category";
        //NRD

        SalesLine."FTT-CST Location Code" := SalesLineLast2."FTT-CST Location Code";
        SalesLine.ValidateShortcutDimCode(3, SalesLineLast2."FTT-CST Location Code");
        SalesLine."FTT-CST Sublocation" := SalesLineLast2."FTT-CST Sublocation";
        SalesLine."FTT-CST Component Option" := SalesLineLast2."FTT-CST Component Option";
        SalesLine."FTT-CST Cost Type" := CostType2;
        SalesLine.Validate("FTT-CST Agreement Date From", SalesLineLast2."FTT-CST Agreement Date From");
        SalesLine.Validate("FTT-CST Agreement Date To", SalesLineLast2."FTT-CST Agreement Date To");
        SalesLine.Insert(true);
    end;

    local procedure GetLineNo(DocumentType: Enum "Sales Document Type"; DocumentNo: Code[20]; var SalesLineLast: Record "Sales Line"): Integer
    var
        SalesLine: Record "Sales Line";
    begin
        SalesLine.SetRange("Document Type", DocumentType);
        SalesLine.SetRange("Document No.", DocumentNo);
        if SalesLine.FindLast() then begin
            SalesLineLast := SalesLine;
            exit(SalesLine."Line No." + 10000);
        end;
        exit(10000);
    end;
    //+
    var
        RecurringItemSalesMng: Codeunit "FTT-CST RecurringItemSalesMng";
        RedundancySalesAmount: Decimal;
        DRSalesAmoount: Decimal;
        SetupSalesAmount: Decimal;
        FeedSalesAmount: decimal;
        HostingSalesAmount: Decimal;
        LicenseSalesAmount: Decimal;
        CrossConnectSalesAmount: Decimal;
        IntegrationSalesAmount: Decimal;
        NRCSales: Decimal;
        WRCSales: Decimal;

    procedure CalculateLicenseSales(var pLicenseSalesAmount: Decimal)
    var
        SalesLine: record "Sales Line";
        SalesReceivables: record "Sales & Receivables Setup";
    begin
        SalesReceivables.Get();
        pLicenseSalesAmount := 0;
        SalesLine.SetRange("Document Type", Rec."Document Type");
        SalesLine.SetRange("Document No.", Rec."Document No.");
        SalesLine.SetRange("FTT-CST Parent Item Cat. Code", SalesReceivables."FTT-CST LICENSE");
        SalesLine.SetRange("FTT-CST Optional", SalesLine."FTT-CST Optional"::No); //NRD
        if SalesLine.FindSet() then
            repeat
                pLicenseSalesAmount := pLicenseSalesAmount + SalesLine."Line Amount";
            //pLicenseSalesAmount := pLicenseSalesAmount + SalesLine."Amount Including VAT";
            until SalesLine.next = 0;
        pLicenseSalesAmount := pLicenseSalesAmount * (100 - InvoiceDiscountPct) / 100;
    end;

    procedure CalculateFeedSales(var pFeedSalesAmount: Decimal)
    var
        SalesLine: record "Sales Line";
        SalesReceivables: Record "Sales & Receivables Setup";
    begin
        SalesReceivables.Get();
        pFeedSalesAmount := 0;
        SalesLine.SetRange("Document Type", Rec."Document Type");
        SalesLine.SetRange("Document No.", Rec."Document No.");
        SalesLine.SetRange("FTT-CST Parent Item Cat. Code", SalesReceivables."FTT-CST Parent FEED");
        SalesLine.SetRange("FTT-CST Optional", SalesLine."FTT-CST Optional"::No); //NRD
        if SalesLine.FindSet() then
            repeat
                pFeedSalesAmount := pFeedSalesAmount + SalesLine."Line Amount";
            until SalesLine.next = 0;
        pFeedSalesAmount := pFeedSalesAmount * (100 - InvoiceDiscountPct) / 100;
    end;

    procedure CalculateRedundencySales(var pSalesAmount: Decimal)
    var
        SalesLine: record "Sales Line";
        SalesReceivables: record "Sales & Receivables Setup";
    begin
        SalesReceivables.Get();
        pSalesAmount := 0;
        SalesLine.SetRange("Document Type", Rec."Document Type");
        SalesLine.SetRange("Document No.", Rec."Document No.");
        SalesLine.SetRange("FTT-CST Parent Item Cat. Code", SalesReceivables."FTT-CST Redundancy Category");
        SalesLine.SetRange("FTT-CST Optional", SalesLine."FTT-CST Optional"::No); //NRD
        if SalesLine.FindSet() then
            repeat
                pSalesAmount := pSalesAmount + SalesLine."Line Amount";
            until SalesLine.next = 0;
        pSalesAmount := pSalesAmount * (100 - InvoiceDiscountPct) / 100;
    end;

    procedure CalculateDRSales(var pSalesAmount: Decimal)
    var
        SalesLine: record "Sales Line";
        SalesReceivables: record "Sales & Receivables Setup";
    begin
        SalesReceivables.Get();
        pSalesAmount := 0;
        SalesLine.SetRange("Document Type", Rec."Document Type");
        SalesLine.SetRange("Document No.", Rec."Document No.");
        SalesLine.SetRange("FTT-CST Parent Item Cat. Code", SalesReceivables."FTT-CST DR Category");
        SalesLine.SetRange("FTT-CST Optional", SalesLine."FTT-CST Optional"::No); //NRD
        if SalesLine.FindSet() then
            repeat
                pSalesAmount := pSalesAmount + SalesLine."Line Amount";
            until SalesLine.next = 0;
        pSalesAmount := pSalesAmount * (100 - InvoiceDiscountPct) / 100;
    end;

    procedure CalculateSetupSales(var pSalesAmount: Decimal)
    var
        SalesLine: record "Sales Line";
        SalesReceivables: record "Sales & Receivables Setup";
    begin
        SalesReceivables.Get();
        pSalesAmount := 0;
        SalesLine.SetRange("Document Type", Rec."Document Type");
        SalesLine.SetRange("Document No.", Rec."Document No.");
        //SalesLine.SetRange("FTT-CST Parent Item Cat. Code", 'HARDWARE');
        SalesLine.SetRange("FTT-CST Parent Item Cat. Code", SalesReceivables."FTT-CST HARDWARE");
        SalesLine.SetRange("FTT-CST Optional", SalesLine."FTT-CST Optional"::No); //NRD
        if SalesLine.FindSet() then
            repeat
                pSalesAmount := pSalesAmount + SalesLine."Line Amount";
            until SalesLine.next = 0;
        //pSalesAmount := pSalesAmount * (100 - InvoiceDiscountPct) / 100;
    end;

    procedure CalculateHostingSales(var pSalesAmount: Decimal)
    var
        SalesLine: record "Sales Line";
        SalesReceivables: record "Sales & Receivables Setup";
    begin
        SalesReceivables.Get();
        pSalesAmount := 0;
        SalesLine.SetRange("Document Type", Rec."Document Type");
        SalesLine.SetRange("Document No.", Rec."Document No.");
        SalesLine.SetRange("FTT-CST Parent Item Cat. Code", SalesReceivables."FTT-CST Hosting and management");
        SalesLine.SetRange("FTT-CST Optional", SalesLine."FTT-CST Optional"::No); //NRD
        if SalesLine.FindSet() then
            repeat
                pSalesAmount := pSalesAmount + SalesLine."Line Amount";
            until SalesLine.next = 0;
        //pSalesAmount := pSalesAmount * (100 - InvoiceDiscountPct) / 100;
    end;

    procedure CalculateCrossConnectSales(var pSalesAmount: Decimal)
    var
        SalesLine: record "Sales Line";
        SalesReceivables: Record "Sales & Receivables Setup";
    begin
        SalesReceivables.Get();
        pSalesAmount := 0;
        SalesLine.SetRange("Document Type", Rec."Document Type");
        SalesLine.SetRange("Document No.", Rec."Document No.");
        SalesLine.SetRange("FTT-CST Parent Item Cat. Code", SalesReceivables."FTT-CST Parent CROSS CONNECT");
        SalesLine.SetRange("FTT-CST Optional", SalesLine."FTT-CST Optional"::No); //NRD
        if SalesLine.FindSet() then
            repeat
                pSalesAmount := pSalesAmount + SalesLine."Line Amount";
            until SalesLine.next = 0;
        //pSalesAmount := pSalesAmount * (100 - InvoiceDiscountPct) / 100;

        SalesLine.RESET;
        SalesLine.SetRange("Document Type", Rec."Document Type");
        SalesLine.SetRange("Document No.", Rec."Document No.");
        SalesLine.SetRange("FTT-CST Parent Item Cat. Code", SalesReceivables."FTT-CST INTERNATIONAL Line");
        SalesLine.SetRange("FTT-CST Optional", SalesLine."FTT-CST Optional"::No); //NRD
        if SalesLine.FindSet() then
            repeat
                pSalesAmount := pSalesAmount + SalesLine."Line Amount";
            until SalesLine.next = 0;
        //pSalesAmount := pSalesAmount * (100 - InvoiceDiscountPct) / 100;
    end;

    procedure CalculateIntegrationSales(var pSalesAmount: Decimal)
    var
        SalesLine: record "Sales Line";
        SalesReceivables: record "Sales & Receivables Setup";
    begin
        SalesReceivables.Get();
        pSalesAmount := 0;

        SalesLine.SetRange("Document Type", Rec."Document Type");
        SalesLine.SetRange("Document No.", Rec."Document No.");
        SalesLine.SetRange("FTT-CST Parent Item Cat. Code", SalesReceivables."FTT-CST Integration Category");
        SalesLine.SetRange("FTT-CST Optional", SalesLine."FTT-CST Optional"::No); //NRD
        if not SalesLine.FindSet() then
            pSalesAmount := 0;

        if SalesLine.FindSet() then
            repeat
                pSalesAmount := pSalesAmount + SalesLine."Line Amount";
            until SalesLine.next = 0;

        //pSalesAmount := pSalesAmount * (100 - InvoiceDiscountPct) / 100;
    end;

    procedure CalculateNRCWRC(var pNRCSalesAmount: Decimal; var pWRCSalesAmount: Decimal)
    var
        SalesLine: record "Sales Line";
    begin
        pNRCSalesAmount := 0;
        pWRCSalesAmount := 0;

        SalesLine.SetRange("Document Type", Rec."Document Type");
        SalesLine.SetRange("Document No.", Rec."Document No.");
        SalesLine.SetRange("FTT-CST Optional", SalesLine."FTT-CST Optional"::No); //NRD
        if not SalesLine.FindSet() then
            pNRCSalesAmount := 0;

        if SalesLine.FindSet() then
            repeat
                if SalesLine."FTT-CST Cost Type" = SalesLine."FTT-CST Cost Type"::NRC then
                    pNRCSalesAmount := pNRCSalesAmount + SalesLine."Line Amount" else
                    pWRCSalesAmount := pWRCSalesAmount + SalesLine."Line Amount";
            until SalesLine.next = 0;

        //pNRCSalesAmount := pNRCSalesAmount * (100 - InvoiceDiscountPct) / 100;
        //pWRCSalesAmount := pWRCSalesAmount * (100 - InvoiceDiscountPct) / 100;
        pWRCSalesAmount := pWRCSalesAmount - InvoiceDiscountAmount;
    end;

    trigger OnAfterGetRecord()
    begin
        CalculateLicenseSales(LicenseSalesAmount);
        CalculateFeedSales(FeedSalesAmount);
        CalculateRedundencySales(RedundancySalesAmount);
        CalculateDRSales(DRSalesAmoount);
        CalculateSetupSales(SetupSalesAmount);
        CalculateHostingSales(HostingSalesAmount);
        CalculateCrossConnectSales(CrossConnectSalesAmount);
        CalculateIntegrationSales(IntegrationSalesAmount);
        CalculateNRCWRC(NRCSales, WRCSales);
        //CurrPage.Update();
    end;

    trigger OnAfterGetCurrRecord()
    begin
        CalculateLicenseSales(LicenseSalesAmount);
        CalculateFeedSales(FeedSalesAmount);
        CalculateRedundencySales(RedundancySalesAmount);
        CalculateDRSales(DRSalesAmoount);
        CalculateSetupSales(SetupSalesAmount);
        CalculateHostingSales(HostingSalesAmount);
        CalculateCrossConnectSales(CrossConnectSalesAmount);
        CalculateIntegrationSales(IntegrationSalesAmount);
        CalculateNRCWRC(NRCSales, WRCSales);
        //CurrPage.Update();
    end;

    trigger OnDeleteRecord(): Boolean
    begin
        IntegrationSalesAmount := 0;
        CrossConnectSalesAmount := 0;
        LicenseSalesAmount := 0;
        CalculateLicenseSales(LicenseSalesAmount);
        CalculateFeedSales(FeedSalesAmount);
        CalculateRedundencySales(RedundancySalesAmount);
        CalculateDRSales(DRSalesAmoount);
        CalculateSetupSales(SetupSalesAmount);
        CalculateHostingSales(HostingSalesAmount);
        CalculateCrossConnectSales(CrossConnectSalesAmount);
        CalculateIntegrationSales(IntegrationSalesAmount);
        CalculateNRCWRC(NRCSales, WRCSales);

        //CurrPage.Update();
    end;

    trigger OnModifyRecord(): Boolean
    begin
        CalculateLicenseSales(LicenseSalesAmount);
        CalculateFeedSales(FeedSalesAmount);
        CalculateRedundencySales(RedundancySalesAmount);
        CalculateDRSales(DRSalesAmoount);
        CalculateSetupSales(SetupSalesAmount);
        CalculateHostingSales(HostingSalesAmount);
        CalculateCrossConnectSales(CrossConnectSalesAmount);
        CalculateIntegrationSales(IntegrationSalesAmount);
        CalculateNRCWRC(NRCSales, WRCSales);
    end;
}