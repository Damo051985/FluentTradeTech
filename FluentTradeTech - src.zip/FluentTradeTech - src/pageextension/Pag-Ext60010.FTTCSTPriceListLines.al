pageextension 60010 "FTT-CST PriceListLines" extends "Price List Lines"
{
    layout
    {
        addafter("Unit Price")
        {
            field("FTT-CST Cost Type"; Rec."FTT-CST Optional for PI")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies optional lines for pricing indication document.';
            }
        }

        modify("Asset No.")
        {
            trigger OnAfterValidate()
            begin
                Commit();
                CheckItemPriceType();
            end;
        }

        modify("Product No.")
        {
            trigger OnAfterValidate()
            begin
                Commit();
                CheckItemPriceType();
            end;
        }
    }

    actions
    {
        addlast(Processing)
        {
            action("FTT-CST Get Rec. Item SL")
            {
                ApplicationArea = All;
                Caption = 'Get Recurring Item Sales Lines';
                Enabled = Rec."Asset Type" = "Price Asset Type"::Item;
                Image = ItemWorksheet;
                ToolTip = 'View a list of the standard sales lines that have been assigned to the item to be used for recurring sales.';

                trigger OnAction()
                begin
                    Clear(RecurringItemSalesMng);
                    RecurringItemSalesMng.InsertPriceLines(Rec, "FTT-CST Stn. Item Sales Type"::Manual);
                end;
            }
        }
    }

    local procedure CheckItemPriceType()
    begin
        Clear(RecurringItemSalesMng);
        if RecurringItemSalesMng.CheckItemPriceType(Rec, "FTT-CST Stn. Item Sales Type"::"Always Ask") then
            RecurringItemSalesMng.InsertPriceLines(Rec, "FTT-CST Stn. Item Sales Type"::"Always Ask")
        else
            if RecurringItemSalesMng.CheckItemPriceType(Rec, "FTT-CST Stn. Item Sales Type"::Automatic) then
                RecurringItemSalesMng.InsertPriceLines(Rec, "FTT-CST Stn. Item Sales Type"::Automatic);
    end;

    var
        RecurringItemSalesMng: Codeunit "FTT-CST RecurringItemSalesMng";
}
