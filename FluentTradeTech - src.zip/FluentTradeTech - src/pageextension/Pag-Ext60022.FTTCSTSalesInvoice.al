pageextension 60022 "FTT-CST SalesInvoice" extends "Sales Invoice"
{
    layout
    {
        modify("Salesperson Code")
        {
            //FTTNimrod - 
            trigger OnAfterValidate()
            var
                RecSalesRep: Record "Responsibility Center";
                RecUserSetup: Record "User Setup";
                RecSalesHeader: Record "Sales Header";
            begin
                //CurrPage.SalesLines.Page.UpdateForm(true);
                CurrPage.SalesLines.Page.Update(false);
                CurrPage.Update(true);
                if not RecSalesHeader.get(rec."Document Type", rec."No.") then
                    exit;

                if RecUserSetup.Get(UserId) then
                    if RecUserSetup."Sales Resp. Ctr. Filter" = '' then begin
                        RecSalesRep.Reset();
                        RecSalesRep.SetRange(Code, rec."Salesperson Code");
                        RecSalesRep.SetFilter("Sales Manager ID", '<>%1', '');
                        if RecSalesRep.FindFirst() then begin
                            RecSalesHeader.Validate("Responsibility Center", RecSalesRep.Code);
                            RecSalesHeader.Modify();
                        end else begin
                            RecSalesHeader.Validate("Responsibility Center", '');
                            RecSalesHeader.Modify();
                        end;
                        Commit();

                        CurrPage.Update(false);
                    end;

            end;
            //+
        }
        addafter("Due Date")
        {
            field("FTT-CST Agr. Starting Date"; Rec."FTT-CST Agr. Starting Date")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies a starting date of the agreement.';
            }
            field("FTT-CST Agr. Ending Date"; Rec."FTT-CST Agr. Ending Date")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies an ending date of the agreement.';
            }
        }
    }

    actions
    {
        addafter(GetRecurringSalesLines)
        {
            action("FTT-CST Update Qty. for Agr")
            {
                ApplicationArea = All;
                Caption = 'Update Item Quantity for Agreement';
                Ellipsis = true;
                Image = UpdateUnitCost;
                ToolTip = 'Update Quantity based on the Agreement period and Item Type';

                trigger OnAction()
                begin
                    Rec.UpdateQuantity();
                end;
            }
        }
        addafter(GetRecurringSalesLines_Promoted)
        {
            actionref("FTT-CST Update Qty. for Agr_Promoted"; "FTT-CST Update Qty. for Agr")
            {
            }
        }
    }
}
