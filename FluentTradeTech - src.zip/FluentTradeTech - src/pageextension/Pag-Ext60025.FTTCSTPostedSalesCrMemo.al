pageextension 60025 "FTT-CST PostedSalesCrMemo" extends "Posted Sales Credit Memo"
{
    layout
    {
        addafter("Document Date")
        {
            field("FTT-CST Agr. Period Number"; Rec."FTT-CST Agr. Period Number")
            {
                ApplicationArea = All;
                Editable = false;
                ToolTip = 'Specifies a number of the agreement period for the document that was posted.';
            }
        }
    }
    actions
    {
        addafter("Update Document")
        {
            action(OpenCrossConnectRelated)
            {
                ApplicationArea = All;
                Caption = 'Open Cross Connect Related';
                Ellipsis = true;
                Promoted = true;
                PromotedIsBig = true;
                PromotedCategory = Process;
                Image = InteractionLog;
                ToolTip = 'Open Cross Connecte Related to this Document';

                trigger OnAction()
                var
                    pagCrossConnectCard: page "FTT-CST Cross Connect Card";
                    CrossConnectHdr: Record "FTT-CST Cross Connect Hdr";
                    recSalesPSCMLInes: Record "Sales Cr.Memo Line";
                    recSalesInvHdr: Record "Sales Invoice Header";
                begin
                    clear(pagCrossConnectCard);

                    recSalesPSCMLInes.Reset();
                    recSalesPSCMLInes.SetRange("Document No.", rec."No.");
                    recSalesPSCMLInes.SetRange("FTT-CST Copied Document Type", recSalesPSCMLInes."FTT-CST Copied Document Type"::"Posted Invoice");
                    if recSalesPSCMLInes.FindFirst() then begin
                        if recSalesInvHdr.Get(recSalesPSCMLInes."FTT-CST Copied Document No.") then begin
                            CrossConnectHdr.Reset();
                            CrossConnectHdr.SetRange("Document Type", CrossConnectHdr."Document Type"::Order);
                            CrossConnectHdr.SetRange("Document No.", recSalesInvHdr."Order No.");
                            CrossConnectHdr.SetRange("Customer No.", rec."Sell-to Customer No.");
                            if not CrossConnectHdr.FindFirst() then
                                Error('No Record Found!');

                            pagCrossConnectCard.SetRecord(CrossConnectHdr);
                            pagCrossConnectCard.Run();
                        end;
                    end;
                end;
            }
            //+
        }
    }
}
