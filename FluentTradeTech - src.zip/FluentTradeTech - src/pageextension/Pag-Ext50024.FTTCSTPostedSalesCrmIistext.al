pageextension 50024 "P. Sales Crmemo List Ext" extends "Posted Sales Credit Memos"
{
    layout
    {
        addafter("Remaining Amount")
        {
            field("Total Comm. Base Amt. (LCY)"; Rec."Total Comm. Base Amt. (LCY)")
            {
                ApplicationArea = all;
            }
            field("Total Comm. Base Amt."; Rec."Total Comm. Base Amt.")
            {
                ApplicationArea = all;
            }
        }
    }

    actions
    {
        // Add changes to page actions here
    }

    var
        myInt: Integer;
}