pageextension 60012 "FTT-CST SalesPriceLists" extends "Sales Price Lists"
{
    actions
    {
        addafter(Category_Report)
        {
            actionref(FTTCSTCreatePricingInd_Promoted; FTTCSTCreatePricingInd)
            {
            }
        }
        addlast(Reporting)
        {
            action(FTTCSTCreatePricingInd)
            {
                ApplicationArea = All;
                Caption = 'Create Pricing Indication';
                Ellipsis = true;
                Image = PrintCheck;
                ToolTip = 'Create a printed form of pricing indication';

                trigger OnAction()
                var
                    FTTCSTReportMng: Codeunit "FTT-CST ReportMng";
                begin
                    Clear(FTTCSTReportMng);
                    FTTCSTReportMng.ReportPricingIndicationTemplateSaveToWord(Rec);
                end;
            }
        }
    }
}
