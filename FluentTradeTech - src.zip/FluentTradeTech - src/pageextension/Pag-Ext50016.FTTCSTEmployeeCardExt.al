pageextension 50016 "Employee Card Ext." extends "Employee Card"
{
    layout
    {
        addafter("Company E-Mail")
        {
            field(Department; Rec.Department)
            {
                ApplicationArea = all;
            }
        }
        addafter("Phone No.")
        {
            field("Emergency Contact No."; Rec."Emergency Contact No.")
            {
                ApplicationArea = all;
            }
        }
        addafter("Privacy Blocked")
        {
            field("Allergies"; Rec."Allergies")
            {
                ApplicationArea = all;
                Visible = False;
            }
        }
    }

    actions
    {
        addFIRST("E&mployee")
        {
            action(Allergy)
            {
                ApplicationArea = All;
                Caption = 'Allergies';
                Promoted = True;
                PromotedCategory = "Category4";
                Image = Lock;
                RunObject = Page "FTT Allergies";
                RunPageLink = "Employee No." = field("No.");
                ToolTip = 'Open the list of any allergies that is registered for the employee.';
            }
        }

    }


    var
        myInt: Integer;
}