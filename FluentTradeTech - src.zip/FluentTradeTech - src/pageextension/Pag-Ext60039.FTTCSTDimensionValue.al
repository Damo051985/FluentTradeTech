pageextension 60039 "FTT-CST Dimension Values" extends "Dimension Values"
{
    layout
    {
        addafter("Dimension Value Type")
        {
            field("FTT-CST Sublocation"; Rec."FTT-CST Sublocation")
            {
                ApplicationArea = all;
            }
        }
        //>>Dan
        addafter("FTT-CST Sublocation")
        {
            field("Procuct category"; Rec."Product Category")
            {
                ApplicationArea = all;
            }
        }
        //<<dan
    }
}