pageextension 60043 "FTTCST-EmployeeList-EXT" extends "Employee List"
{
    actions
    {
        addFIRST("E&mployee")
        {
            action(Allergy)
            {
                ApplicationArea = All;
                Caption = 'Allergies';
                Image = Lock;
                RunObject = Page "FTT Allergies";
                RunPageLink = "Employee No." = field("No.");
                ToolTip = 'Open the list of any allergies that is registered for the employee.';
            }
        }

    }

}
