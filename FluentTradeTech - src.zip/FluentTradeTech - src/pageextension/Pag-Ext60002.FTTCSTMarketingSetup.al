pageextension 60002 "FTT-CST MarketingSetup" extends "Marketing Setup"
{
    layout
    {
        addafter(Duplicates)
        {
            group("FTT-CST Notifications")
            {
                Caption = 'Notifications';

                field("FTT-CST Sending E-mail Account"; Rec."FTT-CST Sending E-mail Account")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies e-mail account for the notification sending.';
                }
                field("FTT-CST Def. Attach. Not. Per."; Rec."FTT-CST Def. Attach. Not. Per.")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies e-mail account for the notification sending.';
                }
                field("FTT-CST Def. Mailing Group"; Rec."FTT-CST Def. Mailing Group")
                {
                    ApplicationArea = All;
                    ToolTip = 'Specifies default mailing group for customer and contacts.';
                }
            }
        }
    }
}
