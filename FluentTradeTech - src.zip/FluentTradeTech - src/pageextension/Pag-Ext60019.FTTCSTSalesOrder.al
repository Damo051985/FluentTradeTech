pageextension 60019 "FTT-CST SalesOrder" extends "Sales Order"
{
    layout
    {
        addafter("No.")
        {
            field("FTT-CST Order Type"; Rec."FTT-CST Order Type")
            {
                ApplicationArea = all;
                Editable = True;
                ToolTip = 'Specify the Order Type for Order';
            }
            field("FTT-CST Primary Order"; Rec."FTT-CST Primary Order")
            {
                ApplicationArea = all;
                ToolTip = 'Specify the Primary Order for the Order if the order is Renewal or Aditinal';
            }
        }

        addafter(Status)
        {
            field("Invoice without MSA"; Rec."Invoice without MSA")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies whether to allow sales order posting without an attached MSA document';
            }
        }
        modify("Due Date")
        {
            Caption = 'RFP Due Date';
        }
        addafter("Due Date")
        {
            field("FTT-CST Agr. Starting Date"; Rec."FTT-CST Agr. Starting Date")
            {
                ApplicationArea = All;
                Caption = 'Agreement Starting Date'; //NRD
                ToolTip = 'Specifies a starting date of the agreement.';
                trigger OnValidate()
                Var
                    lSL: Record "Sales Line";
                    YearInt: Integer;
                begin
                    if rec."FTT-CST Agr. Starting Date" <> 0D then
                        Rec.Validate("FTT-CST Contract Length", 1);
                    Rec.ValidateSinceGoLiveDate();
                    Rec.Modify();

                    Clear(lSL);
                    lSL.SetRange("Document Type", Rec."Document Type");
                    lSL.SetRange("Document No.", Rec."No.");
                    IF lSL.FindSet then begin
                        YearInt := Date2DMY(Rec."FTT-CST Agr. Starting Date", 3);
                        lSL.MODIFYALL(lSL."FTT-CST Year", YearInt);
                    end;
                end;
            }
            field("FTT-CST Agr. Ending Date"; Rec."FTT-CST Agr. Ending Date")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies an ending date of the agreement.';
            }
            Field("Service Now"; Rec."Service Now")
            {
                ApplicationArea = All;
            }

            Field("Payment Status"; Rec."Payment Status")
            {
                ApplicationArea = All;
            }
            field("FTT-CST Component Option"; Rec."FTT-CST Component Option")
            {
                ApplicationArea = All;
                Visible = false;
                ToolTip = 'Specifies an ending date of the agreement.';
            }
            field("FTT-CST Region Code"; Rec."FTT-CST Region Code")
            {
                ApplicationArea = All;
                Visible = false;
                ToolTip = 'Specifies an ending date of the';
                Caption = 'Location Code';
            }
            field("FTT-CST Agr. Period Number"; Rec."FTT-CST Agr. Period Number")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies a number of the agreement period for this sales order.';
            }

        }

        modify("Requested Delivery Date")
        {
            Visible = false;
        }
        modify("Salesperson Code")
        {
            Importance = Promoted;
            //FTTNimrod - 
            trigger OnAfterValidate()
            var
                RecSalesRep: Record "Responsibility Center";
                RecUserSetup: Record "User Setup";
                RecSalesHeader: Record "Sales Header";
            begin
                //CurrPage.SalesLines.Page.UpdateForm(true);
                CurrPage.SalesLines.Page.Update(false);
                CurrPage.Update(true);
                if not RecSalesHeader.get(rec."Document Type", rec."No.") then
                    exit;

                if RecUserSetup.Get(UserId) then
                    if RecUserSetup."Sales Resp. Ctr. Filter" = '' then begin
                        RecSalesRep.Reset();
                        RecSalesRep.SetRange(Code, rec."Salesperson Code");
                        RecSalesRep.SetFilter("Sales Manager ID", '<>%1', '');
                        if RecSalesRep.FindFirst() then begin
                            RecSalesHeader.Validate("Responsibility Center", RecSalesRep.Code);
                            RecSalesHeader.Modify();
                        end else begin
                            RecSalesHeader.Validate("Responsibility Center", '');
                            RecSalesHeader.Modify();
                        end;
                        Commit();

                        CurrPage.Update(false);
                    end;
            end;
        }

        addfirst(factboxes)
        {
            // part(MyPagePart; "FTT-CST Customer Statistics")
            // {
            //     ApplicationArea = All;
            //     Caption = 'Opportunities';
            //     SubPageLink = "No." = FIELD("Sell-to Customer No."),
            //                   "Date Filter" = FIELD("Date Filter");
            // }
            part(MyPagePart2; "FTT-CST Quote Statistics")
            {
                ApplicationArea = All;
                Caption = 'Opportunities';
                SubPageLink = "No." = FIELD("No.");
            }
        }
    }

    actions
    {
        modify(Post)
        {
            trigger OnBeforeAction()
            var
                recSalesLine: Record "Sales Line";
            begin
                recSalesLine.Reset();
                recSalesLine.SetRange("Document Type", rec."Document Type");
                recSalesLine.SetRange("Document No.", rec."No.");
                recSalesLine.SetFilter("Qty. to Ship", '%1', 0);
                if recSalesLine.FindSet() then
                    repeat
                        recSalesLine.Validate(Quantity, recSalesLine."FTT-CST Qty");

                        recSalesLine.Modify();
                    until recSalesLine.Next() = 0;

            end;
        }
        modify(PostAndNew)
        {
            trigger OnBeforeAction()
            var
                recSalesLine: Record "Sales Line";
            begin
                recSalesLine.Reset();
                recSalesLine.SetRange("Document Type", rec."Document Type");
                recSalesLine.SetRange("Document No.", rec."No.");
                recSalesLine.SetFilter("Qty. to Ship", '%1', 0);
                if recSalesLine.FindSet() then
                    repeat
                        recSalesLine.Validate(Quantity, recSalesLine."FTT-CST Qty");

                        recSalesLine.Modify();
                    until recSalesLine.Next() = 0;

            end;
        }
        modify(PostAndSend)
        {
            trigger OnBeforeAction()
            var
                recSalesLine: Record "Sales Line";
            begin
                recSalesLine.Reset();
                recSalesLine.SetRange("Document Type", rec."Document Type");
                recSalesLine.SetRange("Document No.", rec."No.");
                recSalesLine.SetFilter("Qty. to Ship", '%1', 0);
                if recSalesLine.FindSet() then
                    repeat
                        recSalesLine.Validate(Quantity, recSalesLine."FTT-CST Qty");

                        recSalesLine.Modify();
                    until recSalesLine.Next() = 0;

            end;
        }
        addafter(GetRecurringSalesLines)
        {
            action("FTT-CST Update Qty. for Agr")
            {
                ApplicationArea = All;
                Caption = 'Update Quantity'; //NRD
                //Caption = 'Update Quantity for Agreement';
                Ellipsis = true;
                Image = UpdateUnitCost;
                ToolTip = 'Update Quantity based on the Agreement period and Item Type';

                trigger OnAction()
                begin
                    Rec.UpdateQuantity3();
                end;
            }

            action("FTT-CST Update Qty. for Inv")
            {
                ApplicationArea = All;
                Caption = 'Update Quantity for Invoice';
                Ellipsis = true;
                Image = UpdateShipment;
                ToolTip = 'Update Item Quantity based on the Invoice period and Item Type';

                trigger OnAction()
                var
                    UpdateQtyForInvoiceDialog: Page "FTT-CST UpdateQtyForInvoice";
                begin
                    UpdateQtyForInvoiceDialog.SetRecord(Rec);
                    if UpdateQtyForInvoiceDialog.RunModal() = Action::Cancel then
                        exit;

                    Rec.UpdateQuantity2(
                        UpdateQtyForInvoiceDialog.GetInvoiceStartingDate(),
                        UpdateQtyForInvoiceDialog.GetInvoiceEndingDate());
                end;
            }
            action("FTT-CST ITEM CHAD")
            {
                ApplicationArea = All;
                Caption = 'Item Dependencies';
                Ellipsis = true;
                Image = AddAction;

                trigger OnAction()
                var
                    varFilterPageBuilder: FilterPageBuilder;
                    Item: Record Item;
                    ItemListPage: page "Item List";
                    SelectionFilterManagement: Codeunit SelectionFilterManagement;
                    Dependancy: page "FTT-CST Smart Dep by Location";
                    SmartDependancy: page "FTT-CST Smart Dep by Location";
                    DependencyRec: Record "FTT-CST Dependency Filters";
                    ItemFilters: text[1024];
                    DependencyItems: record "FTT-CST Dependancy Item";
                    DepFiltersCopy: record "FTT-CST Dep. Filters Copy";
                    DepUtility: Codeunit "FTT-CST Dependency Utility";
                    CrossConnectHdr: Record "FTT-CST Cross Connect Hdr";
                begin
                    DepUtility.CheckDependencySetup();
                    Rec.TestField("FTT-CST Agr. Starting Date");
                    Rec.TestField("FTT-CST Contract Length");
                    DependencyRec.SetRange("Sales Document No.", Rec."No.");
                    DependencyRec.DeleteAll();
                    DepFiltersCopy.SetRange("Sales Document No.", Rec."No.");
                    DepFiltersCopy.DeleteAll();
                    DependencyItems.SetRange("Sales Document No.", Rec."No.");
                    DependencyItems.DeleteAll();

                    DepFiltersCopy.DeleteAll;
                    if DependencyRec.FindSet() then
                        repeat
                            DependencyItems.SetRange("Filter No.", DependencyRec."Filter No.");
                            DependencyItems.SetRange("Sales Document No.", rec."No.");
                            DependencyItems.DeleteAll(); //NRD - Fix 

                            DepFiltersCopy.SetRange("Sales Document No.", DependencyRec."Sales Document No.");
                            DepFiltersCopy.SetRange("Filter No.", DependencyRec."Filter No.");
                            DepFiltersCopy.DeleteAll();
                        until DependencyRec.next = 0;

                    if not DependencyRec.GET(Rec."No.", 1) then begin
                        DependencyRec.Init();
                        DependencyRec."Filter No." := 1;
                        DependencyRec."Sales Document No." := Rec."No.";
                        DependencyRec."Document Type" := rec."Document Type"; // NRD
                        DependencyRec."Sell-to Customer No." := Rec."Sell-to Customer No.";
                        DependencyRec."Currency Code" := Rec."Currency Code";
                        DependencyRec."Currency Factor" := Rec."Currency Factor";
                        DependencyRec."Customer Price Group" := Rec."Customer Price Group";
                        DependencyRec."Posting Date" := Rec."Order Date";
                        DependencyRec.Insert();
                        Commit();
                    end;

                    Dependancy.LookupMode(true);
                    Dependancy.SetTableView(DependencyRec);
                    if Dependancy.RunModal() = Action::LookupOK then begin
                        Dependancy.GetRecord(DependencyRec);
                        if DependencyRec."FTT-CST Conectivity" = DependencyRec."FTT-CST Conectivity"::Yes then
                            if DependencyRec."FTT-CST Licences Filters" <> '' then
                                ItemFilters := DependencyRec."FTT-CST Licences Filters";

                        if DependencyRec."FTT-CST NON Standard maker" <> '' then
                            if ItemFilters <> '' then
                                ItemFilters := ItemFilters + '|' + DependencyRec."FTT-CST NON Standard maker"
                            else
                                ItemFilters := DependencyRec."FTT-CST NON Standard maker";

                        if DependencyRec."FTT-CST Standard maker feed" <> '' then
                            if ItemFilters <> '' then
                                ItemFilters := ItemFilters + '|' + DependencyRec."FTT-CST Standard maker feed"
                            else
                                ItemFilters := DependencyRec."FTT-CST Standard maker feed";

                        if DependencyRec."FTT-CST Standard taker feed" <> '' then
                            if ItemFilters <> '' then
                                ItemFilters := ItemFilters + '|' + DependencyRec."FTT-CST Standard taker feed"
                            else
                                ItemFilters := DependencyRec."FTT-CST Standard taker feed";

                        if DependencyRec."FTT-CST NON Standard taker" <> '' then
                            if ItemFilters <> '' then
                                ItemFilters := ItemFilters + '|' + DependencyRec."FTT-CST NON Standard taker"
                            else
                                ItemFilters := DependencyRec."FTT-CST NON Standard taker";

                        if DependencyRec."FTT-CST CPU" <> '' then
                            if ItemFilters <> '' then
                                ItemFilters := ItemFilters + '|' + DependencyRec."FTT-CST CPU"
                            else
                                ItemFilters := DependencyRec."FTT-CST CPU";

                        if DependencyRec."FTT-CST HARDWARE" <> '' then
                            if ItemFilters <> '' then
                                ItemFilters := ItemFilters + '|' + DependencyRec."FTT-CST HARDWARE"
                            else
                                ItemFilters := DependencyRec."FTT-CST HARDWARE";

                        DependencyItems.SetRange("Filter No.", DependencyRec."Filter No.");
                        if DependencyItems.FindSet() then
                            repeat
                                if ItemFilters <> '' then
                                    ItemFilters := ItemFilters + '|' + DependencyItems."No." else
                                    ItemFilters := DependencyItems."No.";
                            until DependencyItems.next = 0;
                        InitNewLines(Rec, ItemFilters, DependencyRec."Filter No.");
                        Commit();
                        UpdateCrossConnectStatus();
                        Rec.UpdateQuantity();

                    end else begin
                        CrossConnectHdr.Reset();
                        CrossConnectHdr.SetRange("Document Type", rec."Document Type");
                        CrossConnectHdr.SetRange("Document No.", rec."No.");
                        CrossConnectHdr.SetRange("Cross Connect Status", CrossConnectHdr."Cross Connect Status"::Open);
                        if CrossConnectHdr.FindFirst() then
                            CrossConnectHdr.Delete(true);
                    end;
                end;
            }

            action("FTT-CST SOW")
            {
                ApplicationArea = All;
                Caption = 'SOW';
                Ellipsis = true;
                Image = Workflow;
                trigger OnAction()
                var
                    DocumentAttachmentPage: Page "Document Attachment Details";
                    DocumentAttachment: Record "Document Attachment";
                begin
                    DocumentAttachmentPage.SetTableView(DocumentAttachment);
                    DocumentAttachmentPage.Run();
                end;
            }
            action("FTT-CST Renewal")
            {
                ApplicationArea = all;
                Caption = 'Create Renewal';
                Ellipsis = true;
                Visible = true;
                Image = CreateDocument;
                trigger OnAction()
                var
                    pagCreateRenewals: page "FTT-CST CreateRenewals";
                    lstartdate: Date;
                    lenddate: Date;
                    isAdditionIncl: Boolean;
                begin
                    Clear(pagCreateRenewals);

                    pagCreateRenewals.SetDate1(rec."FTT-CST Agr. Starting Date");
                    pagCreateRenewals.SetDate2(rec."FTT-CST Agr. Ending Date");
                    if rec."FTT-CST Primary Order" = '' then
                        pagCreateRenewals.SetOrderNo(rec."No.")
                    else
                        pagCreateRenewals.SetOrderNo(rec."FTT-CST Main Order No.");

                    if Confirm('Are you sure that you would like to create Renewal for the current Sales Order?') then begin
                        if pagCreateRenewals.RunModal() <> Action::Cancel then begin
                            lstartdate := pagCreateRenewals.GetDate2();
                            lenddate := pagCreateRenewals.GetDate3();
                            isAdditionIncl := pagCreateRenewals.GetInc();
                            if lenddate = 0D then
                                lenddate := CalcDate('1Y', lstartdate);

                            CreateRenewal2(rec, lstartdate, lenddate, isAdditionIncl);
                            //CreateRenewal(Rec);
                        end;
                    end;
                end;
            }
            //Additions
            action("FTT-CST Additions")
            {
                ApplicationArea = all;
                Caption = 'Create Additions';
                Ellipsis = true;
                Visible = true;
                Image = CreateDocument;
                trigger OnAction()

                begin
                    if Confirm('Are you sure that you would like to create Additions for the current Sales Order?') then begin
                        CreateAdditions(Rec);
                    end;
                end;
            }
            //NRD
            action(CalculateCommissioBaseAmount)
            {

                ApplicationArea = all;
                Caption = 'Calculate Commission Base Amount';
                Ellipsis = true;
                Visible = true;
                Image = Recalculate;
                trigger OnAction()
                var
                    codCommMgt: codeunit "FTT-CST Commission Mgt.";
                begin
                    if not Confirm('Do you want to calculate the Lines for Commission?', false, 0) then
                        exit;

                    codCommMgt.CalculateCommissionBase(Rec);
                    CurrPage.Update(false);
                    CurrPage.SalesLines.page.Update(false);
                end;
            }
            //NRD - 
            action("FTT-CST Create Pricing Prop")
            {
                ApplicationArea = All;
                Caption = 'Generate Sales Order';
                Ellipsis = true;
                Image = PrintChecklistReport;
                ToolTip = 'Generate a printed template of pricing proposal';

                trigger OnAction()
                var
                    codGMAILIntegSpreed: Codeunit "GMAIL Integ. SO Spreadsheet";
                    OptionMenu: Label 'Generate to Excel,Generate to Word';
                    OptionConfirm: Label 'Choose one of the following options:';
                    Options: Text[50];
                    Selected: Integer;
                    repSalesQuote: report "Sales Document - Test";
                    SalesHeader_l: Record "Sales Header";
                    Report: ReportFormat;
                    OutStream2: OutStream;
                    TempBlob: codeunit "Temp Blob";
                    Instream2: InStream;
                    txtFilename: Text;
                begin
                    Options := OptionMenu;
                    Selected := StrMenu(Options, 1, OptionConfirm);
                    case Selected of
                        1:
                            begin
                                Commit();
                                codGMAILIntegSpreed.UpdateCRMTemplatefromSalesOrder(rec, false);
                            end;
                        2:
                            begin
                                //NRD
                                Clear(repSalesQuote);
                                // if not SalesHeader_l.get(rec."Document Type", rec."No.") then
                                //     exit;
                                SalesHeader_l.Reset();
                                SalesHeader_l.SetRange("Document Type", rec."Document Type");
                                SalesHeader_l.SetRange("No.", rec."No.");
                                if SalesHeader_l.FindFirst() then begin
                                    TempBlob.CreateOutStream(OutStream2);

                                    repSalesQuote.SetTableView(SalesHeader_l);
                                    repSalesQuote.UseRequestPage(false);
                                    repSalesQuote.SaveAs('', Report::Word, OutStream2);
                                    TempBlob.CreateInStream(Instream2);
                                    txtFilename := Format('SO-' + SalesHeader_l."No." + '_' + SalesHeader_l."Ship-to Name" + '.docx');
                                    DownloadFromStream(Instream2, '', '', '', txtFilename);
                                end;

                            end;
                    end;
                end;
            }
            //NRD
            action(OpenCrossConnectRelated)
            {
                ApplicationArea = All;
                Caption = 'Open Cross Connect Related';
                Ellipsis = true;
                Image = InteractionLog;
                ToolTip = 'Open Cross Connecte Related to this Document';

                trigger OnAction()
                var
                    pagCrossConnectCard: page "FTT-CST Cross Connect Card";
                    CrossConnectHdr: Record "FTT-CST Cross Connect Hdr";
                begin
                    clear(pagCrossConnectCard);

                    CrossConnectHdr.Reset();
                    CrossConnectHdr.SetRange("Document Type", rec."Document Type");
                    CrossConnectHdr.SetRange("Document No.", rec."No.");
                    CrossConnectHdr.SetRange("Customer No.", rec."Sell-to Customer No.");
                    if not CrossConnectHdr.FindFirst() then
                        Error('No Record Found!');


                    pagCrossConnectCard.SetRecord(CrossConnectHdr);
                    pagCrossConnectCard.Run();
                end;
            }
            //+


        }
        addafter(GetRecurringSalesLines_Promoted)
        {
            actionref("FTT-CST Update Qty. for Agr_Promoted"; "FTT-CST Update Qty. for Agr")
            {
            }

            actionref("FTT-CST Update Qty. for Inv_Promoted"; "FTT-CST Update Qty. for Inv")
            {
            }

            actionref("FTT-CST ITEM CHA_Promoted"; "FTT-CST ITEM CHAD")
            {
            }
            actionref("FTT-CST Renewal_Promoted"; "FTT-CST Renewal")
            {

            }
            actionref("FTT-CST Additions_Promoted"; "FTT-CST Additions")
            {

            }
            actionref("CalculateCommissioBaseAmount_Promoted"; "CalculateCommissioBaseAmount")
            {
            }
            actionref("FTT-CST Create Pricing Prop_Promoted"; "FTT-CST Create Pricing Prop")
            {
                Visible = true;
            }


        }
    }
    local procedure UpdateCrossConnectStatus()
    var
        recCrossConnectHdr: Record "FTT-CST Cross Connect Hdr";
    begin
        recCrossConnectHdr.Reset();
        recCrossConnectHdr.SetRange("Document Type", rec."Document Type");
        recCrossConnectHdr.SetRange("Document No.", rec."No.");
        recCrossConnectHdr.SetRange("Customer No.", rec."Sell-to Customer No.");
        recCrossConnectHdr.SetRange("Cross Connect Status", recCrossConnectHdr."Cross Connect Status"::Open);
        if recCrossConnectHdr.FindFirst() then begin
            recCrossConnectHdr."Cross Connect Status" := recCrossConnectHdr."Cross Connect Status"::"Line Inserted";
            recCrossConnectHdr.Modify();
        end;
    end;

    procedure CreateRenewal(var pSalesHeader: Record "Sales Header")
    var
        newSalesHeader: Record "Sales Header";
        recSalesHeader: Record "Sales Header";
        pageSalesOrder: Page "Sales Order";
        FromSalesLines: Record "Sales Line";
        ToSalesLines: Record "Sales Line";
        CreatedOrderNo: Code[20];
        LineNo: Integer;
        pageSalesList: Page "Sales List";
    begin
        if pSalesHeader."FTT-CST Order Type" = pSalesHeader."FTT-CST Order Type"::Primary then begin
            newSalesHeader.TransferFields(Rec);
            newSalesHeader."FTT-CST Primary Order" := pSalesHeader."No.";
            newSalesHeader."FTT-CST Main Order No." := pSalesHeader."No.";
            newSalesHeader."FTT-CST Primary Order" := pSalesHeader."No.";
            newSalesHeader."FTT-CST Order Type" := newSalesHeader."FTT-CST Order Type"::Renewal;
            newSalesHeader."FTT-CST Agr. Ending Date" := CalcDate('1Y', pSalesHeader."FTT-CST Agr. Ending Date");
            newSalesHeader."FTT-CST Agr. Starting Date" := CalcDate('1Y', pSalesHeader."FTT-CST Agr. Starting Date");
            newSalesHeader."No." := '';
            newSalesHeader.Insert(true);
            Commit();
            CreatedOrderNo := newSalesHeader."No.";

            FromSalesLines.SetRange("Document Type", pSalesHeader."Document Type");
            FromSalesLines.SetRange("Document No.", pSalesHeader."No.");

            if FromSalesLines.FindSet() then
                repeat
                    ToSalesLines.TransferFields(FromSalesLines);
                    ToSalesLines."Document No." := newSalesHeader."No.";
                    ToSalesLines."FTT-CST Main Order No." := newSalesHeader."FTT-CST Main Order No.";
                    ToSalesLines."FTT-CST Primary Order" := newSalesHeader."FTT-CST Primary Order";
                    ToSalesLines."FTT-CST Order Type" := ToSalesLines."FTT-CST Order Type"::Renewal;
                    ToSalesLines."FTT-CST Use for Renewal" := true;
                    ToSalesLines.Insert(True);
                    LineNo := ToSalesLines."Line No.";
                    FromSalesLines."FTT-CST Use for Renewal" := false;
                    FromSalesLines.Modify()
                until FromSalesLines.Next() = 0;
            Commit();

            FromSalesLines.Reset;
            FromSalesLines.SetRange("Document Type", pSalesHeader."Document Type");
            FromSalesLines.SetRange("FTT-CST Primary Order", pSalesHeader."No.");
            FromSalesLines.SetFilter("FTT-CST Order Type", '%1|%2', FromSalesLines."FTT-CST Order Type"::Additions, FromSalesLines."FTT-CST Order Type"::Renewal);
            FromSalesLines.SetRange("FTT-CST Use for Renewal", true);
            FromSalesLines.SetFilter("Document No.", '<>%1', CreatedOrderNo);
            if not FromSalesLines.FindSet() then begin
                pageSalesOrder.SetRecord(newSalesHeader);
                pageSalesOrder.Run();
            end else begin
                recSalesHeader.SetRange("FTT-CST Primary Order", pSalesHeader."No.");
                recSalesHeader.SetFilter("No.", '<>%1', CreatedOrderNo);
                recSalesHeader.SetFilter("FTT-CST Order Type", '%1|%2', FromSalesLines."FTT-CST Order Type"::Additions, FromSalesLines."FTT-CST Order Type"::Renewal);
                recSalesHeader.SetRange("FTT-CST Use for Renewal", true);
                pageSalesList.SetTableView(recSalesHeader);
                pageSalesList.LookupMode(true);
                if pageSalesList.RunModal() = Action::LookupOK then begin
                    pageSalesList.SetSelectionFilter(SelectedSalesOrders);
                    CreateRenewalfromAdditions(newSalesHeader, pSalesHeader."FTT-CST Primary Order");
                end;
            end;
        end;

        if pSalesHeader."FTT-CST Order Type" = pSalesHeader."FTT-CST Order Type"::Renewal then begin
            newSalesHeader.TransferFields(Rec);
            newSalesHeader."FTT-CST Primary Order" := pSalesHeader."FTT-CST Primary Order";
            newSalesHeader."FTT-CST Main Order No." := pSalesHeader."FTT-CST Primary Order";
            newSalesHeader."FTT-CST Order Type" := newSalesHeader."FTT-CST Order Type"::Renewal;
            newSalesHeader."FTT-CST Agr. Starting Date" := CalcDate('<1Y>', pSalesHeader."FTT-CST Agr. Starting Date");
            newSalesHeader."FTT-CST Agr. Ending Date" := CalcDate('<1Y>', pSalesHeader."FTT-CST Agr. Ending Date");
            newSalesHeader."No." := '';
            newSalesHeader.Insert(true);
            Commit();
            CreatedOrderNo := newSalesHeader."No.";

            FromSalesLines.SetRange("Document Type", pSalesHeader."Document Type");
            FromSalesLines.SetRange("Document No.", pSalesHeader."No.");

            if FromSalesLines.FindSet() then
                repeat
                    ToSalesLines.TransferFields(FromSalesLines);
                    ToSalesLines."Document No." := newSalesHeader."No.";
                    ToSalesLines."FTT-CST Main Order No." := newSalesHeader."FTT-CST Main Order No.";
                    ToSalesLines."FTT-CST Order Type" := ToSalesLines."FTT-CST Order Type"::Renewal;
                    ToSalesLines."FTT-CST Use for Renewal" := true;
                    ToSalesLines."FTT-CST Agreement Date From" := newSalesHeader."FTT-CST Agr. Starting Date";
                    ToSalesLines."FTT-CST Agreement Date To" := newSalesHeader."FTT-CST Agr. Ending Date";
                    ToSalesLines.Insert(True);
                    LineNo := ToSalesLines."Line No.";
                    FromSalesLines."FTT-CST Use for Renewal" := false;
                    FromSalesLines.Modify()
                until FromSalesLines.Next() = 0;
            Commit();

            FromSalesLines.Reset;
            FromSalesLines.SetRange("Document Type", pSalesHeader."Document Type");
            FromSalesLines.SetRange("FTT-CST Primary Order", pSalesHeader."No.");
            FromSalesLines.SetFilter("FTT-CST Order Type", '%1|%2', FromSalesLines."FTT-CST Order Type"::Additions, FromSalesLines."FTT-CST Order Type"::Renewal);
            FromSalesLines.SetFilter("Document No.", '<>%1', CreatedOrderNo);
            FromSalesLines.SetRange("FTT-CST Use for Renewal", true);
            if not FromSalesLines.FindSet() then begin
                pageSalesOrder.SetRecord(newSalesHeader);
                pageSalesOrder.Run();
            end else begin
                recSalesHeader.Reset();
                recSalesHeader.SetRange("FTT-CST Primary Order", pSalesHeader."No.");
                recSalesHeader.SetFilter("No.", '<>%1', newSalesHeader."No.");
                recSalesHeader.SetFilter("FTT-CST Order Type", '%1|%2', FromSalesLines."FTT-CST Order Type"::Additions, FromSalesLines."FTT-CST Order Type"::Renewal);
                recSalesHeader.SetRange("FTT-CST Order Type", pSalesHeader."FTT-CST Order Type"::Additions);
                recSalesHeader.SetRange("FTT-CST Use for Renewal", true);

                pageSalesList.SetTableView(recSalesHeader);
                pageSalesList.LookupMode(true);
                if pageSalesList.RunModal() = Action::LookupOK then begin
                    pageSalesList.SetSelectionFilter(SelectedSalesOrders);
                    CreateRenewalfromAdditions(newSalesHeader, pSalesHeader."FTT-CST Primary Order");
                end;
            end;
        end;

        if pSalesHeader."FTT-CST Order Type" = pSalesHeader."FTT-CST Order Type"::Additions then begin
            newSalesHeader.TransferFields(Rec);
            newSalesHeader."FTT-CST Primary Order" := pSalesHeader."FTT-CST Primary Order";
            newSalesHeader."FTT-CST Main Order No." := pSalesHeader."FTT-CST Primary Order";
            newSalesHeader."FTT-CST Order Type" := newSalesHeader."FTT-CST Order Type"::Renewal;
            newSalesHeader."FTT-CST Agr. Starting Date" := CalcDate('<1Y>', pSalesHeader."FTT-CST Agr. Starting Date");
            newSalesHeader."FTT-CST Agr. Ending Date" := CalcDate('<1Y>', pSalesHeader."FTT-CST Agr. Ending Date");
            newSalesHeader."No." := '';
            newSalesHeader.Insert(true);
            Commit();
            CreatedOrderNo := newSalesHeader."No.";

            FromSalesLines.SetRange("Document Type", pSalesHeader."Document Type");
            FromSalesLines.SetRange("Document No.", pSalesHeader."No.");

            if FromSalesLines.FindSet() then
                repeat
                    ToSalesLines.TransferFields(FromSalesLines);
                    ToSalesLines."Document No." := newSalesHeader."No.";
                    ToSalesLines."FTT-CST Main Order No." := newSalesHeader."FTT-CST Main Order No.";
                    ToSalesLines."FTT-CST Order Type" := ToSalesLines."FTT-CST Order Type"::Renewal;
                    ToSalesLines."FTT-CST Use for Renewal" := true;
                    ToSalesLines."FTT-CST Agreement Date From" := newSalesHeader."FTT-CST Agr. Starting Date";
                    ToSalesLines."FTT-CST Agreement Date To" := newSalesHeader."FTT-CST Agr. Ending Date";
                    ToSalesLines.Insert(True);
                    LineNo := ToSalesLines."Line No.";
                    FromSalesLines."FTT-CST Use for Renewal" := false;
                    FromSalesLines.Modify()
                until FromSalesLines.Next() = 0;
            Commit();

            FromSalesLines.Reset;
            FromSalesLines.SetRange("Document Type", pSalesHeader."Document Type");
            FromSalesLines.SetRange("FTT-CST Primary Order", pSalesHeader."FTT-CST Primary Order");
            FromSalesLines.SetFilter("FTT-CST Order Type", '%1|%2', FromSalesLines."FTT-CST Order Type"::Additions, FromSalesLines."FTT-CST Order Type"::Renewal);
            FromSalesLines.SetRange("FTT-CST Use for Renewal", true);
            FromSalesLines.SetFilter("Document No.", '<>%1', CreatedOrderNo);
            if not FromSalesLines.FindSet() then begin
                pageSalesOrder.SetRecord(newSalesHeader);
                pageSalesOrder.Run();
            end else begin
                recSalesHeader.Reset();
                recSalesHeader.SetRange("FTT-CST Primary Order", pSalesHeader."FTT-CST Primary Order");
                recSalesHeader.SetFilter("No.", '<>%1', newSalesHeader."No.");
                recSalesHeader.SetFilter("FTT-CST Order Type", '%1|%2', FromSalesLines."FTT-CST Order Type"::Additions, FromSalesLines."FTT-CST Order Type"::Renewal);
                recSalesHeader.SetRange("FTT-CST Use for Renewal", true);

                pageSalesList.SetTableView(recSalesHeader);
                pageSalesList.LookupMode(true);
                if pageSalesList.RunModal() = Action::LookupOK then begin
                    pageSalesList.SetSelectionFilter(SelectedSalesOrders);
                    CreateRenewalfromAdditions(newSalesHeader, pSalesHeader."FTT-CST Primary Order");
                end;
            end;
        end;
    end;

    local procedure InsertNewLines2(FromSalesLines: Record "Sales Line"; newSalesHeader: Record "Sales Header"; pRenewalStartdate: Date; pRenewalEndDate: Date)
    var
        DimensionValues: Record "Dimension Value";
        ToSalesLines: Record "Sales Line";
    begin
        ToSalesLines.Init;
        ToSalesLines."Line No." := FromSalesLines."Line No.";
        ToSalesLines."Document No." := newSalesHeader."No.";
        ToSalesLines."Document Type" := newSalesHeader."Document Type";
        ToSalesLines.Validate("Sell-to Customer No.", newSalesHeader."Sell-to Customer No.");
        ToSalesLines.Validate("Customer Price Group", newSalesHeader."Customer Price Group");
        ToSalesLines.Validate("Customer Disc. Group", newSalesHeader."Customer Disc. Group");
        ToSalesLines.Validate("Currency Code", newSalesHeader."Currency Code");
        ToSalesLines.Validate(Type, ToSalesLines.Type::Item);
        ToSalesLines.validate("No.", FromSalesLines."No.");

        ToSalesLines."FTT-CST Delivery PROD Date" := 0D; //NRD - fix the error on renewals if the dates are difference
        ToSalesLines."FTT-CST Delivery UAT Date" := 0D; //NRD - fix the error on renewals if the dates are difference
        ToSalesLines."Agreement Period" := FromSalesLines."Agreement Period" + 1;
        ToSalesLines."Separated Seq." := FromSalesLines."Separated Seq.";
        ToSalesLines."Document No." := newSalesHeader."No.";
        ToSalesLines."FTT-CST Main Order No." := newSalesHeader."FTT-CST Main Order No.";
        ToSalesLines."FTT-CST Primary Order" := newSalesHeader."FTT-CST Primary Order";
        ToSalesLines."FTT-CST Order Type" := ToSalesLines."FTT-CST Order Type"::Renewal;
        ToSalesLines."FTT-CST Use for Renewal" := true;

        ToSalesLines."Allow Line Disc." := newSalesHeader."Allow Line Disc.";
        ToSalesLines."Transaction Type" := newSalesHeader."Transaction Type";
        ToSalesLines."Transport Method" := newSalesHeader."Transport Method";
        ToSalesLines."Bill-to Customer No." := newSalesHeader."Bill-to Customer No.";
        ToSalesLines."Price Calculation Method" := newSalesHeader."Price Calculation Method";
        ToSalesLines."Gen. Bus. Posting Group" := newSalesHeader."Gen. Bus. Posting Group";
        ToSalesLines."VAT Bus. Posting Group" := newSalesHeader."VAT Bus. Posting Group";

        ToSalesLines."FTT-CST Comments" := FromSalesLines."FTT-CST Comments";

        ToSalesLines."FTT-CST Use for Discount" := FromSalesLines."FTT-CST Use for Discount";
        ToSalesLines."Allow Line Disc." := FromSalesLines."FTT-CST Use for Discount";
        ToSalesLines."Allow Invoice Disc." := FromSalesLines."FTT-CST Use for Discount";
        ToSalesLines."FTT-CST Parent Item Cat. Code" := FromSalesLines."FTT-CST Parent Item Cat. Code";
        ToSalesLines."FTT-CST Comments Fluent" := FromSalesLines."FTT-CST Comments Fluent";
        ToSalesLines."FTT-CST DR" := FromSalesLines."FTT-CST DR";
        ToSalesLines."FTT-CST Integration" := FromSalesLines."FTT-CST Integration";
        ToSalesLines."FTT-CST Redundancy" := FromSalesLines."FTT-CST Redundancy";
        ToSalesLines."FTT-CST Redundancy PriceCalc %" := FromSalesLines."FTT-CST Redundancy PriceCalc %";
        ToSalesLines."FTT-CST Location Code" := FromSalesLines."FTT-CST Location Code";
        ToSalesLines."FTT-CST Location Type" := FromSalesLines."FTT-CST Location Type";
        ToSalesLines."FTT-CST Component Option" := FromSalesLines."FTT-CST Component Option";
        ToSalesLines."FTT-CST Sublocation" := FromSalesLines."FTT-CST Sublocation";
        ToSalesLines."Shortcut Dimension 1 Code" := newSalesHeader."Shortcut Dimension 1 Code";
        ToSalesLines."Shortcut Dimension 2 Code" := newSalesHeader."Shortcut Dimension 2 Code";
        ToSalesLines."FTT-CST Cost Type" := FromSalesLines."FTT-CST Cost Type";

        ToSalesLines."Unit Price" := FromSalesLines."Unit Price";
        ToSalesLines."FTT-CST Unit Price" := FromSalesLines."FTT-CST Unit Price";
        ToSalesLines."FTT-CST Qty" := FromSalesLines."FTT-CST Qty";
        ToSalesLines.validate(Quantity, FromSalesLines.Quantity);
        ToSalesLines.ValidateShortcutDimCode(3, FromSalesLines."FTT-CST Location Code");
        //Add Dimesnsion for Sublocation
        DimensionValues.Reset;
        DimensionValues.SetRange("FTT-CST Sublocation", FromSalesLines."FTT-CST Sublocation");
        if DimensionValues.FindFirst() then
            ToSalesLines.ValidateShortcutDimCode(4, DimensionValues.Code);

        if ToSalesLines.Insert(True) then begin
            if FromSalesLines."Separated Seq." = 0 then begin
                ToSalesLines."FTT-CST Agreement Date From" := pRenewalStartdate; //NRD - fix the error on renewals if the dates are difference
                ToSalesLines."FTT-CST Agreement Date To" := pRenewalEndDate; //NRD - fix the error on renewals if the dates are difference
            end else if FromSalesLines."Separated Seq." = 1 then begin
                ToSalesLines."FTT-CST Agreement Date From" := pRenewalStartdate;
                ToSalesLines."FTT-CST Agreement Date To" := CalcDate('<-CY>', pRenewalEndDate);
            end else if FromSalesLines."Separated Seq." = 2 then begin
                ToSalesLines."FTT-CST Agreement Date From" := CalcDate('<-CY>', pRenewalEndDate);
                ToSalesLines."FTT-CST Agreement Date To" := pRenewalEndDate;
            end;
            ToSalesLines.Modify();
        end;

    end;

    procedure CreateRenewal2(var pSalesHeader: Record "Sales Header"; pRenewalStartdate: date; pRenewalEndDate: Date; IncludeAddtion: Boolean) //NRD
    var
        newSalesHeader: Record "Sales Header";
        recSalesHeader: Record "Sales Header";
        pageSalesOrder: Page "Sales Order";
        FromSalesLines: Record "Sales Line";
        ToSalesLines: Record "Sales Line";
        DimensionValues: Record "Dimension Value";
        CreatedOrderNo: Code[20];
        LineNo: Integer;
        pageSalesList: Page "Sales Order List";
    begin
        if pSalesHeader."FTT-CST Order Type" = pSalesHeader."FTT-CST Order Type"::Primary then begin
            newSalesHeader.TransferFields(Rec);
            newSalesHeader."FTT-CST Primary Order" := pSalesHeader."No.";
            newSalesHeader."FTT-CST Main Order No." := pSalesHeader."No.";
            newSalesHeader."FTT-CST Primary Order" := pSalesHeader."No.";
            newSalesHeader."FTT-CST Order Type" := newSalesHeader."FTT-CST Order Type"::Renewal;
            newSalesHeader."FTT-CST Agr. Ending Date" := pRenewalEndDate;
            newSalesHeader."FTT-CST Agr. Starting Date" := pRenewalStartdate;

            newSalesHeader."No." := '';
            newSalesHeader.Insert(true);
            Commit();
            CreatedOrderNo := newSalesHeader."No.";

            FromSalesLines.SetRange("Document Type", pSalesHeader."Document Type");
            FromSalesLines.SetRange("Document No.", pSalesHeader."No.");
            FromSalesLines.SetFilter("FTT-CST Cost Type", '<>%1', FromSalesLines."FTT-CST Cost Type"::NRC); //NRD
            if FromSalesLines.FindSet() then
                repeat
                    InsertNewLines2(FromSalesLines, newSalesHeader, pRenewalStartdate, pRenewalEndDate);
                    FromSalesLines."FTT-CST Use for Renewal" := false;
                    FromSalesLines.Modify()
                until FromSalesLines.Next() = 0;
            Commit();


            if IncludeAddtion then begin
                recSalesHeader.Reset();
                recSalesHeader.SetRange("FTT-CST Primary Order", pSalesHeader."No.");
                recSalesHeader.SetFilter("No.", '<>%1', CreatedOrderNo);
                //recSalesHeader.SetFilter("FTT-CST Order Type", '%1|%2', recSalesHeader."FTT-CST Order Type"::Additions, recSalesHeader."FTT-CST Order Type"::Renewal)
                recSalesHeader.SetFilter("FTT-CST Order Type", '%1', recSalesHeader."FTT-CST Order Type"::Additions);
                recSalesHeader.SetRange("FTT-CST Use for Renewal", true);
                recSalesHeader.SetFilter("FTT-CST Agr. Ending Date", '%1..%2', pSalesHeader."FTT-CST Agr. Starting Date", pSalesHeader."FTT-CST Agr. Ending Date");
                if recSalesHeader.FindSet() then begin
                    pageSalesList.SetTableView(recSalesHeader);
                    pageSalesList.LookupMode(true);
                    if pageSalesList.RunModal() = Action::LookupOK then begin
                        pageSalesList.SetSelectionFilter(SelectedSalesOrders);
                        CreateRenewalfromAdditions(newSalesHeader, pSalesHeader."FTT-CST Primary Order");
                    end;
                end else begin
                    pageSalesOrder.SetRecord(newSalesHeader);
                    pageSalesOrder.Run();
                end;
            end else begin
                pageSalesOrder.SetRecord(newSalesHeader);
                pageSalesOrder.Run();
            end;
        end;

        if pSalesHeader."FTT-CST Order Type" = pSalesHeader."FTT-CST Order Type"::Renewal then begin
            newSalesHeader.TransferFields(Rec);
            newSalesHeader."FTT-CST Primary Order" := pSalesHeader."FTT-CST Primary Order";
            newSalesHeader."FTT-CST Main Order No." := pSalesHeader."FTT-CST Primary Order";
            newSalesHeader."FTT-CST Order Type" := newSalesHeader."FTT-CST Order Type"::Renewal;
            newSalesHeader."FTT-CST Agr. Ending Date" := pRenewalEndDate;
            newSalesHeader."FTT-CST Agr. Starting Date" := pRenewalStartdate;
            newSalesHeader."No." := '';
            newSalesHeader.Insert(true);
            Commit();
            CreatedOrderNo := newSalesHeader."No.";

            FromSalesLines.SetRange("Document Type", pSalesHeader."Document Type");
            FromSalesLines.SetRange("Document No.", pSalesHeader."No.");
            FromSalesLines.SetFilter("FTT-CST Cost Type", '<>%1', FromSalesLines."FTT-CST Cost Type"::NRC); //NRD
            if FromSalesLines.FindSet() then
                repeat
                    InsertNewLines2(FromSalesLines, newSalesHeader, pRenewalStartdate, pRenewalEndDate);
                    FromSalesLines."FTT-CST Use for Renewal" := false;
                    FromSalesLines.Modify()
                until FromSalesLines.Next() = 0;
            Commit();


            if IncludeAddtion then begin
                recSalesHeader.Reset();
                recSalesHeader.SetRange("FTT-CST Primary Order", pSalesHeader."FTT-CST Primary Order");
                recSalesHeader.SetFilter("No.", '<>%1', CreatedOrderNo);
                //recSalesHeader.SetFilter("FTT-CST Order Type", '%1|%2', recSalesHeader."FTT-CST Order Type"::Additions, recSalesHeader."FTT-CST Order Type"::Renewal)
                recSalesHeader.SetFilter("FTT-CST Order Type", '%1', recSalesHeader."FTT-CST Order Type"::Additions);
                recSalesHeader.SetRange("FTT-CST Use for Renewal", true);

                recSalesHeader.SetFilter("FTT-CST Agr. Ending Date", '%1..%2', pSalesHeader."FTT-CST Agr. Starting Date", pSalesHeader."FTT-CST Agr. Ending Date");
                if recSalesHeader.FindSet() then begin
                    pageSalesList.SetTableView(recSalesHeader);
                    pageSalesList.LookupMode(true);
                    if pageSalesList.RunModal() = Action::LookupOK then begin
                        pageSalesList.SetSelectionFilter(SelectedSalesOrders);
                        CreateRenewalfromAdditions(newSalesHeader, pSalesHeader."FTT-CST Primary Order");
                    end;
                end else begin
                    pageSalesOrder.SetRecord(newSalesHeader);
                    pageSalesOrder.Run();
                end;
            end else begin
                pageSalesOrder.SetRecord(newSalesHeader);
                pageSalesOrder.Run();
            end;
            //end;
        end;

        if pSalesHeader."FTT-CST Order Type" = pSalesHeader."FTT-CST Order Type"::Additions then begin
            newSalesHeader.TransferFields(Rec);
            newSalesHeader."FTT-CST Primary Order" := pSalesHeader."FTT-CST Primary Order";
            newSalesHeader."FTT-CST Main Order No." := pSalesHeader."FTT-CST Primary Order";
            newSalesHeader."FTT-CST Order Type" := newSalesHeader."FTT-CST Order Type"::Renewal;
            newSalesHeader."FTT-CST Agr. Ending Date" := pSalesHeader."FTT-CST Agr. Ending Date";
            newSalesHeader."FTT-CST Agr. Starting Date" := pSalesHeader."FTT-CST Agr. Starting Date";

            newSalesHeader."No." := '';
            newSalesHeader.Insert(true);
            Commit();
            CreatedOrderNo := newSalesHeader."No.";

            FromSalesLines.SetRange("Document Type", pSalesHeader."Document Type");
            FromSalesLines.SetRange("Document No.", pSalesHeader."No.");
            FromSalesLines.SetFilter("FTT-CST Cost Type", '<>%1', FromSalesLines."FTT-CST Cost Type"::NRC); //NRD
            if FromSalesLines.FindSet() then
                repeat
                    InsertNewLines2(FromSalesLines, newSalesHeader, pRenewalStartdate, pRenewalEndDate);
                    FromSalesLines."FTT-CST Use for Renewal" := false;
                    FromSalesLines.Modify()
                until FromSalesLines.Next() = 0;
            Commit();


            if IncludeAddtion then begin
                recSalesHeader.Reset();
                recSalesHeader.SetRange("FTT-CST Primary Order", pSalesHeader."FTT-CST Primary Order");
                recSalesHeader.SetFilter("No.", '<>%1', CreatedOrderNo);
                //recSalesHeader.SetFilter("FTT-CST Order Type", '%1|%2', recSalesHeader."FTT-CST Order Type"::Additions, recSalesHeader."FTT-CST Order Type"::Renewal)
                recSalesHeader.SetFilter("FTT-CST Order Type", '%1', recSalesHeader."FTT-CST Order Type"::Additions);
                recSalesHeader.SetRange("FTT-CST Use for Renewal", true);
                recSalesHeader.SetFilter("FTT-CST Agr. Ending Date", '%1..%2', pSalesHeader."FTT-CST Agr. Starting Date", pSalesHeader."FTT-CST Agr. Ending Date");
                if recSalesHeader.FindSet() then begin
                    pageSalesList.SetTableView(recSalesHeader);
                    pageSalesList.LookupMode(true);
                    if pageSalesList.RunModal() = Action::LookupOK then begin
                        pageSalesList.SetSelectionFilter(SelectedSalesOrders);
                        CreateRenewalfromAdditions(newSalesHeader, pSalesHeader."FTT-CST Primary Order");
                    end;
                end else begin
                    pageSalesOrder.SetRecord(newSalesHeader);
                    pageSalesOrder.Run();
                end;
            end else begin
                pageSalesOrder.SetRecord(newSalesHeader);
                pageSalesOrder.Run();
            end;
        end;
        Commit();
        RefreshAllLines(newSalesHeader);

    end;

    local procedure RefreshAllLines(pSalesheader: Record "Sales Header")
    var
        salesline: Record "Sales Line";
        FTTUnitprice: Decimal;
    begin
        FTTUnitprice := 0;
        salesline.Reset();
        salesline.SetRange("Document Type", pSalesheader."Document Type");
        salesline.SetRange("Document No.", pSalesheader."No.");
        salesline.SetFilter("FTT-CST Cost Type", '%1|%2', salesline."FTT-CST Cost Type"::MRC, salesline."FTT-CST Cost Type"::YRCCalculated);
        if salesline.FindSet() then
            repeat
                if salesline."FTT-CST Cost Type" = salesline."FTT-CST Cost Type"::YRCCalculated then
                    salesline."FTT-CST Unit Price" := 0;

                if (salesline."FTT-CST Cost Type" = salesline."FTT-CST Cost Type"::MRC) AND (salesline."Separated Seq." = 1) then
                    FTTUnitprice := salesline."FTT-CST Unit Price";

                if (salesline."FTT-CST Cost Type" = salesline."FTT-CST Cost Type"::MRC) AND (salesline."Separated Seq." = 2) then begin
                    salesline."FTT-CST Unit Price" := FTTUnitprice;
                    salesline.Validate(Quantity, salesline."FTT-CST Qty");
                    FTTUnitprice := 0;
                end;

                salesline.Modify();
            until salesline.Next() = 0;
    end;

    procedure CreateRenewalfromAdditions(var SalesHeader: Record "Sales Header"; MainOrderNo: Code[20])
    var
        SalesOrder: Page "Sales Order";
        FromSalesLines: Record "Sales Line";
        ToSalesLines: Record "Sales Line";
        LineNo: Integer;
        UnitPriceMRC: Decimal;
        I: Integer;
        DiffDate1: Decimal;
    begin

        FromSalesLines.SetRange("Document Type", SalesHeader."Document Type");
        FromSalesLines.SetRange("Document No.", SalesHeader."No.");
        if FromSalesLines.FindLast() then
            LineNo := FromSalesLines."Line No." else
            LineNo := 0;
        FromSalesLines.Reset();

        if SelectedSalesOrders.FindSet() then
            repeat
                FromSalesLines.Reset();
                FromSalesLines.SetRange("Document Type", SelectedSalesOrders."Document Type");
                FromSalesLines.SetRange("Document No.", SelectedSalesOrders."No.");
                FromSalesLines.SetFilter("FTT-CST Cost Type", '<>%1', FromSalesLines."FTT-CST Cost Type"::NRC); //NRD
                //FromSalesLines.SetRange("FTT-CST Order Type", FromSalesLines."FTT-CST Order Type"::Additions);
                FromSalesLines.SetRange("FTT-CST Use for Renewal", true);

                if FromSalesLines.FindSet() then
                    repeat
                        //NRD - Checking if there's diffirence date.

                        if isGetDiffDate(FromSalesLines."FTT-CST Agreement Date From", FromSalesLines."FTT-CST Agreement Date To") = 12 then begin
                            UnitPriceMRC := 0;
                            LineNo := LineNo + 10000;
                            ToSalesLines.TransferFields(FromSalesLines);
                            ToSalesLines."Agreement Period" := FromSalesLines."Agreement Period" + 1; //NRD
                            ToSalesLines."Document No." := SalesHeader."No.";
                            if FromSalesLines."FTT-CST Cost Type" = FromSalesLines."FTT-CST Cost Type"::YRC then begin //NRD
                                ToSalesLines.Validate(Quantity, 1);
                                ToSalesLines.Validate("FTT-CST Qty", 1);
                            end else if FromSalesLines."FTT-CST Cost Type" = FromSalesLines."FTT-CST Cost Type"::MRC then begin //NRD
                                UnitPriceMRC := (FromSalesLines."FTT-CST Unit Price" * FromSalesLines."FTT-CST Qty") * 12 / FromSalesLines."FTT-CST Qty";
                                ToSalesLines.Validate("Unit Price", UnitPriceMRC);
                            end;
                            //+

                            ToSalesLines."FTT-CST Agreement Date From" := SalesHeader."FTT-CST Agr. Starting Date";
                            ToSalesLines."FTT-CST Agreement Date To" := SalesHeader."FTT-CST Agr. Ending Date";

                            ToSalesLines."FTT-CST Delivery PROD Date" := 0D; //NRD - fix the error on renewals if the dates are difference
                            ToSalesLines."FTT-CST Delivery UAT Date" := 0D; //NRD - fix the error on renewals if the dates are difference
                            ToSalesLines."FTT-CST Main Order No." := SalesHeader."FTT-CST Main Order No.";
                            ToSalesLines."FTT-CST Order Type" := ToSalesLines."FTT-CST Order Type"::Renewal;
                            ToSalesLines."Line No." := LineNo;
                            ToSalesLines."FTT-CST Use for Renewal" := true;
                            ToSalesLines.Insert();
                            FromSalesLines."FTT-CST Use for Renewal" := false;
                            FromSalesLines.Modify();
                        end else begin
                            //NRD - Separate an Item into 2 lines if it's not 12 months period based on the Agreement Date.

                            for I := 1 to 2 do begin
                                if I = 1 then begin
                                    UnitPriceMRC := 0;
                                    LineNo := LineNo + 10000;
                                    //ToSalesLines.TransferFields(FromSalesLines);

                                    InsertNewLines4(FromSalesLines, SalesHeader, SalesHeader."FTT-CST Agr. Starting Date", CalcDate('1Y', FromSalesLines."FTT-CST Agreement Date From"), 1, LineNo);

                                end else begin
                                    LineNo := LineNo + 10000;
                                    InsertNewLines3(FromSalesLines, SalesHeader, CalcDate('1Y', FromSalesLines."FTT-CST Agreement Date From"), SalesHeader."FTT-CST Agr. Ending Date", 2, LineNo);
                                end;

                            end;
                            FromSalesLines."FTT-CST Use for Renewal" := false;
                            FromSalesLines.Modify();
                            //+
                        end;
                    until FromSalesLines.Next() = 0;
                SelectedSalesOrders."FTT-CST Use for Renewal" := false;
                SelectedSalesOrders.Modify();
            until SelectedSalesOrders.next = 0;
        Commit();
        SalesOrder.SetRecord(SalesHeader);
        SalesOrder.Run();
    end;

    local procedure InsertNewLines4(FromSalesLines: Record "Sales Line"; newSalesHeader: Record "Sales Header"; pRenewalStartdate: Date; pRenewalEndDate: Date; SeparatedSeq: Integer; LineNo: Integer)
    var
        DimensionValues: Record "Dimension Value";
        ToSalesLines: Record "Sales Line";
        DiffDate1: Decimal;
        UnitPriceMRC: Decimal;
    begin
        ToSalesLines.Init;
        ToSalesLines."Line No." := LineNo;
        ToSalesLines."Document No." := newSalesHeader."No.";
        ToSalesLines."Document Type" := newSalesHeader."Document Type";
        ToSalesLines.Validate("Sell-to Customer No.", newSalesHeader."Sell-to Customer No.");
        ToSalesLines.Validate("Customer Price Group", newSalesHeader."Customer Price Group");
        ToSalesLines.Validate("Customer Disc. Group", newSalesHeader."Customer Disc. Group");
        ToSalesLines.Validate("Currency Code", newSalesHeader."Currency Code");
        ToSalesLines.Validate(Type, ToSalesLines.Type::Item);
        ToSalesLines.validate("No.", FromSalesLines."No.");

        ToSalesLines."FTT-CST Delivery PROD Date" := 0D; //NRD - fix the error on renewals if the dates are difference
        ToSalesLines."FTT-CST Delivery UAT Date" := 0D; //NRD - fix the error on renewals if the dates are difference
        ToSalesLines."Agreement Period" := FromSalesLines."Agreement Period";
        ToSalesLines."Separated Seq." := SeparatedSeq;
        ToSalesLines."Document No." := newSalesHeader."No.";
        ToSalesLines."FTT-CST Main Order No." := newSalesHeader."FTT-CST Main Order No.";
        ToSalesLines."FTT-CST Primary Order" := newSalesHeader."FTT-CST Primary Order";
        ToSalesLines."FTT-CST Order Type" := ToSalesLines."FTT-CST Order Type"::Renewal;
        ToSalesLines."FTT-CST Use for Renewal" := true;

        ToSalesLines."Allow Line Disc." := newSalesHeader."Allow Line Disc.";
        ToSalesLines."Transaction Type" := newSalesHeader."Transaction Type";
        ToSalesLines."Transport Method" := newSalesHeader."Transport Method";
        ToSalesLines."Bill-to Customer No." := newSalesHeader."Bill-to Customer No.";
        ToSalesLines."Price Calculation Method" := newSalesHeader."Price Calculation Method";
        ToSalesLines."Gen. Bus. Posting Group" := newSalesHeader."Gen. Bus. Posting Group";
        ToSalesLines."VAT Bus. Posting Group" := newSalesHeader."VAT Bus. Posting Group";

        ToSalesLines."FTT-CST Comments" := FromSalesLines."FTT-CST Comments";

        ToSalesLines."FTT-CST Use for Discount" := FromSalesLines."FTT-CST Use for Discount";
        ToSalesLines."Allow Line Disc." := FromSalesLines."FTT-CST Use for Discount";
        ToSalesLines."Allow Invoice Disc." := FromSalesLines."FTT-CST Use for Discount";
        ToSalesLines."FTT-CST Parent Item Cat. Code" := FromSalesLines."FTT-CST Parent Item Cat. Code";
        ToSalesLines."FTT-CST Comments Fluent" := FromSalesLines."FTT-CST Comments Fluent";
        ToSalesLines."FTT-CST DR" := FromSalesLines."FTT-CST DR";
        ToSalesLines."FTT-CST Integration" := FromSalesLines."FTT-CST Integration";
        ToSalesLines."FTT-CST Redundancy" := FromSalesLines."FTT-CST Redundancy";
        ToSalesLines."FTT-CST Redundancy PriceCalc %" := FromSalesLines."FTT-CST Redundancy PriceCalc %";
        ToSalesLines."FTT-CST Location Code" := FromSalesLines."FTT-CST Location Code";
        ToSalesLines."FTT-CST Location Type" := FromSalesLines."FTT-CST Location Type";
        ToSalesLines."FTT-CST Component Option" := FromSalesLines."FTT-CST Component Option";
        ToSalesLines."FTT-CST Sublocation" := FromSalesLines."FTT-CST Sublocation";
        ToSalesLines."Shortcut Dimension 1 Code" := newSalesHeader."Shortcut Dimension 1 Code";
        ToSalesLines."Shortcut Dimension 2 Code" := newSalesHeader."Shortcut Dimension 2 Code";
        ToSalesLines."FTT-CST Cost Type" := FromSalesLines."FTT-CST Cost Type";

        if (FromSalesLines.Quantity < 1) AND (FromSalesLines."FTT-CST Cost Type" <> FromSalesLines."FTT-CST Cost Type"::MRC) then begin
            DiffDate1 := 1 - FromSalesLines.Quantity;
        end else if FromSalesLines."FTT-CST Cost Type" <> FromSalesLines."FTT-CST Cost Type"::MRC then begin
            DiffDate1 := GetDiffDate(newSalesHeader."FTT-CST Agr. Starting Date", CalcDate('1Y', FromSalesLines."FTT-CST Agreement Date From"), FromSalesLines."FTT-CST Cost Type");
        end else
            DiffDate1 := GetDiffDate(newSalesHeader."FTT-CST Agr. Starting Date", CalcDate('1Y', FromSalesLines."FTT-CST Agreement Date From"), FromSalesLines."FTT-CST Cost Type");

        ToSalesLines.ValidateShortcutDimCode(3, FromSalesLines."FTT-CST Location Code");
        //Add Dimesnsion for Sublocation
        DimensionValues.Reset;
        DimensionValues.SetRange("FTT-CST Sublocation", FromSalesLines."FTT-CST Sublocation");
        if DimensionValues.FindFirst() then
            ToSalesLines.ValidateShortcutDimCode(4, DimensionValues.Code);


        if FromSalesLines."FTT-CST Cost Type" = FromSalesLines."FTT-CST Cost Type"::YRC then begin //NRD
            ToSalesLines."Unit Price" := FromSalesLines."Unit Price";
            ToSalesLines."FTT-CST Unit Price" := FromSalesLines."FTT-CST Unit Price";
            ToSalesLines."FTT-CST Qty" := FromSalesLines."FTT-CST Qty";
            ToSalesLines.Validate(Quantity, DiffDate1);
        end else if FromSalesLines."FTT-CST Cost Type" = FromSalesLines."FTT-CST Cost Type"::MRC then begin //NRD
            UnitPriceMRC := (FromSalesLines."FTT-CST Unit Price" * FromSalesLines.Quantity) * 12 / FromSalesLines."FTT-CST Qty";
            ToSalesLines."Unit Price" := (UnitPriceMRC - FromSalesLines."Unit Price");
            ToSalesLines."FTT-CST Unit Price" := FromSalesLines."FTT-CST Unit Price";
            ToSalesLines."FTT-CST Qty" := FromSalesLines."FTT-CST Qty";
            ToSalesLines.Validate(Quantity, FromSalesLines."FTT-CST Qty");

        end else if FromSalesLines."FTT-CST Cost Type" = FromSalesLines."FTT-CST Cost Type"::YRCCalculated then begin //NRD
            ToSalesLines."Unit Price" := FromSalesLines."Unit Price";
            ToSalesLines."FTT-CST Unit Price" := FromSalesLines."FTT-CST Unit Price";
            ToSalesLines."FTT-CST Qty" := FromSalesLines."FTT-CST Qty";
            ToSalesLines.Validate(Quantity, DiffDate1);
        end;


        if ToSalesLines.Insert(True) then begin
            Commit();
            ToSalesLines."FTT-CST Agreement Date From" := pRenewalStartdate;
            ToSalesLines."FTT-CST Agreement Date To" := pRenewalEndDate;
            ToSalesLines.Modify();
        end;
    end;

    local procedure InsertNewLines3(FromSalesLines: Record "Sales Line"; newSalesHeader: Record "Sales Header"; pRenewalStartdate: Date; pRenewalEndDate: Date; SeparatedSeq: Integer; LineNo: Integer)
    var
        DimensionValues: Record "Dimension Value";
        ToSalesLines: Record "Sales Line";
    begin
        ToSalesLines.Init;
        ToSalesLines."Line No." := LineNo;
        ToSalesLines."Document No." := newSalesHeader."No.";
        ToSalesLines."Document Type" := newSalesHeader."Document Type";
        ToSalesLines.Validate("Sell-to Customer No.", newSalesHeader."Sell-to Customer No.");
        ToSalesLines.Validate("Customer Price Group", newSalesHeader."Customer Price Group");
        ToSalesLines.Validate("Customer Disc. Group", newSalesHeader."Customer Disc. Group");
        ToSalesLines.Validate("Currency Code", newSalesHeader."Currency Code");
        ToSalesLines.Validate(Type, ToSalesLines.Type::Item);
        ToSalesLines.validate("No.", FromSalesLines."No.");

        ToSalesLines."FTT-CST Delivery PROD Date" := 0D; //NRD - fix the error on renewals if the dates are difference
        ToSalesLines."FTT-CST Delivery UAT Date" := 0D; //NRD - fix the error on renewals if the dates are difference
        ToSalesLines."Agreement Period" := FromSalesLines."Agreement Period" + 1;
        ToSalesLines."Separated Seq." := SeparatedSeq;
        ToSalesLines."Document No." := newSalesHeader."No.";
        ToSalesLines."FTT-CST Main Order No." := newSalesHeader."FTT-CST Main Order No.";
        ToSalesLines."FTT-CST Primary Order" := newSalesHeader."FTT-CST Primary Order";
        ToSalesLines."FTT-CST Order Type" := ToSalesLines."FTT-CST Order Type"::Renewal;
        ToSalesLines."FTT-CST Use for Renewal" := true;

        ToSalesLines."Allow Line Disc." := newSalesHeader."Allow Line Disc.";
        ToSalesLines."Transaction Type" := newSalesHeader."Transaction Type";
        ToSalesLines."Transport Method" := newSalesHeader."Transport Method";
        ToSalesLines."Bill-to Customer No." := newSalesHeader."Bill-to Customer No.";
        ToSalesLines."Price Calculation Method" := newSalesHeader."Price Calculation Method";
        ToSalesLines."Gen. Bus. Posting Group" := newSalesHeader."Gen. Bus. Posting Group";
        ToSalesLines."VAT Bus. Posting Group" := newSalesHeader."VAT Bus. Posting Group";

        ToSalesLines."FTT-CST Comments" := FromSalesLines."FTT-CST Comments";

        ToSalesLines."FTT-CST Use for Discount" := FromSalesLines."FTT-CST Use for Discount";
        ToSalesLines."Allow Line Disc." := FromSalesLines."FTT-CST Use for Discount";
        ToSalesLines."Allow Invoice Disc." := FromSalesLines."FTT-CST Use for Discount";
        ToSalesLines."FTT-CST Parent Item Cat. Code" := FromSalesLines."FTT-CST Parent Item Cat. Code";
        ToSalesLines."FTT-CST Comments Fluent" := FromSalesLines."FTT-CST Comments Fluent";
        ToSalesLines."FTT-CST DR" := FromSalesLines."FTT-CST DR";
        ToSalesLines."FTT-CST Integration" := FromSalesLines."FTT-CST Integration";
        ToSalesLines."FTT-CST Redundancy" := FromSalesLines."FTT-CST Redundancy";
        ToSalesLines."FTT-CST Redundancy PriceCalc %" := FromSalesLines."FTT-CST Redundancy PriceCalc %";
        ToSalesLines."FTT-CST Location Code" := FromSalesLines."FTT-CST Location Code";
        ToSalesLines."FTT-CST Location Type" := FromSalesLines."FTT-CST Location Type";
        ToSalesLines."FTT-CST Component Option" := FromSalesLines."FTT-CST Component Option";
        ToSalesLines."FTT-CST Sublocation" := FromSalesLines."FTT-CST Sublocation";
        ToSalesLines."Shortcut Dimension 1 Code" := newSalesHeader."Shortcut Dimension 1 Code";
        ToSalesLines."Shortcut Dimension 2 Code" := newSalesHeader."Shortcut Dimension 2 Code";
        ToSalesLines."FTT-CST Cost Type" := FromSalesLines."FTT-CST Cost Type";

        ToSalesLines."Unit Price" := FromSalesLines."Unit Price";
        ToSalesLines."FTT-CST Unit Price" := FromSalesLines."FTT-CST Unit Price";
        ToSalesLines."FTT-CST Qty" := FromSalesLines."FTT-CST Qty";
        ToSalesLines.validate(Quantity, FromSalesLines.Quantity);
        ToSalesLines.ValidateShortcutDimCode(3, FromSalesLines."FTT-CST Location Code");
        //Add Dimesnsion for Sublocation
        DimensionValues.Reset;
        DimensionValues.SetRange("FTT-CST Sublocation", FromSalesLines."FTT-CST Sublocation");
        if DimensionValues.FindFirst() then
            ToSalesLines.ValidateShortcutDimCode(4, DimensionValues.Code);

        if ToSalesLines.Insert(True) then begin
            Commit();
            ToSalesLines."FTT-CST Agreement Date From" := pRenewalStartdate;
            ToSalesLines."FTT-CST Agreement Date To" := pRenewalEndDate;
            ToSalesLines.Modify();
        end;
    end;


    local procedure isGetDiffDate(StartingDate: Date; EndingDate: Date): Decimal
    var
        DiffDate: Decimal;
        DiffM: Integer;
        DiffY: Integer;
    begin
        DiffM := Date2DMY(EndingDate, 2) - Date2DMY(StartingDate, 2);
        DiffY := Date2DMY(EndingDate, 3) - Date2DMY(StartingDate, 3);
        DiffDate := 12 * DiffY + DiffM;

        EXIT(DiffDate);
    end;

    local procedure GetDiffDate(StartingDate: Date; EndingDate: Date; FTTCSTCostType: Enum "FTT-CST Cost Type"): Decimal
    var
        GeneralLedgerSetup: Record "General Ledger Setup";
        DiffDate: Decimal;
        DiffM: Integer;
        DiffY: Integer;
    begin
        if FTTCSTCostType = "FTT-CST Cost Type"::NRC then
            exit(DiffDate);
        if FTTCSTCostType = "FTT-CST Cost Type"::YRCCalculated then
            exit(DiffDate);


        DiffM := Date2DMY(EndingDate, 2) - Date2DMY(StartingDate, 2);
        DiffY := Date2DMY(EndingDate, 3) - Date2DMY(StartingDate, 3);
        DiffDate := 12 * DiffY + DiffM;
        if Date2DMY(EndingDate, 1) > Date2DMY(StartingDate, 1) then
            DiffDate += 1;


        if DiffDate = 0 then
            DiffDate := 1;

        if FTTCSTCostType = "FTT-CST Cost Type"::YRC then
            DiffDate := DiffDate / 12;

        if FTTCSTCostType = "FTT-CST Cost Type"::MRC then
            DiffDate := DiffDate;


        GeneralLedgerSetup.Get();
        DiffDate := Round(DiffDate, GeneralLedgerSetup."Unit-Amount Rounding Precision");
        exit(DiffDate);


    end;


    procedure CreateAdditions(var SalesHeader: Record "Sales Header")
    var
        newSalesHeader: record "Sales Header";
        SalesOrder: Page "Sales Order";
        FromSalesLines: Record "Sales Line";
        ToSalesLines: Record "Sales Line";
        LineNo: Integer;
    begin
        newSalesHeader.TransferFields(Rec);
        if SalesHeader."FTT-CST Order Type" = SalesHeader."FTT-CST Order Type"::Primary then begin
            newSalesHeader."FTT-CST Primary Order" := Rec."No.";
            newSalesHeader."FTT-CST Main Order No." := Rec."No.";
        end else begin
            newSalesHeader."FTT-CST Primary Order" := Rec."FTT-CST Main Order No.";
            newSalesHeader."FTT-CST Main Order No." := Rec."FTT-CST Main Order No.";
        end;

        newSalesHeader."FTT-CST Order Type" := newSalesHeader."FTT-CST Order Type"::Additions;
        newSalesHeader."FTT-CST Use for Renewal" := true;
        // newSalesHeader."FTT-CST Agr. Starting Date" := CalcDate('1Y', Rec."FTT-CST Agr. Starting Date");
        // newSalesHeader."FTT-CST Agr. Ending Date" := CalcDate('1Y', Rec."FTT-CST Agr. Ending Date");
        newSalesHeader."FTT-CST Agr. Starting Date" := Rec."FTT-CST Agr. Starting Date"; //NRD
        newSalesHeader."FTT-CST Agr. Ending Date" := Rec."FTT-CST Agr. Ending Date"; //NRD
        newSalesHeader."No." := '';
        newSalesHeader.Insert(true);

        Commit();

        SalesOrder.SetRecord(newSalesHeader);
        SalesOrder.Run();
    end;

    procedure InitNewLines(SalesHeader: Record "Sales Header"; SelectionFilter: Text[1024]; FilterNo: integer);
    var
        SalesLine: Record "Sales Line";
        ItemFilters: Record "FTT-CST Dependency Filters";
        LineNo: Integer;
        DependancyItem: Record "FTT-CST Dependancy Item";
        ItemCategotyCode: record "Item Category";
        ItemSt: record Item;
        DimensionValues: Record "Dimension Value";
        Currency: Record Currency;
        CurrExchRate: Record "Currency Exchange Rate";
        YearInt: Integer;
    begin
        ItemFilters.Get(SalesHeader."No.", FilterNo);
        SalesHeader."FTT-CST Component Option" := ItemFilters."FTT-CST Component Option";
        SalesHeader."FTT-CST Region Code" := ItemFilters."FTT-CST Location Code";
        SalesHeader."FTT-CST Use for Renewal" := true;
        SalesHeader.Modify();

        SalesLine.SetRange("Document Type", SalesHeader."Document Type");
        SalesLine.SetRange("Document No.", SalesHeader."No.");
        IF SalesLine.FindLast() THEN
            LineNo := SalesLine."Line No." else
            LineNo := 0;

        DependancyItem.SetFilter("No.", SelectionFilter);
        DependancyItem.SetFilter("Sales Document No.", Rec."No."); //27.05.2024 IVS Added

        DependancyItem.SetCurrentKey(Level);
        if DependancyItem.FindSet() then
            repeat
                SalesLine.Init();
                SalesLine."Line No." := LineNo + 10000;
                Salesline."Document No." := SalesHeader."No.";
                SalesLine."Document Type" := SalesHeader."Document Type";
                SalesLine.Validate("Sell-to Customer No.", SalesHeader."Sell-to Customer No.");
                SalesLine.Validate("Customer Price Group", SalesHeader."Customer Price Group");
                SalesLine.Validate("Customer Disc. Group", SalesHeader."Customer Disc. Group");
                SalesLine.Validate("Currency Code", SalesHeader."Currency Code");
                SalesLine.Validate(Type, SalesLine.Type::Item);
                SalesLine.Validate("No.", DependancyItem."No.");
                SalesLine.validate("Unit Price", DependancyItem."Unit Price");
                YearInt := Date2DMY(SalesHeader."FTT-CST Agr. Starting Date", 3);
                SalesLine."FTT-CST Year" := YearInt;
                SalesLine.insert();

                SalesLine."Allow Line Disc." := SalesHeader."Allow Line Disc.";
                SalesLine."Transaction Type" := SalesHeader."Transaction Type";
                SalesLine."Transport Method" := SalesHeader."Transport Method";
                SalesLine."Bill-to Customer No." := SalesHeader."Bill-to Customer No.";
                SalesLine."Price Calculation Method" := SalesHeader."Price Calculation Method";
                SalesLine."Gen. Bus. Posting Group" := SalesHeader."Gen. Bus. Posting Group";
                SalesLine."VAT Bus. Posting Group" := SalesHeader."VAT Bus. Posting Group";

                if DependancyItem."FTT-CST Quantity" > 1 then begin
                    SalesLine.Quantity := DependancyItem."FTT-CST Quantity";
                    SalesLine."FTT-CST Qty" := DependancyItem."FTT-CST Quantity";
                end else begin
                    SalesLine.Quantity := 1;
                    SalesLine."FTT-CST Qty" := 1;

                end;

                LineNo := SalesLine."Line No.";
                SalesLine."FTT-CST Comments" := DependancyItem."FTT-CST Comments";
                SalesLine.Validate("FTT-CST Optional", DependancyItem.Optional);

                if DependancyItem.Optional = DependancyItem.Optional::Yes then
                    SalesLine.Validate(Quantity, SalesLine.Quantity);

                SalesLine."FTT-CST Use for Discount" := DependancyItem."FTT-CST Use for Discount";
                SalesLine."Allow Line Disc." := DependancyItem."FTT-CST Use for Discount";
                SalesLine."Allow Invoice Disc." := DependancyItem."FTT-CST Use for Discount";
                Salesline."FTT-CST Parent Item Cat. Code" := DependancyItem."FTT-CST Parent Category Code";
                SalesLine."FTT-CST Comments Fluent" := DependancyItem."FTT-CST Comments Fluent";
                SalesLine."FTT-CST DR" := DependancyItem.DR;
                SalesLine."FTT-CST Integration" := DependancyItem."Integr."; //NRD
                SalesLine."FTT-CST Redundancy" := DependancyItem.Redundancy;
                SalesLine."FTT-CST Redundancy PriceCalc %" := DependancyItem."FTT-CST RED/DR PriceCalc %";
                SalesLine."FTT-CST Location Code" := DependancyItem."Location Code";
                SalesLine."FTT-CST Location Type" := DependancyItem."FTT-CST Location Type";
                SalesLine."FTT-CST Component Option" := DependancyItem."FTT-CST Component Option";
                SalesLine."FTT-CST Sublocation" := DependancyItem."FTT-CST Sublocation";
                SalesLine."Shortcut Dimension 1 Code" := SalesHeader."Shortcut Dimension 1 Code";
                SalesLine."Shortcut Dimension 2 Code" := SalesHeader."Shortcut Dimension 2 Code";
                SalesLine."FTT-CST Use for Renewal" := TRUE;
                SalesLine."FTT-CST Main Order No." := SalesHeader."FTT-CST Main Order No.";
                SalesLine."FTT-CST Primary Order" := SalesHeader."FTT-CST Primary Order";
                SalesLine."FTT-CST Order Type" := SalesHeader."FTT-CST Order Type";

                SalesLine."Unit Price" := DependancyItem."Unit Price";
                SalesLine."FTT-CST Unit Price" := DependancyItem."Unit Price";

                if ItemSt.Get(DependancyItem."No.") then
                    SalesLine.Validate("FTT-CST Cost Type", ItemSt."FTT-CST Cost Type");
                SalesLine."SDP Items" := ItemSt."SDP Items"; //NRD
                SalesLine.isRedundancyCalculated := false;  //NRD
                SalesLine.isDRCalculated := false;  //NRD
                SalesLine.isIntegCalculated := false;  //NRD

                SalesLine.ValidateShortcutDimCode(3, SalesLine."FTT-CST Location Code");
                //Add Dimesnsion for Sublocation
                DimensionValues.Reset;
                DimensionValues.SetRange("FTT-CST Sublocation", SalesLine."FTT-CST Sublocation");
                if DimensionValues.FindFirst() then
                    SalesLine.ValidateShortcutDimCode(4, DimensionValues.Code);

                SalesLine.Validate("FTT-CST Optional", DependancyItem.Optional);
                if DependancyItem.Optional = DependancyItem.Optional::Yes then
                    SalesLine.Validate(Quantity, SalesLine.Quantity);

                if (SalesLine."FTT-CST Cost Type" = SalesLine."FTT-CST Cost Type"::NRC) then // AND (SalesLine."FTT-CST Parent Item Cat. Code" = 'HARDWARE') then //NRD - Fixed the Unit Price and Line amount
                    SalesLine.Validate(Quantity, SalesLine.Quantity);

                SalesLine."Allow Invoice Disc." := SalesLine."FTT-CST Use for Discount";
                SalesLine."Allow Line Disc." := SalesLine."FTT-CST Use for Discount";
                if SalesLine.Modify() then;

            // SalesLine.Validate("FTT-CST Optional", DependancyItem.Optional);
            // SalesLine.Validate(Quantity, SalesLine.Quantity);
            // SalesLine.Modify();
            until DependancyItem.Next() = 0;

        DependancyItem.SetRange("Filter No.", FilterNo);
        DependancyItem.SetRange("Sales Document No.", rec."No.");
        DependancyItem.DeleteAll();
    end;

    local procedure ValidateQTYInLines(pSalesHeader: record "Sales Header")
    var
        SalesLines_l: Record "Sales Line";
    begin
        SalesLines_l.Reset();
        SalesLines_l.SetRange("Document Type", pSalesHeader."Document Type");
        SalesLines_l.SetRange("Document No.", pSalesHeader."No.");
        SalesLines_l.SetFilter("FTT-CST Cost Type", '<>%1', SalesLines_l."FTT-CST Cost Type"::MRC);
        if SalesLines_l.FindSet() then
            repeat
                SalesLines_l.Validate(Quantity);
            until SalesLines_l.Next() = 0;

    end;

    var
        Text002: Label 'Fluent Trade Technologies software pricing methodology is based on the individual components and feeds that its clients utilise. This initial pricing proposal is presented in %1 and relates to the proposed initial project scope as Fluent understands it. Final written requirements are to be mutually agreed upon before a firm price proposal from Fluent. If relevant, additional hardware and infrastructure fees may also apply. ';
        Text001: text[450];
        SelectedSalesOrders: Record "Sales Header";
}
