pageextension 60001 "FTT-CST ContactList" extends "Contact List"
{
    layout
    {
        modify("No.")
        {
            StyleExpr = SubsidiaryStyle;
        }
        modify(Name)
        {
            StyleExpr = SubsidiaryStyle;
        }
        modify("Business Relation")
        {
            Visible = false;
        }
        addafter("Company Name")
        {
            field("FTT-CST Subsidiary Name"; Rec."FTT-CST Subsidiary Name")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies the name of the subsidiary company. If the contact is a person, Specifies the name of the subsidiary company for which this contact works. This field is not editable.';
            }
            field("FTT-CST ContBusinessRelation"; Rec."FTT-CST ContBusinessRelation")
            {
                ApplicationArea = all;
            }
        }
        addfirst(factboxes)
        {
            part("Attached Documents"; "Document Attachment Factbox")
            {
                ApplicationArea = All;
                Caption = 'Attachments';
                SubPageLink = "Table ID" = const(Database::Contact), "No." = field("No.");
            }
        }
    }
    actions
    {
        addafter("P&erson")
        {
            action(ImportContacts)
            {
                Caption = 'Import Contacts';
                Promoted = true;
                PromotedCategory = Process;
                Image = Import;
                ApplicationArea = All;

                trigger OnAction()
                var
                    FTTContacts: record "FTT-CST Contact";
                    XMLImportContacts: XmlPort "FTT-CST Import Contact";
                    Contacts: Record Contact;
                    Contacts2: Record Contact;

                begin
                    FTTContacts.DeleteAll();
                    XMLImportContacts.SetTableView(FTTContacts);
                    XMLImportContacts.Run();

                    if FTTContacts.FindSet() then
                        repeat
                            if FTTContacts.Type = FTTContacts.type::Company then begin
                                if not Contacts.get(FTTContacts."No.") then begin
                                    Contacts.Init();
                                    Contacts2.TransferFields(FTTContacts);
                                    Contacts."No." := '';
                                    if Contacts.Insert(true) then;
                                end
                            end;
                        until FTTContacts.Next = 0;
                end;
            }
        }
        modify(Email)
        {
            ApplicationArea = all;
            Visible = false;

        }
        addafter(WordTemplate)
        {
            action(Email2)
            {
                ApplicationArea = All;
                Caption = 'Send Email';
                Image = Email;
                ToolTip = 'Send an email to this contact.';
                trigger OnAction()
                var
                    TempEmailItem: Record "Email Item" temporary;
                    EmailScenario: Enum "Email Scenario";
                    userSetup: Record "User Setup";
                    SignatureCustom: Codeunit "Fluent Custom Subscriber";
                    isEmailSigInc: Boolean;
                    GmailMaintenanceSetup: Record "GMAIL Maintenance Setup";
                begin
                    if not GmailMaintenanceSetup.Get() then
                        exit;

                    isEmailSigInc := false;
                    if userSetup.Get(UserId) then begin
                        if userSetup."Email Signature Included" then begin
                            userSetup.TestField("Job Position");
                            userSetup.TestField("E-Mail");
                            userSetup.TestField("Phone No.");
                            isEmailSigInc := true;
                        end
                    end else
                        Error('User Setup does not exist for this ID : %1', UserId);

                    TempEmailItem.AddSourceDocument(Database::Contact, Rec.SystemId);
                    if GmailMaintenanceSetup."Add to BCC as Default" then
                        TempEmailItem."Send CC" := GmailMaintenanceSetup."CRM Email";

                    TempEmailitem."Send to" := Rec."E-Mail";
                    if isEmailSigInc then
                        TempEmailItem.SetBodyText(SignatureCustom.GenerateSignatureEmailBodyReport(userSetup));

                    TempEmailItem.Send(false, EmailScenario::Default);
                end;
            }
            action(UpdateContactBusRelation)
            {
                Caption = 'Update Contact Business Relation';
                Image = UpdateDescription;
                ApplicationArea = all;
                trigger OnAction()
                var
                    recContact: Record Contact;
                    recContact2: Record Contact;
                    ContactBusRelation: Record "Contact Business Relation";
                    recCustomer: Record Customer;
                begin
                    rec.SetFilter(Type, '%1', rec.Type::Company);
                    if rec.FindSet() then
                        repeat
                            recContact := rec;
                            ContactBusRelation.reset;
                            ContactBusRelation.SetRange("Contact No.", rec."No.");
                            if ContactBusRelation.FindFirst() then begin
                                if ContactBusRelation."Link to Table" = ContactBusRelation."Link to Table"::Customer then begin
                                    recCustomer.Reset();
                                    recCustomer.SetRange("No.", ContactBusRelation."No.");
                                    recCustomer.SetRange(Prospect, false);
                                    if recCustomer.FindFirst() then begin
                                        recContact."FTT-CST ContBusinessRelation" := recContact."FTT-CST ContBusinessRelation"::Customer;
                                        recContact.Modify();
                                        Commit();
                                        recContact2.Reset();
                                        recContact2.SetFilter(Type, '%1', recContact2.type::Person);
                                        recContact2.SetFilter("Company No.", recContact."No.");
                                        if recContact2.FindSet() then
                                            recContact2.ModifyAll(recContact2."FTT-CST ContBusinessRelation", recContact2."FTT-CST ContBusinessRelation"::Customer);
                                    end;


                                end else if ContactBusRelation."Link to Table" = ContactBusRelation."Link to Table"::Vendor then begin
                                    recContact."FTT-CST ContBusinessRelation" := recContact."FTT-CST ContBusinessRelation"::Vendor;
                                    recContact.Modify();
                                    Commit();

                                    recContact2.Reset();
                                    recContact2.SetFilter(Type, '%1', recContact2.type::Person);
                                    recContact2.SetFilter("Company No.", recContact."No.");
                                    if recContact2.FindSet() then
                                        recContact2.ModifyAll(recContact2."FTT-CST ContBusinessRelation", recContact2."FTT-CST ContBusinessRelation"::Vendor);
                                end else if ContactBusRelation."Link to Table" = ContactBusRelation."Link to Table"::Employee then begin
                                    recContact."FTT-CST ContBusinessRelation" := recContact."FTT-CST ContBusinessRelation"::Employee;
                                    recContact.Modify();
                                    Commit();

                                    recContact2.Reset();
                                    recContact2.SetFilter(Type, '%1', recContact2.type::Person);
                                    recContact2.SetFilter("Company No.", recContact."No.");
                                    if recContact2.FindSet() then
                                        recContact2.ModifyAll(recContact2."FTT-CST ContBusinessRelation", recContact2."FTT-CST ContBusinessRelation"::Employee);
                                end;
                            end;
                        until rec.Next() = 0;

                    rec.Reset();
                    CurrPage.Update(false);
                    Message('Done');
                end;
            }
        }
    }

    procedure FilterSalesMngr(): Code[20];
    var
        MySesSet: SessionSettings;
        lSP: Record "Salesperson/Purchaser";
        UserSETUP: Record "User Setup";
        lUser: Record User;
        lSPCode: Code[250];
    Begin
        lSPCode := '';
        MySesSet.Init;
        IF MySesSet.ProfileId <> 'FTT_SALES_MANAGER' THEN
            Exit(lSPCode);

        IF UserSETUP.GET(UserID) then begin
            lSP.SETRANGE("User ID", UserSETUP."User ID");
            IF lSP.FINDSET THEN begin
                repeat
                    lSPCode := lSP.Code + '|';
                until lSP.Next = 0;
                lSPCode := DELCHR(lSPCode, '>', '|');
            End;
        end;
        Exit(lSPCode);

    End;

    trigger OnOpenPage()
    var
        UserSETUP: Record "User Setup"; //Nimrod

    begin
        Rec.SetCurrentKey("Company Name", "Company No.", "FTT-CST Subsidiary Name", "FTT-CST Subsidiary No.", "FTT-CST Subsidiary Type", Type, Name);

        //Nimrod +
        if not UserSETUP.Get(UserId) then
            exit;

        if (UserSETUP."Sales Resp. Ctr. Filter" <> '') then begin //NRD
            rec.FilterGroup(2);
            rec.SetRange(Rec."Salesperson Code", UserSETUP."Sales Resp. Ctr. Filter");
            rec.FilterGroup(0);
        end;

        IF FilterSalesMngr <> '' THEN begin
            rec.FilterGroup(2);
            rec.Setfilter(Rec."Salesperson Code", '%1', FilterSalesMngr());
            rec.FilterGroup(0);
        end;
    end;

    trigger OnAfterGetRecord()

    begin
        case Rec.Type of
            Rec.Type::Company:
                SubsidiaryStyle := 'Strong';
            Rec.Type::Person:
                SubsidiaryStyle := 'None';
            Rec.Type::"Subsidiary Company":
                SubsidiaryStyle := 'AttentionAccent';
        end;

    end;

    var
        SubsidiaryStyle: Text;
}
