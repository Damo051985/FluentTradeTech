pageextension 60004 "FTT-CST DocAttmtDetails" extends "Document Attachment Details"
{
    layout
    {
        modify("File Extension")
        {
            Visible = false;
        }
        modify("File Type")
        {
            ApplicationArea = all;
            Editable = isEditable;

        }
        addafter("Attached Date")
        {
            //>>dan 082924
            field("FTT-CST Starting Date"; Rec."FTT-CST Starting Date")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies the starting date for the document expiration.';
            }
            //<<dan 082924
            field("FTT-CST Expiration Date"; Rec."FTT-CST Expiration Date")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies the date when the document expires.';
            }
            field("FTT-CST Notification Period"; Rec."FTT-CST Notification Period")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies the period for the document expiration.';
            }
            field("FTT-CST Notification Date"; Rec."FTT-CST Notification Date")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies the date when the notification for the document will be created.';
            }
            //>>dan 082924
            field("FTT-CST Employee"; Rec."FTT-CST Employee")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies the starting date for the document expiration.';
                Visible = False;
            }

            //<<dan 082924
        }

        addafter(Name)
        {
            field("FTT-CST Final Document"; Rec."FTT-CST Final Document") //NRD
            {
                ApplicationArea = all;
                ToolTip = 'Specifes that the attached document is a Final Document';
                trigger OnValidate()
                begin
                    if rec."FTT-CST Google Drive Link" <> '' then begin
                        rec."Table ID" := rec."Table ID";
                        rec."No." := rec."No.";
                        rec."File Name" := 'No Attachment';
                        rec."File Type" := rec."File Type"::Excel;
                        rec."File Extension" := 'xlsx';
                        //rec."Document Reference ID" := recAttacment.Data;
                        rec."Attached By" := UserSecurityId();
                        rec."Attached Date" := CurrentDateTime;
                        IF rec.Insert() THEN begin
                            rec."FTT-CST Contact Name" := GetContactName(Rec);
                            rec.Modify();
                        end;

                        CurrPage.Update();
                    end;
                    //if not rec.HasContent() then
                    //  Error('No Attachment found !');
                end;
            }
            field("FTT-CST Document Type"; Rec."FTT-CST Document Type")
            {
                ApplicationArea = all;
                Editable = False;
            }
            field("FTT-CST Document Name"; Rec."FTT-CST Document Name")
            {
                ApplicationArea = All;
                Editable = True;
                ToolTip = 'Specifies the document name.';
            }
            field("FTT-CST Serial Number"; Rec."FTT-CST Serial Number")
            {
                ApplicationArea = All;
                Editable = True;
                Visible = gVis;
                ToolTip = 'Specifies the serial number.';
            }
            field("FTT-CST Contact Name"; Rec."FTT-CST Contact Name")
            {
                ApplicationArea = All;
                Editable = false;
                Visible = gVis;
                ToolTip = 'Specifies the contact name.';
            }
            field("FTT-CST Google Drive Link"; Rec."FTT-CST Google Drive Link") //NRD
            {
                ApplicationArea = all;

                trigger OnLookup(var Text: Text): Boolean
                var
                    pagHyperLink: Page "HyperLink Show";
                begin

                    if rec."FTT-CST Google Drive Link" = '' then
                        Error('No Google Drive Link found!');

                    pagHyperLink.SetURL(rec."FTT-CST Google Drive Link");
                    pagHyperLink.Run();
                end;
            }
            field("MSA Document"; Rec."MSA Document")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies that the attached document is a MSA Document';
                Visible = gVis;
                trigger OnValidate()
                var
                    lDocAtt: Record "Document Attachment";
                Begin
                    IF Rec."MSA Document" THEN BEGIN
                        Rec."FTT-CST Document Type" := Rec."FTT-CST Document Type"::MSA;
                        Rec."FTT-CST SOW Document" := False;
                        Rec."FTT-CST Others" := False;
                        Rec."FTT-CST NDA" := False;
                        Rec.Modify;
                    End ELSE begin
                        Rec."FTT-CST Document Type" := Rec."FTT-CST Document Type"::Others;
                        Rec.Modify;
                    end;
                End;
            }
            field("SOW Document"; Rec."FTT-CST SOW Document")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies that the attached document is a SOW Document';
                Visible = gVis;
                trigger OnValidate()
                var
                    lDocAtt: Record "Document Attachment";
                Begin
                    IF Rec."FTT-CST SOW Document" THEN BEGIN
                        Rec."FTT-CST Document Type" := Rec."FTT-CST Document Type"::SOW;
                        Rec."MSA Document" := False;
                        Rec."FTT-CST Others" := False;
                        Rec."FTT-CST NDA" := False;
                        Rec.Modify;
                    End ELSE begin
                        Rec."FTT-CST Document Type" := Rec."FTT-CST Document Type"::Others;
                        Rec.Modify;
                    end;
                End;
            }
            field("NDA"; Rec."FTT-CST NDA")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies that the attached document is a NDA Document';
                Visible = gVis;
                trigger OnValidate()
                var
                    lDocAtt: Record "Document Attachment";
                Begin
                    IF Rec."FTT-CST NDA" THEN BEGIN
                        Rec."FTT-CST Document Type" := Rec."FTT-CST Document Type"::NDA;
                        Rec."MSA Document" := False;
                        Rec."FTT-CST Others" := False;
                        Rec."FTT-CST SOW Document" := False;
                        Rec.Modify;
                    End ELSE begin
                        Rec."FTT-CST Document Type" := Rec."FTT-CST Document Type"::Others;
                        Rec.Modify;
                    end;
                End;
            }
            field("Others"; Rec."FTT-CST Others")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies that the attached document is a Other document';
                trigger OnValidate()
                var
                    lDocAtt: Record "Document Attachment";
                Begin
                    IF Rec."FTT-CST Others" THEN BEGIN
                        Rec."FTT-CST Document Type" := Rec."FTT-CST Document Type"::Others;
                        Rec."MSA Document" := False;
                        Rec."FTT-CST NDA" := False;
                        Rec."FTT-CST SOW Document" := False;
                        Rec."Medical Contract" := False;
                        Rec."Employment Contract" := False;
                        Rec.Modify;
                    End ELSE begin
                        Rec."FTT-CST Document Type" := Rec."FTT-CST Document Type"::Others;
                        Rec.Modify;
                    end;

                End;
            }
            field("EMPCont"; Rec."Employment Contract")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies that the attached document is a Employment Contract';
                Visible = NOT gVis;
                trigger OnValidate()
                var
                    lDocAtt: Record "Document Attachment";
                Begin
                    IF Rec."Employment Contract" then BEGIN
                        Rec."FTT-CST Document Type" := Rec."FTT-CST Document Type"::"Employment Contract";
                        Rec."Medical Contract" := False;
                        Rec."FTT-CST Others" := False;
                    END ELSE begin
                        Rec."FTT-CST Document Type" := Rec."FTT-CST Document Type"::Others;
                    end;
                    Rec.Modify;
                End;
            }
            field("MedCont"; Rec."Medical Contract")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies that the attached document is a Medical Contract';
                Visible = NOT gVis;
                trigger OnValidate()
                var
                    lDocAtt: Record "Document Attachment";
                Begin
                    IF Rec."Medical Contract" then BEGIN
                        Rec."FTT-CST Document Type" := Rec."FTT-CST Document Type"::"Medical Contract";
                        Rec."Employment Contract" := False;
                        Rec."FTT-CST Others" := False;
                    END ELSE begin
                        Rec."FTT-CST Document Type" := Rec."FTT-CST Document Type"::Others;
                    end;
                    Rec.Modify;
                End;
            }
        }
    }
    Local Procedure GetContactName(pRec: Record "Document Attachment"): Text[100]
    var
        lCont: Record Contact;
        lOpp: Record Opportunity;
        lSH: Record "Sales Header";
        lCust: Record Customer;
    Begin
        case
            pRec."Table ID" of
            5050:
                begin
                    IF lCont.GET(pRec."No.") then
                        Exit(lCont.Name);
                end;
            5092:
                begin
                    IF lOpp.Get(pRec."No.") then
                        IF lCont.GET(lOpp."Contact No.") then
                            EXIT(lCont."Name");
                end;
            36:
                begin
                    IF lSH.GET(pRec."Document Type", Rec."No.") then
                        IF lCont.GET(lSH."Sell-to Contact No.") then
                            EXIT(lCont.Name);
                end;
            18:
                begin
                    IF lCust.GET(pRec."No.") then begin
                        IF lCont.GET(lCust."Primary Contact No.") then
                            EXIT(lCont.Name);
                        EXIT(lCust.Name);
                    End;
                end;
        End;
    End;

    Procedure VisibleSelectedFields(pVis: Boolean; pCode: Code[20])
    var
        lEmp: Record Employee;
    Begin
        gVis := pVIS;
        IF lEmp.GET(pCode) THEN
            gVis := FALSE;
    End;

    trigger OnAfterGetCurrRecord()
    begin
        if rec."File Name" = 'No Attachment' then
            isEditable := true
        else
            isEditable := false;
    end;

    var
        [InDataSet]
        VisibleSOW: Boolean;
        isEditable: Boolean;


    procedure SetSOWVisible(SOW: Boolean)
    begin
        VisibleSOW := SOW;
    end;

    var
        EmpText: Text[50];
        gVis: Boolean;
}
