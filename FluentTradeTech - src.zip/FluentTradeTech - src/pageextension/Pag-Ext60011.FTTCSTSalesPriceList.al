pageextension 60011 "FTT-CST SalesPriceList" extends "Sales Price List"
{
    actions
    {
        addafter(SuggestLines)
        {
            action(FTTCSTCreatePricingInd)
            {
                ApplicationArea = All;
                Caption = 'Create Pricing Indication';
                Ellipsis = true;
                Image = PrintCheck;
                ToolTip = 'Create a printed form of pricing indication';

                trigger OnAction()
                var
                    FTTCSTReportMng: Codeunit "FTT-CST ReportMng";
                begin
                    Clear(FTTCSTReportMng);
                    FTTCSTReportMng.ReportPricingIndicationTemplateSaveToWord(Rec);
                end;
            }
        }
        addafter(SuggestLines_Promoted)
        {
            actionref(FTTCSTCreatePricingInd_Promoted; FTTCSTCreatePricingInd)
            {
            }
        }
    }
}
