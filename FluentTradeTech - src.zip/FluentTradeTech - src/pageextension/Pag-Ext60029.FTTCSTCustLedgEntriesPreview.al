pageextension 60029 "FTTCST CustLedgEntriesPreview" extends "Cust. Ledg. Entries Preview"
{
    layout
    {
        addafter(RemainingAmountLCY)
        {
            // field("FTT-CST Comm. Base Am. (LCY)"; Rec."FTT-CST Comm. Base Am. (LCY)")
            // {
            //     ApplicationArea = All;
            //     ToolTip = 'Specifies the total commission base amount to the customer entry.';
            // }
        }
    }
}
