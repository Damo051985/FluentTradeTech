pageextension 60038 "FTT-CST Opportunity List" extends "Opportunity List"
{
    layout
    {
        modify("Campaign No.")
        {
            Visible = false;
        }
        modify("Campaign Description")
        {
            Visible = false;
        }
        modify("Contact No.")
        {
            Visible = false;
        }
        modify("Contact Name")
        {
            Visible = true;
        }
        modify("Sales Document No.")
        {
            Visible = False;
        }
        Modify("Calcd. Current Value (LCY)")
        {
            Visible = False;
        }
        Modify("Estimated Value (LCY)")
        {
            Visible = False;
        }
        moveafter(Description; "Contact Name")
        addafter(Closed)
        {
            field("FTT-CST OnHold"; Rec."FTT-CST OnHold")
            {
                ApplicationArea = all;
            }
        }
        //>>Dan 082724
        addfirst(Factboxes)
        {
            part("Attached Documents"; "Document Attachment Factbox")
            {
                ApplicationArea = All;
                Caption = 'Attachments';
                SubPageLink = "Table ID" = const(Database::"Opportunity"),
                              "No." = field("No.");
            }
        }
        //<<Dan 082724
        addafter("Estimated Closing Date")
        {
            Field(EstValCur; EstValCur)
            {
                ApplicationArea = all;
                Caption = 'Estimated Value - Currency';
                Editable = False;
            }
            Field(EstVal; EstVal)
            {
                ApplicationArea = all;
                Caption = 'Estimated Value';
                Editable = False;
            }
            Field(ProbPerc; ProbPerc)
            {
                ApplicationArea = all;
                Caption = 'Probability %';
                Editable = False;
            }
        }
    }
    actions
    {
        modify("Co&mments")
        { Visible = false; }
        /*
        modify("Co&mments_Promoted")
        { Visible = false; }
        
        modify(Control5)
        {
            Visible = false;
        }
        */
        modify(Update)
        {
            ApplicationArea = all;

            trigger OnBeforeAction()
            var
                lOpp: Record Opportunity;
                lOppEnt: Record "Opportunity Entry";
                lDocAtt: Record "Document Attachment";
                lUserSet: Record "User Setup";
                lCont: Record Contact;
                lCust: Record Customer;
                lSH: Record "Sales Header";
                lHasNDA: Boolean;
                MySesSet: SessionSettings;
            Begin
                //>>Dan Update 102924
                MySesSet.Init;
                IF MySesSet.ProfileId = 'FTT_SALES_DIRECTOR' THEN
                    IF (lUserSet.GET(UserId)) AND (lUserSet."Skip NDA Validation") THEN
                        Exit;
                lHasNDA := False;
                Clear(lOpp);
                Clear(lOppEnt);
                lOppEnt.SETRANGE("Opportunity No.", Rec."No.");
                lOppEnt.SETFILTER(Active, '%1', TRUE);
                IF lOppEnt.FINDFIRST THEN begin
                    IF lOppEnt."Sales Cycle Stage" = 5 then begin
                        IF lOpp.GET(lOppEnt."Opportunity No.") THEN
                            lOpp.CalcFields("Contact Name");
                        Clear(lDocAtt);
                        lDocAtt.SETRANGE("Table ID", 5092);
                        lDocAtt.SETRANGE("No.", Rec."No.");
                        //lDocAtt.SETFILTER("FTT-CST NDA", '%1', TRUE);
                        IF lDocAtt.FINDFIRST THEN
                            IF (lDocAtt."FTT-CST NDA") OR (lDocAtt."MSA Document") THEN
                                lHasNDA := TRUE;

                        lCont.RESET;
                        IF lCont.GET(lOpp."Contact No.") THEN begin
                            Clear(lDocAtt);
                            lDocAtt.SETRANGE("Table ID", 5050);
                            lDocAtt.SETRANGE("No.", lCont."No.");
                            //lDocAtt.SETFILTER("FTT-CST NDA", '%1', TRUE);
                            IF lDocAtt.FINDFIRST THEN
                                IF (lDocAtt."FTT-CST NDA") OR (lDocAtt."MSA Document") THEN
                                    lHasNDA := TRUE;
                        end;
                        lCust.RESET;
                        lCust.SETRANGE(Name, lOpp."Contact Name");
                        IF lCust.FINDFIRST THEN BEGIN
                            Clear(lDocAtt);
                            lDocAtt.SETRANGE("Table ID", 18);
                            lDocAtt.SETRANGE("No.", lCust."No.");
                            //lDocAtt.SETFILTER("FTT-CST NDA", '%1', TRUE);
                            IF lDocAtt.FINDFIRST THEN
                                IF (lDocAtt."FTT-CST NDA") OR (lDocAtt."MSA Document") THEN
                                    lHasNDA := TRUE;
                        end;
                        Clear(lSH);
                        lSH.SETRANGE("Opportunity No.", lOpp."No.");
                        IF lSH.FINDFIRST then begin
                            Clear(lDocAtt);
                            lDocAtt.SETRANGE("Table ID", 36);
                            lDocAtt.SETRANGE("No.", lSH."No.");
                            //lDocAtt.SETFILTER("FTT-CST NDA", '%1', TRUE);
                            IF lDocAtt.FINDFIRST THEN
                                IF (lDocAtt."FTT-CST NDA") OR (lDocAtt."MSA Document") THEN
                                    lHasNDA := True;
                        End;
                        IF NOT lHasNDA then
                            Error('You cannot go to next stage before you have assigned NDA (or MSA) Document.');
                    end;
                end;
                //<<Dan Update 102924
            End;
        }
        modify("Show Sales Quote")
        {
            Visible = false; //NRD
        }
        modify(CreateSalesQuote)
        {
            Caption = 'Old Create Sales Quote';
            Visible = false; //NRD
        }
        addafter("Activate First Stage")
        {
            action(ShowRelatedQuote)
            {
                ApplicationArea = all;
                Caption = 'Show Sales Quotes';
                Promoted = true;
                PromotedIsBig = true;
                PromotedCategory = Process;
                trigger OnAction()
                begin
                    ShowRelatedSalesQuote();
                end;
            }
        }
        addbefore(CreateSalesQuote)
        {
            action(CreateSalesQuoteFTT)
            {
                ApplicationArea = RelationshipMgmt;
                Caption = 'Create Sales &Quote';
                Promoted = true;
                PromotedCategory = Process;
                PromotedIsBig = true;
                PromotedOnly = true;
                Enabled = OppInProgress2;
                Image = Allocate;
                ToolTip = 'Create a new sales quote with the opportunity inserted as the customer.';
                Visible = true;

                trigger OnAction()
                var
                    Opportunity: Record Opportunity;
                    Opportunity2: record Opportunity;
                    OpportEntry: Record "Opportunity Entry";
                    OpportunityEntry: record "Opportunity Entry";
                    //OpportunityEntry: record "Opportunity Entry";
                    SalesCycleStage: Record "Sales Cycle Stage";
                    SalesHader: Record "Sales Header";
                    SalesQuote: Page "Sales Quote";
                    OpportunityList: Page "Opportunity List";
                    UpdateOpportunity: page "Update Opportunity";
                    SelectedOpp: Text[1024];
                    SalesQuoteNo: Code[20];
                begin
                    SelectedOpp := '';
                    if Confirm(InfoMessage) then begin
                        Opportunity.SetRange("Contact No.", rec."Contact No.");
                        Opportunity.SetRange(Status, Opportunity.Status::"In Progress");
                        Opportunity.SetFilter(Status, '%1', Opportunity.Status::"In Progress");
                        Opportunity.SetFilter("Estimated Value (LCY)", '>%1', 0);
                        Opportunity.SetFilter("Current Sales Cycle Stage", '<>%1', 0);
                        OpportunityList.LookupMode(TRUE);
                        OpportunityList.SetTableView(Opportunity);

                        if OpportunityList.RunModal() = Action::LookupOK then begin
                            OpportunityList.SetSelectionFilter(Opportunity2);
                            if Opportunity2.FindSet() then
                                repeat
                                    if Opportunity2.Status = Opportunity2.Status::"In Progress" then begin
                                        if Opportunity2."Estimated Value (LCY)" = 0 then
                                            Opportunity2."Estimated Value (LCY)" := 10000;
                                        Opportunity2.Modify();

                                        OpportunityEntry.Reset();
                                        OpportunityEntry.SetRange("Opportunity No.", Opportunity2."No.");
                                        OpportunityEntry.SetRange("Sales Cycle Stage", 8);

                                        if NOT OpportunityEntry.FindSet() then begin
                                            OpportunityEntry.Init();
                                            OpportunityEntry."Sales Cycle Code" := Opportunity2."Sales Cycle Code";
                                            OpportunityEntry.Validate("Sales Cycle Stage", 8);
                                            OpportunityEntry."Action Type" := OpportunityEntry."Action Type"::Jump;
                                            OpportunityEntry."Action Taken" := OpportunityEntry."Action Taken"::Jumped;
                                            OpportunityEntry."Estimated Value (LCY)" := Opportunity2."Estimated Value (LCY)";
                                            OpportunityEntry.InitOpportunityEntry(Opportunity2);
                                            OpportunityEntry.InsertEntry(OpportunityEntry, false, true);
                                            OpportunityEntry.UpdateEstimates();
                                        end else begin
                                            if SalesQuoteNo = '' then begin
                                                Opportunity2."Sales Document No." := '';
                                                Opportunity2."Sales Document Type" := Opportunity2."Sales Document Type"::" ";
                                                Opportunity2.FTTCSTCreateQuote(SalesQuoteNo);
                                                Commit();
                                            end;
                                            Opportunity2."Sales Document No." := SalesQuoteNo;
                                            Opportunity2."Sales Document Type" := Opportunity2."Sales Document Type"::Quote;
                                            Opportunity2.Modify();

                                            OpportunityEntry.Reset;
                                            OpportunityEntry.SetRange("Opportunity No.", Opportunity2."No.");
                                            OpportunityEntry.ModifyAll("FTT-CST Sales Quote No.", SalesQuoteNo);
                                        end;
                                    end;
                                until Opportunity2.next = 0;
                            Commit();
                            if SalesQuoteNo <> '' then begin
                                SalesHader.Get(SalesHader."Document Type"::Quote, SalesQuoteNo);
                                SalesQuote.SetRecord(SalesHader);
                                SalesQuote.Run();
                            end;
                        end;
                    end else begin
                        Rec."Sales Document No." := '';
                        Rec."Sales Document Type" := rec."Sales Document Type"::" ";
                        Rec.CreateQuote();
                    end;
                    CurrPage.Update();
                end;
            }
        }

    }
    procedure ShowRelatedSalesQuote()
    var
        SalesHeader: record "Sales Header";
        SalesQuote: page "Sales Quotes";
    begin
        SalesHeader.SetRange("Opportunity No.", Rec."No.");
        if SalesHeader.Count() > 0 then begin
            SalesQuote.SetTableView(SalesHeader);
            SalesQuote.RunModal();
        end else
            Message(NoQuoteMessage);
    end;

    Local Procedure GetLineDetails()
    Var
        lOppEnt: Record "Opportunity Entry";
    Begin
        EstVal := 0;
        EstValCur := '';
        ProbPerc := 0;
        lOppEnt.SETRANGE("Opportunity No.", Rec."No.");
        lOppEnt.SETFILTER(Active, '%1', True);
        IF NOT lOppEnt.IsEmpty THEN begin
            lOppEnt.Findfirst;
            EstValCur := lOppEnt."Estimated Value - Currency";
            EstVal := lOppEnt."Estimated Value (LCY)";
            ProbPerc := lOppEnt."Probability %";
        end;
    End;
    //Nimrod+

    trigger OnOpenPage()
    var
        UserSETUP: Record "User Setup";
        lUser: Record User;
        MySesSet: SessionSettings;
        lPageExtContactList: Page "Contact List";
    begin

        if not UserSETUP.Get(UserId) then
            exit;

        if UserSETUP."Sales Resp. Ctr. Filter" <> '' then begin
            rec.FilterGroup(2);
            rec.SetRange(Rec."Salesperson Code", UserSETUP."Sales Resp. Ctr. Filter");
            rec.FilterGroup(0);
        end;
        /*
        MySesSet.Init;
        IF MySesSet.ProfileId = 'FTT_SALES_MANAGER' THEN BEGIN
            Clear(lUser);
            IF UserSetup.GET(UserId) THEN begin
                lUser.SetRange("User Name", UserSetup."User ID");
                IF lUser.FINDFIRST THEN begin
                    rec.FilterGroup(2);
                    rec.SetRange(Rec.SystemCreatedBy, lUser."User Security ID");
                    rec.FilterGroup(0);
                end;
            end;
        END ELSE begin
        */
        IF lPageExtContactList.FilterSalesMngr <> '' THEN begin
            rec.FilterGroup(2);
            rec.Setfilter(Rec."Salesperson Code", '%1', lPageExtContactList.FilterSalesMngr());
            rec.FilterGroup(0);
        end;
        //end;

    end;
    //-

    trigger OnAfterGetCurrRecord()
    begin
        OppInProgress2 := Rec.Status = Rec.Status::"In Progress";
    end;

    trigger OnAfterGetRecord()
    begin
        GetLineDetails();
    end;


    var
        InfoMessage: Label 'Would you like to add another opportunity within the upcoming Sales Quote';
        NoQuoteMessage: Label 'System does not have Sales Quotes created from this Opportunity';
        OppInProgress2: Boolean;
        EstVal, ProbPerc : Decimal;
        EstValCur: Code[20];
}