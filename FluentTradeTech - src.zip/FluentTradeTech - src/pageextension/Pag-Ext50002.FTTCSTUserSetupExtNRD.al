pageextension 50002 "User Setup Ext. NRD" extends "User Setup"
{
    layout
    {
        addbefore(Email)
        {
            field("Commission Full Access"; Rec."Commission Full Access") //NRD
            {
                ApplicationArea = all;
            }
            field("GMAIL Admin Access"; Rec."GMAIL Admin Access")
            {
                ApplicationArea = all;
            }
            field("Prospect Visibilty"; Rec."Prospect Visibilty")
            {
                ApplicationArea = all;
                ToolTip = 'To specify the user will be able to see all the prospect customer in the system';
            }
            field("Permission to Create Sales"; Rec."Permission to Create Sales")
            {
                ApplicationArea = all;
                ToolTip = 'To specify the user will allow to create sales';
            }
            field("Sales Quote Admin"; Rec."Sales Quote Admin")
            {
                ApplicationArea = all;
            }
            field("Email Signature Included"; Rec."Email Signature Included")
            {
                ApplicationArea = all;
                Caption = 'Include Email Signature';
            }
            field("Last Remark Message"; Rec."Last Remark Message")
            {
                ApplicationArea = all;

            }
            field("Job Position"; Rec."Job Position")
            {
                ApplicationArea = all;
                ShowMandatory = true;
            }
            field("Skip NDA"; Rec."Skip NDA Validation")
            {
                ApplicationArea = all;

            }


        }
        addafter("User ID")
        {
            field("Full Name"; Rec."Full Name")
            {
                ApplicationArea = all;
                ShowMandatory = true;
            }
        }

        modify(PhoneNo)
        {
            ApplicationArea = all;
            ShowMandatory = true;
        }
        modify(Email)
        {
            ApplicationArea = all;
            ShowMandatory = true;
        }


    }


    var
        myInt: Integer;
}