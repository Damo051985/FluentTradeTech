pageextension 60013 "FTT-CST ItemList" extends "Item List"
{
    Editable = true;
    layout
    {
        addbefore("No.")
        {
            field("FTT-CST Mark"; Rec."FTT-CST Mark")
            {
                ApplicationArea = all;
                Visible = false;
            }
        }
        addafter(Description)
        {
            field("FTT-CST Quanity"; Rec."FTT-CST Quantity")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies the name of the subsidiary company. If the contact is a person, Specifies the name of the subsidiary company for which this contact works. This field is not editable.';
                Visible = QuantityVisible;
                Editable = true;
            }

            field("FTT-CST Redundancy PriceCalc %"; Rec."FTT-CST Redundancy PriceCalc %")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies the name of the subsidiary company. If the contact is a person, Specifies the name of the subsidiary company for which this contact works. This field is not editable.';
                Visible = RedandencyVisible;
                Editable = true;
            }
            field("FTT-CST Integr PriceCalc %"; Rec."FTT-CST Integr PriceCalc %")
            {
                ApplicationArea = All;
                Caption = 'Integration %';
                ToolTip = 'Specifies the name of the subsidiary company. If the contact is a person, Specifies the name of the subsidiary company for which this contact works. This field is not editable.';
                Visible = IntegrationVisible;
            }

        }
        modify(Type)
        { Visible = false; }
        modify("Substitutes Exist")
        { Visible = false; }
        modify("Assembly BOM")
        { Visible = false; }
        modify("Base Unit of Measure")
        { Visible = false; }
        modify("Cost is Adjusted")
        { Visible = false; }
        modify("Unit Cost")
        { Visible = false; }
        modify("Vendor No.")
        { Visible = false; }
        modify("Default Deferral Template Code")
        { Visible = false; }
        modify(InventoryField)
        { Visible = false; }
        modify("Unit Price")
        {
            //Visible = PriceVisible; 
            Visible = true; //FTT.Nimrod.
        }

    }
    actions
    {
        addlast(Sales)
        {
            action("FTT-CST Recurring Sales Lines")
            {
                ApplicationArea = All;
                Caption = 'Recurring Sales Line';
                Image = ItemWorksheet;
                RunObject = page "FTT-CST Stn. Item Sales Codes";
                RunPageLink = "Item No." = field("No.");
                ToolTip = 'Set up recurring sales lines for the item that can quickly be inserted on a sales document for the customer.';
            }
        }
    }
    var
        [InDataSet]
        RedandencyVisible: Boolean;
        [InDataSet]
        IntegrationVisible: Boolean;
        [InDataSet]
        PriceVisible: Boolean;
        [InDataSet]
        QuantityVisible: Boolean;

    procedure SetVisibility(Red: Boolean; Integ: boolean)
    begin
        RedandencyVisible := Red;
        IntegrationVisible := Integ;
    end;

    procedure SetQtyVisible(pQtyVisible: Boolean)
    begin
        QuantityVisible := pQtyVisible;
    end;

    trigger OnOpenPage()
    begin
        //RedandencyVisible := true;
        //PriceVisible := true;
    end;

    trigger OnAfterGetCurrRecord()
    begin
        rec."FTT-CST Mark" := TRUE;
    end;

    procedure SetFilters(Filter: text[1024])
    begin
        SetPriceViaible(true);
        Rec.SetFilter("No.", Filter);
        CurrPage.Update();
    end;

    procedure SetPriceViaible(Visible: Boolean)
    begin
        PriceVisible := Visible;
    end;
}
