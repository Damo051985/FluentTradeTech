pageextension 50018 "FTT-CST Sales OrderList Ext." extends "Sales Order List"
{
    layout
    {
        modify("Your Reference")
        {
            ApplicationArea = all;
            Visible = true;
        }
        addbefore("No.")
        {
            field("FTT-CST Use for Renewal"; Rec."FTT-CST Use for Renewal")
            {
                ApplicationArea = all;
                Caption = 'Will Be Used for Renewal';
                Visible = False;
            }
            field("FTT-CST Order Type"; Rec."FTT-CST Order Type")
            {
                ApplicationArea = all;
            }



        }
        AddAfter(Status)
        {
            Field("Service Now"; Rec."Service Now")
            {
                ApplicationArea = All;
            }
            Field("Payment Status"; Rec."Payment Status")
            {
                ApplicationArea = All;
            }
        }
        modify("Sell-to Customer No.")
        {
            Visible = false;
        }
        modify("Salesperson Code")
        {
            Visible = true;
        }
        modify("Currency Code")
        {
            Caption = 'Currency';
            Visible = true;

        }
        moveafter("Sell-to Customer Name"; "Salesperson Code")
        movebefore("Salesperson Code"; "Currency Code")
        addafter("Sell-to Customer Name")
        {


            field("FTT-CST Agr. Starting Date"; Rec."FTT-CST Agr. Starting Date")
            {
                ApplicationArea = all;
                Caption = 'Agreement Starting Date';
            }
            field(DeliveryProdDate; GetDeliveryProdDate(rec))
            {
                ApplicationArea = all;
                Caption = 'Delivery PROD Date';
            }
            field(DeliveryUATDate; GetDeliveryUATDate(rec))
            {
                ApplicationArea = all;
                Caption = 'Delivery UAT Date';
            }
            field("FTT-CST Agr. Ending Date"; Rec."FTT-CST Agr. Ending Date")
            {
                ApplicationArea = all;
            }
            //>>dan 082924

            //<<dan 082924
        }

    }

    trigger OnAfterGetCurrRecord()
    var
        myInt: Integer;
    begin
        rec.CalcFields("Work Description");
    end;

    local procedure GetDeliveryProdDate(pSaleaheader: Record "Sales Header"): Date
    var
        salesLine_l: Record "Sales Line";
    begin
        salesLine_l.Reset();
        salesLine_l.SetRange("Document Type", pSaleaheader."Document Type");
        salesLine_l.SetRange("Document No.", pSaleaheader."No.");
        if salesLine_l.FindFirst() then
            exit(salesLine_l."FTT-CST Delivery PROD Date");

    end;

    local procedure GetDeliveryUATDate(pSaleaheader: Record "Sales Header"): Date
    var
        salesLine_l: Record "Sales Line";
    begin
        salesLine_l.Reset();
        salesLine_l.SetRange("Document Type", pSaleaheader."Document Type");
        salesLine_l.SetRange("Document No.", pSaleaheader."No.");
        if salesLine_l.FindFirst() then
            exit(salesLine_l."FTT-CST Delivery UAT Date");

    end;
}