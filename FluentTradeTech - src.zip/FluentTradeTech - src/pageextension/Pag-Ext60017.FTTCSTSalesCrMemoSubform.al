pageextension 60017 "FTT-CST SalesCrMemoSubform" extends "Sales Cr. Memo Subform"
{
    layout
    {

        modify(FilteredTypeField)
        {
            Visible = false;
        }
        modify("Item Reference No.")
        {
            Visible = false;
        }
        modify("Allow Invoice Disc.")
        {
            Visible = false;
        }
        modify("Allow Item Charge Assignment")
        {
            visible = false;
        }
        modify("Unit Price")
        {
            Visible = false;
        }
        modify("Inv. Discount Amount")
        {
            Editable = false;
            Visible = false;
        }
        modify("Invoice Discount Amount")
        {
            //Editable = false;
            Caption = 'Discount Amount';
            Visible = true;
        }
        modify("Total Amount Incl. VAT")
        {
            Editable = false;
        }
        modify(ShortcutDimCode3)
        {
            Visible = true;
        }
        modify(ShortcutDimCode4)
        {
            Visible = true;
        }

        movebefore(Description; ShortcutDimCode3)
        //movebefore(ShortcutDimCode4; ShortcutDimCode3)
        addafter(ShortcutDimCode3)
        {
            field("FTT-CST Parent Item Cat. Code"; Rec."FTT-CST Parent Item Cat. Code")
            {
                ApplicationArea = all;
                Visible = false;
            }
            field("FTT-CST Sublocation"; Rec."FTT-CST Sublocation")
            {
                ApplicationArea = all;
                Visible = true;
            }
            field("FTT-CST Component Option"; Rec."FTT-CST Component Option")
            {
                ApplicationArea = all;
            }
        }
        modify("Line Discount Amount")
        {
            Visible = false;
        }
        //modify("Invoice Discount Amount")

        addafter(Description)
        {
            field("FTT-CST Optional"; Rec."FTT-CST Optional")
            {
                ApplicationArea = All;
                Editable = false;
                Visible = true;
            }
            field("FTT-CST Redundancy"; Rec."FTT-CST Redundancy")
            {
                ApplicationArea = all;
                Visible = false;
            }
            field("FTT-CST DR"; Rec."FTT-CST DR")
            {
                ApplicationArea = all;
                Visible = false;
            }
            field("FTT-CST Redundancy PriceCalc %"; Rec."FTT-CST Redundancy PriceCalc %")
            {
                ApplicationArea = all;
                Visible = false;
            }
            field("FTT-CST Location Code"; Rec."FTT-CST Location Code")
            {
                ApplicationArea = all;
                Visible = false;
            }
        }
        addbefore(Quantity)
        {
            field("Commission Base Amount"; Rec."Commission Base Amount") //NRD- Commission
            {
                ApplicationArea = all;
                Editable = false;
                Visible = false;
            }
            field("FTT-CST Unit Price"; Rec."FTT-CST Unit Price")
            {
                ApplicationArea = all;
                Caption = 'Unit Price';
                Visible = true;
                DecimalPlaces = 2 : 2;
            }

        }
        addafter("Line Amount")
        {
            field("FTT-CST Cost Type"; Rec."FTT-CST Cost Type")
            {
                ApplicationArea = All;
                Width = 8;
                Visible = true;
                HideValue = Rec.Type <> "Sales Line Type"::Item;
                ToolTip = 'Specifies a cost type of the item.';
            }
            field("FTT-CST Agreement Date From"; Rec."FTT-CST Agreement Date From")
            {
                Caption = 'Agreement Starting Date'; //NRD
                CaptionClass = 'Agreement Starting Date'; //NRD
                ApplicationArea = all;
            }
            //NRD
            field("FTT-CST Delivery PROD Date"; Rec."FTT-CST Delivery PROD Date")
            {
                ApplicationArea = All;
                Editable = Rec.Type = "Sales Line Type"::Item;
                Visible = true;
                ToolTip = 'Specifies an ending date of the agreement period for the line.';
            }
            field("FTT-CST Delivery UAT Date"; Rec."FTT-CST Delivery UAT Date")
            {
                ApplicationArea = All;
                Visible = true;
                Editable = Rec.Type = "Sales Line Type"::Item;
                ToolTip = 'Specifies an ending date of the agreement period for the line.';
            }
            field("FTT-CST Agreement Date To"; Rec."FTT-CST Agreement Date To")
            {
                ApplicationArea = All;
                Visible = true;
                Editable = Rec.Type = "Sales Line Type"::Item;
                ToolTip = 'Specifies an ending date of the agreement period for the line.';
            }
            //+
            field("FTT-CST Comments Fluent"; Rec."FTT-CST Comments Fluent")
            {
                ApplicationArea = All;
                Editable = true;
                width = 10;
            }
            field("FTT-CST Comments"; Rec."FTT-CST Comments")
            {
                ApplicationArea = All;
                Editable = true;
                width = 10;
            }
            field("Agreement Period"; Rec."Agreement Period")
            {
                ApplicationArea = all;
            }
        }

        // addbefore(Quantity)
        // {
        //     field("FTT-CST Cost Type"; Rec."FTT-CST Cost Type")
        //     {
        //         ApplicationArea = All;
        //         HideValue = Rec.Type <> "Sales Line Type"::Item;
        //         ToolTip = 'Specifies a cost type of the item.';
        //     }
        // }
        modify("No.")
        {
            trigger OnAfterValidate()
            begin
                Commit();
                Clear(RecurringItemSalesMng);
                if RecurringItemSalesMng.CheckItemSalesType(Rec, "FTT-CST Stn. Item Sales Type"::"Always Ask") then
                    RecurringItemSalesMng.InsertSalesLines(Rec, "FTT-CST Stn. Item Sales Type"::"Always Ask")
                else
                    if RecurringItemSalesMng.CheckItemSalesType(Rec, "FTT-CST Stn. Item Sales Type"::Automatic) then
                        RecurringItemSalesMng.InsertSalesLines(Rec, "FTT-CST Stn. Item Sales Type"::Automatic);
            end;
        }

        addbefore("TotalSalesLine.""Line Amount""")
        {
            field("FTT License Sales"; LicenseSalesAmount)
            {
                Caption = 'License';
                ApplicationArea = all;
                Editable = false;
            }
            field("FTT Feed Sales"; FeedSalesAmount)
            {
                Caption = 'Feed';
                ApplicationArea = all;
                Editable = false;
            }
            field("FTT Redundancy Sales"; RedundancySalesAmount)
            {
                Caption = 'Redundancy';
                ApplicationArea = all;
                Editable = false;
            }
            field("FTT DR Sales"; DRSalesAmoount)
            {
                Caption = 'DR';
                ApplicationArea = all;
                Editable = false;
            }
            field("FTT DR Integration"; IntegrationSalesAmount)
            {
                Caption = 'Integration';
                ApplicationArea = all;
                Editable = false;
            }
            field("Hardware + Setup Sales"; SetupSalesAmount)
            {
                Caption = 'Hardware + Setup';
                ApplicationArea = all;
                Editable = false;
            }
            field("Hosting Management Sales"; HostingSalesAmount)
            {
                Caption = 'Hosting & Management';
                ApplicationArea = all;
                Editable = false;
            }
            field("Cross Сonnects - Total"; CrossConnectSalesAmount)
            {
                Caption = 'Connectivity';
                ApplicationArea = all;
                Editable = false;
            }
        }
        addafter("Total Amount Incl. VAT")
        {
            group(gr1)
            {
                ShowCaption = false;
                field("NRC Sales"; NRCSales)
                {
                    Caption = 'NRC';
                    ApplicationArea = all;
                    Editable = false;
                }
                field("MRC Sales"; WRCSales)
                {
                    Caption = 'YRC';
                    ApplicationArea = all;
                    Editable = false;
                }
            }
        }
        modify("Invoice Disc. Pct.")
        {
            Editable = true;
            trigger OnAfterValidate()
            begin
                CalculateLicenseSales(LicenseSalesAmount);
                CalculateFeedSales(FeedSalesAmount);
                CalculateRedundencySales(RedundancySalesAmount);
                CalculateDRSales(DRSalesAmoount);
                CalculateSetupSales(SetupSalesAmount);
                CalculateHostingSales(HostingSalesAmount);
                CalculateCrossConnectSales(CrossConnectSalesAmount);
                CalculateIntegrationSales(IntegrationSalesAmount);
                CalculateNRCWRC(NRCSales, WRCSales);
            end;
        }
    }
    actions
    {

        modify(Dimensions)
        {
            Visible = true;
        }

        addlast("&Line")
        {
            action("FTT-CST Get Rec. Item SL")
            {
                ApplicationArea = All;
                Caption = 'Get Recurring Item Sales Lines';
                Enabled = Rec.Type = "Sales Line Type"::Item;
                Image = ItemWorksheet;
                ToolTip = 'View a list of the standard sales lines that have been assigned to the item to be used for recurring sales.';
                Visible = true;

                trigger OnAction()
                begin
                    Clear(RecurringItemSalesMng);
                    RecurringItemSalesMng.InsertSalesLines(Rec, "FTT-CST Stn. Item Sales Type"::Manual);
                end;
            }
            action("FTT-CST Add Redundancy Line")
            {
                ApplicationArea = All;
                Caption = 'Add Redundancy Item Line';
                Visible = true;
                Image = ItemReservation;
                ToolTip = 'Insert a redundancy item with automatic price calculation.';

                trigger OnAction()
                var
                    FTTCSTCalculateRedundancy: Codeunit "FTT-CST CalculateRedundancy";
                begin
                    FTTCSTCalculateRedundancy.CalculateRedundancy(Rec."Document Type", Rec."Document No.");
                end;
            }
            action("FTT-CST Add DR Line")
            {
                ApplicationArea = All;
                Caption = 'Add DR Item Line';
                Visible = true;
                //Image = Item;
                ToolTip = 'Insert a dr item with automatic price calculation.';

                trigger OnAction()
                var
                    FTTCSTCalculateRedundancy: Codeunit "FTT-CST CalculateRedundancy";
                begin
                    FTTCSTCalculateRedundancy.CalculateDR(Rec."Document Type", Rec."Document No.");
                end;
            }
            action("FTT-CST Add Integration Line")
            {
                ApplicationArea = All;
                Caption = 'Add Integration Item Line';
                Visible = true;
                //Image = ItemReservation;
                ToolTip = 'Insert a Integration item with automatic price calculation.';

                trigger OnAction()
                var
                    FTTCSTCalculateRedundancy: Codeunit "FTT-CST CalculateRedundancy";
                begin
                    FTTCSTCalculateRedundancy.CalculateInt(Rec."Document Type", Rec."Document No.");
                end;
            }
        }
    }

    var
        RecurringItemSalesMng: Codeunit "FTT-CST RecurringItemSalesMng";
        RedundancySalesAmount: Decimal;
        DRSalesAmoount: Decimal;
        SetupSalesAmount: Decimal;
        FeedSalesAmount: decimal;
        HostingSalesAmount: Decimal;
        LicenseSalesAmount: Decimal;
        CrossConnectSalesAmount: Decimal;
        IntegrationSalesAmount: Decimal;
        NRCSales: Decimal;
        WRCSales: Decimal;

    procedure CalculateLicenseSales(var pLicenseSalesAmount: Decimal)
    var
        SalesLine: record "Sales Line";
        SalesReceivables: record "Sales & Receivables Setup";
    begin
        SalesReceivables.Get();
        pLicenseSalesAmount := 0;
        SalesLine.SetRange("Document Type", Rec."Document Type");
        SalesLine.SetRange("Document No.", Rec."Document No.");
        SalesLine.SetRange("FTT-CST Parent Item Cat. Code", SalesReceivables."FTT-CST LICENSE");
        SalesLine.SetRange("FTT-CST Optional", SalesLine."FTT-CST Optional"::No); //NRD
        if SalesLine.FindSet() then
            repeat
                pLicenseSalesAmount := pLicenseSalesAmount + SalesLine."Line Amount";
            //pLicenseSalesAmount := pLicenseSalesAmount + SalesLine."Amount Including VAT";
            until SalesLine.next = 0;
        pLicenseSalesAmount := pLicenseSalesAmount * (100 - InvoiceDiscountPct) / 100;
    end;

    procedure CalculateFeedSales(var pFeedSalesAmount: Decimal)
    var
        SalesLine: record "Sales Line";
        SalesReceivables: Record "Sales & Receivables Setup";
    begin
        SalesReceivables.Get();
        pFeedSalesAmount := 0;
        SalesLine.SetRange("Document Type", Rec."Document Type");
        SalesLine.SetRange("Document No.", Rec."Document No.");
        SalesLine.SetRange("FTT-CST Parent Item Cat. Code", SalesReceivables."FTT-CST Parent FEED");
        SalesLine.SetRange("FTT-CST Optional", SalesLine."FTT-CST Optional"::No); //NRD
        if SalesLine.FindSet() then
            repeat
                pFeedSalesAmount := pFeedSalesAmount + SalesLine."Line Amount";
            until SalesLine.next = 0;
        pFeedSalesAmount := pFeedSalesAmount * (100 - InvoiceDiscountPct) / 100;
    end;

    procedure CalculateRedundencySales(var pSalesAmount: Decimal)
    var
        SalesLine: record "Sales Line";
        SalesReceivables: record "Sales & Receivables Setup";
    begin
        SalesReceivables.Get();
        pSalesAmount := 0;
        SalesLine.SetRange("Document Type", Rec."Document Type");
        SalesLine.SetRange("Document No.", Rec."Document No.");
        SalesLine.SetRange("FTT-CST Parent Item Cat. Code", SalesReceivables."FTT-CST Redundancy Category");
        SalesLine.SetRange("FTT-CST Optional", SalesLine."FTT-CST Optional"::No); //NRD
        if SalesLine.FindSet() then
            repeat
                pSalesAmount := pSalesAmount + SalesLine."Line Amount";
            until SalesLine.next = 0;
        pSalesAmount := pSalesAmount * (100 - InvoiceDiscountPct) / 100;
    end;

    procedure CalculateDRSales(var pSalesAmount: Decimal)
    var
        SalesLine: record "Sales Line";
        SalesReceivables: record "Sales & Receivables Setup";
    begin
        SalesReceivables.Get();
        pSalesAmount := 0;
        SalesLine.SetRange("Document Type", Rec."Document Type");
        SalesLine.SetRange("Document No.", Rec."Document No.");
        SalesLine.SetRange("FTT-CST Parent Item Cat. Code", SalesReceivables."FTT-CST DR Category");
        SalesLine.SetRange("FTT-CST Optional", SalesLine."FTT-CST Optional"::No); //NRD
        if SalesLine.FindSet() then
            repeat
                pSalesAmount := pSalesAmount + SalesLine."Line Amount";
            until SalesLine.next = 0;
        pSalesAmount := pSalesAmount * (100 - InvoiceDiscountPct) / 100;
    end;

    procedure CalculateSetupSales(var pSalesAmount: Decimal)
    var
        SalesLine: record "Sales Line";
        SalesReceivables: record "Sales & Receivables Setup";
    begin
        SalesReceivables.Get();
        pSalesAmount := 0;
        SalesLine.SetRange("Document Type", Rec."Document Type");
        SalesLine.SetRange("Document No.", Rec."Document No.");
        //SalesLine.SetRange("FTT-CST Parent Item Cat. Code", 'HARDWARE');
        SalesLine.SetRange("FTT-CST Parent Item Cat. Code", SalesReceivables."FTT-CST HARDWARE");
        SalesLine.SetRange("FTT-CST Optional", SalesLine."FTT-CST Optional"::No); //NRD
        if SalesLine.FindSet() then
            repeat
                pSalesAmount := pSalesAmount + SalesLine."Line Amount";
            until SalesLine.next = 0;
        //pSalesAmount := pSalesAmount * (100 - InvoiceDiscountPct) / 100;
    end;

    procedure CalculateHostingSales(var pSalesAmount: Decimal)
    var
        SalesLine: record "Sales Line";
        SalesReceivables: record "Sales & Receivables Setup";
    begin
        SalesReceivables.Get();
        pSalesAmount := 0;
        SalesLine.SetRange("Document Type", Rec."Document Type");
        SalesLine.SetRange("Document No.", Rec."Document No.");
        SalesLine.SetRange("FTT-CST Parent Item Cat. Code", SalesReceivables."FTT-CST Hosting and management");
        SalesLine.SetRange("FTT-CST Optional", SalesLine."FTT-CST Optional"::No); //NRD
        if SalesLine.FindSet() then
            repeat
                pSalesAmount := pSalesAmount + SalesLine."Line Amount";
            until SalesLine.next = 0;
        //pSalesAmount := pSalesAmount * (100 - InvoiceDiscountPct) / 100;
    end;

    procedure CalculateCrossConnectSales(var pSalesAmount: Decimal)
    var
        SalesLine: record "Sales Line";
        SalesReceivables: Record "Sales & Receivables Setup";
    begin
        SalesReceivables.Get();
        pSalesAmount := 0;
        SalesLine.SetRange("Document Type", Rec."Document Type");
        SalesLine.SetRange("Document No.", Rec."Document No.");
        SalesLine.SetRange("FTT-CST Parent Item Cat. Code", SalesReceivables."FTT-CST Parent CROSS CONNECT");
        SalesLine.SetRange("FTT-CST Optional", SalesLine."FTT-CST Optional"::No); //NRD
        if SalesLine.FindSet() then
            repeat
                pSalesAmount := pSalesAmount + SalesLine."Line Amount";
            until SalesLine.next = 0;
        //pSalesAmount := pSalesAmount * (100 - InvoiceDiscountPct) / 100;

        SalesLine.RESET;
        SalesLine.SetRange("Document Type", Rec."Document Type");
        SalesLine.SetRange("Document No.", Rec."Document No.");
        SalesLine.SetRange("FTT-CST Parent Item Cat. Code", SalesReceivables."FTT-CST INTERNATIONAL Line");
        SalesLine.SetRange("FTT-CST Optional", SalesLine."FTT-CST Optional"::No); //NRD
        if SalesLine.FindSet() then
            repeat
                pSalesAmount := pSalesAmount + SalesLine."Line Amount";
            until SalesLine.next = 0;
        //pSalesAmount := pSalesAmount * (100 - InvoiceDiscountPct) / 100;
    end;

    procedure CalculateIntegrationSales(var pSalesAmount: Decimal)
    var
        SalesLine: record "Sales Line";
        SalesReceivables: record "Sales & Receivables Setup";
    begin
        SalesReceivables.Get();
        pSalesAmount := 0;

        SalesLine.SetRange("Document Type", Rec."Document Type");
        SalesLine.SetRange("Document No.", Rec."Document No.");
        SalesLine.SetRange("FTT-CST Parent Item Cat. Code", SalesReceivables."FTT-CST Integration Category");
        SalesLine.SetRange("FTT-CST Optional", SalesLine."FTT-CST Optional"::No); //NRD
        if not SalesLine.FindSet() then
            pSalesAmount := 0;

        if SalesLine.FindSet() then
            repeat
                pSalesAmount := pSalesAmount + SalesLine."Line Amount";
            until SalesLine.next = 0;

        //pSalesAmount := pSalesAmount * (100 - InvoiceDiscountPct) / 100;
    end;

    procedure CalculateNRCWRC(var pNRCSalesAmount: Decimal; var pWRCSalesAmount: Decimal)
    var
        SalesLine: record "Sales Line";
    begin
        pNRCSalesAmount := 0;
        pWRCSalesAmount := 0;

        SalesLine.SetRange("Document Type", Rec."Document Type");
        SalesLine.SetRange("Document No.", Rec."Document No.");
        SalesLine.SetRange("FTT-CST Optional", SalesLine."FTT-CST Optional"::No); //NRD
        if not SalesLine.FindSet() then
            pNRCSalesAmount := 0;

        if SalesLine.FindSet() then
            repeat
                if SalesLine."FTT-CST Cost Type" = SalesLine."FTT-CST Cost Type"::NRC then
                    pNRCSalesAmount := pNRCSalesAmount + SalesLine."Line Amount" else
                    pWRCSalesAmount := pWRCSalesAmount + SalesLine."Line Amount";
            until SalesLine.next = 0;

        //pNRCSalesAmount := pNRCSalesAmount * (100 - InvoiceDiscountPct) / 100;
        //pWRCSalesAmount := pWRCSalesAmount * (100 - InvoiceDiscountPct) / 100;
        pWRCSalesAmount := pWRCSalesAmount - InvoiceDiscountAmount;
    end;

    trigger OnAfterGetRecord()
    begin
        CalculateLicenseSales(LicenseSalesAmount);
        CalculateFeedSales(FeedSalesAmount);
        CalculateRedundencySales(RedundancySalesAmount);
        CalculateDRSales(DRSalesAmoount);
        CalculateSetupSales(SetupSalesAmount);
        CalculateHostingSales(HostingSalesAmount);
        CalculateCrossConnectSales(CrossConnectSalesAmount);
        CalculateIntegrationSales(IntegrationSalesAmount);
        CalculateNRCWRC(NRCSales, WRCSales);
        //CurrPage.Update();
    end;

    trigger OnAfterGetCurrRecord()
    begin
        CalculateLicenseSales(LicenseSalesAmount);
        CalculateFeedSales(FeedSalesAmount);
        CalculateRedundencySales(RedundancySalesAmount);
        CalculateDRSales(DRSalesAmoount);
        CalculateSetupSales(SetupSalesAmount);
        CalculateHostingSales(HostingSalesAmount);
        CalculateCrossConnectSales(CrossConnectSalesAmount);
        CalculateIntegrationSales(IntegrationSalesAmount);
        CalculateNRCWRC(NRCSales, WRCSales);
        //CurrPage.Update();
    end;

    trigger OnDeleteRecord(): Boolean
    begin
        IntegrationSalesAmount := 0;
        CrossConnectSalesAmount := 0;
        LicenseSalesAmount := 0;
        CalculateLicenseSales(LicenseSalesAmount);
        CalculateFeedSales(FeedSalesAmount);
        CalculateRedundencySales(RedundancySalesAmount);
        CalculateDRSales(DRSalesAmoount);
        CalculateSetupSales(SetupSalesAmount);
        CalculateHostingSales(HostingSalesAmount);
        CalculateCrossConnectSales(CrossConnectSalesAmount);
        CalculateIntegrationSales(IntegrationSalesAmount);
        CalculateNRCWRC(NRCSales, WRCSales);

        //CurrPage.Update();
    end;

    trigger OnModifyRecord(): Boolean
    begin
        CalculateLicenseSales(LicenseSalesAmount);
        CalculateFeedSales(FeedSalesAmount);
        CalculateRedundencySales(RedundancySalesAmount);
        CalculateDRSales(DRSalesAmoount);
        CalculateSetupSales(SetupSalesAmount);
        CalculateHostingSales(HostingSalesAmount);
        CalculateCrossConnectSales(CrossConnectSalesAmount);
        CalculateIntegrationSales(IntegrationSalesAmount);
        CalculateNRCWRC(NRCSales, WRCSales);
    end;
}