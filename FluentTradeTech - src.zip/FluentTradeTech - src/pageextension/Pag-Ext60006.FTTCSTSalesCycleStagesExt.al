pageextension 60006 "FTT-CST SalesCycleStagesExt" extends "Sales Cycle Stages"
{
    layout
    {
        addafter("Allow Skip")
        {
            field("FTT-CST Create Opp. Notif"; Rec."FTT-CST Create Opp. Notif.")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies that for this sales cycle stage e-mail notifcation.';
            }
            //NRD
            field("Required Estimated Value"; Rec."Required Estimated Value")
            {
                ApplicationArea = all;
                ToolTip = 'Specifies that for this sales cycle stage require Estimated Sales Value(LCY)';
            }
            //+
        }
    }
}
