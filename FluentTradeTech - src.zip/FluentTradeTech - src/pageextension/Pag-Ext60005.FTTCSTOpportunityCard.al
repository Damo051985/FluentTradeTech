pageextension 60005 "FTT-CST OpportunityCard" extends "Opportunity Card"
{
    layout
    {
        addafter("Segment No.")
        {
            field("FTT-CST Notif. Mail. Gr. Code"; Rec."FTT-CST Notif. Mail. Gr. Code")
            {
                ApplicationArea = All;
                ToolTip = 'Specifies opportunity mailing group for notifications.';
            }
        }
        modify("Sales Cycle Code")
        {
            Visible = false;
        }
        modify("No.")
        {
            ApplicationArea = all;
            Visible = False;
        }
        modify("ContactPhoneNo")
        {
            ApplicationArea = all;
            Visible = False;
        }
        modify("ContactMobilePhoneNo")
        {
            ApplicationArea = all;
            Visible = False;
        }
        modify("ContactEmail")
        {
            ApplicationArea = all;
            Visible = False;
        }
        modify("Contact Company Name")
        {
            ApplicationArea = all;
            Visible = False;
        }
        modify("Sales Document Type")
        {
            ApplicationArea = all;
            Visible = False;
        }
        modify("Sales Document No.")
        {
            ApplicationArea = all;
            Visible = False;
        }
        modify("Priority")
        {
            ApplicationArea = all;
            Visible = False;
        }
        modify("Closed")
        {
            ApplicationArea = all;
            Visible = False;
        }
        modify("Creation Date")
        {
            ApplicationArea = all;
            Visible = False;
        }
        modify("Date Closed")
        {
            ApplicationArea = all;
            Visible = False;
        }
        modify("Segment No.")
        {
            ApplicationArea = all;
            Visible = False;
        }
        modify("Campaign No.")
        {
            ApplicationArea = all;
            Visible = False;
        }
        addafter(Closed)
        {
            field("FTT-CST OnHold"; Rec."FTT-CST OnHold")
            {
                ApplicationArea = all;
            }
        }
        addafter("Contact No.")
        {
            field("FTT-CST Contact No."; Rec."FTT-CST Contact No.")
            {
                ApplicationArea = all;
                trigger OnValidate()
                var
                    Contact: Record Contact;
                Begin
                    IF Rec."Contact No." <> '' THEN
                        IF Contact.GET(Rec."Contact No.") THEN
                            Contact.CheckIfPrivacyBlockedGeneric;
                    Rec.CALCFIELDS(Rec."Contact Name", Rec."Contact Company Name");
                End;
            }
        }
        addafter("FTT-CST Notif. Mail. Gr. Code")
        {
            field("FTT-CST Currency"; Rec."FTT-CST Currency")
            {
                ApplicationArea = all;
                Editable = False;
            }
        }
        modify("Contact No.")
        {
            ApplicationArea = all;
            Visible = False;
        }
        addfirst(factboxes)
        {
            //>>Dan 082724
            part("Attached Documents"; "Document Attachment Factbox")
            {
                ApplicationArea = All;
                Caption = 'Attachments';
                SubPageLink = "Table ID" = const(Database::"Opportunity"),
                              "No." = field("No.");
            }
            //<<Dan 082724
            part(GmailInboxPart; "GMAIL Inbox factbox")
            {
                //ApplicationArea = All;
                Caption = 'Emails';
                ApplicationArea = all;
                SubPageLink = "Linked Document No." = FIELD("No.");
            }
            part(EstValPart; "FTT-CST Est. Val. Factbox")
            {
                //ApplicationArea = All;
                Caption = 'Estimated Sales Value (LCY)';
                ApplicationArea = all;
                SubPageLink = "Linked No." = FIELD("No.");
            }
        }
    }
    actions
    {
        modify("Co&mments")
        { Visible = false; }

        modify(Update)
        {
            ApplicationArea = all;

            trigger OnBeforeAction()
            var
                lOpp: Record Opportunity;
                lOppEnt: Record "Opportunity Entry";
                lDocAtt: Record "Document Attachment";
                lUserSet: Record "User Setup";
                lCont: Record Contact;
                lCust: Record Customer;
                lSH: Record "Sales Header";
                lHasNDA: Boolean;
                MySesSet: SessionSettings;
            Begin
                //>>Dan Update 102924
                MySesSet.Init;
                IF MySesSet.ProfileId = 'FTT_SALES_DIRECTOR' THEN
                    IF (lUserSet.GET(UserId)) AND (lUserSet."Skip NDA Validation") THEN
                        Exit;
                lHasNDA := False;
                Clear(lOpp);
                Clear(lOppEnt);
                lOppEnt.SETRANGE("Opportunity No.", Rec."No.");
                lOppEnt.SETFILTER(Active, '%1', TRUE);
                IF lOppEnt.FINDFIRST THEN begin
                    IF lOppEnt."Sales Cycle Stage" = 5 then begin
                        IF lOpp.GET(lOppEnt."Opportunity No.") THEN
                            lOpp.CalcFields("Contact Name");
                        Clear(lDocAtt);
                        lDocAtt.SETRANGE("Table ID", 5092);
                        lDocAtt.SETRANGE("No.", Rec."No.");
                        //lDocAtt.SETFILTER("FTT-CST NDA", '%1', TRUE);
                        IF lDocAtt.FINDFIRST THEN
                            IF (lDocAtt."FTT-CST NDA") OR (lDocAtt."MSA Document") THEN
                                lHasNDA := TRUE;

                        lCont.RESET;
                        IF lCont.GET(lOpp."Contact No.") THEN begin
                            Clear(lDocAtt);
                            lDocAtt.SETRANGE("Table ID", 5050);
                            lDocAtt.SETRANGE("No.", lCont."No.");
                            //lDocAtt.SETFILTER("FTT-CST NDA", '%1', TRUE);
                            IF lDocAtt.FINDFIRST THEN
                                IF (lDocAtt."FTT-CST NDA") OR (lDocAtt."MSA Document") THEN
                                    lHasNDA := TRUE;
                        end;
                        lCust.RESET;
                        lCust.SETRANGE(Name, lOpp."Contact Name");
                        IF lCust.FINDFIRST THEN BEGIN
                            Clear(lDocAtt);
                            lDocAtt.SETRANGE("Table ID", 18);
                            lDocAtt.SETRANGE("No.", lCust."No.");
                            //lDocAtt.SETFILTER("FTT-CST NDA", '%1', TRUE);
                            IF lDocAtt.FINDFIRST THEN
                                IF (lDocAtt."FTT-CST NDA") OR (lDocAtt."MSA Document") THEN
                                    lHasNDA := TRUE;
                        end;
                        Clear(lSH);
                        lSH.SETRANGE("Opportunity No.", lOpp."No.");
                        IF lSH.FINDFIRST then begin
                            Clear(lDocAtt);
                            lDocAtt.SETRANGE("Table ID", 36);
                            lDocAtt.SETRANGE("No.", lSH."No.");
                            //lDocAtt.SETFILTER("FTT-CST NDA", '%1', TRUE);
                            IF lDocAtt.FINDFIRST THEN
                                IF (lDocAtt."FTT-CST NDA") OR (lDocAtt."MSA Document") THEN
                                    lHasNDA := True;
                        End;
                        IF NOT lHasNDA then
                            Error('You cannot go to next stage before you have assigned NDA (or MSA) Document.');
                    end;
                end;
                //<<Dan Update 102924
            End;
        }

        modify(CreateSalesQuote)
        {
            Caption = 'Old Create Sales Quote';
            Visible = false; //NRD
        }
        addafter(CloseOpportunity)
        {

            action(PriceLists)
            {
                ApplicationArea = Basic, Suite;
                Caption = 'Sales Price Lists';
                Image = Price;
                PromotedCategory = Process;
                Promoted = true;
                PromotedIsBig = true;
                ToolTip = 'View or set up sales price lists for products that you sell to the customer. A product price is automatically granted on invoice lines when the specified criteria are met, such as customer, quantity, or ending date.';

                trigger OnAction()
                var
                    RecContact: Record Contact;
                    PriceUXManagement: Codeunit "Price UX Management";
                    PageCloseOpportunity: page "Close Opportunity";
                begin
                    if RecContact.Get(rec."Contact No.") then
                        PriceUXManagement.ShowPriceLists(RecContact, Enum::"Price Type"::Sale, Enum::"Price Amount Type"::Any);
                end;
            }
            action(Email)
            {
                ApplicationArea = All;
                Caption = 'Send Email';
                Image = Email;
                ToolTip = 'Send an email to this Contact.';
                PromotedCategory = Process;
                Promoted = true;
                PromotedIsBig = true;
                trigger OnAction()
                var
                    TempEmailItem: Record "Email Item" temporary;
                    EmailScenario: Enum "Email Scenario";
                    userSetup: Record "User Setup";
                    SignatureCustom: Codeunit "Fluent Custom Subscriber";
                    RecContact: Record Contact;
                    isEmailSigInc: Boolean;
                    GmailMaintenanceSetup: record "GMAIL Maintenance Setup";
                begin
                    if not GmailMaintenanceSetup.Get() then
                        exit;
                    isEmailSigInc := false;
                    if userSetup.Get(UserId) then begin
                        userSetup.TestField("Email Signature Included", true);
                        if userSetup."Email Signature Included" then begin
                            userSetup.TestField("Job Position");
                            userSetup.TestField("E-Mail");
                            userSetup.TestField("Phone No.");
                            //userSetup.TestField("CRM Email");
                            isEmailSigInc := true;
                        end
                    end else
                        Error('User Setup does not exist for this ID : %1', UserId);

                    if not RecContact.Get(rec."Contact No.") then
                        exit;

                    TempEmailItem.AddSourceDocument(Database::Contact, RecContact.SystemId);
                    TempEmailitem."Send to" := RecContact."E-Mail";

                    if GmailMaintenanceSetup."Add to BCC as Default" then
                        TempEmailItem."Send CC" := GmailMaintenanceSetup."CRM Email";
                    if isEmailSigInc then
                        TempEmailItem.SetBodyText(SignatureCustom.GenerateSignatureEmailBodyReport(userSetup));

                    TempEmailItem.Send(false, EmailScenario::Default);

                end;


            }
            action(Emails)
            {
                ApplicationArea = All;
                Caption = 'Emails';
                Image = History;
                PromotedCategory = Process;
                Promoted = true;
                PromotedIsBig = true;
                RunObject = page "GMAIL Received Emails";
                RunPageView = where("Email Type" = const(Inbox));
            }
            action(OpenEstValue)
            {
                ApplicationArea = All;
                Caption = 'Open Estimated Sales Value (LCY)';
                Image = ViewJob;
                PromotedCategory = Process;
                Promoted = true;
                PromotedIsBig = true;
                RunPageMode = view;
                trigger OnAction()
                var
                    pagEstValue: page "FTT-CST Est. Value Mod View";
                    recEstValie: Record "FTT-CST Estimated Value Mod";
                begin
                    Clear(pagEstValue);
                    recEstValie.Reset();
                    recEstValie.SetRange("Linked No.", rec."No.");
                    if recEstValie.FindSet() then
                        pagEstValue.SetTableView(recEstValie)
                    else
                        pagEstValue.SetTableView(recEstValie);

                    pagEstValue.Run();

                end;

            }

        }

        modify("Show Sales Quote")
        {
            Visible = false; //NRD
        }
        addbefore("Show Sales Quote")
        {


            action(ShowRelatedQuote)
            {
                ApplicationArea = all;
                Caption = 'Show Sales Quotes';
                Promoted = true;
                PromotedIsBig = true;
                PromotedCategory = Process;
                trigger OnAction()
                begin
                    ShowRelatedSalesQuote();
                end;
            }

        }

        addbefore(CreateSalesQuote)
        {
            action(CreateSalesQuoteFTT)
            {
                ApplicationArea = RelationshipMgmt;
                Caption = 'Create Sales &Quote';
                Promoted = true;
                PromotedCategory = Process;
                PromotedIsBig = true;
                PromotedOnly = true;
                Enabled = OppInProgress2;
                Image = Allocate;
                ToolTip = 'Create a new sales quote with the opportunity inserted as the customer.';
                Visible = true;

                trigger OnAction()
                var
                    Opportunity: Record Opportunity;
                    Opportunity2: record Opportunity;
                    OpportEntry: Record "Opportunity Entry";
                    OpportunityEntry: record "Opportunity Entry";
                    //OpportunityEntry: record "Opportunity Entry";
                    SalesCycleStage: Record "Sales Cycle Stage";
                    SalesHader: Record "Sales Header";
                    SalesQuote: Page "Sales Quote";
                    OpportunityList: Page "Opportunity List";
                    UpdateOpportunity: page "Update Opportunity";
                    SelectedOpp: Text[1024];
                    SalesQuoteNo: Code[20];
                begin
                    SelectedOpp := '';
                    if Confirm(InfoMessage) then begin
                        Opportunity.SetRange("Contact No.", rec."Contact No.");
                        Opportunity.SetRange(Status, Opportunity.Status::"In Progress");
                        Opportunity.SetFilter(Status, '%1', Opportunity.Status::"In Progress");
                        Opportunity.SetFilter("Estimated Value (LCY)", '>%1', 0);
                        Opportunity.SetFilter("Current Sales Cycle Stage", '<>%1', 0);
                        OpportunityList.LookupMode(TRUE);
                        OpportunityList.SetTableView(Opportunity);

                        if OpportunityList.RunModal() = Action::LookupOK then begin
                            OpportunityList.SetSelectionFilter(Opportunity2);
                            if Opportunity2.FindSet() then
                                repeat
                                    if Opportunity2.Status = Opportunity2.Status::"In Progress" then begin
                                        if Opportunity2."Estimated Value (LCY)" = 0 then begin
                                            Opportunity2."Estimated Value (LCY)" := 10000;
                                            Opportunity2.Modify();
                                        end;

                                        OpportunityEntry.Reset();
                                        OpportunityEntry.SetRange("Opportunity No.", Opportunity2."No.");
                                        OpportunityEntry.SetRange("Sales Cycle Stage", 8);

                                        if NOT OpportunityEntry.FindSet() then begin
                                            OpportunityEntry.Init();
                                            OpportunityEntry."Sales Cycle Code" := Opportunity2."Sales Cycle Code";
                                            OpportunityEntry.Validate("Sales Cycle Stage", 8);
                                            OpportunityEntry."Action Type" := OpportunityEntry."Action Type"::Jump;
                                            OpportunityEntry."Action Taken" := OpportunityEntry."Action Taken"::Jumped;
                                            OpportunityEntry."Estimated Value (LCY)" := Opportunity2."Estimated Value (LCY)";
                                            OpportunityEntry.InitOpportunityEntry(Opportunity2);
                                            OpportunityEntry.InsertEntry(OpportunityEntry, false, true);
                                            OpportunityEntry.UpdateEstimates();
                                        end else begin
                                            if SalesQuoteNo = '' then begin
                                                Opportunity2."Sales Document No." := '';
                                                Opportunity2."Sales Document Type" := Opportunity2."Sales Document Type"::" ";
                                                Opportunity2.FTTCSTCreateQuote(SalesQuoteNo); //First
                                                Commit();
                                            end else begin
                                                SalesHader.Get(SalesHader."Document Type"::Quote, SalesQuoteNo);
                                                Opportunity2.CreateSalesLinesFromEstValue(SalesHader);
                                            end;

                                            Opportunity2."Sales Document No." := SalesQuoteNo;
                                            Opportunity2."Sales Document Type" := Opportunity2."Sales Document Type"::Quote;
                                            Opportunity2.Modify();

                                            OpportunityEntry.Reset;
                                            OpportunityEntry.SetRange("Opportunity No.", Opportunity2."No.");
                                            OpportunityEntry.ModifyAll("FTT-CST Sales Quote No.", SalesQuoteNo);
                                        end;
                                    end;
                                until Opportunity2.next = 0;
                            Commit();
                            if SalesQuoteNo <> '' then begin
                                SalesHader.Get(SalesHader."Document Type"::Quote, SalesQuoteNo);
                                SalesQuote.SetRecord(SalesHader);
                                SalesQuote.Run();
                            end;
                        end;
                        // end else begin
                        //     Rec."Sales Document No." := '';
                        //     Rec."Sales Document Type" := rec."Sales Document Type"::" ";
                        //     Rec.CreateQuote();
                    end;
                    CurrPage.Update();
                end;
            }
        }
    }

    trigger OnNewRecord(BelowxRec: Boolean)
    var
        SalesCycle: Record "Sales Cycle";
        CodeSalesCycle: code[10];
    begin
        Evaluate(CodeSalesCycle, 'AGRMT');
        if SalesCycle.GET(CodeSalesCycle) THEN begin
            Rec."Sales Cycle Code" := SalesCycle.Code;
            //Rec.Modify();
        end;
        if Rec."Sales Cycle Code" <> '' then
            Rec.FillNotifMailGrCode();
    end;

    procedure ShowRelatedSalesQuote()
    var
        SalesHeader: record "Sales Header";
        SalesQuote: page "Sales Quotes";
    begin
        SalesHeader.SetRange("Opportunity No.", Rec."No.");
        if SalesHeader.Count() > 0 then begin
            SalesQuote.SetTableView(SalesHeader);
            SalesQuote.RunModal();
        end else
            Message(NoQuoteMessage);
    end;

    trigger OnAfterGetCurrRecord()
    begin
        OppInProgress2 := Rec.Status = Rec.Status::"In Progress";
        Rec."FTT-CST Contact No." := Rec."Contact No.";
    end;

    var
        InfoMessage: Label 'Would you like to add another opportunity within the upcoming Sales Quote?';
        NoQuoteMessage: Label 'System does not have Sales Quotes created from this Opportunity';
        OppInProgress2: Boolean;


}
