pageextension 50001 "SuggesstedEmailaddress Ext." extends "Email Address Lookup"
{
    layout
    {
        addafter(EntityGroup)
        {
            group(GroupDepartmentFilter)
            {
                Visible = EntityType = Enum::"Email Address Entity"::Employee;
                Caption = 'Department filters';

                field(DepartmentFilter; DepartmentSelection)
                {
                    ApplicationArea = All;
                    Caption = 'Department Selection';
                    ToolTip = 'A comma separated list of Department.';

                    trigger OnValidate()
                    var
                        GroupEmployee: Record Employee;
                    begin
                        if DepartmentSelection = DepartmentSelection::" " then begin
                            rec.Reset();
                            Rec.SetFilter(rec."Entity type", '%1', rec."Entity type"::Employee);
                            CurrPage.Update();
                        end else begin
                            GroupEmployee.Reset();
                            GroupEmployee.SetFilter(Department, '%1', DepartmentSelection);
                            if GroupEmployee.FindSet() then
                                Rec.SetFilter(rec.Department, '%1', GroupEmployee.Department);
                            CurrPage.Update();
                        end;
                    end;
                }
            }
        }

        modify(Company)
        {
            ApplicationArea = all;
            Visible = IsEmployeeHideCompanyName;
        }
        modify("Type of entity")
        {
            ApplicationArea = all;
            trigger OnBeforeValidate()
            begin
                case rec."Entity type" of
                    rec."Entity type"::Customer:
                        IsEmployeeHideCompanyName := true;
                    rec."Entity type"::Contact:
                        IsEmployeeHideCompanyName := false;
                    rec."Entity type"::User:
                        IsEmployeeHideCompanyName := false;
                    rec."Entity type"::Vendor:
                        IsEmployeeHideCompanyName := false;
                    rec."Entity type"::Employee:
                        IsEmployeeHideCompanyName := false;
                end;

                CurrPage.Update();
                // Commit();
            end;

            trigger OnAfterValidate()
            begin
                case rec."Entity type" of
                    rec."Entity type"::Customer:
                        IsEmployeeHideCompanyName := true;
                    rec."Entity type"::Contact:
                        IsEmployeeHideCompanyName := false;
                    rec."Entity type"::User:
                        IsEmployeeHideCompanyName := false;
                    rec."Entity type"::Vendor:
                        IsEmployeeHideCompanyName := false;
                    rec."Entity type"::Employee:
                        IsEmployeeHideCompanyName := false;
                end;

                CurrPage.Update();
                // Commit();
            end;
        }

    }

    actions
    {
        // Add changes to page actions here
    }

    trigger OnOpenPage()

    begin
        IsEmployeeHideCompanyName := true;
    end;

    trigger OnAfterGetRecord()
    begin
        case rec."Entity type" of
            rec."Entity type"::Customer:
                IsEmployeeHideCompanyName := true;
            rec."Entity type"::Contact:
                IsEmployeeHideCompanyName := false;
            rec."Entity type"::User:
                IsEmployeeHideCompanyName := false;
            rec."Entity type"::Vendor:
                IsEmployeeHideCompanyName := false;
            rec."Entity type"::Employee:
                IsEmployeeHideCompanyName := false;
        end;

        //CurrPage.Update();

    end;

    var
        DepartmentSelection: enum "Department Filter";
        IsEmployeeHideCompanyName: Boolean;


}