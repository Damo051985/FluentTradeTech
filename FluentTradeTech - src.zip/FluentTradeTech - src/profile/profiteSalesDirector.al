profile FTT_SALES_DIRECTOR
{
    Description = 'This is the profile for the FTT SALES DIRECTOR';
    RoleCenter = "CEO and President Role Center";
    Customizations = Configuration1, MyCustom23, MyCustom24, MyCustomization1, MyCustomization2, MyCustomization3, MyCustomization4, MyCustomization5, MyCustomization6, MyCustomization7, MyCustomization8, MyCustomization9, MyCustomization10, MyPriceList, MyCustomizatio10;
    Caption = 'FTT SALES DIRECTOR';
}

pagecustomization Configuration1 customizes "Order Processor Role Center"
{
    actions
    {
        // Hides the Customers action
        modify(Customers)
        {
            Visible = false;
        }
    }
}
//>>dan
pagecustomization MyCustom23 customizes "Contact Card"
{
    layout
    {
        Modify("FTT-CST Role")
        {
            Visible = True;
        }
        Modify("FTT-CST Subsidiary no.")
        { Visible = False; }
        Modify("FTT-CST Subsidiary name")
        { Visible = False; }
        Modify("Contact Business Relation")
        { Visible = False; }
        Modify("Search name")
        { Visible = False; }
        Modify("VAT Registration No.")
        { Visible = False; }
        Modify("Parental Consent Received")
        { Visible = False; }
        Modify(Minor)
        { Visible = False; }
        Modify("Privacy Blocked")
        { Visible = False; }
        Modify("Exclude from Segment")
        { Visible = False; }
        Modify("Date of Last Interaction")
        { Visible = False; }
        Modify(LastDateTimeModified)
        { Visible = False; }
        Modify("Organizational Level Code")
        { Visible = False; }
        Modify("Salutation Code")
        { Visible = False; }
        Modify("Format Region")
        { Visible = False; }
        Modify("Language Code")
        { Visible = False; }
        Modify("Correspondence Type")
        { Visible = False; }
        Modify("Fax No.")
        { Visible = False; }
        Modify("Registration Number")
        { Visible = False; }
        Modify("Next Task Date")
        { Visible = False; }
        Modify("Last Date Attempted")
        { Visible = False; }
        Modify("Company Name")
        { Visible = False; }
    }
}
pagecustomization MyCustom24 customizes "Item Card"
{
    layout
    {
        Modify("Costs & Posting")
        {
            Visible = False;
        }
        Modify("Replenishment")
        {
            Visible = False;
        }
        Modify("Profit %")
        { Visible = False; }
    }
}
//<<Dan
pagecustomization MyCustomization10 customizes "Sales Quotes"
{
    layout
    {

        //moveafter("Sell-to Contact"; "Due Date")

        modify("Sell-to Customer No.")
        { visible = false; }
        //>>dan 090624
        modify("Sell-to Customer Name")
        { visible = false; }
        //<<dan 090624
        modify("External Document No.")
        { visible = false; }
        modify("Sell-to Contact")
        { visible = false; }
        modify("Salesperson Code")
        {
            Importance = Promoted;
            Visible = true;
        }
        modify("Posting Date")
        {
            Visible = false;
        }
        modify("Requested Delivery Date")
        {
            Visible = false;
        }
        modify("Location Code")
        {
            Visible = false;
        }
        modify("Quote Valid Until Date")
        {
            Visible = true;
        }
        modify("Assigned User ID")
        {
            Visible = false;
        }
        modify("Currency Code")
        {
            Visible = true;
        }
        modify(Status)
        {
            Visible = true;
        }
        movebefore(Amount; "Currency Code")
        movebefore("Currency Code"; "FTT-CST Agr. Starting Date")

    }

}

pagecustomization MyCustomization1 customizes "Sales Quote"
{
    layout
    {

        moveafter("Sell-to Contact"; "Due Date")
        modify("Shipment Date")
        { visible = false; }
        modify(Control1900316107)
        {
            Visible = false;
        }
        modify(Control1902018507)
        {
            Visible = false;
        }
        modify("External Document No.")
        { visible = false; }
        modify("Sell-to Contact")
        { visible = false; }
        modify("Salesperson Code")
        {
            visible = false;
        }
        modify("Location Code")
        {
            visible = false;
        }
        modify("Assigned User ID")
        {
            visible = false;
        }
        modify("Quote Valid Until Date")
        {
            Visible = true;
        }

    }
    actions
    {
        movefirst(Category_Process; "FTT-CST ITEM CHAD_Promoted2")
        moveafter("FTT-CST ITEM CHAD_Promoted2"; "FTT-CST Create Pricing Prop_Promoted")
        moveafter("FTT-CST Create Pricing Prop_Promoted"; "FTT-CST Update Qty. for Agr_Promoted")
        //moveafter("FTT-CST Update Qty. for Agr_Promoted"; "FTT-CST ITEM CHAD_Promoted2")
        //moveafter("FTT-CST ITEM CHAD_Promoted2"; "FTT-CST ITEM CHAD_Promoted")
        modify(DocAttach)
        {
            visible = false;
        }
        modify("FTT-CST Update Qty. for Agr_Promoted")
        {
            Visible = true;
        }
        moveafter(MakeInvoice_Promoted; Customer_Promoted)
        moveafter(Customer_Promoted; "C&ontact_Promoted")
        moveafter("C&ontact_Promoted"; "Co&mments_Promoted")
        modify("Co&mments_Promoted")
        {
            Visible = true;
        }
        modify(SendApprovalRequest_Promoted)
        { Visible = false; }
        modify(Category_Category9)
        { Visible = false; }
        modify(Category_Category10)
        { Visible = false; }
        modify(Category_Category8)
        { Visible = false; }
        modify("&Quote")
        { Visible = false; }
        modify("Request Approval")
        { Visible = false; }
        modify(Reopen_Promoted)
        { Visible = false; }
        modify(Category_Prepare)
        { Visible = false; }
        modify(Category_Category6)
        { Visible = false; }
        modify(Category_Category4)
        { Visible = false; }
        modify("Archive Document_Promoted")
        { Visible = false; }
        modify("F&unctions")
        {
            Visible = false;
        }

    }
}

pagecustomization MyCustomization2 customizes "Sales Order"
{

    layout
    {
        modify("Posting Date")
        {
            Visible = false;
        }
        modify("Sell-to Contact")
        {
            Visible = false;
        }
        modify("Sell-to Contact No.")
        {
            Visible = false;
        }
        modify("Quote No.")
        {
            Visible = false;
        }
        modify("Responsibility Center")
        {
            Visible = false;
        }
        moveafter("Sell-to Customer Name"; "Quote No.")
        moveafter("Order Date"; "Salesperson Code")
        modify("FTT-CST Agr. Period Number")
        {
            Visible = false;
        }
        modify("Due Date")
        { visible = false; }
        modify("Shipment Date")
        { visible = false; }
        modify("VAT Reporting Date")
        {
            Visible = false;
        }
        modify("External Document No.")
        {
            Visible = false;
        }
        modify(Control1900316107)
        {
            Visible = false;
        }
        modify(Control1902018507)
        {
            Visible = false;
        }


    }
    actions
    {

        modify("Create &Warehouse Shipment")
        {
            Visible = false;
        }
        modify("Create &Warehouse Shipment_Promoted")
        {
            Visible = false;
        }
        modify("Create Inventor&y Put-away/Pick")
        {
            Visible = false;
        }
        modify("Create Inventor&y Put-away/Pick_Promoted")
        {
            Visible = false;
        }
        modify("Archive Document_Promoted")
        {
            Visible = false;
        }
        modify(Category_Category7)
        {
            visible = false;
        }
        modify(Category_Category4)
        {
            visible = false;
        }
        modify(Category_Category8)
        {
            visible = false;
        }

        modify(Category_Category9)
        {
            visible = false;
        }
        modify(Category_Category11)
        {
            Visible = false;
        }
        modify("&Print")
        { Visible = false; }
        //modify("O&rder")
        //{ Visible = false; }
        modify("&Order Confirmation")
        { Visible = false; }
        modify(PostAndSend_Promoted)
        { Visible = false; }
        modify(PreviewPosting_Promoted)
        { Visible = false; }
        modify(PostAndNew_Promoted)
        { Visible = false; }
        modify(Reopen_Promoted)
        { Visible = false; }

        movefirst(Category_Process; "FTT-CST Additions_Promoted")
        moveafter("FTT-CST Additions_Promoted"; "FTT-CST Renewal_Promoted")
        moveafter("FTT-CST Renewal_Promoted"; "FTT-CST Update Qty. for Agr_Promoted")
        moveafter("FTT-CST Update Qty. for Agr_Promoted"; "FTT-CST Update Qty. for Inv_Promoted")
        moveafter("FTT-CST Update Qty. for Inv_Promoted"; "FTT-CST ITEM CHA_Promoted")
        moveafter("FTT-CST ITEM CHA_Promoted"; Customer_Promoted)
        moveafter(Customer_Promoted; Invoices_Promoted)
        moveafter(Invoices_Promoted; Post_Promoted)
        moveafter(Post_Promoted; Release_Promoted)
        moveafter(Release_Promoted; "Co&mments_Promoted")
        moveafter("Co&mments_Promoted"; DocAttach_Promoted)
    }
}

pagecustomization MyCustomization3 customizes "Sales Order Subform"
{

    layout
    {
        modify("Total VAT Amount")
        {
            Visible = false;
        }
        modify("Total Amount Excl. VAT")
        {
            Visible = false;
        }
        moveafter(Description; ShortcutDimCode3)
        modify("Item Reference No.")
        {
            Visible = false;
        }
        modify("Planned Delivery Date")
        { Visible = false; }
        modify("Planned Shipment Date")
        {
            Visible = false;
        }
        modify("Shipment Date")
        { Visible = false; }
        modify("Qty. Assigned")
        { Visible = false; }
        modify("Item Charge Qty. to Handle")
        { Visible = false; }
        modify("Qty. to Assemble to Order")
        { Visible = false; }
        modify("Reserved Quantity")
        { Visible = false; }
        modify("Quantity Invoiced")
        { Visible = false; }
        modify("Qty. to Assign")
        { Visible = false; }
        modify("Unit of Measure Code")
        { Visible = false; }
        modify("Shortcut Dimension 1 Code")
        { Visible = false; }
        modify("Shortcut Dimension 2 Code")
        { Visible = false; }
    }
    actions
    {
        modify("Item Availability by")
        { Visible = false; }
        modify("Related Information")
        { Visible = false; }
        modify("O&rder")
        { Visible = false; }
        modify("&Line")
        { Visible = false; }
        modify(SelectMultiItems)
        { Visible = false; }

        // movelast(processing; "FTT-CST Add Redundancy Line")
        // moveafter("FTT-CST Add Redundancy Line"; "FTT-CST Add DR Line")
        // moveafter("FTT-CST Add DR Line"; "FTT-CST Add Integration Line")
        // moveafter("FTT-CST Add Integration Line"; GetLineDiscount)
        modify("FTT-CST Add Redundancy Line")
        { Visible = false; }
        modify("FTT-CST Add DR Line")
        { Visible = false; }
        modify("FTT-CST Add Integration Line")
        { Visible = false; }
        modify(GetLineDiscount)
        { Visible = false; }

    }

}

pagecustomization MyCustomization4 customizes "Sales Invoice Subform"
{

    layout
    {
        modify("Total VAT Amount")
        {
            Visible = false;
        }
        modify("Total Amount Excl. VAT")
        {
            Visible = false;
        }
        modify("Item Reference No.")
        {
            Visible = false;
        }
        modify("Location Code")
        {
            Visible = false;
        }
        modify("Shortcut Dimension 1 Code")
        { Visible = false; }
        modify("Shortcut Dimension 2 Code")
        { Visible = false; }
        modify("Qty. to Assign")
        { Visible = false; }
        modify("Unit of Measure Code")
        { Visible = false; }
    }
    actions
    {
        movefirst(processing; "FTT-CST Add Redundancy Line")
        modify(SelectMultiItems)
        { Visible = FALSE; }
        moveafter("FTT-CST Add Redundancy Line"; "FTT-CST Add DR Line")
        moveafter("FTT-CST Add DR Line"; "FTT-CST Add Integration Line")
        moveafter("FTT-CST Add Integration Line"; GetLineDiscount)
        modify("&Line")
        { Visible = false; }

    }

}


pagecustomization MyCustomization5 customizes "Sales Invoice"
{

    layout
    {
        modify("Sell-to Contact")
        {
            Visible = false;
        }
        modify("Sell-to Contact No.")
        {
            Visible = false;
        }

        moveafter("Posting Date"; "Salesperson Code")

        modify("Due Date")
        { visible = false; }
        modify("Shipment Date")
        { visible = false; }
        modify("VAT Reporting Date")
        {
            Visible = false;
        }
        modify("External Document No.")
        {
            Visible = false;
        }
        modify("Salesperson Code")
        {
            Importance = Promoted;
        }
        modify(Control1900316107)
        { VISIBLE = FALSE; }
        modify(Control1901314507)
        { Visible = false; }
    }
    actions
    {

        modify(Category_Category7)
        {
            visible = false;
        }
        modify(Category_Category4)
        {
            visible = false;
        }
        modify(Category_Category8)
        {
            visible = false;
        }

        modify(Category_Category9)
        {
            visible = false;
        }
        modify(Category_Category11)
        {
            Visible = false;
        }
        modify(PostAndNew_Promoted)
        { Visible = false; }
        modify(Reopen_Promoted)
        { Visible = false; }
        modify(Category_Category6)
        { Visible = false; }
        modify(Category_PrintSend)
        { Visible = false; }
        movefirst(Category_Process; "FTT-CST Update Qty. for Agr_Promoted")
        moveafter("FTT-CST Update Qty. for Agr_Promoted"; Function_CustomerCard_Promoted)
        moveafter(Function_CustomerCard_Promoted; Post_Promoted)
        moveafter(Post_Promoted; Release_Promoted)
        moveafter(Release_Promoted; "Co&mments_Promoted")
        moveafter("Co&mments_Promoted"; DocAttach_Promoted)
        moveafter(DocAttach_Promoted; CopyDocument_Promoted)
        modify(PostAndSend_Promoted)
        {
            Visible = false;
        }


    }
}
pagecustomization MyCustomization6 customizes "Sales Quote Subform"
{

    layout
    {
        modify("Total VAT Amount")
        {
            Visible = false;
        }
        modify("Allow Invoice Disc.")
        {
            Visible = false;
        }
        modify("Total Amount Excl. VAT")
        {
            Visible = false;
        }
        modify("Item Reference No.")
        {
            Visible = false;
        }
        modify("No.")
        { Visible = false; }
        modify("Location Code")
        {
            Visible = false;

        }
        modify("Unit of Measure Code")
        { Visible = false; }
        modify("Qty. to Assemble to Order")
        { Visible = false; }
        modify("Qty. Assigned")
        { Visible = false; }
        modify("Qty. to Assign")
        { Visible = false; }
        modify("Shortcut Dimension 1 Code")
        { Visible = false; }
        modify("Shortcut Dimension 2 Code")
        { Visible = false; }

    }
    actions
    {
        movefirst(processing; "FTT-CST Add Redundancy Line")
        moveafter("FTT-CST Add Redundancy Line"; "FTT-CST Add DR Line")
        moveafter("FTT-CST Add DR Line"; "FTT-CST Add Integration Line")
        moveafter("FTT-CST Add Integration Line"; SelectMultiItems)
        modify("&Line")
        { Visible = false; }
        modify("F&unctions")
        { Visible = false; }
        modify(Dimensions)
        { Visible = false; }
        modify(InsertExtTexts)
        { Visible = false; }
        modify(GetLineDiscount)
        { Visible = false; }

    }

}


pagecustomization MyCustomization8 customizes "CEO and President Role Center"
{
    layout
    {
        movefirst(Control1900724808; Control1907692088)
        moveafter(Control1907692088; Control1907692008)

        //Control24)
        //moveafter(Control21; Control24)
        //moveafter(Control1907692008; Control27)
        movefirst(Control1900724708; Control27)
        moveafter(Control27; Control29)
        modify(Control4)
        { Visible = false; }
        modify(Control29)
        { visible = false; }
        modify(Control24)
        { Visible = false; }
        modify(Control21)
        { Visible = false; }

    }
    actions
    {
        movefirst(embedding; Opportunity)
        moveafter(Opportunity; Contacts)
        moveafter(Contacts; Customers)
        moveafter(Customers; "Sales Quotes")
        moveafter(Customers; "FTT-CST CPG")
        moveafter("FTT-CST CPG"; "Sales Quotes")
        moveafter("Sales Quotes"; "Sales Orders")
        moveafter("Sales Orders"; "FTT-CST SOW")
        moveafter("FTT-CST SOW"; "Sales Invoices")
        moveafter("Sales Invoices"; "Sales Analysis Report")
        moveafter("Sales Analysis Report"; "Sales Budgets")


        modify("Account Schedules")
        {
            Visible = false;
        }
        modify("Analysis by Dimensions")
        {
            Visible = false;
        }
        modify("Budgets")
        {
            Visible = false;
        }
        modify("Customer - &Balance")
        {
            Visible = false;
        }
        modify("Vendor - &Purchase List")
        {
            Visible = false;
        }
        modify("&Trial Balance/Budget")
        {
            Visible = false;
        }
        modify("&Closing Trial Balance")
        {
            Visible = false;
        }
        modify("&Fiscal Year Balance")
        {
            Visible = false;
        }
        modify("Navi&gate")
        {
            Visible = false;
        }
        modify("Recei&vables-Payables")
        {
            Visible = false;
        }

    }
}

pagecustomization MyCustomization7 customizes "Opportunity Card"
{
    layout
    {
        modify(Control7)
        {
            Visible = false;
        }

    }
    actions
    {
        modify("Co&mments")
        { Visible = false; }
        modify("Co&mments_Promoted")
        { Visible = false; }
    }
}
pagecustomization MyPriceList customizes "Customer Price Groups"
{
    actions
    {
        movefirst(Promoted; PriceLists_Promoted)
        moveafter(PriceLists_Promoted; PriceLines_Promoted)
        modify(PriceLists_Promoted)
        {
            Visible = true;
        }
    }
}


pagecustomization MyCustomization9 customizes "Opportunity List"
{
    layout
    {
        modify(Control5)
        {
            Visible = false;
        }
        modify("Sales Document No.")
        {
            Visible = False;
        }
        Modify("Calcd. Current Value (LCY)")
        {
            Visible = False;
        }
        Modify("Estimated Value (LCY)")
        {
            Visible = False;
        }
    }
    actions
    {
        modify("Co&mments")
        { Visible = false; }
    }
}

pagecustomization MyCustomizatio10 customizes "Customer Card"
{
    layout
    {


    }
    actions
    {

        modify(ApplyTemplate_Promoted)
        {
            Visible = false;
        }
        modify(MergeDuplicate_Promoted)
        {
            Visible = false;
        }
        modify(Category_Category5)
        {
            Visible = false;
        }
        modify(Category_Category6)
        {
            Visible = false;
        }
        modify(Category_Category4)
        {
            Visible = false;
        }
        modify(Category_Category7)
        {
            Visible = false;
        }
        modify(Category_Category9)
        {
            Visible = false;
        }
        modify(Category_Report)
        {
            Visible = false;
        }

        modify(DiscountLines_Promoted)
        {
            Visible = false;
        }

        modify(PriceLists_Promoted)
        {
            Visible = true;
        }
        moveafter(Category_Process; PriceLists_Promoted)
        modify(Category_Process)
        {
            Visible = false;
        }
        modify(Contact_Promoted)
        {
            Visible = true;
        }
        modify("F&unctions")
        {
            Visible = false;
        }
        modify("Request Approval")
        {
            Visible = false;
        }
        modify(Workflow)
        {
            Visible = false;
        }
        modify(NewBlanketSalesOrder)
        {
            Visible = false;
        }
        modify("Blanket Orders")
        {
            Visible = false;
        }
        modify(NewReminder)
        {
            Visible = false;
        }

        movefirst(Category_Category5; DiscountLines_Promoted)
        movefirst(Category_Category7; Category_Category5)
        movebefore(History; Documents)

    }
}