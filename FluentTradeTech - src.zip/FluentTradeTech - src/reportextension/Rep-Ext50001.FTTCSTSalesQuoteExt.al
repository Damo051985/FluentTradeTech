reportextension 50001 "SalesQuoteExt NRD" extends 1304
{

    WordLayout = './src/ReportExtension/Layout/Standard Sales Quote Email (Word)2.docx';

    dataset
    {
        add(header)
        {
            column(SalesPersonPosition; GetPositionPhoneAndEmailFullName(1))
            {
            }
            column(SalesPersonMobile; 'Mobile No.: ' + GetPositionPhoneAndEmailFullName(2))
            {
            }
            column(SalesPersonEmail; 'Email: ' + GetPositionPhoneAndEmailFullName(3))
            {
            }
            column(FullName; GetPositionPhoneAndEmailFullName(4))
            {
            }
        }
    }


    local procedure GetPositionPhoneAndEmailFullName(IntCheck: Integer): Text
    var
        recuserSetup: Record "User Setup";
    begin
        if not recuserSetup.Get(UserId) then
            exit;

        if IntCheck = 1 then
            exit(recuserSetup."Job Position");

        if IntCheck = 2 then
            exit(recuserSetup."Phone No.");

        if IntCheck = 3 then
            exit(recuserSetup."E-Mail");

        if IntCheck = 4 then
            exit(recuserSetup."Full Name");

        exit('');
    end;
}