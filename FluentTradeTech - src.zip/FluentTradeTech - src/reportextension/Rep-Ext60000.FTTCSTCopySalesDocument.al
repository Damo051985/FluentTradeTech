reportextension 60000 "FTT-CST CopySalesDocument" extends "Copy Sales Document"
{
    requestpage
    {
        layout
        {
            addafter(RecalculateLines)
            {
                field(FTTCSTPriceAdjFactor; FTTCSTPriceAdjFactor)
                {
                    ApplicationArea = All;
                    Caption = 'Price Adjustment Factor';
                    Editable = EditPriceAdjFactor;
                    MinValue = 0;
                }
            }

            addafter(SellToCustName)
            {
                field(FTTCSTAgrPeriodUpdate; FTTCSTAgrPeriodUpdate)
                {
                    ApplicationArea = All;
                    Caption = 'Agreement Period Update';
                }
            }

            modify(DocumentType)
            {
                trigger OnAfterValidate()
                begin
                    IsEditablePriceAdjFactor();
                end;
            }

            modify(RecalculateLines)
            {
                trigger OnAfterValidate()
                begin
                    IsEditablePriceAdjFactor();
                end;
            }

            modify(IncludeHeader_Options)
            {
                trigger OnAfterValidate()
                begin
                    IsEditablePriceAdjFactor();
                end;
            }
        }

        trigger OnOpenPage()
        begin
            FTTCSTPriceAdjFactor := 1;
            Evaluate(FTTCSTAgrPeriodUpdate, '0D');
            IsEditablePriceAdjFactor();
        end;
    }

    trigger OnPostReport()
    begin
        if FTTCSTPriceAdjFactor = 0 then
            FTTCSTPriceAdjFactor := 1;

        ModifyAgrPeriodUpdate();
        ModifyPriceAdjFactor();
        ModifyCostType();
    end;

    local procedure IsEditablePriceAdjFactor()
    begin
        if CheckDocumentType() then
            EditPriceAdjFactor := true
        else begin
            EditPriceAdjFactor := false;
            FTTCSTPriceAdjFactor := 1;
        end;
    end;

    local procedure ModifyAgrPeriodUpdate()
    var
        SalesHeaderFrom: Record "Sales Header";
        SalesInvoiceHeader: Record "Sales Invoice Header";
        SalesInvoiceLine: Record "Sales Invoice Line";
        SalesLine: Record "Sales Line";
        SalesLineFrom: Record "Sales Line";
    begin
        if not CheckDocumentType() then
            exit;

        if SalesHeader."Document Type" in ["Sales Document Type"::Quote, "Sales Document Type"::Order, "Sales Document Type"::Invoice] then begin
            case FromDocType of
                "Sales Document Type From"::"Posted Invoice":
                    SalesInvoiceHeader.Get(FromDocNo);
                "Sales Document Type From"::Quote:
                    SalesHeaderFrom.Get("Sales Document Type"::Quote, FromDocNo);
                "Sales Document Type From"::Order:
                    SalesHeaderFrom.Get("Sales Document Type"::Order, FromDocNo);
                "Sales Document Type From"::Invoice:
                    SalesHeaderFrom.Get("Sales Document Type"::Invoice, FromDocNo);
            end;

            if FromDocType = "Sales Document Type From"::"Posted Invoice" then begin
                SalesInvoiceLine.SetRange("Document No.", SalesInvoiceHeader."No.");
                if SalesInvoiceLine.FindSet() then
                    repeat
                        SalesLine.Reset();
                        SalesLine.SetRange("FTT-CST Copied Document Type", "Sales Document Type From"::"Posted Invoice");
                        SalesLine.SetRange("FTT-CST Copied Document No.", SalesInvoiceLine."Document No.");
                        SalesLine.SetRange("FTT-CST Copied Line No.", SalesInvoiceLine."Line No.");
                        SalesLine.SetRange("Document No.", SalesHeader."No.");
                        if SalesLine.FindSet(true) then begin
                            if SalesInvoiceLine."FTT-CST Agreement Date From" <> 0D then
                                SalesLine."FTT-CST Agreement Date From" := CalcDate(FTTCSTAgrPeriodUpdate, SalesInvoiceLine."FTT-CST Agreement Date From")
                            else
                                SalesLine."FTT-CST Agreement Date From" := 0D;

                            if SalesInvoiceLine."FTT-CST Agreement Date To" <> 0D then
                                SalesLine."FTT-CST Agreement Date To" := CalcDate(FTTCSTAgrPeriodUpdate, SalesInvoiceLine."FTT-CST Agreement Date To")
                            else
                                SalesLine."FTT-CST Agreement Date To" := 0D;
                            SalesLine."FTT-CST Copied Document Type" := "Sales Document Type From"::Quote;
                            SalesLine."FTT-CST Copied Document No." := '';
                            SalesLine."FTT-CST Copied Line No." := 0;
                            SalesLine.Modify();

                            if IncludeHeader then begin
                                if SalesInvoiceHeader."FTT-CST Agr. Starting Date" <> 0D then
                                    SalesHeader."FTT-CST Agr. Starting Date" := CalcDate(FTTCSTAgrPeriodUpdate, SalesInvoiceHeader."FTT-CST Agr. Starting Date");
                                if SalesInvoiceHeader."FTT-CST Agr. Ending Date" <> 0D then
                                    SalesHeader."FTT-CST Agr. Ending Date" := CalcDate(FTTCSTAgrPeriodUpdate, SalesInvoiceHeader."FTT-CST Agr. Ending Date");
                                SalesHeader.Modify();
                            end;
                        end;
                    until SalesInvoiceLine.Next() = 0;
            end;

            if FromDocType in ["Sales Document Type From"::Quote, "Sales Document Type From"::Order, "Sales Document Type From"::Invoice] then begin
                SalesLineFrom.SetRange("Document Type", SalesHeaderFrom."Document Type");
                SalesLineFrom.SetRange("Document No.", SalesHeaderFrom."No.");
                if SalesLineFrom.FindSet() then
                    repeat
                        SalesLine.Reset();
                        if SalesLineFrom."Document Type" = "Sales Document Type"::Quote then
                            SalesLine.SetRange("FTT-CST Copied Document Type", "Sales Document Type From"::Quote);
                        if SalesLineFrom."Document Type" = "Sales Document Type"::Order then
                            SalesLine.SetRange("FTT-CST Copied Document Type", "Sales Document Type From"::Order);
                        if SalesLineFrom."Document Type" = "Sales Document Type"::Invoice then
                            SalesLine.SetRange("FTT-CST Copied Document Type", "Sales Document Type From"::Invoice);
                        SalesLine.SetRange("FTT-CST Copied Document No.", SalesLineFrom."Document No.");
                        SalesLine.SetRange("FTT-CST Copied Line No.", SalesLineFrom."Line No.");
                        SalesLine.SetRange("Document No.", SalesHeader."No.");
                        if SalesLine.FindSet(true) then begin
                            if SalesLineFrom."FTT-CST Agreement Date From" <> 0D then
                                SalesLine."FTT-CST Agreement Date From" := CalcDate(FTTCSTAgrPeriodUpdate, SalesLineFrom."FTT-CST Agreement Date From")
                            else
                                SalesLine."FTT-CST Agreement Date From" := 0D;

                            if SalesLineFrom."FTT-CST Agreement Date To" <> 0D then
                                SalesLine."FTT-CST Agreement Date To" := CalcDate(FTTCSTAgrPeriodUpdate, SalesLineFrom."FTT-CST Agreement Date To")
                            else
                                SalesLine."FTT-CST Agreement Date To" := 0D;
                            SalesLine."FTT-CST Copied Document Type" := "Sales Document Type From"::Quote;
                            SalesLine."FTT-CST Copied Document No." := '';
                            SalesLine."FTT-CST Copied Line No." := 0;
                            SalesLine.Modify();

                            if IncludeHeader then begin
                                if SalesHeaderFrom."FTT-CST Agr. Starting Date" <> 0D then
                                    SalesHeader."FTT-CST Agr. Starting Date" := CalcDate(FTTCSTAgrPeriodUpdate, SalesHeaderFrom."FTT-CST Agr. Starting Date");
                                if SalesHeaderFrom."FTT-CST Agr. Ending Date" <> 0D then
                                    SalesHeader."FTT-CST Agr. Ending Date" := CalcDate(FTTCSTAgrPeriodUpdate, SalesHeaderFrom."FTT-CST Agr. Ending Date");
                                SalesHeader.Modify();
                            end;
                        end;
                    until SalesLineFrom.Next() = 0;
            end;
        end;
    end;

    local procedure ModifyPriceAdjFactor()
    var
        SalesLine: Record "Sales Line";
    begin
        if not CheckDocumentType() then
            exit;

        SalesLine.SetRange("Document Type", SalesHeader."Document Type");
        SalesLine.SetRange("Document No.", SalesHeader."No.");
        if not SalesLine.FindSet() then
            exit;

        repeat
            SalesLine.Validate("Unit Price", Round(SalesLine."Unit Price" * FTTCSTPriceAdjFactor));
            SalesLine.Modify();
        until SalesLine.Next() = 0;
    end;

    local procedure ModifyCostType()
    var
        EventFunctions: Codeunit "FTT-CST Event Functions";
    begin
        if RecalculateLines then
            exit;

        EventFunctions.ModifyCostType(SalesHeader);
    end;

    local procedure CheckDocumentType(): Boolean
    begin
        if FromDocType in [
                       "Sales Document Type From"::Quote,
                       "Sales Document Type From"::Order,
                       "Sales Document Type From"::Invoice,
                       "Sales Document Type From"::"Posted Invoice"
        ] then
            exit(true);

        exit(false);
    end;

    var
        FTTCSTAgrPeriodUpdate: DateFormula;
        EditPriceAdjFactor: Boolean;
        FTTCSTPriceAdjFactor: Decimal;
}
