reportextension 50002 "SalesPersionComExt" extends 115
{

    dataset
    {
        modify("Salesperson/Purchaser")
        {
            trigger OnBeforeAfterGetRecord()
            var
                UserSetup: record "User Setup"; //NRD.-
                ERROR001_l: Label 'Not allowed to generate other salesperson commission. \ This field should be your salesperson code %1 not %2! ';
            begin
                //NRD+ User can be able to see the commission where they are the salesperson.
                if UserSetup.Get(UserId) then
                    if UserSetup."Salespers./Purch. Code" <> '' then
                        if UserSetup."Salespers./Purch. Code" <> Code then
                            Error(ERROR001_l, UserSetup."Salespers./Purch. Code", Code);
                //NRD-
            end;
        }
    }


}