enumextension 50002 "R. Selection Usage Ext. " extends "Report Selection Usage"
{
    value(113; "Signature") { Caption = 'Signature'; }
}