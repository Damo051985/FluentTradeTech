enumextension 50001 "R. Usage Ext. NRD" extends "Report Selection Usage Sales"
{
    value(113; "Signature") { Caption = 'Signature'; }
}