enumextension 60000 "FTT-CST ContactTypeExt" extends "Contact Type"
{
    value(60000; "Subsidiary Company")
    {
        Caption = 'Subsidiary Company';
    }
}
