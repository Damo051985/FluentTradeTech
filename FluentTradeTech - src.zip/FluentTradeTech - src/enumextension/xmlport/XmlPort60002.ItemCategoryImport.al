xmlport 60003 "FTT-CST Import ItemCategory"
{
    Format = VariableText;
    Direction = Import;
    TextEncoding = UTF8;
    UseRequestPage = false;
    TableSeparator = '';//New line

    schema
    {
        textelement(Root)
        {
            tableelement(ItemCategory; "Item Category")
            {
                XmlName = 'Item';
                fieldelement(Code; ItemCategory.Code)
                {
                }
                fieldelement(ParentCategory; ItemCategory."Parent Category")
                {
                }
                fieldelement(Description; ItemCategory.Description)
                {
                }
                fieldelement(Indentation; ItemCategory.Indentation)
                {
                }
                fieldelement(PresentationOrder; ItemCategory."Presentation Order")
                {
                }
                fieldelement(HasChildren; ItemCategory."Has Children")
                {
                }
                fieldelement(LastModifiedDate; ItemCategory."Last Modified Date Time")
                {
                }
                fieldelement(FTTCSTIntegratioBaseItem; ItemCategory."FTT-CST  Integration Base Item")
                {

                }
                fieldelement(FTTCSRDRBaseItem; ItemCategory."FTT-CST DR Base Item")
                {

                }
                fieldelement(FTTCSTRedundancyBaseItem; ItemCategory."FTT-CST Redundancy Base Item")
                {

                }
            }
        }
    }
}