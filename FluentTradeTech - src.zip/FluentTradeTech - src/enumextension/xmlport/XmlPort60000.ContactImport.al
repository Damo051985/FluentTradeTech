xmlport 60000 "FTT-CST Import Contact"
{
    Caption = 'Export Contact';
    Direction = Import;
    Format = VariableText;
    TableSeparator = '<NewLine>';
    TextEncoding = UTF8;
    UseRequestPage = false;

    schema
    {
        textelement(Root)
        {
            tableelement(Contact; "FTT-CST Contact")
            {
                RequestFilterFields = "No.";
                XmlName = 'Contact';
                fieldelement(No; Contact."No.")
                {
                }
                fieldelement(ExternalID; Contact."External ID")
                {
                }
                fieldelement(Name; Contact.Name)
                {
                }
                fieldelement(Name2; Contact."Name 2")
                {
                }
                fieldelement(Address; Contact.Address)
                {
                }
                fieldelement(Address2; Contact."Address 2")
                {
                }
                fieldelement(County; Contact.County)
                {
                }
                fieldelement(PostCode; Contact."Post Code")
                {
                }
                fieldelement(City; Contact.City)
                {
                }
                fieldelement(CountryRegionCode; Contact."Country/Region Code")
                {
                }
                fieldelement(PhoneNo; Contact."Phone No.")
                {
                }
                fieldelement(TelexNo; Contact."Telex No.")
                {
                }
                fieldelement(FaxNo; Contact."Fax No.")
                {
                }
                fieldelement(TelexAnswerBack; Contact."Telex Answer Back")
                {
                }
                fieldelement(TerritoryCide; Contact."Territory Code")
                {
                }
                fieldelement(CurrencyCode; Contact."Currency Code")
                {
                }
                fieldelement(LanguageCode; Contact."Language Code")
                {
                }
                fieldelement(SalespersonCode; Contact."Salesperson Code")
                {
                }
                fieldelement(VatRegistrationNo; Contact."VAT Registration No.")
                {
                }
                fieldelement("E-Mail"; Contact."E-Mail")
                {
                }
                fieldelement(HomePage; Contact."Home Page")
                {
                }
                fieldelement(Type; Contact.Type)
                {
                }
                fieldelement(CompanyName; Contact."Company Name")
                {
                }
                fieldelement(CompanyNo; Contact."Company No.")
                {
                }
                fieldelement(FirstName; Contact."First Name")
                {
                }
                fieldelement(MiddleName; Contact."Middle Name")
                {
                }
                fieldelement(SurName; Contact.Surname)
                {
                }
                fieldelement(Jobtitle; Contact."Job Title")
                {
                }
                fieldelement(Initials; Contact.Initials)
                {
                }
                fieldelement(ExtensionNo; Contact."Extension No.")
                {
                }
                fieldelement(MobilePhoneNo; Contact."Mobile Phone No.")
                {
                }
                fieldelement(Pager; Contact.Pager)
                {
                }
                fieldelement(OrganizationalLevelCode; Contact."Organizational Level Code")
                {
                }
                fieldelement(ExcludefromSegment; Contact."Exclude from Segment")
                {
                }
                fieldelement(CorrespondanceType; Contact."Correspondence Type")
                {
                }
                fieldelement(SalutationCode; Contact."Salutation Code")
                {
                }
            }
        }
    }

    requestpage
    {

        layout
        {
        }

        actions
        {
        }
    }
}

