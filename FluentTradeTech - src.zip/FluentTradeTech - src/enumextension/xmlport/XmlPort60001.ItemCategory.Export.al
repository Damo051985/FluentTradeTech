xmlport 60002 "FTT-CST Export ItemCategory"
{
    Format = VariableText;
    Direction = Export;
    TextEncoding = UTF8;
    UseRequestPage = false;
    TableSeparator = '';//New line

    schema
    {
        textelement(Root)
        {
            tableelement(Integer; Integer)
            {
                XmlName = 'ItemCategory';
                SourceTableView = SORTING(Number) WHERE(Number = CONST(1));
                textelement(ItemCategoryCode)
                {

                    trigger OnBeforePassVariable()
                    begin
                        ItemCategoryCode := ItemCategory.FieldCaption(Code);
                    end;
                }
                textelement(ItemCategoryParentCategory)
                {

                    trigger OnBeforePassVariable()
                    begin
                        ItemCategoryParentCategory := ItemCategory.FieldCaption("Parent Category");
                    end;
                }
                textelement(ItemCategoryDescription)
                {

                    trigger OnBeforePassVariable()
                    begin
                        ItemCategoryDescription := ItemCategory.FieldCaption(Description);
                    end;
                }
                textelement(ItemInventoryTitle)
                {

                    trigger OnBeforePassVariable()
                    begin
                        ItemInventoryTitle := ItemCategory.FieldCaption(Indentation);
                    end;
                }
                textelement(ItemBaseUnitofMeasureTitle)
                {

                    trigger OnBeforePassVariable()
                    begin
                        ItemBaseUnitofMeasureTitle := ItemCategory.FieldCaption("Presentation Order");
                    end;
                }
                textelement(ItemBaseCostisAdjustedTitle)
                {

                    trigger OnBeforePassVariable()
                    begin
                        ItemBaseCostisAdjustedTitle := ItemCategory.FieldCaption("Has Children");
                    end;
                }
                textelement(ItemCategoryLastModifiedDateTime)
                {

                    trigger OnBeforePassVariable()
                    begin
                        ItemCategoryLastModifiedDateTime := ItemCategory.FieldCaption("Last Modified Date Time");
                    end;
                }
                textelement(ItemCategoryFTTCSTIntegrationBaseItem)
                {

                    trigger OnBeforePassVariable()
                    begin
                        ItemCategoryFTTCSTIntegrationBaseItem := ItemCategory.FieldCaption("FTT-CST  Integration Base Item");
                    end;
                }
                textelement(ItemCategoryFTTCSTDRBaseItem)
                {

                    trigger OnBeforePassVariable()
                    begin
                        ItemCategoryFTTCSTDRBaseItem := ItemCategory.FieldCaption("FTT-CST DR Base Item");
                    end;
                }
                textelement(FTTCSTRedundancyBaseItem)
                {

                    trigger OnBeforePassVariable()
                    begin
                        FTTCSTRedundancyBaseItem := ItemCategory.FieldCaption("FTT-CST Redundancy Base Item");
                    end;
                }
            }
            tableelement(ItemCategory; "Item Category")
            {
                XmlName = 'ItemCategory';
                RequestFilterFields = Code;
                fieldelement(Code; ItemCategory.Code)
                {
                }
                fieldelement(ParentCategory; ItemCategory."Parent Category")
                {
                }
                fieldelement(Description; ItemCategory.Description)
                {
                }
                fieldelement(Indentation; ItemCategory.Indentation)
                {
                }
                fieldelement(PresentationOrder; ItemCategory."Presentation Order")
                {
                }
                fieldelement(HasChildren; ItemCategory."Has Children")
                {
                }
                fieldelement(LastModifiedDate; ItemCategory."Last Modified Date Time")
                {
                }
                fieldelement(FTTCSTIntegratioBaseItem; ItemCategory."FTT-CST  Integration Base Item")
                {

                }
                fieldelement(FTTCSRDRBaseItem; ItemCategory."FTT-CST DR Base Item")
                {

                }
                fieldelement(FTTCSTRedundancyBaseItem; ItemCategory."FTT-CST Redundancy Base Item")
                {

                }
            }
        }
    }
}
